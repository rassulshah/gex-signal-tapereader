// test_pane_host.cpp -- lsPullStats 1.1.0 (default) / lsStackStats 1.1.0 (-DSTACK) against the mock host (of140: bars in LOTS, the SPEC
// message grammar, pace, rebuilt; expectations updated for those deliberate changes):
// feed bucketing, decided candles, spikes / letters / dash / labels on the chart, info box + message line + hover, the session record
// (write / reload), params, settings, axis headroom, drain limits, pre-load candles show nothing.
#ifdef STACK
#include "StackStats.cpp"
typedef StackStats Ind;
#else
#include "PullStats.cpp"
typedef PullStats Ind;
#endif
#include <cstdio>
#ifdef STACK
#define PANE_VERSION_UNDER_TEST "1.1.1"
#else
#define PANE_VERSION_UNDER_TEST "1.2.0"
#endif
#include <unistd.h>
#include <filesystem>
#include <vector>
namespace mock { Host* current = nullptr; Feed feed; }
namespace off { long long off_test_now_ms = 1000000; void* off_test_cursor_wnd = nullptr; }
static int fails = 0, passes = 0;
#define CHECK(c, m) do { if (c) ++passes; else { ++fails; std::printf("FAIL %d %s\n", __LINE__, m); } } while (0)
static std::string readAll(const std::string& p) { std::ifstream f(p.c_str()); std::stringstream s; s << f.rdbuf(); return s.str(); }
static void dispose(Ind* p) { p->destroy(); p->~Ind(); ::operator delete(p); }
static Ind* make() { return static_cast<Ind*>(CreateExtension()); }
static const unsigned long T0 = 1791900000UL;
static mock::Bar bar(unsigned long t) { mock::Bar b; b.time = t; b.close = 7000.0f; b.low = 6999.5f; b.high = 7001.0f; b.volume = 100; b.rows.push_back(mock::Price(7000.0f, 50, 50, 100)); return b; }
static int nextId = 1;
static void ev(unsigned char a, unsigned char side, float px, unsigned long size, RTDATE t, int id) { mock::feed.push(a, side, px, size, t, id); }
static const mock::Draw* textAt(mock::Host& h, const std::string& t, COLOR c = 0xFFFFFFFF) { for (auto& d : h.draws) if (d.type == "text" && d.text == t && (c == 0xFFFFFFFF || d.color == c)) return &d; return nullptr; }
static void dump(mock::Host& h) { if (getenv("DBG")) for (auto& d : h.draws) if (d.type == "text") std::printf("  T %d,%d %06lx [%s]\n", d.x, d.y, (unsigned long)d.color, d.text.c_str()); }
static std::string msgLine(mock::Host& h) { dump(h); for (auto& d : h.draws) if (d.type == "text" && d.y < h.paneTop + 20 && (d.color == off::C_NEUTRAL || d.color == off::C_GREEN_SPIKE || d.color == off::C_RED_SPIKE)) return d.text; return "?"; }
// the message line may be cut with "..." at the last bar (this mock chart is narrow): it must be a prefix of "<time> <message>"
static bool msgIs(mock::Host& h, unsigned long t, const std::string& msg) {
    time_t v = (time_t)t; struct tm x; gmtime_r(&v, &x); const std::string full = off::clockShort(x.tm_hour, x.tm_min) + " " + msg; std::string got = msgLine(h);
    const std::vector<std::string> vs = off::compactVariants(full);      // (1.1.1) or one of fitMessage's shortened forms
    for (const std::string& t : vs) if (got == t) return true;
    if (got.size() < 10 || got.compare(got.size() - 3, 3, "...") != 0) return false;
    got.resize(got.size() - 3); return vs.back().compare(0, got.size(), got) == 0;
}
// the info box's row labels top-down (white labels at the box's left text column)
static std::string rowOrder(mock::Host& h) {
    std::string o; const char* known[] = { "Pulled", "Added", "Before price", "Traded first", "Pace", "Crowd", "Rebuilt", "Refills (I)" };
    for (auto& d : h.draws) if (d.type == "text") for (const char* k : known) if (d.text == k) { o += d.text + "|"; break; }
    return o;
}
static COLOR msgColour(mock::Host& h) { for (auto& d : h.draws) if (d.type == "text" && d.y < h.paneTop + 20 && (d.color == off::C_NEUTRAL || d.color == off::C_GREEN_SPIKE || d.color == off::C_RED_SPIKE)) return d.color; return 1; }
// the two values right of a label in a two-column box row
static std::pair<std::string, std::string> row(mock::Host& h, const std::string& label) {
    for (size_t i = 0; i + 2 < h.draws.size(); ++i) if (h.draws[i].type == "text" && h.draws[i].text == label && h.draws[i].color == 0x00FFFFFF) return std::make_pair(h.draws[i + 1].text, h.draws[i + 2].text);
    return std::make_pair(std::string("?"), std::string("?"));
}
// a normal candle k: n bids + n offers placed near price and (Pull) pulled / (Stack) left resting
static void normalCandle(int k, int n) {
    const RTDATE t = T0 + 60 * k - 30;
    for (int i = 0; i < n; ++i) {
        const int b = nextId++, a = nextId++;
        ev(0, 1, 6999.75f, 2, t, b); ev(0, 0, 7000.25f, 2, t, a);
#ifndef STACK
        ev(2, 1, 6999.75f, 2, t, b); ev(2, 0, 7000.25f, 2, t, a);
#endif
    }
}
#ifdef STACK
static std::string ps_or_st_name() { return "StackStats"; }
#else
static std::string ps_or_st_name() { return "PullStats"; }
#endif
static void step(mock::Host& h, Ind* p, int k) { h.bars.push_back(bar(T0 + 60UL * k)); off::off_test_now_ms += 100; p->calc(0); off::off_test_now_ms += 600; p->calc(0); }

// (1.0.1, Rassul 1:43 PM) NO WHITE OUTLINE: every rectangle except the info box (black fill, grey border) is drawn flat - width 0,
// border = fill, and the PEN in effect (IRT draws the perimeter with it) = fill. Returns the number of offending rectangles.
static int outlined(mock::Host& h, int* flat = nullptr) {
    int bad = 0, ok = 0;
    for (auto& d : h.draws) if (d.type == "box" && d.color != 0x00000000) { if (d.width != 0 || d.border != d.color || d.pen != d.color) ++bad; else ++ok; }
    if (flat) *flat = ok;
    return bad;
}
static int whitePenOnColour(mock::Host& h) { int n = 0; for (auto& d : h.draws) if (d.type == "box" && d.color != 0x00FFFFFF && d.color != 0x00000000 && (d.pen == 0x00FFFFFF || d.border == 0x00FFFFFF)) ++n; return n; }

int main() {
    char tmpl[] = "/tmp/panXXXXXX"; const char* tmp = mkdtemp(tmpl); setenv("USERPROFILE", tmp, 1);
    const std::string flex = std::string(tmp) + "\\InvestorRT\\rtx\\lsFlexLevels";
    const std::string NAME = ps_or_st_name();
    mock::Host h; mock::current = &h; h.tick = 0.25f; h.seconds = 60; h.symbol = "ESZ6"; h.root = "ES"; h.paneBottom = 300; h.paneRight = 2000; h.ppb = 10; h.barW = 20;   /* (1.1.1) 20 px bars: the wider info box (Crowd row) leaves room for the message */
    h.listIndex = 0; h.parms[0] = 20; h.parms[4] = 10; h.parms[5] = 0;
    for (int i = 0; i < 31; ++i) h.bars.push_back(bar(T0 + 60UL * i));    // 30 closed + forming bar 30
    Ind* p = make(); p->calc(0); auto* S = p->testState();
    CHECK((h.flags & TRACK_MOUSE) && !(h.flags & OVERLAY) && (h.xflags & CALL_CONTINUOUSLY), "flags: own pane, TRACK_MOUSE, CALL_CONTINUOUSLY");
    CHECK(mock::feed.opens == 1 && mock::feed.lastTicker == "ESZ6" && S->feed.via == "chart symbol ESZ6", "feed opened once, chart symbol");
    CHECK(S->ser.bars.empty() && S->firstBarKey < 0, "no events yet: nothing decided, no fake history");
    h.draws.clear(); p->draw();
    int bars0 = 0; for (auto& d : h.draws) if (d.type == "box" && d.color != 0 && d.color != 0x009CA3AF && d.y > 30) ++bars0;
    CHECK(bars0 == 0 && msgIs(h, T0 + 60 * 29, "No order data for this candle (before the indicator loaded)"), "candles before load: nothing drawn, the line says why");
    // 8 normal candles (4 orders per side each), the first is partial (the feed started inside it)
    for (int k = 30; k < 38; ++k) { normalCandle(k, 4); off::off_test_now_ms += 50; p->calc(0); step(h, p, k + 1); }
    CHECK(S->ser.bars.size() == 8 && S->ser.bars.begin()->second.r.partial && !S->ser.bars.rbegin()->second.r.partial, "8 decided candles, the first one partial");
#ifndef STACK
    CHECK(S->ser.bars[T0 + 60 * 33].r.pullN[0] == 4 && S->ser.bars[T0 + 60 * 33].r.pullN[1] == 4, "bucketing: 4 bids + 4 offers pulled in candle 33");
    // candle 38: 20 offers pulled incl. one 80-lot; a DEL after a FILL is not a pull
    { const RTDATE t = T0 + 60 * 38 - 30;
      for (int i = 0; i < 19; ++i) { const int a = nextId++; ev(0, 0, 7001.0f, 3, t, a); ev(2, 0, 7001.0f, 3, t, a); }   // 4 ticks away: not "just before"
      const int big = nextId++; ev(0, 0, 7001.25f, 80, t, big); ev(2, 0, 7001.25f, 80, t, big);
      const int f = nextId++; ev(0, 1, 6999.5f, 5, t, f); ev(3, 1, 6999.5f, 5, t, f); ev(2, 1, 6999.5f, 0, t, f);
      for (int i = 0; i < 4; ++i) { const int b = nextId++; ev(0, 1, 6999.75f, 2, t, b); ev(2, 1, 6999.75f, 2, t, b); } }
#else
    // candle 38: 20 bids added incl. one 60-lot; refills after fills at 6999.75 (an iceberg: 3 shown, 15 traded)
    { const RTDATE t = T0 + 60 * 38 - 30;
      for (int i = 0; i < 4; ++i) ev(0, 0, 7000.25f, 2, t, nextId++);
      for (int i = 0; i < 14; ++i) ev(0, 1, 6999.5f, 2, t, nextId++);
      ev(0, 1, 6999.25f, 60, t, nextId++);
      int id = nextId++; ev(0, 1, 6999.0f, 3, t, id);                     // a price nothing else rests at
      for (int r = 0; r < 5; ++r) { ev(3, 1, 6999.0f, 3, t, id); ev(2, 1, 6999.0f, 0, t, id); id = nextId++; ev(0, 1, 6999.0f, 3, t, id); }
      ev(3, 1, 6999.5f, 1, t, nextId++); }   // the last fill is at 6999.5: last trade there
#endif
    off::off_test_now_ms += 50; p->calc(0);
    h.bars.push_back(bar(T0 + 60UL * 39)); off::off_test_now_ms += 100; p->calc(0);
    CHECK(!S->ser.bars.count(T0 + 60 * 38), "a closed candle waits 0.5 s");
    off::off_test_now_ms += 600; p->calc(0);
    const off::PaneBar B = S->ser.bars[T0 + 60 * 38];
    if (getenv("DBG")) std::printf("B add %lld/%lld ref %lld/%lld ice %lld %lld/%lld let [%s][%s] dash %lld spike %d%d msg [%s] r0 %.2f r1 %.2f near %lld ref %lld\n", B.r.addN[0], B.r.addN[1], B.r.refN[0], B.r.refN[1], B.r.ice[0], B.r.iceShown[0], B.r.iceTraded[0], B.let[0].c_str(), B.let[1].c_str(), B.dash[0], B.spike[0], B.spike[1], B.msg.line1.c_str(), B.m[0].ratio[1], B.m[1].ratio[0], S->e.near, S->e.ref);
#ifndef STACK
    CHECK(B.r.pullN[1] == 20 && B.r.pullN[0] == 4 && B.r.pullMax[1] == 80 && B.spike[1] && !B.spike[0] && B.let[1] == "L" && B.let[0].empty(), "candle 38: 20 offers pulled (spike), L for the 80-lot; the filled bid is not a pull");
    CHECK(B.r.pullC[1] == 137 && B.msg.line1 == "Sellers pulled 20 offers totaling 137 lots (17.1x) fast (p 17.1x ?) - resistance leaving." && B.msg.impl == nl::BULL, "(1.1.0) message: offers pulled (lots) = bullish, resistance leaving, pace fast ?");
    const int qv = 137; const std::string qr = "17.1x";
#else
    CHECK(B.r.addN[0] == 21 && B.r.refN[0] == 5 && B.r.ice[0] == 1 && B.r.iceShown[0] == 3 && B.r.iceTraded[0] == 15 && B.spike[0] && B.let[0] == "IL" && B.dash[0] == 15, "candle 38: 21 bids added (spike), 5 refills (dash at 15 refilled lots), iceberg 3 shown / 15 traded -> I, 60-lot -> L");
    CHECK(B.r.addC[0] == 106 && B.r.hitC[0] == 16 && B.r.rebuildC[0] == 15 && B.msg.line1 == "Buyers added 21 bids totaling 106 lots (13.2x) fast (p 13.2x ?) - rebuilt 94% after hits ? - real support." && B.msg.impl == nl::BULL,
          "(1.1.0) message: 21 bids / 106 lots added, pace fast ?, rebuilt 94% (15 of 16 hit lots back) ? = real support");
    const int qv = 106; const std::string qr = "13.2x";
#endif
    h.draws.clear(); p->draw();
    const int xc = 50 + 38 * h.barW, side = NAME == "PullStats" ? 1 : 0;
    const COLOR spikeC = side == 0 ? off::C_GREEN_SPIKE : off::C_RED_SPIKE;
    int sp = 0, top = 0; for (auto& d : h.draws) if (d.type == "box" && d.color == spikeC && d.x >= xc - 9 && d.r <= xc + 9) { ++sp; top = d.y; }
    CHECK(sp == 1, "the spike bar in the bright colour");
    const mock::Draw* q = textAt(h, std::to_string(qv), spikeC); const mock::Draw* x = textAt(h, qr, spikeC);
    const mock::Draw* pl = textAt(h, "p " + qr, spikeC);
    CHECK(q && x && pl && x->y < pl->y && pl->y < q->y && q->y < top, "(1.1.0) spike label in 3 rows: ratio / pace / lots, above the bar, spike colour");
    CHECK(textAt(h, "L", 0) != nullptr, "letter L drawn (black on white)");
    { int flat = 0; const int bad = outlined(h, &flat); CHECK(bad == 0 && whitePenOnColour(h) == 0 && flat >= 10, "(1.0.1) no white outline: bars, letter boxes and the refill dash drawn flat (pen = border = fill)"); }
    { RTX_EVENT e; std::memset(&e, 0, sizeof(e)); e.type = E_MOUSE_MOVE; e.v.mouse.bar = 38; p->mouse(&e); h.draws.clear(); p->draw();
      int flat = 0; CHECK(outlined(h, &flat) == 0 && whitePenOnColour(h) == 0, "(1.0.1) hovered candle 38: no white outline on its bars or letter boxes");
      e.v.mouse.bar = -1; p->mouse(&e); h.draws.clear(); p->draw(); }
#ifdef STACK
    int dash = 0; for (auto& d : h.draws) if (d.type == "box" && d.color == 0x00FFFFFF && d.b - d.y == 2 && d.x >= xc - 9 && d.r <= xc) ++dash;
    CHECK(dash == 1 && textAt(h, "I", 0) != nullptr, "a white dash inside the bids bar + I (1.0.1)");
    { int rDrawn = 0; for (auto& d : h.draws) if (d.type == "text" && d.text == "R") ++rDrawn; CHECK(rDrawn == 0, "nothing draws the letter R (reserved for the future stop-run signal)"); }
    int dashes = 0; for (auto& d : h.draws) if (d.type == "box" && d.color == 0x00FFFFFF && d.b - d.y == 2) ++dashes;
    CHECK(dashes == 1, "dash only where refills are notable");
#endif
    // message line + info box for the last closed candle (Live)
    CHECK(msgIs(h, T0 + 60 * 38, B.msg.line1) && msgColour(h) == off::C_GREEN_SPIKE && textAt(h, "Live", 0x00FFFFFF), "message line + Live box");
#ifndef STACK
    CHECK(row(h, "Pulled") == std::make_pair(std::string("8 (1.0x)"), std::string("137 (17.1x)")) && row(h, "Pace").second == "17.1x (2.0x) ?" && row(h, "Crowd").second == "20 \xB7 avg 6.9 \xB7 top 58%"
          && row(h, "Traded first").second == "no" && row(h, "Before price").second == "no" && rowOrder(h) == "Pulled|Before price|Traded first|Pace|Crowd|", "(1.1.1) info box: Pulled, Before price, Traded first, Pace, Crowd");
    COLOR cb = 0, ca = 0; for (size_t i = 0; i + 2 < h.draws.size(); ++i) if (h.draws[i].text == "Pulled") { cb = h.draws[i + 1].color; ca = h.draws[i + 2].color; }
    CHECK(cb == 0x0022C55E && ca == 0x00EF4444, "bids values green, offers values red");
#else
    CHECK(row(h, "Added").first == "106 (13.2x)" && row(h, "Pace").first == "13.2x (2.0x) ?" && row(h, "Crowd").first == "21 \xB7 avg 5.0 \xB7 top 57%" && row(h, "Rebuilt").first == "94% ?"
          && row(h, "Refills (I)").first.find("5 (") == 0 && rowOrder(h) == "Added|Rebuilt|Pace|Crowd|Refills (I)|", "(1.1.1) info box: Added, Rebuilt, Pace, Crowd, Refills (I)");
#endif
    // hover: box + message for another candle, together
    RTX_EVENT e; std::memset(&e, 0, sizeof(e)); e.type = E_MOUSE_MOVE; e.v.mouse.bar = 34; const int inv = h.invalidates; p->mouse(&e);
    h.draws.clear(); p->draw();
    CHECK(h.invalidates == inv + 1 && msgIs(h, T0 + 60 * 34, "Normal activity - no spike") && msgColour(h) == off::C_NEUTRAL && textAt(h, "Live", 0x00FFFFFF) == nullptr, "hover candle 34: neutral message + its box header");
    e.v.mouse.bar = 20; p->mouse(&e); h.draws.clear(); p->draw();
    CHECK(msgIs(h, T0 + 60 * 20, "No order data for this candle (before the indicator loaded)") && row(h, NAME == "PullStats" ? "Pulled" : "Added").first == "n/a", "hover a pre-load candle: n/a");
    e.v.mouse.bar = -1; p->mouse(&e);
    {   // (1.1.1, Rassul 9:25 PM) the CHART-WIDE hover: another pane's plugin (the Tape Reader in the price pane, window 501) publishes the
        // candle under the mouse; this pane follows it without the mouse inside it; Live when the mouse leaves; other charts never interfere
        h.visFrom = 0; h.visTo = (int)h.bars.size() - 1;
        const unsigned long long t0 = h.bars.front().time, t1 = h.bars.back().time;
        hb::fakeCursor() = 501; hb::publish("ESZ6", 60, h.bars[34].time, t0, t1);
        const int inv0 = h.invalidates; off::off_test_now_ms += 10; p->calc(0);
        CHECK(S->hov.hover.bar == 34 && h.invalidates > inv0, "mouse over the price pane: this pane follows candle 34 (redrawn once)");
        const int inv1 = h.invalidates; off::off_test_now_ms += 10; p->calc(0);
        CHECK(h.invalidates == inv1, "no change: no redraw");
        h.draws.clear(); p->draw();
        CHECK(msgIs(h, T0 + 60 * 34, "Normal activity - no spike") && textAt(h, "Live", 0x00FFFFFF) == nullptr, "its message line and info box show candle 34");
        hb::fakeCursor() = 999; off::off_test_now_ms += 10; p->calc(0);
        CHECK(S->hov.hover.bar == -1, "mouse left the chart: back to Live");
        hb::fakeCursor() = 601; hb::publish("NQZ6", 60, h.bars[20].time, t0, t1); off::off_test_now_ms += 10; p->calc(0);
        CHECK(S->hov.hover.bar == -1, "a second chart (NQ) under the mouse: this chart stays Live");
        hb::publish("ESZ6", 60, h.bars[20].time, h.bars[5].time, t1); off::off_test_now_ms += 10; p->calc(0);
        CHECK(S->hov.hover.bar == -1, "a second ES chart (other visible range) under the mouse: this chart stays Live");
        hb::fakeCursor() = 0; unsetenv("LRA_HV_ESZ6_60"); unsetenv("LRA_HV_NQZ6_60"); h.visFrom = h.visTo = -1;
    }
    // the axis: headroom, bars at their values
    h.draws.clear(); p->draw(); double mn = 0, mx = 0; p->scale(0, (int)h.bars.size() - 1, &mn, &mx);
    CHECK(S->axisTop == qv && mx >= qv * 1.45 && mn < 0 && mn > -1, "axis in lots, headroom >= 1.45x the tallest bar");
    const double v = mn + (mx - mn) * (double)(h.paneBottom - top) / (double)(h.paneBottom - h.paneTop);
    CHECK(std::fabs(v - qv) <= (mx - mn) / (h.paneBottom - h.paneTop) * 1.5, "the spike bar's top sits at its value on the axis");
    // the session record + reload
    const std::string rec = flex + "\\" + NAME + "\\ES-ESZ6-60-20261013.csv";
    const std::string R = readAll(rec);
    CHECK(R.find("bar_time|ct_time|dbo|partial|events|") != std::string::npos && R.find("|" + B.msg.line1 + "|") != std::string::npos, "record written with the message");
    size_t lines = 0; for (char c : R) lines += c == '\n'; CHECK(lines == 2 + 9, "9 decided candles once each + 2 header lines");
    CHECK(!readAll(flex + "\\" + NAME + "\\ES-ESZ6-60-20261013-sizes.txt").empty(), "the session size distributions saved");
    dispose(p); h.data = nullptr; mock::feed.ev.clear(); mock::feed.at = 0;
    p = make(); off::off_test_now_ms += 100; p->calc(0); S = p->testState();
    CHECK(S->ser.bars.size() == 9 && S->ser.bars[T0 + 60 * 38].fromFile && S->ser.bars[T0 + 60 * 38].let[side] == B.let[side] && S->ser.bars[T0 + 60 * 38].msg.line1 == B.msg.line1 && S->ser.bars[T0 + 60 * 38].spike[side], "restart in the session: the record reloads (letters, spike, message)");
    CHECK(S->e.restDist.total > 0 && readAll(rec) == R, "size distributions reloaded; the record not rewritten");
    // late events for a decided candle are not used
    ev(0, 1, 6999.75f, 2, T0 + 60 * 38 - 30, nextId++); off::off_test_now_ms += 100; p->calc(0);
    CHECK(S->lateDropped >= 1 && S->ser.bars[T0 + 60 * 38].r.events == B.r.events, "late events for a decided candle: counted, never change it (no repaint)");
    // settings: Apply writes the per-market file; garbage never saved; a dialog change re-decides
    const std::string pp = flex + "\\" + NAME + ".place-ES.txt";
    h.parms[0] = 20; h.listIndex = 4; h.spikeAvg = 2.0f; h.spikeJump = 1.5f; h.parms[4] = 10; h.parms[5] = 0; p->parmsApply();
    const std::string want = NAME == "PullStats" ? "20,4,20,15,10,0,1\n" : "20,4,20,15,10,0\n";   // (PullStats 1.2.0) + Record order feed
    CHECK(readAll(pp) == want, "Apply writes ratioBars,pos,avg,jump,lookback,near (+ record for PullStats)");
    h.parms[0] = 500; p->parmsApply(); CHECK(readAll(pp) == want, "out of range never saved");
    p->parmsLoad(); CHECK(readAll(pp) == want, "loading never saves");
    h.parms[0] = 20; h.spikeAvg = 0.0f; p->parmsApply(); off::off_test_now_ms += 1100; p->calc(0);
    CHECK(S->set.pos == 4 && !S->ser.spike.on() && !S->ser.bars[T0 + 60 * 38].spike[side], "Spike vs average 0 = off: re-decided");
    h.spikeAvg = 2.0f; p->parmsApply(); off::off_test_now_ms += 1100; p->calc(0);
    CHECK(S->ser.bars[T0 + 60 * 38].spike[side], "back on");
    // params file: spikes from the nightly win where set; a wrong MARKET is reported
    { std::ofstream f((flex + "\\LRA-OrderFlow-ES.csv").c_str()); f << "VERSION,1\nMARKET,ES\nPARAM,spikeAvgX,9.0\n"; }
    off::off_test_now_ms += 6000; p->calc(0);
    CHECK(S->ser.spike.avgT == 90 && S->ser.bars[T0 + 60 * 38].spike[side], "params spikeAvgX 9.0 applies to NEW candles only (closed colours final)");
    { std::ofstream f((flex + "\\LRA-OrderFlow-ES.csv").c_str()); f << "VERSION,1\nMARKET,NQ\nPARAM,spikeAvgX,9.0\n"; }   // same size, same second
    off::off_test_now_ms += 61000; p->calc(0);                         // the once-a-minute re-read catches it
    const std::string st = readAll(flex + "\\" + NAME + "\\status-ES-ESZ6-60.txt");
    CHECK(st.find(std::string("VERSION,") + std::string(PANE_VERSION_UNDER_TEST)) != std::string::npos && st.find("PARAMS_SOURCE,defaults (MARKET mismatch)") != std::string::npos && st.find("PARAMS_NOTE,MARKET is NQ, chart is ES") != std::string::npos && S->ser.spike.avgT == 20, "status: the reason for defaults");
    // drain limits
    mock::feed.ev.clear(); mock::feed.at = 0;
    for (int i = 0; i < 11000; ++i) ev(0, 1, 6999.75f, 1, T0 + 60 * 40 - 10, 900000 + i);
    h.bars.push_back(bar(T0 + 60UL * 40)); off::off_test_now_ms += 10; p->calc(0);
    CHECK(mock::feed.at == 5000 && S->feed.lastCapped, "<= 5,000 events per call, backlog carried");
    h.bars.push_back(bar(T0 + 60UL * 41)); off::off_test_now_ms += 700; p->calc(0);
    CHECK(!S->ser.bars.count(T0 + 60 * 40) && mock::feed.at == 10000, "a closed candle waits for the backlog");
    off::off_test_now_ms += 700; p->calc(0); off::off_test_now_ms += 700; p->calc(0);
    CHECK(S->ser.bars.count(T0 + 60 * 40) && S->ser.bars[T0 + 60 * 40].r.events == 11000, "decided with every event once caught up");
    // ================= (of140) the blue options line: present + fresh only, from the bar it ARRIVED on, gates =================
    {
        const COLOR BLUE = 0x0058A6FF;
        auto blue = [&]() -> std::string { for (auto& d : h.draws) if (d.type == "text" && d.color == BLUE) return d.text; return std::string(); };
        const std::string op = flex + "\\LRA-Options-ES.csv";
        auto writeOpt = [&](long long asof) { std::ofstream f(op.c_str()); f << "VERSION,1\nMARKET,ES\nASOF," << asof << "\nOHIT,5800,P,2.4,2.0,dn,put sellers,1200\nOPULL,CR,5840,-30,dn,-\nOSTACK,PS,5790,40,+,3,2.4,building\n"; };
        { std::ofstream f((flex + "\\LRA-OrderFlow-ES.csv").c_str()); f << "VERSION,1\nMARKET,ES\n"; }
        h.now = h.bars.back().time;                                            // the chart's clock = the forming bar
        const long long arrivedOn = (long long)h.bars.back().time;
        h.draws.clear(); p->draw(); CHECK(blue().empty(), "no options file: no blue line");
        writeOpt((long long)std::time(NULL) - 60); off::off_test_now_ms += 6000; p->calc(0); off::off_test_now_ms += 61000; p->calc(0);
        CHECK(S->opt.why == "ok" && S->opt.hist.v.size() == 1 && S->opt.hist.v[0].barKey == arrivedOn, "the grid arrives on the forming bar");
        h.draws.clear(); p->draw();
        const std::string want = NAME == "PullStats" ? "oPull: CR 5840 wall -30% since open (-) \xB7 IV dn ?" : "oStack: PS 5790 wall 2.4x (+) building +40% \xB7 3 snaps ?";   // SPEC 5:49 PM
        const mock::Draw* bl = textAt(h, want, BLUE); const mock::Draw* ml = nullptr; for (auto& d : h.draws) if (d.type == "text" && d.y < h.paneTop + 20 && d.color != BLUE && d.color != 0x00FFFFFF && d.color != 0x0022C55E && d.color != 0x00EF4444) ml = &d;
        CHECK(bl != nullptr && ml != nullptr && bl->y > ml->y, "Live: the blue line (this pane's own stat, '?' until proven) under the message line");
        RTX_EVENT e2; std::memset(&e2, 0, sizeof(e2)); e2.type = E_MOUSE_MOVE; e2.v.mouse.bar = 38; p->mouse(&e2); h.draws.clear(); p->draw();
        CHECK(blue().empty(), "a candle before the grid arrived shows no options line (never back-dated)");
        e2.v.mouse.bar = -1; p->mouse(&e2);
        { std::ofstream f((flex + "\\LRA-OrderFlow-ES.csv").c_str()); f << "VERSION,1\nMARKET,ES\nOPULL_SHOW,on\nOSTACK_SHOW,on\n"; }
        off::off_test_now_ms += 61000; p->calc(0); h.draws.clear(); p->draw();
        CHECK(blue() == want.substr(0, want.size() - 2), "gate on (proven in this market): no '?'");
        { std::ofstream f((flex + "\\LRA-OrderFlow-ES.csv").c_str()); f << "VERSION,1\nMARKET,ES\nOPULL_SHOW,off\nOSTACK_SHOW,off\n"; }
        off::off_test_now_ms += 61000; p->calc(0); h.draws.clear(); p->draw();
        CHECK(blue().empty(), "gate off: hidden");
        { std::ofstream f((flex + "\\LRA-OrderFlow-ES.csv").c_str()); f << "VERSION,1\nMARKET,ES\n"; }
        writeOpt((long long)std::time(NULL) - 1300); off::off_test_now_ms += 61000; p->calc(0); h.draws.clear(); p->draw();
        CHECK(S->opt.hist.v.size() == 2 && blue().empty(), "a grid older than 20 min: hidden (stale)");
        writeOpt((long long)std::time(NULL) - 30); { std::ofstream f(op.c_str(), std::ios::app); f << "# x\n"; } off::off_test_now_ms += 61000; p->calc(0); h.draws.clear(); p->draw();
        CHECK(blue() == want, "a fresh grid again: shown");
        const std::string stt = readAll(flex + "\\" + NAME + "\\status-ES-ESZ6-60.txt");
        CHECK(stt.find("OPTIONS,ok,asof ") != std::string::npos, "status: the options file state");
        std::remove(op.c_str()); off::off_test_now_ms += 61000; p->calc(0); h.draws.clear(); p->draw();
        CHECK(S->opt.why == "no file" && blue() == want, "file removed: no new grid; the candle keeps the grid it had (fresh)");
    }
#ifndef STACK
    // ================= (of140) the RESET: a LATER message, posted only when known, never back-dated =================
    {
        const long long K = (long long)h.bars.back().time;                     // the forming candle: a big bid pull in it
        for (int i = 0; i < 30; ++i) { const int b = nextId++; ev(0, 1, 6999.75f, 4, (RTDATE)(K - 30), b); ev(2, 1, 6999.75f, 4, (RTDATE)(K - 30), b); }
        off::off_test_now_ms += 50; p->calc(0);
        h.bars.push_back(bar((unsigned long)(K + 60))); off::off_test_now_ms += 100; p->calc(0); off::off_test_now_ms += 600; p->calc(0);
        const off::PaneBar pk = S->ser.bars[K];
        CHECK(pk.msgSide == 0 && pk.kind == 1 && pk.msg.line1.find("Buyers pulled 30 bids totaling 120 lots") == 0 && S->rw.on && S->rw.target == 96, "the pull candle: support leaving; the reset watch opens (80% of 120 lots)");
        for (int i = 0; i < 25; ++i) ev(0, 1, 6999.75f, 4, (RTDATE)(K + 20), nextId++);   // 100 lots back 20 s after the pull candle closed
        off::off_test_now_ms += 50; p->calc(0);
        CHECK(S->ser.bars[K].msg.line1 == pk.msg.line1, "while the next candle forms, nothing changes (the pull candle is final)");
        h.bars.push_back(bar((unsigned long)(K + 120))); off::off_test_now_ms += 100; p->calc(0); off::off_test_now_ms += 600; p->calc(0);
        time_t v = (time_t)K; struct tm x; gmtime_r(&v, &x);
        const std::string want = "Bids back within 20 s of the " + off::clockShort(x.tm_hour, x.tm_min) + " pull - reset, not a retreat.";
        CHECK(S->ser.bars[K + 60].msg.line1 == want && S->ser.bars[K + 60].msg.impl == nl::NEUTRAL && S->rw.resets == 1, "the next candle (decided at its close) carries the reset, white");
        CHECK(S->ser.bars[K].msg.line1 == pk.msg.line1 && S->ser.bars[K].msg.impl == nl::BEAR, "the pull candle is never re-written (no back-dating)");
        h.draws.clear(); p->draw(); CHECK(msgIs(h, (unsigned long)(K + 60), want) && msgColour(h) == off::C_NEUTRAL, "drawn on the later candle, white");
        CHECK(readAll(flex + "\\PullStats\\ES-ESZ6-60-20261013.csv").find("|" + want + "|") != std::string::npos, "the reset is in the session record (a restart shows it)");
    }
#endif
#ifndef STACK
    {   // (1.2.0) Record order feed: ON (default) appends every drained event in mbo_live's format; OFF writes nothing
        const std::string rr = std::string(tmp) + "/irt"; mrec::rootOverride() = rr; mrec::testFreeBytes() = 50LL << 30;
        auto files = [&]() { std::vector<std::string> v; std::error_code ec; if (std::filesystem::exists(rr, ec)) for (auto& e : std::filesystem::recursive_directory_iterator(rr, ec)) if (e.is_regular_file()) v.push_back(e.path().string()); return v; };
        auto lines = [&](const std::string& f) { std::ifstream in(f.c_str()); std::string l; std::vector<std::string> v; while (std::getline(in, l)) v.push_back(l); return v; };
        h.box6 = 1; p->parmsApply(); off::off_test_now_ms += 1100; p->calc(0);
        CHECK(readAll(pp).find(",1\n") != std::string::npos, "Record order feed box: on by default, saved as the 7th field");
        const unsigned long te = (unsigned long)h.bars.back().time - 20;
        for (int k = 0; k < 5; ++k) ev((unsigned char)(k % 4), (unsigned char)(k % 2), 7000.25f + 0.25f * (float)k, (unsigned long)(k + 1), te, 900000 + k);
        off::off_test_now_ms += 50; p->calc(0);
        CHECK(files().empty() || lines(files()[0]).size() <= 1, "nothing written within the second the events arrived (buffered)");
        off::off_test_now_ms += 1100; p->calc(0);
        std::vector<std::string> fs = files();
        CHECK(fs.size() == 1 && fs[0].find("/ES/mbo_") != std::string::npos, "one hour file under <root>/<session>/ES/mbo_HH.csv");
        std::vector<std::string> L = fs.empty() ? std::vector<std::string>() : lines(fs[0]);
        CHECK(L.size() == 6 && L[0] == mrec::HEADER, "header + the 5 events");
        CHECK(L.size() == 6 && L[1].find("|NEW|7000.25|0|1|900000|0|S|0|0") != std::string::npos && L[4].find("|FILL|7001|") != std::string::npos, "rows in mbo_live's format (time|action|price|prev|size|id|aggr|side|bid|ask)");
        h.draws.clear(); p->draw();                                          // a draw never writes
        h.box6 = 0; p->parmsApply(); off::off_test_now_ms += 1100; p->calc(0);
        CHECK(readAll(pp).find(",0\n") != std::string::npos, "unticked: saved as 0");
        for (int k = 0; k < 5; ++k) ev(0, 1, 6999.0f, 1, te, 910000 + k);
        off::off_test_now_ms += 1100; p->calc(0); off::off_test_now_ms += 1100; p->calc(0);
        CHECK(!fs.empty() && lines(fs[0]).size() == 6 && files().size() == 1, "OFF: nothing more is written");
        off::off_test_now_ms += 16000; p->calc(0);
        CHECK(readAll(flex + "\\PullStats\\status-ES-ESZ6-60.txt").find("\nMBO_RECORD,off (setting),rows 5,") != std::string::npos, "status: MBO_RECORD off, 5 rows written before");
        h.box6 = 1; p->parmsApply(); off::off_test_now_ms += 1100; p->calc(0);
        mrec::rootOverride().clear();
    }
#endif
    // fail closed without a host slot; two charts independent
    mock::Host z; z.noSlot = true; mock::current = &z; z.bars.push_back(bar(T0)); z.bars.push_back(bar(T0 + 60)); Ind* zp = make(); zp->calc(0); zp->draw();
    CHECK(zp->testState() == nullptr, "no host slot: fail closed");
    dispose(zp); mock::current = &h;
    dispose(p);
    std::printf("host %s: %d passed, %d failed\n", NAME.c_str(), passes, fails); return fails ? 1 : 0;
}
