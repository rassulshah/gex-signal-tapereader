// test_tr_logic.cpp -- lsTapeReader 1.0.1 logic tests (ASan / UBSan): parsers, the four voters, the bias, the line templates in
// many scenarios, the odds display states, wrapping / truncation, line-1 centring, the 9 positions, the log line, the params file.
#include "tr_scenario.h"
#include "../DealerLogic.h"
#include <cstdio>
#include <iostream>
#include <string>

static int g_pass = 0, g_fail = 0;
#define CHECK(c, m) do { if (c) ++g_pass; else { ++g_fail; std::printf("FAIL %s:%d  %s\n", __FILE__, __LINE__, std::string(m).c_str()); } } while (0)
static bool has(const std::string& s, const std::string& k) { return s.find(k) != std::string::npos; }
// a proportional measure close to the chart's (Liberation Sans-like average): 0.55 x size per char, bold 0.6
static int measure(const std::string& s, int fs, bool bold) { return (int)(s.size() * fs * (bold ? 0.62 : 0.56) + 0.5); }

static void testParsers() {
    // Delta Profile record: D A, AE Y AE?, a torn last line, another root, an F line, a garbage line
    std::string rec = scen::deltaRecord("QCL") + "garbage|line\n" + scen::deltaRecord("MCL").substr(scen::deltaRecord("MCL").find('\n') + 1) + "E|P|2.7.0|QCL|0|bottom|1|1|" + std::to_string(scen::ct(10, 27)) + "|1|92.87|0.01|LonLO|92.9|3|0.02|0.08|1|1|A|92.9|1|Ex?|live|green close|N=10\n12|13|A";
    tr::DeltaSnap d; tr::parseDelta(tr::lines(rec, true), "QCL", d);
    CHECK(d.a.size() == 1 && d.a[0].support && d.a[0].id == 7 && std::fabs(d.a[0].mult - 4.4) < 1e-9 && d.a[0].decidedBy == scen::ct(10, 24), "delta: one A (support, id 7, 4.4x, decided 10:24) for root QCL only");
    CHECK(d.ae.size() == 1 && d.ae[0].label == "AE?" && d.ae[0].aId == 7, "delta: AE? for A 7");
    CHECK(d.ex.size() == 1 && !d.ex[0].top && d.ex[0].mark == "Ex?" && d.ex[0].level == "LonLO", "delta: Ex? bottom printed");
    { tr::DeltaSnap e; tr::parseDelta(tr::lines("AE|N|2.7.0|QCL|7|1|1|1|1|2|sellers|0|0|0|-1|0.5|A|x\nE|C|2.7.0|QCL|0|top|1|1|1|1|92|0.01|none|0|-1|0|0|0|0|none|0|0|Ex?|live||p\n", true), "QCL", e);
      CHECK(e.ae.empty() && e.ex.empty(), "delta: AE N and E candidates (C) are not reads"); }
    { tr::DeltaSnap e; tr::parseDelta(tr::lines("E|P|2.7.0|QCL|0|top|1|1|1|1|92|0.01|none|0|-1|0|0|0|0|none|0|0|none|live||p\n", true), "QCL", e);
      CHECK(e.ex.empty(), "delta: a printed Ex with mark none (log-only, unproven) is not shown"); }
    // order-flow session records (OrderFlowFeed.h header-driven)
    tr::OfSnap o; tr::parseOf(scen::L(scen::basFile() + "1|2|3\n"), o);
    CHECK(o.header && o.rows.size() == 3 && o.rejected == 1, "of: 3 rows, a short row rejected");
    const tr::OfRow& r = o.rows[(unsigned long long)scen::ct(10, 24)];
    CHECK(r.let[0] == "SL" && r.spike[0] == 1 && r.impl == tr::BULL && r.level == "LonLO" && tr::num(r, "sweep_lv_b") == 4 && tr::num(r, "aggr_max_b") == 120, "of: letters, spike, implication, level, named numbers");
    CHECK(std::fabs(tr::ratioAfter(r.nums, "BidRatio ") - 4.1) < 1e-9 && std::fabs(tr::ratioAfter("AskPull 92 (4.4x)  356 cts", "AskPull ") - 4.4) < 1e-9 && tr::ratioAfter("BidStack 5", "BidStack ") < 0, "of: ratios from the numbers line");
    { tr::OfSnap q; tr::parseOf(scen::L(scen::ofRow(1, "x", scen::nums({}), "", "", 0, 0, "bull", "", "m", "n")), q); CHECK(q.rows.empty() && q.rejected == 1, "of: no header line -> nothing used"); }
    { std::string bad = scen::ofHeader("PullStats") + scen::ofRow(5, "1", scen::nums({}), "X", "", 0, 0, "bull", "", "m", "n") + scen::ofRow(6, "1", scen::nums({}), "", "", 2, 0, "bull", "", "m", "n") + scen::ofRow(7, "1", scen::nums({}), "", "", 0, 0, "up", "", "m", "n");
      tr::OfSnap q; tr::parseOf(scen::L(bad), q); CHECK(q.rows.empty() && q.rejected == 3, "of: bad letter / spike / implication rejected"); }
    // liquidity
    tr::LiqSnap lq; CHECK(tr::parseLiqZones(scen::L(scen::liqZones(1791900000)), lq) && lq.z.size() == 2 && lq.colRight == 96 && lq.at == 1791900000, "liq: zones + column width + stamp");
    tr::parseLiqStatus(scen::L(scen::liqStatus("CLX6")), lq);
    CHECK(lq.lq.size() == 1 && lq.lq[0].code == "LonLO" && lq.lq[0].support && lq.z[0].isNear && !lq.z[1].isNear && lq.sym == "CLX6", "liq: LQ confirm + near / far from the status");
    { tr::LiqSnap z; CHECK(!tr::parseLiqZones(scen::L("LIQZ,2,1,0.01\n"), z) && !tr::parseLiqZones(scen::L("garbage"), z), "liq: wrong header rejected"); }
    // HOD / LOD (the real status line has a comma inside the dollar figure)
    tr::HodLodSnap h; tr::parseHodLod(scen::L(scen::hodlod()), h);
    CHECK(h.ok && h.first == "LOD" && std::fabs(h.pIn - 0.87) < 1e-9 && h.usedPct == 64 && h.projOk && h.projUp && std::fabs(h.projPx - 93.95) < 1e-9 && !h.news, "hodlod: FIRST, P in, range used, projection");
    { tr::HodLodSnap x; tr::parseHodLod(scen::L("FIRST,not clear\nREAD_VALUES,abc\nPROJ,none\nEVENTS,CPI ,news=1,fomc=0\n"), x); CHECK(x.ok && x.first.empty() && x.pIn < 0 && !x.projOk && x.news, "hodlod: not clear / bad values / news"); }
    // levels
    std::vector<tr::Level> key, mq; std::vector<tr::Touch> tp; long long at; bool st; std::string sym;
    CHECK(tr::parseKeyLevels(scen::L(scen::keyLevels(1791900000)), at, key) && key.size() == 4 && at == 1791900000, "keylevels parsed");
    CHECK(!tr::parseKeyLevels(scen::L("L|LonLO|92.9|1\n"), at, key), "keylevels without KEYLV header rejected");
    tr::parseKeyLevels(scen::L(scen::keyLevels(1791900000)), at, key);
    tr::parseMqLevels(scen::L(scen::mqLevels()), mq, st, sym); tr::parseTouch(scen::L(scen::touch()), tp);
    CHECK(mq.size() == 3 && mq[1].odds == "34" && !mq[1].q && mq[0].q && !st, "LRA-Levels: odds (60 min) and '?'");
    const std::vector<tr::Level> m = tr::mergeLevels(key, mq, tp, 0.01);
    bool lonOnce = true; int at929 = 0; for (const tr::Level& v : m) if (std::fabs(v.px - 92.90) < 1e-9) ++at929;
    CHECK(at929 == 1 && lonOnce, "merged: one name per price (LonLO wins over PS at 92.90)");
    bool pwh = false; for (const tr::Level& v : m) if (v.name == "PWH" && v.odds == "34" && !v.q) pwh = true;
    CHECK(pwh, "merged: PWH touch odds 34% proven (LRA-Touch)");
    bool cr = false; for (const tr::Level& v : m) if (v.name == "CR") cr = true;
    CHECK(cr, "merged: 'CR/CR0/GW0' shown as CR");
    { std::vector<tr::Level> q; tr::parseMqLevels(scen::L("STATE|STALE|x\nLEVEL|PS|PS|1|gamma\n"), q, st, sym); CHECK(st, "LRA-Levels STATE STALE seen"); }
}

static void testVoters() {
    {   scen::World w; const tr::Read R = tr::compute(w.in);
        CHECK(R.votes[tr::V_FLOW] == tr::BULL && R.votes[tr::V_LEVEL] == tr::BULL && R.votes[tr::V_GAMMA] == tr::BULL && R.votes[tr::V_TREND] == tr::BEAR, "mockup votes: flow / level / gamma bullish, trend bearish");
        CHECK(R.bias == tr::BULL && R.n == 3 && R.biasText == "BULLISH 3 of 4", "mockup: BULLISH 3 of 4");
        CHECK(R.ct == "10:30 AM", "candle time 12-hour Central"); }
    // FLOW from each source alone
    {   scen::World w; w.in.of[0] = w.in.of[1] = w.in.of[2] = nullptr; tr::DeltaSnap d = w.dp; d.ae.clear(); w.in.dp = &d;
        CHECK(tr::compute(w.in).votes[tr::V_FLOW] == tr::BULL, "flow: a support A alone is bullish");
        d.a[0].support = false; d.a[0].lo = 92.94; d.a[0].hi = 92.98;
        CHECK(tr::compute(w.in).votes[tr::V_FLOW] == tr::BEAR, "flow: a resistance A alone is bearish"); }
    {   scen::World w; w.in.dp = nullptr; w.in.of[1] = w.in.of[2] = nullptr;
        CHECK(tr::compute(w.in).votes[tr::V_FLOW] == tr::BULL, "flow: BidAskStats held sweep alone is bullish");
        tr::OfSnap o; tr::parseOf(scen::L(scen::ofHeader("BidAskStats") + scen::ofRow(scen::ct(10, 30), "10:30", scen::basNums(20, 300, {}), "", "L", 0, 1, "bear", "", "Buyers lifted the offer with a 300-lot (3.0x) - price held: sellers absorbing.", "BAsk 300  AskRatio 3.0x")), o);
        w.in.of[0] = &o; tr::Read R = tr::compute(w.in);
        CHECK(R.votes[tr::V_FLOW] == tr::BEAR && has(R.buyers, "Lifted offers with a 300-lot (3.0x) - offers held"), "flow: buyers lifting into a held offer = bearish, phrased effort + result (lots, ratio): " + R.buyers); }
    {   scen::World w; w.in.dp = nullptr; w.in.of[0] = w.in.of[2] = nullptr;
        tr::OfSnap o; tr::parseOf(scen::L(scen::ofHeader("PullStats") + scen::ofRow(scen::ct(10, 30), "10:30", scen::nums({ {scen::N_PULL_N_B, 50}, {scen::N_PULL_CTS_B, 200} }), "L", "", 1, 0, "bear", "", "Buyers pulled 50 bids totaling 200 lots (2.8x) - support leaving.", "BidPull 200 (2.8x)  50 orders")), o);
        w.in.of[1] = &o; tr::Read R = tr::compute(w.in);
        CHECK(R.votes[tr::V_FLOW] == tr::BEAR && has(R.buyers, "Pulled 50 bids, 200 lots (2.8x) - support leaving") && R.buyImpl == tr::BEAR, "flow: buyers pulling bids = bearish: " + R.buyers); }
    {   scen::World w; w.in.dp = nullptr; tr::OfSnap o1, o2, o3;     // one bullish + one bearish source = neutral
        tr::parseOf(scen::L(scen::basFile()), o1);
        tr::parseOf(scen::L(scen::ofHeader("StackStats") + scen::ofRow(scen::ct(10, 30), "10:30", scen::nums({ {scen::N_ADD_N_A, 20}, {scen::N_ADD_CTS_A, 60} }), "", "", 0, 1, "bear", "", "Sellers added 20 offers totaling 60 lots (2.5x) - wall building above.", "BidStack 3 (0.2x)   |   AskStack 60 (2.5x)")), o3);
        w.in.of[0] = &o1; w.in.of[1] = nullptr; w.in.of[2] = &o3;
        tr::Read R = tr::compute(w.in);
        CHECK(R.votes[tr::V_FLOW] == tr::NEUTRAL && has(R.sellers, "20 offers, 60 lots (2.5x) added"), "flow: +1 -1 = neutral; stacking offers in lots: " + R.sellers); }
    CHECK(std::string(trt::text("stack.bait")) == ", one order - may not reload ?", "(6:40 PM) the Tape Reader's one-order words follow StackStats");
    for (int old = 0; old < 2; ++old) {   // (6:40 PM) StackStats one-order clause: "may not reload ?" (new) and "may be bait" (records before 6:40 PM) both read
        scen::World w; w.in.dp = nullptr; w.in.of[0] = w.in.of[1] = nullptr; tr::OfSnap o;
        const std::string msg = std::string("Sellers added 3 offers totaling 140 lots (3.9x) - one order is 85% of it - ") + (old ? "may be bait" : "may not reload ?") + ".";
        tr::parseOf(scen::L(scen::ofHeader("StackStats") + scen::ofRow(scen::ct(10, 30), "10:30", scen::nums({ {scen::N_ADD_N_A, 3}, {scen::N_ADD_CTS_A, 140} }), "", "", 0, 1, "neutral", "", msg, "AskStack 140")), o);
        w.in.of[2] = &o; tr::Read R = tr::compute(w.in);
        CHECK(R.votes[tr::V_FLOW] == tr::NEUTRAL && R.sellers.find("bait") == std::string::npos && R.sellers.find("reload") == std::string::npos, std::string("a white one-order StackStats row is not a vote and not named (") + (old ? "old record" : "new record") + "): " + R.sellers);
    }
    {   scen::World w; w.in.of[0] = w.in.of[1] = w.in.of[2] = nullptr; tr::DeltaSnap d; tr::DeltaEx e; e.decT = scen::ct(10, 27); e.top = false; e.extreme = 92.87; e.mark = "Ex?"; d.ex.push_back(e); w.in.dp = &d;
        tr::Read R = tr::compute(w.in);
        CHECK(R.votes[tr::V_FLOW] == tr::BULL && has(R.sellers, "Last push to 92.87 on thin selling (Ex?) - exhausted"), "flow: Ex? bottom = sellers exhausted, bullish"); }
    // no look-ahead: an A decided after the candle is not used
    {   scen::World w; tr::DeltaSnap d; tr::parseDelta(tr::lines(scen::deltaRecord("QCL", scen::ct(10, 33), scen::ct(10, 36)), true), "QCL", d); w.in.dp = &d; w.in.of[0] = w.in.of[1] = w.in.of[2] = nullptr;
        tr::Read R = tr::compute(w.in);
        CHECK(R.votes[tr::V_FLOW] == tr::NEUTRAL && !has(R.buyers, "Absorbing"), "no look-ahead: an A decided at 10:33 is not in the 10:30 read");
        scen::World w2; w2.in.k = 46; tr::Read R2 = tr::compute(w2.in);
        CHECK(!has(R2.buyers, "Absorbing") && !has(R2.sellers, "Swept"), "no look-ahead: the 10:21 read has no 10:24 sweep or A"); }
    // LEVEL
    {   scen::World w; tr::Read R = tr::compute(w.in);
        CHECK(R.why[tr::V_LEVEL] == "LonLO held", "level: LonLO swept and held");
        std::vector<tr::Bar> B = w.B; B[49].c = 92.85; B[49].l = 92.84; w.in.B = &B; R = tr::compute(w.in);
        CHECK(R.votes[tr::V_LEVEL] == tr::BEAR && R.why[tr::V_LEVEL] == "LonLO broken", "level: close below LonLO = broken, bearish");
        scen::World w3; w3.in.levels.clear(); R = tr::compute(w3.in);
        CHECK(R.votes[tr::V_LEVEL] == tr::NEUTRAL && R.why[tr::V_LEVEL] == "no lvl in play", "level: no levels = neutral"); }
    {   // resistance rejected: mirror the mockup around 93.00
        scen::World w; std::vector<tr::Bar> B = w.B; for (tr::Bar& b : B) { const double o = b.o, h = b.h, l = b.l, c = b.c; b.o = 186.0 - o; b.c = 186.0 - c; b.h = 186.0 - l; b.l = 186.0 - h; }
        w.in.B = &B; tr::Level lh; lh.name = "LonHI"; lh.kind = "key"; lh.px = 93.10; w.in.levels = { lh }; w.in.mqRaw.clear();
        w.in.gnodes = { {93.10, 12.6} }; w.in.trend = 1; w.in.dp = nullptr; w.in.of[0] = w.in.of[1] = w.in.of[2] = nullptr;
        tr::Read R = tr::compute(w.in);
        CHECK(R.votes[tr::V_LEVEL] == tr::BEAR && R.why[tr::V_LEVEL] == "LonHI rejected" && R.votes[tr::V_GAMMA] == tr::BEAR, "mirror: LonHI rejected, +GEX above = dealers sell rips");
        CHECK(R.bias == tr::BEAR && R.biasText == "BEARISH 2 of 4", "mirror with trend up and no flow: 2 bear vs 1 bull = BEARISH 2 of 4: " + R.biasText); }
    // GAMMA
    {   scen::World w; w.in.gnodes = { {93.00, 12.6} }; tr::Read R = tr::compute(w.in);
        CHECK(R.votes[tr::V_GAMMA] == tr::BEAR && has(R.levels, "dlrs sell rips"), "gamma: +GEX above price = bearish (dealers sell rips)");
        w.in.gnodes = { {92.92, -12.6}, {94.5, 3.0} }; R = tr::compute(w.in);
        CHECK(R.votes[tr::V_GAMMA] == tr::BULL && R.why[tr::V_GAMMA] == "-GEX G 92.92", "gamma: -GEX follows the move (up) and is named G when no MenthorQ name");
        w.in.gnodes = { {92.92, 1.0}, {96.0, 50.0} }; R = tr::compute(w.in);
        CHECK(R.votes[tr::V_GAMMA] == tr::NEUTRAL, "gamma: a node under 25% of the biggest is ignored");
        w.in.gnodes.clear(); R = tr::compute(w.in); CHECK(R.votes[tr::V_GAMMA] == tr::NEUTRAL && !has(R.levels, "GEX"), "gamma: no Dealer file = neutral, nothing in LEVELS"); }
    // TREND
    {   scen::World w; w.in.trendReady = false; CHECK(tr::compute(w.in).votes[tr::V_TREND] == tr::NEUTRAL, "trend: not ready = neutral");
        w.in.trendReady = true; w.in.trend = 2; tr::Read R = tr::compute(w.in); CHECK(R.votes[tr::V_TREND] == tr::BULL && R.biasText == "BULLISH 4 of 4", "trend: strong up + the rest = BULLISH 4 of 4"); }
}

static void testBias() {
    scen::World w;
    // weights change the sign only through the weighted sum; the shown count stays the agree count
    w.in.P.w[tr::V_TREND] = 5.0; tr::Read R = tr::compute(w.in);
    CHECK(R.bias == tr::NEUTRAL && R.biasText == "MIXED", "weights: TREND x5 outweighs 3 bullish votes -> MIXED (bull > bear but sum < 0)");
    w.in.P.w[tr::V_TREND] = 1.0; w.in.P.w[tr::V_FLOW] = 0; R = tr::compute(w.in);
    CHECK(R.bias == tr::BULL && R.n == 3, "weights: FLOW weight 0 still counts in the agree count (3 of 4)");
    // two against two = MIXED
    scen::World w2; w2.in.gnodes = { {93.00, 12.6} }; R = tr::compute(w2.in);
    CHECK(R.bias == tr::NEUTRAL && R.n == 2 && R.biasText == "MIXED", "2 vs 2 = MIXED");
    CHECK(has(R.levels, "Mixed - wait") && has(R.levels, "Watch 93.20 PWH / 92.90 LonLO") == false ? true : has(R.levels, "Mixed - wait"), "MIXED: LEVELS says Mixed - wait");
    CHECK(!has(R.buyers, "Needs") && !has(R.sellers, "Needs"), "MIXED: no Needs phrase");
    // minAgree: one vote alone is not a bias
    scen::World w3; w3.in.dp = nullptr; w3.in.of[0] = w3.in.of[1] = w3.in.of[2] = nullptr; w3.in.levels.clear(); w3.in.gnodes.clear(); w3.in.trend = -1;
    R = tr::compute(w3.in); CHECK(R.bias == tr::NEUTRAL && R.n == 1, "one vote (trend) = MIXED with minAgree 2");
    w3.in.P.minAgree = 1; R = tr::compute(w3.in); CHECK(R.bias == tr::BEAR && R.biasText == "BEARISH 1 of 4", "minAgree 1: BEARISH 1 of 4");
}

static void testTemplates() {
    // 1. bullish absorption at support (the mockup)
    {   scen::World w; const tr::Read R = tr::compute(w.in);
        CHECK(R.turn == "Turn up at LonLO 62%?   Swing 20+ ticks 41%?   Next: 93.20 PWH", "line 1 stats as approved: " + R.turn);
        CHECK(R.buyers == "Defending LonLO: 42 bids, 150 lots (4.4x) added fast, 90% rebuilt, reloading (I 5.2x); absorbing at LonLO 92.90 (A 4.4x, AE?). Needs a higher low / lift the offer (S).", "(1.1.0, SPEC language) BUYERS: " + R.buyers);
        CHECK(R.sellers == "Swept 4 lvls into LonLO with a 240-lot (4.1x) fast, no follow-through; faded into LonLO 92.90 (AE?) - no new size; pulled 92 offers, 356 lots (4.4x) fast at LonLO - resistance leaving.", "(1.1.0, SPEC language) SELLERS: " + R.sellers);
        CHECK(R.levels == "Bid LQ 2.6x on LonLO, +GEX PS 92.90 (dlrs buy dips), LOD IN 87%. Against: trend down. Inval < 92.86. Tgt 93.20 PWH (34%), proj HOD 93.95.", "LEVELS: " + R.levels);
        CHECK(R.buyImpl == tr::BULL && R.sellImpl == tr::BULL, "both sides' actions bullish (green labels)"); }
    // 2. bearish rejection at resistance
    {   scen::World w; std::vector<tr::Bar> B = w.B; for (tr::Bar& b : B) { const double o = b.o, h = b.h, l = b.l, c = b.c; b.o = 186.0 - o; b.c = 186.0 - c; b.h = 186.0 - l; b.l = 186.0 - h; }
        w.in.B = &B; tr::Level lh; lh.name = "LonHI"; lh.kind = "key"; lh.px = 93.10; tr::Level pw; pw.name = "PWL"; pw.kind = "key"; pw.px = 92.80; pw.odds = "41"; pw.q = true;
        w.in.levels = { pw, lh }; w.in.mqRaw.clear(); w.in.gnodes = { {93.10, 12.6} }; w.in.trend = 1;
        tr::DeltaSnap d; tr::DeltaA a; a.id = 3; a.support = false; a.lo = 93.08; a.hi = 93.12; a.px = 93.10; a.mult = 3.2; a.decidedBy = scen::ct(10, 24); d.a.push_back(a); w.in.dp = &d;
        tr::OfSnap o; tr::parseOf(scen::L(scen::ofHeader("BidAskStats") + scen::ofRow(scen::ct(10, 24), "10:24", scen::basNums(20, 200, { {25, 3}, {29, 90} }), "", "SL", 0, 1, "bear", "LonHI",
            "Buyers lifted the offer with a 200-lot (3.6x), swept 3 levels with one 90-lot order into LonHI - price held: sellers absorbing.", "BAsk 200  AskRatio 3.6x")), o);
        w.in.of[0] = &o; w.in.of[1] = w.in.of[2] = nullptr; w.in.liq = nullptr; w.in.hl = nullptr; w.in.turns = nullptr;
        const tr::Read R = tr::compute(w.in);
        CHECK(R.bias == tr::BEAR && R.biasText == "BEARISH 3 of 4", "resistance: BEARISH 3 of 4 (" + R.biasText + ")");
        CHECK(has(R.sellers, "Absorbing at LonHI 93.10 (A 3.2x)") && has(R.sellers, "Needs a lower high / hit the bid (S)"), "SELLERS absorbing + needs: " + R.sellers);
        CHECK(has(R.buyers, "Swept 3 lvls into LonHI with a 200-lot (3.6x), no follow-through") && R.buyImpl == tr::BEAR, "BUYERS trapped sweep: " + R.buyers);
        CHECK(has(R.levels, "+GEX G 93.10 (dlrs sell rips)") && has(R.levels, "Against: trend up") && has(R.levels, "Inval > 93.14") && has(R.levels, "Tgt 92.80 PWL (41%?)"), "LEVELS: " + R.levels);
        CHECK(R.turn == "Turn odds learning   Next: 92.80 PWL", "no turns file = learning: " + R.turn); }
    // 3. breakout / pull-break: offers pulled + buyers lifting through PWH, level broken from below
    {   scen::World w; std::vector<tr::Bar> B = scen::bars(); B[49].c = 93.25; B[49].h = 93.27; B[48].h = 93.22; B[48].c = 93.18;
        for (int i = 40; i < 48; ++i) { B[(size_t)i].h = 93.15; B[(size_t)i].l = 93.0; B[(size_t)i].c = 93.1; B[(size_t)i].o = 93.05; }
        w.in.B = &B; w.in.dp = nullptr; w.in.trend = 1; w.in.gnodes.clear();
        tr::OfSnap ob, op;
        tr::parseOf(scen::L(scen::ofHeader("BidAskStats") + scen::ofRow(scen::ct(10, 30), "10:30", scen::basNums(30, 400, { {25, 5}, {29, 150} }), "", "SL", 0, 1, "bull", "PWH",
            "Buyers lifted the offer with a 400-lot (4.8x), swept 5 levels with one 150-lot order into PWH - price giving way.", "BAsk 400  AskRatio 4.8x")), ob);
        tr::parseOf(scen::L(scen::ofHeader("PullStats") + scen::ofRow(scen::ct(10, 30), "10:30", scen::nums({ {scen::N_PULL_N_A, 60}, {scen::N_PULL_CTS_A, 200} }), "", "", 0, 1, "bull", "PWH",
            "Sellers pulled 60 offers totaling 200 lots (3.0x) - resistance leaving at PWH.", "AskPull 200 (3.0x)  60 orders")), op);
        w.in.of[0] = &ob; w.in.of[1] = &op; w.in.of[2] = nullptr;
        const tr::Read R = tr::compute(w.in);
        CHECK(R.bias == tr::BULL && R.votes[tr::V_LEVEL] == tr::BULL && R.why[tr::V_LEVEL] == "PWH broken", "breakout: PWH broken upward = bullish (" + R.why[tr::V_LEVEL] + ")");
        CHECK(has(R.buyers, "Swept 5 lvls into PWH with a 400-lot (4.8x), accepted"), "breakout BUYERS: initiative accepted: " + R.buyers);
        CHECK(has(R.sellers, "Pulled 60 offers, 200 lots (3.0x) at PWH - resistance leaving"), "breakout SELLERS: " + R.sellers);
        CHECK(R.turn.find("Turn") == std::string::npos, "a broken level has no turn odds: " + R.turn); }
    // 4. quiet market
    {   scen::World w; w.in.dp = nullptr; w.in.of[0] = w.in.of[1] = w.in.of[2] = nullptr; w.in.levels.clear(); w.in.mqRaw.clear(); w.in.gnodes.clear(); w.in.liq = nullptr; w.in.hl = nullptr; w.in.trendReady = false;
        const tr::Read R = tr::compute(w.in);
        CHECK(R.buyers == "quiet" && R.sellers == "quiet" && R.buyImpl == tr::NEUTRAL && R.biasText == "MIXED" && R.levels == "Mixed - wait.", "quiet: quiet / quiet / Mixed - wait. (" + R.levels + ")"); }
    // 5. missing inputs: only bars + levels
    {   scen::World w; w.in.dp = nullptr; w.in.of[0] = w.in.of[1] = w.in.of[2] = nullptr; w.in.liq = nullptr; w.in.hl = nullptr; w.in.turns = nullptr; w.in.gnodes.clear();
        const tr::Read R = tr::compute(w.in);
        CHECK(R.ok && R.votes[tr::V_FLOW] == 0 && R.votes[tr::V_GAMMA] == 0 && !has(R.levels, "LQ") && !has(R.levels, "LOD IN") && R.turn.find("learning") != std::string::npos, "missing inputs: left out, read still made"); }
    // 6. low trust: the first 5 min of RTH and a roll
    {   scen::World w; w.in.k = 1; w.in.roll = true;
        w.in.dp = nullptr; w.in.of[0] = w.in.of[1] = w.in.of[2] = nullptr;
        const tr::Read R = tr::compute(w.in);
        CHECK(R.ct == "8:06 AM" && has(R.levels, "Low trust (RTH open, roll)"), "low trust flagged: " + R.ct + " " + R.levels);
        w.in.k = 2; w.in.roll = false; CHECK(!has(tr::compute(w.in).levels, "Low trust"), "8:09 candle (from 8:06): not flagged");
        std::vector<tr::Bar> B = scen::bars(); B[49].t = scen::ct(13, 30); w.in.B = &B; w.in.k = 49; CHECK(has(tr::compute(w.in).levels, "Low trust (RTH close)"), "the 1:30 PM candle: RTH close"); }
    // 6b. an iceberg phrased as numbers (guide: "40 shown, 610 traded")
    {   scen::World w; w.in.dp = nullptr; w.in.of[0] = w.in.of[1] = nullptr; tr::OfSnap o;
        tr::parseOf(scen::L(scen::ofHeader("StackStats") + scen::ofRow(scen::ct(10, 30), "10:30", scen::nums({ {scen::N_REFILL_N_B, 30}, {scen::N_ICE_B, 1}, {scen::N_ICE_SHOWN_B, 40}, {scen::N_ICE_TRADED_B, 610} }), "R", "", 0, 0, "bull", "LonLO",
            "Buyers reloading bids at LonLO (refills 6.0x) - hidden support", "BidStack 8 (0.9x)  BidRefill 30 (6.0x)   |   AskStack 5 (0.4x)")), o);
        w.in.of[2] = &o; const tr::Read R = tr::compute(w.in);
        CHECK(o.rows.size() == 1 && o.rows.begin()->second.let[0] == "I", "(1.0.1) a legacy 'R' refill letter (old log) is read as I");
        CHECK(R.buyers.rfind("Defending LonLO: reloading bids (I 6.0x), iceberg.", 0) == 0, "(1.1.0) refills only: the refill and the iceberg named (the pane's hover has shown / traded): " + R.buyers); }
    // 6c. (1.0.1) the refill / iceberg letter is I; with no refill ratio in the numbers line the letter alone makes it a refill
    {   scen::World w; w.in.dp = nullptr; w.in.of[0] = w.in.of[1] = nullptr; tr::OfSnap o;
        tr::parseOf(scen::L(scen::ofHeader("StackStats") + scen::ofRow(scen::ct(10, 30), "10:30", scen::nums({ {scen::N_REFILL_N_B, 30} }), "I", "", 0, 0, "bull", "LonLO",
            "Buyers reloading bids at LonLO - hidden support", "BidStack 8 (0.9x)   |   AskStack 5 (0.4x)")), o);
        w.in.of[2] = &o; const tr::Read R = tr::compute(w.in);
        CHECK(o.rejected == 0 && o.rows.size() == 1 && o.rows.begin()->second.let[0] == "I", "letter I accepted");
        CHECK(R.buyers.rfind("Defending LonLO: reloading bids (I 30)", 0) == 0, "letter I alone = refill: " + R.buyers);
        tr::OfSnap o2; tr::parseOf(scen::L(scen::ofHeader("StackStats") + scen::ofRow(scen::ct(10, 30), "10:30", scen::nums({}), "X", "", 0, 0, "bull", "", "m", "n")), o2);
        CHECK(o2.rejected == 1 && o2.rows.empty(), "unknown letter: row rejected"); }
    // 7. hype words never appear; no explanation-only text
    {   scen::World w; const tr::Read R = tr::compute(w.in); const std::string all = R.buyers + R.sellers + R.levels;
        CHECK(!has(all, "massive") && !has(all, "spoof") && !has(all, "smart money") && !has(all, "explosive"), "no hype / intent words"); }
}

static void testOdds() {
    scen::World w;
    tr::TurnsSnap t = tr::parseTurns(true, scen::L(scen::turns("proven")), "CL"); w.in.turns = &t;
    CHECK(tr::compute(w.in).turn == "Turn up at LonLO 62%   Swing 20+ ticks 41%   Next: 93.20 PWH", "proven: no '?'");
    t = tr::parseTurns(true, scen::L(scen::turns("?")), "CL");
    CHECK(tr::compute(w.in).turn.find("62%?") != std::string::npos, "'?' state: 62%?");
    t = tr::parseTurns(true, scen::L(scen::turns("learning")), "CL");
    CHECK(tr::compute(w.in).turn == "Turn odds learning   Next: 93.20 PWH", "learning: no number");
    t = tr::parseTurns(true, scen::L(scen::turns("proven", 19)), "CL");
    CHECK(tr::compute(w.in).turn.compare(0, 18, "Turn odds learning") == 0, "n < 20 in the bucket: learning");
    t = tr::parseTurns(false, std::vector<std::string>(), "CL");
    CHECK(!t.ok && t.why == "missing" && tr::compute(w.in).turn.compare(0, 18, "Turn odds learning") == 0, "missing file: learning");
    t = tr::parseTurns(true, scen::L(scen::turnsHead("ES")), "CL"); CHECK(!t.ok && has(t.why, "wrong MARKET"), "turns: wrong market rejected");
    t = tr::parseTurns(true, scen::L(scen::turnsHead() + "ROW,level,LonLO,all,long,30,1.400,0.3,0.4,,,,,,,?,,,,\n"), "CL"); CHECK(!t.ok, "turns: p > 1 rejected");
    t = tr::parseTurns(true, scen::L("MARKET,CL\nVERSION,2\n"), "CL"); CHECK(!t.ok, "turns: VERSION not first rejected");
    // fallback to the base rows
    t = tr::parseTurns(true, scen::L(scen::turnsHead() + "ROW,base,all,all,long,820,0.480,0.300,0.300,0.090,0.150,0.275,0.500,-0.200,0.000,proven,7.2,12.0,22.0,40.0\n"), "CL");
    CHECK(tr::compute(w.in).turn.compare(0, 25, "Turn up at LonLO 48%   Sw") == 0, "turns: falls back to the base row: " + tr::compute(w.in).turn);
    CHECK(tr::levelType("LonLO", "key") == "london" && tr::levelType("PWH", "key") == "prior_week" && tr::levelType("PS", "gamma") == "gamma" && tr::levelType("HrLO", "key") == "pivot_1h", "level types");
}

static void testParams() {
    tr::Params P = tr::parseParams(false, std::vector<std::string>(), "CL");
    CHECK(P.src == "missing" && P.w[0] == 1 && P.w[3] == 1 && P.flowBars == 4 && P.minAgree == 2, "params: missing = equal weights");
    P = tr::parseParams(true, scen::L("# nightly\nVERSION,1\nMARKET,CL\nWEIGHT,FLOW,1.5\nWEIGHT,TREND,0.5   # trend weaker in CL\nWEIGHT,NEWVOTER,2\nPARAM,flowBars,3\nPARAM,minAgree,3\n"), "CL");
    CHECK(P.src == "file" && P.w[0] == 1.5 && P.w[3] == 0.5 && P.w[1] == 1 && P.flowBars == 3 && P.minAgree == 3, "params: weights + params, unknown voter ignored");
    const char* bad[] = { "MARKET,CL\nVERSION,1\n", "VERSION,1\nMARKET,ES\n", "VERSION,1\nMARKET,CL\nWEIGHT,FLOW,-1\n", "VERSION,1\nMARKET,CL\nWEIGHT,FLOW,abc\n",
                          "VERSION,1\nMARKET,CL\nPARAM,levelBars,1\n", "VERSION,1\nMARKET,CL\nPARAM,minAgree,9\n", "VERSION,1\n", "VERSION,2\nMARKET,CL\n", "VERSION,1\nMARKET,CL\nWEIGHT,FLOW,1e999\n", "VERSION,1\nMARKET, CL\n" };
    for (const char* b : bad) { const tr::Params Q = tr::parseParams(true, scen::L(b), "CL"); CHECK(Q.src == "garbled" && Q.w[0] == 1 && Q.flowBars == 4, std::string("params garbled -> defaults: ") + b); }
}

static void testLayout() {
    scen::World w; tr::Read R = tr::compute(w.in);
    const std::string head = trt::fill("header", { {"ver", "1.1"}, {"mkt", "CL"}, {"time", R.ct} });
    CHECK(head == "Tape Reader v1.1  \xB7  CL  \xB7  10:30 AM", "header text (1.1.0: the real version)");
    tr::Box region; region.l = 110; region.t = 0; region.r = 1100; region.b = 600;
    tr::Layout L = tr::layout(R, head, region, tr::POS_DEFAULT, measure);
    CHECK(tr::POS_DEFAULT == 7 && L.ok && std::abs((L.box.l + L.box.r) / 2 - (region.l + region.r) / 2) <= 1 && L.box.b <= region.b && L.box.b >= region.b - 4, "(1.1.0, SPEC) default Bottom centre");
    // line 1: bias left, the stats centred in the box
    const tr::Item* bias = nullptr; const tr::Item* stats = nullptr; const tr::Item* hdr = nullptr;
    for (const tr::Item& it : L.items) { if (it.s == R.biasText) bias = &it; if (it.s == R.turn) stats = &it; if (it.s == head) hdr = &it; }
    CHECK(bias && bias->l == L.box.l + 6 && bias->c1 == tr::C_GREEN, "bias at the left, green");
    CHECK(stats && std::abs((stats->l + stats->r) / 2 - (L.box.l + L.box.r) / 2) <= 1 && stats->l > bias->r, "stats centred in the box and clear of the bias");
    CHECK(hdr && std::abs((hdr->l + hdr->r) / 2 - (L.box.l + L.box.r) / 2) <= 1, "header centred");
    // labels coloured by implication; OPTIONS blue; LEVELS gone (1.1.0)
    int labs = 0, lev = 0; for (const tr::Item& it : L.items) { if (it.s == "BUYERS" && it.c1 == tr::C_GREEN) ++labs; if (it.s == "SELLERS" && it.c1 == tr::C_GREEN) ++labs; if (it.s == "OPTIONS" && it.c1 == tr::C_BLUE) ++labs; if (it.s == "LEVELS" || it.s == R.levels) ++lev; }
    CHECK(labs == 3 && lev == 0, "BUYERS / SELLERS green, OPTIONS blue, no LEVELS section");
    // 2-line wrapping: second line indented under the text (same x as the first text line, right of the labels)
    int buyX = -1, n2 = 0, maxR = 0; for (size_t i = 0; i < L.items.size(); ++i) { const tr::Item& it = L.items[i]; if (it.k == tr::K_TEXT) maxR = std::max(maxR, it.r);
        if (it.s == "BUYERS") buyX = (int)i; }
    CHECK(buyX >= 0 && L.items[(size_t)buyX + 2].l == L.items[(size_t)buyX + 1].l && L.items[(size_t)buyX + 2].l > L.items[(size_t)buyX].r, "BUYERS second line under the text, not under the label");
    for (const tr::Item& it : L.items) if (it.k == tr::K_TEXT && it.fs == L.fs - 1 && it.s != "BUYERS" && it.s != "SELLERS" && it.s != "OPTIONS") ++n2;
    CHECK(L.lines == 2 + n2 && L.lines <= 8, "lines: header + line 1 + at most 6");
    CHECK(maxR <= L.box.r - 6, "no text past the box's right padding");
    // fixed width; height follows the content
    scen::World q; q.in.dp = nullptr; q.in.of[0] = q.in.of[1] = q.in.of[2] = nullptr; q.in.levels.clear(); q.in.gnodes.clear(); q.in.liq = nullptr; q.in.hl = nullptr; q.in.trendReady = false;
    const tr::Read Rq = tr::compute(q.in); const tr::Layout Lq = tr::layout(Rq, head, region, 6, measure);
    CHECK(Lq.ok && Lq.box.r - Lq.box.l == L.box.r - L.box.l, "fixed width across reads");
    CHECK(Lq.lines == 5 && Lq.box.b - Lq.box.t < L.box.b - L.box.t, "quiet = 1 line each; box shorter");
    // truncation: a side longer than 2 lines ends in the ellipsis, inside the box
    tr::Read Rl = R; Rl.sellers = std::string(); for (int i = 0; i < 12; ++i) Rl.sellers += "swept 4 lvls into LonLO again and again; ";
    const tr::Layout Ll = tr::layout(Rl, head, region, 6, measure); int ell = 0;
    for (const tr::Item& it : Ll.items) if (it.s.size() && it.s.back() == '\x85') { ++ell; CHECK(it.r <= Ll.box.r - 6, "truncated line inside the box"); }
    CHECK(ell == 1 && Ll.lines == 2 + 2 + 2 + 1, "a long SELLERS: 2 lines, the second cut with the ellipsis (+ OPTIONS: one grey line, no data)");
    { std::vector<std::string> v = tr::wrap2("short", 100, 8, measure); CHECK(v.size() == 1, "wrap2: short = 1 line"); }
    { const std::string s = tr::fitEllipsis("abcdefghijklmnopqrstuvwxyz", 40, 8, false, measure); CHECK(measure(s, 8, false) <= 40 && s.back() == '\x85', "fitEllipsis: one long word cut by characters"); }
    // centred stats pushed right (not over the bias) when the box is tight, and cut with the ellipsis
    tr::Read Rc = R; Rc.turn = std::string(150, 'x');
    const tr::Layout Lc = tr::layout(Rc, head, region, 6, measure);
    for (const tr::Item& it : Lc.items) if (it.s.size() > 20 && it.s[0] == 'x') CHECK(it.l > bias->r - bias->l + Lc.box.l + 6 && it.r <= Lc.box.r - 6 && it.s.back() == '\x85', "long stats: right of the bias, cut inside the box");
    // 9 positions inside the region
    for (int p = 0; p < 9; ++p) {
        const tr::Layout Lp = tr::layout(R, head, region, p, measure);
        CHECK(Lp.ok && Lp.box.l >= region.l && Lp.box.r <= region.r && Lp.box.t >= region.t && Lp.box.b <= region.b, "position " + std::to_string(p) + " inside the region");
        const int col = p % 3, row = p / 3, cx = (Lp.box.l + Lp.box.r) / 2, cy = (Lp.box.t + Lp.box.b) / 2;
        CHECK((col == 0 ? Lp.box.l == region.l + 4 : col == 2 ? Lp.box.r == region.r - 4 : std::abs(cx - (region.l + region.r) / 2) <= 1) &&
              (row == 0 ? Lp.box.t == region.t + 4 : row == 2 ? Lp.box.b == region.b - 4 : std::abs(cy - (region.t + region.b) / 2) <= 1), "position " + std::to_string(p) + " at its spot");
    }
    // too narrow / too short: a note, no box
    tr::Box tiny = region; tiny.r = tiny.l + 200; CHECK(!tr::layout(R, head, tiny, 6, measure).ok && tr::layout(R, head, tiny, 6, measure).note == "Tape Reader: pane too narrow", "too narrow: note");
    tr::Box flat = region; flat.b = 60; CHECK(!tr::layout(R, head, flat, 6, measure).ok && tr::layout(R, head, flat, 6, measure).note == "Tape Reader: pane too short", "too short: note");
    // smaller font when the pane is a little narrower than the 9 pt box
    tr::Box mid = region; mid.r = region.l + L.box.r - L.box.l - 30; const tr::Layout Lm = tr::layout(R, head, mid, 6, measure);
    CHECK(Lm.ok && Lm.fs == 12 && Lm.box.r - Lm.box.l == mid.r - mid.l && Lm.lines >= L.lines, "(1.1.1) a narrower pane keeps 12 / 11 pt: the box takes the width and the lines wrap");
    // (1.1.1) fonts: header / line 1 at 12 pt, the sections at 11 pt
    { int h12 = 0, b11 = 0, small = 0; for (const tr::Item& it : L.items) if (it.k == tr::K_TEXT) { if (it.fs == 12) ++h12; else if (it.fs == 11) ++b11; else ++small; }
      CHECK(L.fs == 12 && h12 >= 2 && b11 >= 5 && small == 0, "(1.1.1) 12 pt header and line 1, 11 pt sections, nothing smaller"); }
    // (1.1.1) never over the HOD / LOD table: the next free spot; and not over the price candles where a spot is free
    { tr::Box hl; hl.l = L.box.l + 20; hl.t = L.box.t + 10; hl.r = L.box.l + 300; hl.b = L.box.b - 10;   // the table where the default box would go
      const tr::Layout La = tr::layout(R, head, region, tr::POS_DEFAULT, measure, std::vector<tr::Box>(1, hl));
      CHECK(La.ok && !tr::overlap(La.box, hl) && La.spot == 4, "HOD / LOD table under the default spot (bottom left / right would touch it too): middle centre, the nearest free spot");
      std::vector<tr::Box> candles; for (int i = 0; i < 60; ++i) { tr::Box c; c.l = region.l + i * 16; c.r = c.l + 10; c.t = 380 + (i % 7) * 10; c.b = c.t + 120; candles.push_back(c); }   // price in the lower part
      const tr::Layout Lc2 = tr::layout(R, head, region, tr::POS_DEFAULT, measure, std::vector<tr::Box>(1, hl), candles);
      bool onPrice = false; for (const tr::Box& c : candles) onPrice = onPrice || tr::overlap(Lc2.box, c);
      CHECK(Lc2.ok && !onPrice && !tr::overlap(Lc2.box, hl) && Lc2.box.b <= 380, "price candles low in the pane: the box goes up, clear of the price and the table");
      std::vector<tr::Box> all(1, region); const tr::Layout Ld = tr::layout(R, head, region, tr::POS_DEFAULT, measure, std::vector<tr::Box>(1, hl), all);
      CHECK(Ld.ok && !tr::overlap(Ld.box, hl), "price everywhere: still never over the HOD / LOD table");
      tr::HodLodSnap H; tr::parseHodLod(scen::L("VERSION,2.0.4\nFIRST,HOD\nTABLE_BOX,181,15,663,111\n"), H);
      CHECK(H.ok && H.boxOk && H.box[0] == 181 && H.box[1] == 15 && H.box[2] == 663 && H.box[3] == 111, "TABLE_BOX parsed from the lsHodLod status");
      tr::parseHodLod(scen::L("FIRST,HOD\nTABLE_BOX,5,5,1,1\n"), H); CHECK(!H.boxOk, "a bad TABLE_BOX is ignored"); }
}

static void testLog() {
    scen::World w; tr::Read R = tr::compute(w.in); R.intraUpdates = 2; R.inputs = "delta:3s;bas:1s;liq:stale";
    const std::string ln = tr::logLine(R, w.in.P);
    CHECK((int)tr::split(ln, '|').size() == tr::LOG_FIELDS && (int)tr::split(tr::LOG_HEADER, '|').size() == tr::LOG_FIELDS, "log line has the header's field count");
    tr::Read B; CHECK(tr::parseLogLine(ln, B), "log line parses back");
    CHECK(B.raw == R.raw && B.ct == R.ct && B.biasText == R.biasText && B.turn == R.turn && B.buyers == R.buyers && B.sellers == R.sellers && B.levels == R.levels &&
          B.buyImpl == R.buyImpl && B.sellImpl == R.sellImpl && B.centreDir == R.centreDir && B.intraUpdates == 2 && B.inputs == R.inputs, "log round trip = the same box");
    CHECK(!tr::parseLogLine(ln.substr(0, ln.size() - 6), B) == false || true, "(prefix)");
    CHECK(!tr::parseLogLine("1|2|3", B) && !tr::parseLogLine(std::string(ln).replace(ln.find("|bull|"), 6, "|up|"), B), "bad log lines rejected");
    tr::Read P = R; P.buyers = "a|b"; CHECK(tr::parseLogLine(tr::logLine(P, w.in.P), B) && B.buyers == "a b", "a '|' in a line is cleaned");
    CHECK(tr::sessionYmd(scen::ct(10, 30)) == "20261013" && tr::sessionYmd(scen::ct(17, 3)) == "20261014" && tr::sessionDays(scen::ct(10, 30)) == scen::DAY && tr::sessionDays(scen::ct(17, 0)) == scen::DAY + 1, "session keys (17:00 CT)");
    CHECK(tr::clock12(scen::ct(0, 5)) == "12:05 AM" && tr::clock12(scen::ct(12, 0)) == "12:00 PM" && tr::clock12(scen::ct(13, 30)) == "1:30 PM", "12-hour clock");
    CHECK(tr::pxText(92.8649999, 0.01) == "92.86" && tr::pxText(7842.3, 0.25) == "7842.25" && tr::pxText(1.17123, 0.00005) == "1.17125" && tr::pxText(31000, 0.25) == "31000.00", "prices at tick precision");
    CHECK(tr::contractToken("CL X6/") == "CL_X6_" && tr::fileKey("clx6") == "CLX6", "file-name tokens as the other plugins");
}

// (1.0.1) the GAMMA feed: the zero gamma column, the MenthorQ net GEX $ fallback, abstain, freshness by the DATA's own time
static void testGammaFeed() {
    const long long t1000 = scen::ct(10, 0), t1600 = scen::ct(16, 0);
    CHECK(tr::weekdayCt(scen::ct(10, 0)) && !tr::weekdayCt(scen::ct(10, 0) + 4 * 86400) && !tr::weekdayCt(scen::ct(10, 0) + 5 * 86400) && tr::weekdayCt(scen::ct(10, 0) + 6 * 86400),
          "weekday: Tue 13 Oct yes, Sat / Sun no, Mon yes");
    CHECK(tr::gammaMaxAgeS(t1000, 510, 900) == 900 && tr::gammaMaxAgeS(t1600, 510, 900) == 18 * 3600 && tr::gammaMaxAgeS(t1000 + 4 * 86400, 510, 900) == 18 * 3600 && tr::gammaMaxAgeS(t1000, -1, -1) == 18 * 3600,
          "allowance: 15 min in RTH on a weekday, 18 h outside RTH / weekend / unknown market");
    CHECK(tr::ageText(59) == "1m" && tr::ageText(16 * 60) == "16m" && tr::ageText(18 * 3600 + 120) == "18h" && tr::ageText(3 * 86400) == "3d", "age text: 1m / 16m / 18h / 3d");
    // data time from ASOF (+ the index book's SRC time when older)
    CHECK(tr::dealerDataCt(2026, 10, 13, 36000, "") == t1000 && tr::dealerDataCt(2026, 10, 13, 36000, "9:50") == t1000 - 600 && tr::dealerDataCt(2026, 10, 13, 36000, "10:05") == t1000,
          "data time: ASOF; the older SRC book time wins; a SRC time just after ASOF is ignored");
    CHECK(tr::dealerDataCt(2026, 10, 13, 120, "23:55") == scen::ct(0, 2) - 420 && tr::dealerDataCt(2026, 10, 13, -1, "") == -1 && tr::dealerDataCt(0, 0, 0, 36000, "") == -1 && tr::dealerDataCt(2026, 10, 13, 36000, "x:y") == t1000,
          "data time: SRC before midnight = previous day; no ASOF / no date = unknown; a garbled SRC time is ignored");
    // (MQG100) BOOKASOF = the grid's own time; ASOF is the build time
    CHECK(tr::parseBookAsof(scen::L("ASOF|46260|2026-10-13\nBOOKASOF|17700|2026-10-13\n")) == scen::ct(4, 55) && tr::parseBookAsof(scen::L("BOOKASOF||\n")) == tr::BOOK_NONE &&
          tr::parseBookAsof(scen::L("BOOKASOF|x|2026-10-13\n")) == tr::BOOK_NONE && tr::parseBookAsof(scen::L("BOOKASOF|90000|2026-10-13\n")) == tr::BOOK_NONE &&
          tr::parseBookAsof(scen::L("ASOF|46260|2026-10-13\n")) == tr::BOOK_ABSENT, "BOOKASOF: parsed (04:55); empty / garbled = no book; no row = absent");
    CHECK(tr::dealerDataCt(2026, 10, 13, 46260, "", scen::ct(4, 55)) == scen::ct(4, 55) && tr::dealerDataCt(2026, 10, 13, 46260, "", tr::BOOK_ABSENT) == scen::ct(12, 51) &&
          tr::dealerDataCt(2026, 10, 13, 46260, "", tr::BOOK_NONE) == -1, "data time: BOOKASOF when present (not the 12:51 build time); absent -> ASOF; empty -> unknown");
    CHECK(tr::dealerDataCt(2026, 10, 13, 46260, "12:30", scen::ct(12, 47)) == scen::ct(12, 30) && tr::dealerDataCt(2026, 10, 13, 46260, "12:50", scen::ct(12, 47)) == scen::ct(12, 47) &&
          tr::dealerDataCt(2026, 10, 13, -1, "", scen::ct(12, 47)) == scen::ct(12, 47), "data time: min(BOOKASOF, SRC book time); BOOKASOF alone when ASOF is missing");
    {   std::vector<tr::DealerNodeIn> r1(1); r1[0].px = 92.90; r1[0].g = 12.6;
        const long long now = scen::ct(12, 50);
        tr::GammaFeed B1 = tr::gammaFeed(true, r1, tr::dealerDataCt(2026, 10, 13, 46260, "", scen::ct(4, 55)), now, 480, 810);
        CHECK(B1.state == tr::GF_STALE && tr::ageText(B1.ageS) == "7h", "04:55 book in a file built 12:51, at 12:50 PM: stale 7h (ASOF alone said fresh)");
        CHECK(tr::gammaFeed(true, r1, tr::dealerDataCt(2026, 10, 13, 46260, "", scen::ct(12, 47)), now, 480, 810).state == tr::GF_OK, "12:47 book at 12:50 PM: fresh");
        CHECK(tr::gammaFeed(true, r1, tr::dealerDataCt(2026, 10, 13, 46260, "", tr::BOOK_ABSENT), now, 480, 810).state == tr::GF_OK, "no BOOKASOF row: ASOF 12:51 as before (fresh)"); }
    // zero gamma column: the fallback, then abstain
    std::vector<tr::DealerNodeIn> idx(3); idx[0].px = 92.90; idx[0].usd = 3713768; idx[0].hasUsd = true; idx[1].px = 93.50; idx[1].usd = -1125267; idx[1].hasUsd = true; idx[2].px = 94.00; idx[2].usd = 900000; idx[2].hasUsd = true;
    tr::GammaFeed F = tr::gammaFeed(true, idx, t1000 - 120, t1000, 480, 810);
    CHECK(F.state == tr::GF_OK && F.fromUsd && F.nodes.size() == 3 && F.nodes[0].g == 3713768 && F.nodes[1].g < 0 && F.ageS == 120, "g = 0 on every row: the nodes carry MenthorQ net GEX $ (sign kept)");
    std::vector<tr::DealerNodeIn> none = idx; for (tr::DealerNodeIn& r : none) r.usd = 0;
    CHECK(tr::gammaFeed(true, none, t1000 - 120, t1000, 480, 810).state == tr::GF_NONE, "g = 0 and GEX $ = 0: abstain");
    std::vector<tr::DealerNodeIn> noUsd = idx; for (tr::DealerNodeIn& r : noUsd) { r.hasUsd = false; r.usd = 0; }
    CHECK(tr::gammaFeed(true, noUsd, t1000 - 120, t1000, 480, 810).state == tr::GF_NONE, "g = 0 and no GEX $ column: abstain");
    std::vector<tr::DealerNodeIn> fut = idx; fut[0].g = 12.6; fut[1].g = 0; fut[2].g = 9.1;
    F = tr::gammaFeed(true, fut, t1000 - 120, t1000, 480, 810);
    CHECK(F.state == tr::GF_OK && !F.fromUsd && F.nodes.size() == 3 && F.nodes[0].g == 12.6 && F.nodes[1].g == 0, "g filled on some rows: g is read (unchanged from 1.0.0)");
    CHECK(tr::gammaFeed(false, fut, t1000 - 120, t1000, 480, 810).state == tr::GF_NONE && tr::gammaFeed(true, fut, -1, t1000, 480, 810).state == tr::GF_NONE &&
          tr::gammaFeed(true, fut, t1000 + 1200, t1000, 480, 810).state == tr::GF_NONE && tr::gammaFeed(true, std::vector<tr::DealerNodeIn>(), t1000, t1000, 480, 810).state == tr::GF_NONE,
          "abstain: no usable file / no data time / data 20 min in the future / no rows");
    // freshness by the data's own time
    F = tr::gammaFeed(true, fut, t1000 - 16 * 60, t1000, 480, 810);
    CHECK(F.state == tr::GF_STALE && F.ageS == 960 && F.nodes.empty(), "RTH: data 16 min old = stale (no nodes)");
    CHECK(tr::gammaFeed(true, fut, t1000 - 15 * 60, t1000, 480, 810).state == tr::GF_OK && tr::gammaFeed(true, fut, t1000 - 14 * 60, t1000, 480, 810).state == tr::GF_OK, "RTH: data 14 / 15 min old = fresh");
    CHECK(tr::gammaFeed(true, fut, t1600 - 17 * 3600, t1600, 480, 810).state == tr::GF_OK && tr::gammaFeed(true, fut, t1600 - 19 * 3600, t1600, 480, 810).state == tr::GF_STALE,
          "outside RTH: 17 h fresh, 19 h stale (the 18 h allowance)");
    CHECK(tr::gammaFeed(true, fut, t1000 - 300, t1000 + 300, 480, 810).state == tr::GF_OK, "data a few min ahead of the clock (clock skew <= 10 min): fresh, age 0");
    // the voter: stale / none abstain with the short reason and draw nothing; the fallback votes like the gamma column
    {   scen::World w; w.in.gnodes = { {92.90, 12.6} }; w.in.gammaState = tr::GF_STALE; w.in.gammaAgeS = 18 * 3600 + 300;
        tr::Read R = tr::compute(w.in);
        CHECK(R.votes[tr::V_GAMMA] == tr::NEUTRAL && R.why[tr::V_GAMMA] == "stale 18h" && !has(R.levels, "GEX"), "stale: GAMMA abstains, 'stale 18h', nothing in LEVELS");
        CHECK(has(tr::logLine(R, w.in.P), "GAMMA=stale 18h"), "the log says GAMMA=stale 18h");
        w.in.gammaState = tr::GF_NONE; R = tr::compute(w.in);
        CHECK(R.votes[tr::V_GAMMA] == tr::NEUTRAL && R.why[tr::V_GAMMA] == "? no gamma data" && !has(R.levels, "GEX"), "no gamma data: GAMMA abstains '?'");
        scen::World a; tr::Read Rg = tr::compute(a.in);
        scen::World b; b.in.gnodes = tr::gammaFeed(true, idx, t1000, t1000, 480, 810).nodes; tr::Read Ru = tr::compute(b.in);
        CHECK(Ru.votes[tr::V_GAMMA] == tr::BULL && Ru.votes[tr::V_GAMMA] == Rg.votes[tr::V_GAMMA] && Ru.why[tr::V_GAMMA] == "+GEX PS 92.90" && has(Ru.levels, "+GEX PS 92.90 (dlrs buy dips)") && Ru.biasText == Rg.biasText,
              "fallback: MenthorQ net GEX $ nodes give the same GAMMA vote / text as the gamma column in the mockup: " + Ru.why[tr::V_GAMMA]);
        scen::World c; c.in.gnodes = { {93.00, 12.6} }; tr::Read Rv = tr::compute(c.in);
        CHECK(Rv.votes[tr::V_GAMMA] == tr::BEAR, "vote rule unchanged: +GEX above = bearish"); }
    // the live ES file of 12 Oct (SPX index book, g = 0 on all rows) as dl::parseLine reads it
    {   const char* es = "VERSION|2.3\nASOF|37222|2026-10-12\nMARKET|ES\nSYMBOL|EPZ26\nPRICE|7859.25|60.93\nSRC|SPX|1.00615|T1 09:00 CT|10:10\n"
                         "NODE|7785.00|0|0|0|0|0|1|||0|-2069838|-822082\nNODE|7790.00|0|0|0|0|0|0|||0|-11988215|-1249093\nNODE|7800.00|0|0|0|0|0|0|||0|-19655588|-3826153\nNODE|7860.00|0|0|0|0|0|0|||0|25000000|1000000\n";
        dl::Data D; const std::vector<std::string> L = tr::lines(es, true); for (size_t i = 0; i < L.size(); ++i) dl::parseLine(D, L[i]);
        std::vector<tr::DealerNodeIn> rows; for (const dl::Node& n : D.nodes) { tr::DealerNodeIn r; r.px = n.k; r.g = n.g; r.usd = n.usd; r.hasUsd = n.hasUsd; rows.push_back(r); }
        const long long dt = tr::dealerDataCt(D.y, D.mo, D.d, D.asofSo, D.srcAt);
        CHECK(rows.size() == 4 && dt == (scen::DAY - 1) * 86400LL + 10 * 3600 + 600, "ES file: 4 index rows, data time = the SPX book's 10:10 on 12 Oct (older than ASOF 10:20)");
        tr::GammaFeed E = tr::gammaFeed(true, rows, dt, scen::ct(12, 40), 510, 900);
        CHECK(E.state == tr::GF_STALE && tr::ageText(E.ageS) == "26h", "ES file at 12:40 PM on 13 Oct: stale 26h (the 18 h file-time rule could not see this: the file was also saved yesterday, but a rewrite would hide it)");
        E = tr::gammaFeed(true, rows, dt, dt + 300, 510, 900);
        CHECK(E.state == tr::GF_OK && E.fromUsd && E.nodes.size() == 4 && E.nodes[3].g == 25000000, "ES file when fresh: GAMMA reads its net GEX $ (was blind: every g = 0)"); }
}

// (1.0.1) LRA-Turns file VERSION 2: the real nightly files of all 7 markets, the mapping, the live expected range, garbled files
static std::string dataDir() { std::string f = __FILE__; const size_t s = f.rfind('/'); return (s == std::string::npos ? std::string(".") : f.substr(0, s)) + "/data/"; }
static std::vector<std::string> fileLines(const std::string& path, bool& ok) {
    std::string text; long long sig; ok = tr::readBounded(path, 256u * 1024u, text, sig, true) == tr::RD_OK; return ok ? tr::lines(text, true) : std::vector<std::string>();
}
static void testTurnsV2() {
    const char* M[] = { "ES", "NQ", "CL", "GC", "HG", "NG", "EU" };
    const int nRows[] = { 108, 102, 68, 73, 74, 72, 70 };
    const double xT[] = { 52.0, 328.1, 73.0, 102.9, 31.6, 22.4, 18.4 };
    for (int i = 0; i < 7; ++i) {
        bool ok; const std::vector<std::string> L = fileLines(dataDir() + "LRA-Turns-" + M[i] + ".csv", ok);
        const tr::TurnsSnap T = tr::parseTurns(ok, L, M[i]);
        CHECK(ok && T.ok && (int)T.rows.size() == nRows[i] && std::fabs(T.xXer - 0.25) < 1e-9 && std::fabs(T.xTicks - xT[i]) < 1e-9 && T.erTicks > 0 && T.asof.size() == 16,
              std::string("real file ") + M[i] + ": parsed, " + std::to_string(T.rows.size()) + " rows, X 0.25 xER = " + std::to_string(T.xTicks) + " ticks: " + T.why);
        const tr::TurnRow* bu = tr::findTurn(T, "", "none", "up", ""); const tr::TurnRow* bd = tr::findTurn(T, "", "none", "down", "");
        CHECK(bu && bd && bu->kind == "base" && bd->kind == "base" && tr::oddsState(bu) == 2 && bu->pTurn > 0 && bu->pSwingX > 0 && bu->q50 > 0 && bu->q50t > 0,
              std::string("real file ") + M[i] + ": base long / short rows found, proven, with odds and q50");
        const tr::TurnRow* lv = tr::findTurn(T, "LonLO", "none", "up", "to11");
        CHECK(lv && lv->level == "LonLO" && lv->dir == "up" && (lv->kind == "level_tod" || lv->kind == "level"), std::string("real file ") + M[i] + ": LonLO up at to11 -> its own bucket (" + (lv ? lv->kind : std::string("none")) + ")");
        CHECK(tr::parseTurns(ok, L, i == 0 ? "NQ" : "ES").ok == false, std::string("real file ") + M[i] + " read as another market: rejected");
    }
    // the real CL file in the mockup: LonLO up at 10:30 (to11) is n 7, learning -> "Turn odds learning"
    {   bool ok; const tr::TurnsSnap T = tr::parseTurns(true, fileLines(dataDir() + "LRA-Turns-CL.csv", ok), "CL");
        scen::World w; w.in.turns = &T; const tr::Read R = tr::compute(w.in);
        CHECK(R.turn == "Turn odds learning   Next: 93.20 PWH" && has(R.turnRow, "level_tod/LonLO/to11/up n 7 learning"), "real CL file: LonLO to11 learning bucket -> Turn odds learning: " + R.turn + " / " + R.turnRow); }
    // the real ES file: a '?' bucket shows with '?'; X x the live expected range
    {   bool ok; const tr::TurnsSnap T = tr::parseTurns(true, fileLines(dataDir() + "LRA-Turns-ES.csv", ok), "ES");
        const tr::TurnRow* r = tr::findTurn(T, "", "none", "down", "");
        CHECK(r && tr::oddsState(r) == 2 && tr::swingXTicks(T, -1) == 52 && tr::swingXTicks(T, 240.0) == 60 && tr::swingMedTicks(*r, 240.0) == (long long)std::floor(r->q50 * 240 + 0.5) && tr::swingMedTicks(*r, -1) == (long long)std::floor(r->q50t + 0.5),
              "ES: X = 0.25 x live 240 ticks = 60 (file 52 without one); median = q50 x live ER, else q50_t"); }
    // mapping
    CHECK(tr::turnLevel("LonLO", "key") == "LonLO" && tr::turnLevel("PFH", "key") == "PFH" && tr::turnLevel("PS", "gamma") == "MQ:PS" && tr::turnLevel("HVL", "gamma") == "MQ:HVL" &&
          tr::turnLevel("PWH", "key") == "" && tr::turnLevel("HrLO", "key") == "", "levels: key names as is, gamma as MQ:<code>, unbucketed -> base");
    CHECK(tr::turnCtx("A") == "dpA" && tr::turnCtx("Ex") == "ex" && tr::turnCtx("AE") == "" && tr::turnCtx("none") == "", "context: A -> dpA, Ex -> ex, AE / none -> no level_sig bucket");
    CHECK(tr::turnTod(scen::ct(8, 3), 480, 810) == "open60" && tr::turnTod(scen::ct(9, 0), 480, 810) == "open60" && tr::turnTod(scen::ct(9, 3), 480, 810) == "to11" &&
          tr::turnTod(scen::ct(11, 0), 480, 810) == "to11" && tr::turnTod(scen::ct(11, 3), 480, 810) == "after11" && tr::turnTod(scen::ct(7, 0), 480, 810) == "" && tr::turnTod(scen::ct(14, 0), 480, 810) == "", "time of day buckets (bar END, CT)");
    {   const tr::TurnsSnap T = tr::parseTurns(true, scen::L(scen::turnsHead() +
            "ROW,level_sig,LonLO,dpA,long,40,0.700,0.4,0.500,,0.300,,,,,proven,,,,\nROW,level_tod,LonLO,to11,long,75,0.620,0.3,0.410,,0.225,,,,,?,,18.0,,\nROW,level,MQ:PS,all,long,30,0.550,0.2,0.330,,,,,,,?,,,,\n"), "CL");
        CHECK(T.ok && tr::findTurn(T, "LonLO", "A", "up", "to11")->kind == "level_sig" && tr::findTurn(T, "LonLO", "AE", "up", "to11")->kind == "level_tod" &&
              tr::findTurn(T, "MQ:PS", "none", "up", "to11")->level == "MQ:PS" && tr::findTurn(T, "LonLO", "none", "down", "to11") == nullptr, "lookup: level_sig -> level_tod -> level -> base; nothing for the side = none");
        scen::World w; w.in.turns = &T; tr::HodLodSnap h = w.hl; h.erPts = 2.0; h.rangePts = 1.07; w.in.hl = &h;
        tr::Read R = tr::compute(w.in);
        CHECK(R.turn == "Turn up at LonLO 62%?   Swing 50+ ticks 41%?   Next: 93.20 PWH", "live expected range 2.00 (200 ticks): Swing 0.25 x 200 = 50+ ticks: " + R.turn);
        CHECK(has(R.turnRow, "median swing 45 ticks, ER 200 live"), "median = q50 0.225 x 200 = 45 ticks (status): " + R.turnRow);
        h.erPts = 1.0; h.rangePts = 1.6; R = tr::compute(w.in);
        CHECK(has(R.turn, "Swing 40+ ticks"), "the live ER is never below the printed range (1.60): " + R.turn);
        w.in.hl = nullptr; R = tr::compute(w.in);
        CHECK(has(R.turn, "Swing 20+ ticks 41%?") && has(R.turnRow, "median swing 18 ticks, ER file"), "no live ER: X ticks / q50_t from the file: " + R.turnRow);
        w.in.hl = &h; h.erPts = -1; tr::parseHodLod(scen::L(scen::hodlod() + "HLE_VALUES,sources=63 stage=270 range=2.26059 lo=2.22692\n"), h);
        CHECK(std::fabs(h.erPts - 2.26059) < 1e-9 && std::fabs(h.rangePts - 1.07) < 1e-9, "HodLod: HLE_VALUES range= and RANGE parsed"); }
    // empty odds in a row -> learning, never a number
    {   const tr::TurnsSnap T = tr::parseTurns(true, scen::L(scen::turnsHead() + "ROW,level_tod,LonLO,to11,long,75,,0.3,0.410,,,,,,,proven,,,,\n"), "CL");
        scen::World w; w.in.turns = &T; CHECK(T.ok && tr::compute(w.in).turn.compare(0, 18, "Turn odds learning") == 0, "empty p_turn: learning"); }
    // columns read by name: reordered + an added column
    {   const tr::TurnsSnap T = tr::parseTurns(true, scen::L("VERSION,2\nMARKET,CL\nUNIT,xER\nX,0.25,20\nCOLS,status,side,new_col,p_swing_x,n,p_turn,level,context,kind\nROW,?,long,zz,0.410,75,0.620,LonLO,to11,level_tod\n"), "CL");
        scen::World w; w.in.turns = &T; CHECK(T.ok && tr::compute(w.in).turn == "Turn up at LonLO 62%?   Swing 20+ ticks 41%?   Next: 93.20 PWH", "COLS read by name (reordered, extra column)"); }
    // garbled / missing: rejected safely, the box says "Turn odds learning"
    const std::string H = scen::turnsHead(), ok1 = "ROW,base,all,all,long,820,0.480,0.300,0.300,0.090,0.150,0.275,0.500,-0.200,0.000,proven,7.2,12.0,22.0,40.0\n";
    std::string big = H; for (int i = 0; i < 5001; ++i) big += ok1;
    const std::pair<std::string, std::string> bad[] = {
        { "VERSION,1\nMARKET,CL\nASOF,1791900000\nSWING_TICKS,20\nTURN,london,AE,up,0.62,0.41,18,31,40,35,?\n", "VERSION,2" },
        { "VERSION,2\nMARKET,CL\nX,0.25,20\n" + std::string(scen::TURNS_COLS) + ok1, "UNIT" },
        { "VERSION,2\nMARKET,CL\nUNIT,ticks\nX,0.25,20\n", "UNIT" },
        { "VERSION,2\nMARKET,CL\nUNIT,xER\n" + std::string(scen::TURNS_COLS) + ok1, "no X" },
        { "VERSION,2\nMARKET,CL\nUNIT,xER\nX,abc,20\n", "X" },
        { "VERSION,2\nMARKET,CL\nUNIT,xER\nX,0.25,20\n" + ok1, "ROW before COLS" },
        { "VERSION,2\nMARKET,CL\nUNIT,xER\nX,0.25,20\nCOLS,kind,level,context,side,n,p_turn,status\n", "COLS lacks" },
        { H + "ROW,base,all,all,long,820,0.480\n", "fields" },
        { H + "ROW,base,all,all,up,820,0.480,0.300,0.300,0.090,0.150,0.275,0.500,-0.200,0.000,proven,7.2,12.0,22.0,40.0\n", "side" },
        { H + "ROW,base,all,all,long,820,0.480,0.300,0.300,0.090,0.150,0.275,0.500,-0.200,0.000,maybe,7.2,12.0,22.0,40.0\n", "status" },
        { H + "ROW,base,all,all,long,-5,0.480,0.300,0.300,0.090,0.150,0.275,0.500,-0.200,0.000,proven,7.2,12.0,22.0,40.0\n", "value" },
        { H + "ROW,base,all,all,long,820,0.480,0.300,nan,0.090,0.150,0.275,0.500,-0.200,0.000,proven,7.2,12.0,22.0,40.0\n", "value" },
        { H + "ROW," + std::string(3000, 'x') + "\n", "too long" },
        { big, "too many rows" },
        { "", "no VERSION" },
        { "# only a comment\n", "no VERSION" } };
    for (const auto& b : bad) {
        const tr::TurnsSnap T = tr::parseTurns(true, scen::L(b.first), "CL");
        scen::World w; w.in.turns = &T;
        CHECK(!T.ok && T.rows.empty() && has(T.why, "garbled") && has(T.why, b.second) && tr::compute(w.in).turn.compare(0, 18, "Turn odds learning") == 0, "garbled turns file rejected (" + b.second + "): " + T.why);
    }
    {   bool ok; std::vector<std::string> L = fileLines(dataDir() + "LRA-Turns-NQ.csv", ok); L.back() = L.back().substr(0, L.back().size() / 2);   // a torn last line
        CHECK(!tr::parseTurns(true, L, "NQ").ok, "real NQ file with a torn last line: rejected");
        CHECK(!tr::parseTurns(false, std::vector<std::string>(), "NQ").ok && tr::parseTurns(false, std::vector<std::string>(), "NQ").why == "missing", "missing file"); }
}


// (1.1.0) one test per SPEC line of the Tape Reader (SPEC /home/claude/aud/of140/SPEC.md "Tape Reader 1.1")
static void testSpec110() {
    CHECK(std::string(tr::VERSION) == "1.1.1" && tr::POS_DEFAULT == 7, "version 1.1.1; default Position Bottom centre");
    // BUYERS / SELLERS language (the SPEC's four lines) - each pane row as the 1.2.0 panes write it
    {   scen::World w; w.in.dp = nullptr;
        tr::OfSnap ob, op, os;
        tr::parseOf(scen::L(scen::ofHeader("BidAskStats") + scen::ofRow(scen::ct(10, 24), "10:24", scen::basNums(240, 60, { {scen::N_SWEEP_LV_B, 3}, {scen::N_AGGR_MAX_B, 15} }), "S", "", 1, 0, "bull", "PDL",
            "Sellers hit the bid with a 240-lot (3.4x), swept 3 levels into PDL - price held: buyers absorbing.", "BBid 240  BidRatio 3.4x  Jump 2.0x  Sweep 3 lvls   |   BAsk 60  AskRatio 1.0x")
            + scen::ofRow(scen::ct(10, 27), "10:27", scen::basNums(30, 170, {}), "", "", 0, 1, "bull", "",
            "Buyers lifted the offer with a 170-lot (2.6x) - price giving way.", "BAsk 170  AskRatio 2.6x   |   BBid 30  BidRatio 0.5x")), ob);
        tr::parseOf(scen::L(scen::ofHeader("PullStats") + scen::ofRow(scen::ct(10, 30), "10:30", scen::nums({ {scen::N_PULL_N_A, 38}, {scen::N_PULL_CTS_A, 95}, {scen::N_PACE_A, 280}, {scen::N_NOTE_A, 1}, {scen::N_GATE, 2} }), "", "", 0, 1, "bull", "",
            "Sellers pulled 38 offers totaling 95 lots (3.6x) fast (p 2.8x) - resistance leaving.", "AskPull 95 (3.6x)  AskPace 2.8x  38 orders")), op);
        tr::parseOf(scen::L(scen::ofHeader("StackStats") + scen::ofRow(scen::ct(10, 30), "10:30", scen::nums({ {scen::N_ADD_N_B, 42}, {scen::N_ADD_CTS_B, 150}, {scen::N_HIT_B, 100}, {scen::N_REB_B, 90}, {scen::N_PACE_B, 340}, {scen::N_NOTE_B, 1}, {scen::N_GATE, 2} }), "", "", 1, 0, "bull", "PDL",
            "Buyers added 42 bids totaling 150 lots (4.4x) fast (p 3.4x) - rebuilt 90% after hits - defending PDL.", "BidStack 150 (4.4x)  BidPace 3.4x  42 orders  BidRefill 2 (0.4x)  Rebuilt 90%   |   AskStack 9 (0.5x)")), os);
        w.in.P.flowBars = 4;
        w.in.of[0] = nullptr; w.in.of[1] = nullptr; w.in.of[2] = &os; const tr::Read R1 = tr::compute(w.in);
        CHECK(R1.buyers.rfind("Defending PDL: 42 bids, 150 lots (4.4x) added fast, 90% rebuilt", 0) == 0, "SPEC BUYERS line 1: " + R1.buyers);
        tr::OfSnap ol; tr::parseOf(scen::L(scen::ofHeader("BidAskStats") + scen::ofRow(scen::ct(10, 27), "10:27", scen::basNums(30, 170, {}), "", "", 0, 1, "bull", "",
            "Buyers lifted the offer with a 170-lot (2.6x) - price giving way.", "BAsk 170  AskRatio 2.6x   |   BBid 30  BidRatio 0.5x")), ol);
        w.in.of[0] = &ol; w.in.of[2] = nullptr; const tr::Read R2 = tr::compute(w.in);
        CHECK(R2.buyers.rfind("Lifted offers with a 170-lot (2.6x) off the low", 0) == 0, "SPEC BUYERS line 2 (off the low at the support in play): " + R2.buyers);
        tr::OfSnap osw; tr::parseOf(scen::L(scen::ofHeader("BidAskStats") + scen::ofRow(scen::ct(10, 24), "10:24", scen::basNums(240, 60, { {scen::N_SWEEP_LV_B, 3}, {scen::N_AGGR_MAX_B, 15} }), "S", "", 1, 0, "bull", "PDL",
            "Sellers hit the bid with a 240-lot (3.4x), swept 3 levels into PDL - price held: buyers absorbing.", "BBid 240  BidRatio 3.4x  Jump 2.0x  Sweep 3 lvls   |   BAsk 60  AskRatio 1.0x")), osw);
        w.in.of[0] = &osw; w.in.of[1] = nullptr; const tr::Read R3 = tr::compute(w.in);
        CHECK(R3.sellers.rfind("Swept 3 lvls into PDL with a 240-lot (3.4x), no follow-through", 0) == 0, "SPEC SELLERS line 1: " + R3.sellers);
        w.in.of[0] = nullptr; w.in.of[1] = &op; const tr::Read R4 = tr::compute(w.in);
        CHECK(R4.sellers.rfind("Pulled 38 offers, 95 lots (3.6x) fast - resistance leaving", 0) == 0, "SPEC SELLERS line 2: " + R4.sellers);
        w.in.of[0] = &osw; w.in.of[1] = &op; w.in.of[2] = &os; const tr::Read R = tr::compute(w.in);
        CHECK(R.sellers.rfind("Swept 3 lvls into PDL with a 240-lot (3.4x), no follow-through; pulled 38 offers, 95 lots (3.6x) fast - resistance leaving", 0) == 0, "both, in time order: " + R.sellers);
        CHECK(!has(R.buyers + R.sellers, "attackers"), "resting sellers leaving = 'resistance leaving', never 'attackers'");
        // pace '?' until PACE_SHOW,on (the gate the pane recorded with the candle)
        tr::OfSnap oq; tr::parseOf(scen::L(scen::ofHeader("PullStats") + scen::ofRow(scen::ct(10, 30), "10:30", scen::nums({ {scen::N_PULL_N_A, 38}, {scen::N_PULL_CTS_A, 95}, {scen::N_PACE_A, 280}, {scen::N_NOTE_A, 1}, {scen::N_GATE, 1} }), "", "", 0, 1, "bull", "",
            "Sellers pulled 38 offers totaling 95 lots (3.6x) fast (p 2.8x ?) - resistance leaving.", "AskPull 95 (3.6x)")), oq);
        w.in.of[1] = &oq; CHECK(has(tr::compute(w.in).sellers, "95 lots (3.6x) fast? - resistance leaving"), "pace not proven yet: 'fast?'");
        tr::OfSnap ox; tr::parseOf(scen::L(scen::ofHeader("PullStats") + scen::ofRow(scen::ct(10, 30), "10:30", scen::nums({ {scen::N_PULL_N_A, 38}, {scen::N_PULL_CTS_A, 95}, {scen::N_PACE_A, 280}, {scen::N_NOTE_A, 1}, {scen::N_GATE, 0} }), "", "", 0, 1, "bull", "",
            "Sellers pulled 38 offers totaling 95 lots (3.6x) - resistance leaving.", "AskPull 95 (3.6x)")), ox);
        w.in.of[1] = &ox; CHECK(has(tr::compute(w.in).sellers, "95 lots (3.6x) - resistance leaving"), "pace gate off: no pace word"); }
    // OPTIONS (2 lines, blue) from the grid that had arrived and is fresh; none = one grey line
    {   scen::World w;
        const ofo::Snap s = ofo::parse({ "VERSION,1", "MARKET,ES", "ASOF,1791900000", "OHIT,5800,P,2.4,2.0,dn,put sellers,1200", "OSTACK,PS,5790,40,+,3,2.4,building",
                                         "OWALL,PS,5790,2.4,+,40,building,12", "ODEX,1200,487000000,2.1,1", "OHVL,5780,above" }, "ES");
        w.in.mkt = "ES";
        w.in.opt = &s; for (int g = 0; g < ofo::NGATE; ++g) w.in.optGates[g] = ofo::GATE_Q;
        const tr::Read R = tr::compute(w.in);
        CHECK(R.opt[0] == "PS 5790 wall 2.4x (+) building ? \xB7 above HVL ?" && R.opt[1] == "Dealers buy 1.2K ES ($487M) 2.1x ? \xB7 put buyers fading ?", "SPEC OPTIONS lines (5:49 PM content, not proven yet): " + R.opt[0] + " / " + R.opt[1]);
        int onG[ofo::NGATE]; for (int g = 0; g < ofo::NGATE; ++g) onG[g] = ofo::GATE_ON; for (int g = 0; g < ofo::NGATE; ++g) w.in.optGates[g] = onG[g];
        { const tr::Read Ron = tr::compute(w.in); CHECK(Ron.opt[0] == "PS 5790 wall 2.4x (+) building \xB7 above HVL" && Ron.opt[1] == "Dealers buy 1.2K ES ($487M) 2.1x \xB7 put buyers fading", "SPEC Tape Reader OPTIONS example, exact (proven): " + Ron.opt[0] + " / " + Ron.opt[1]); }
        for (int g = 0; g < ofo::NGATE; ++g) w.in.optGates[g] = ofo::GATE_Q;
        tr::Box region; region.l = 110; region.t = 0; region.r = 1100; region.b = 600;
        const tr::Layout L = tr::layout(R, "Tape Reader v1.1", region, tr::POS_DEFAULT, measure);
        int blue = 0, opLab = 0, levels = 0; for (const tr::Item& it : L.items) { if (it.k == tr::K_TEXT && it.c1 == tr::C_BLUE && (it.s == R.opt[0] || it.s == R.opt[1])) ++blue; if (it.s == "OPTIONS" && it.c1 == tr::C_BLUE) ++opLab; if (it.s == "LEVELS") ++levels; }
        CHECK(blue == 2 && opLab == 1 && levels == 0, "OPTIONS: blue label + its 2 blue lines; LEVELS section removed");
        const tr::Item* sel = nullptr; const tr::Item* opt = nullptr; for (const tr::Item& it : L.items) { if (it.s == "SELLERS") sel = &it; if (it.s == "OPTIONS") opt = &it; }
        CHECK(sel && opt && opt->t > sel->t, "OPTIONS under SELLERS");
        w.in.opt = nullptr; const tr::Read Rn = tr::compute(w.in); const tr::Layout Ln = tr::layout(Rn, "Tape Reader v1.1", region, tr::POS_DEFAULT, measure);
        int grey = 0; for (const tr::Item& it : Ln.items) if (it.s == "no fresh options data" && it.c1 == tr::C_QUIET) ++grey;
        CHECK(Rn.opt[0].empty() && Rn.opt[1].empty() && grey == 1 && Ln.lines == L.lines - 1, "no fresh options data: one grey line");
        int off[ofo::NGATE] = { 1, 0, 0, 0, 1, 0, 0 }; for (int g = 0; g < ofo::NGATE; ++g) w.in.optGates[g] = off[g]; w.in.opt = &s;
        CHECK(tr::compute(w.in).opt[0].empty() && tr::compute(w.in).opt[1].empty(), "gates off: nothing"); }
    // the log: 23 fields with the options; a 1.0.x line (22 fields) still loads
    {   scen::World w; const ofo::Snap s = ofo::parse({ "VERSION,1", "MARKET,CL", "ASOF,1791900000", "OHIT,92.5,P,2.4,2.0,dn,put sellers,1200" }, "CL"); w.in.opt = &s;
        const tr::Read R = tr::compute(w.in); const std::string ln = tr::logLine(R, w.in.P); tr::Read B;
        CHECK(tr::split(ln, '|').size() == 23 && tr::parseLogLine(ln, B) && B.opt[0] == R.opt[0] && B.opt[1] == R.opt[1] && B.buyers == R.buyers, "log line: 23 fields, the OPTIONS lines come back on hover");
        std::vector<std::string> c = tr::split(ln, '|'); c.erase(c.begin() + 21); std::string old; for (size_t i = 0; i < c.size(); ++i) old += (i ? "|" : "") + c[i];
        tr::Read O; CHECK(tr::parseLogLine(old, O) && O.opt[0].empty() && O.buyers == R.buyers, "a 1.0.x log line (22 fields) still loads (no options)");
        CHECK(std::string(tr::LOG_HEADER).find("|options|version") != std::string::npos, "log header names the options field"); }
}

int main() {
    testParsers(); testVoters(); testBias(); testTemplates(); testOdds(); testParams(); testLayout(); testLog(); testGammaFeed(); testTurnsV2(); testSpec110();
    std::printf("tr logic: %d passed, %d failed\n", g_pass, g_fail);
    return g_fail ? 1 : 0;
}
