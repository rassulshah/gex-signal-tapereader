#ifndef TR_TEST_SDK_H
#define TR_TEST_SDK_H
// TEST DOUBLE ONLY (lsTapeReader 1.0.0 host tests). Not a replacement for the supplied Linnsoft SDK: only what TapeReader.cpp
// calls, with the same names / argument shapes; drawing is recorded (mock::current->draws) for the tests and the render check.
#include <algorithm>
#include <climits>
#include <cstring>
#include <ctime>
#include <string>
#include <vector>
#include "tr_widths.h"
typedef unsigned long RTDATE;
typedef unsigned long COLOR;
typedef unsigned short RTBOOL;
typedef int RTX_RESULT;
enum { RTX_OK = 0, RTX_FAIL = -1 };
enum { POST_DRAWING = 1 << 18, OVERLAY = 2, NO_UI = 4, INSTRUMENT_SCALE = 1 << 30, TRACK_MOUSE = 1 << 27, FRONT_DRAWING = 1 << 29, SYM_TICKINCR = 171 };
typedef int DRAW_FLAGS; enum { CONNECT_CNONZERO = 1, NO_AUTOSCALE = 2 };
enum iARRAY { barDateTime, barVolume };
enum fARRAY { barOpen, barHigh, barLow, barClose };
enum { E_MOUSE_UP = 7, E_MOUSE_MOVE, E_MOUSE_DBL, E_MOUSE_SCROLL, E_MOUSE_HOVER = 115 };
typedef struct RTX_EVENT { int type; union { struct { short v, h, shift, control; long bar; float price; } mouse; } v; } RTX_EVENT;
namespace mock {
struct Bar { unsigned long time = 0, volume = 100; float open = 100, high = 101, low = 99, close = 100; };
struct Draw { std::string type, text; int l = 0, t = 0, r = 0, b = 0; COLOR color = 0, border = 0; int fs = 0; bool bold = false; };
struct Host {
    std::vector<Bar> bars; void* data = nullptr; bool noSlot = false; float tick = 0.01f; int seconds = 180;
    std::string symbol = "CLX6", root = "QCL";
    int listIndex = -1; int invalidates = 0; unsigned long flags = 0; std::vector<Draw> draws;
    int paneTop = 0, paneBottom = 600, paneLeft = 0, paneRight = 1400; int x0 = 120, ppb = 14; float priceBase = 92.0f, pxPerPoint = 300.0f;
    int fontSize = 12; bool fontBold = false; COLOR ink = 0;
    int visFrom = -1, visTo = -1;                 // (1.1.1) getVisibleBars: -1 = every bar
};
extern Host* current;
}
class cppExtension {
public:
    enum FONT_ID { COURIER = 1, HELVETICA = 4 };
    enum FONT_STYLE { PLAIN = 0, BOLD = 1 };
    enum { P_SOLID = 0, PAT_SOLID = 0, DRAW_OPAQUE = 0, DRAW_INVISIBLE = 0, OUTPUT_NO_UI = 2 };
    enum BAR_POSITION { kBarLeft, kBarCenter, kBarRight };
    struct FONT { FONT_ID id = HELVETICA; short size = 12; FONT_STYLE style = PLAIN; };
    struct CPEN { CPEN(COLOR, int, int) {} };
    struct PNT {
        short h = 0, v = 0;
        RTX_RESULT set(int bar, float price, BAR_POSITION pos = kBarLeft) {
            mock::Host* H = mock::current;
            h = (short)(H->x0 + bar * H->ppb + (pos == kBarRight ? H->ppb / 2 : pos == kBarLeft ? -H->ppb / 2 : 0));
            v = (short)(H->paneBottom - (price - H->priceBase) * H->pxPerPoint); return RTX_OK;
        }
    };
    struct RCT {
        short left = 0, top = 0, right = 0, bottom = 0;
        void set(short l, short t, short r, short b) { left = l; top = t; right = r; bottom = b; }
        void getPaneRect(RTBOOL = false) { set((short)mock::current->paneLeft, (short)mock::current->paneTop, (short)mock::current->paneRight, (short)mock::current->paneBottom); }
        void draw(short w, COLOR border, COLOR fill, int, int) { mock::Draw d; d.type = "box"; d.l = left; d.t = top; d.r = right; d.b = bottom; d.color = fill; d.border = border; d.fs = w; mock::current->draws.push_back(d); }
        void drawText(const char* t, RTBOOL, RTBOOL) { mock::Draw d; d.type = "text"; d.text = t; d.l = left; d.t = top; d.r = right; d.b = bottom; d.color = mock::current->ink; d.fs = mock::current->fontSize; d.bold = mock::current->fontBold; mock::current->draws.push_back(d); }
    };
    struct RTARRAYI {
        iARRAY type; long count;
        RTARRAYI(iARRAY t) : type(t), count((long)mock::current->bars.size()) {}
        unsigned long& operator[](int i) { return type == barDateTime ? mock::current->bars.at((size_t)i).time : mock::current->bars.at((size_t)i).volume; }
    };
    struct RTARRAY {
        fARRAY type; long count;
        RTARRAY(fARRAY t) : type(t), count((long)mock::current->bars.size()) {}
        float& operator[](int i) { mock::Bar& b = mock::current->bars.at((size_t)i); return type == barOpen ? b.open : type == barHigh ? b.high : type == barLow ? b.low : b.close; }
    };
    virtual ~cppExtension() {}
    virtual int init(); virtual int setup(); virtual int calc(int); virtual int done(); virtual int destroy();
    virtual int draw() { return RTX_FAIL; } virtual int mouse(RTX_EVENT*) { return RTX_FAIL; }
    virtual int parmsLoad() { return RTX_FAIL; } virtual int parmsApply() { return RTX_FAIL; } virtual int parmsUpdt(unsigned int) { return RTX_FAIL; }
    void* getUserData() { return mock::current->data; } void setUserData(void* p) { if (!mock::current->noSlot) mock::current->data = p; }
    long getBarCount() { return (long)mock::current->bars.size(); }
    int getVisibleBars(int* a, int* b) { const int n = (int)mock::current->bars.size(); if (n < 1) return RTX_FAIL; *a = mock::current->visFrom >= 0 ? mock::current->visFrom : 0; *b = mock::current->visTo >= 0 ? mock::current->visTo : n - 1; return RTX_OK; }
    char* getRootSymbol(char* b = nullptr, const char* = nullptr) { static char s[32]; char* o = b ? b : s; std::strcpy(o, mock::current->root.c_str()); return o; }
    char* getSymbol() { return const_cast<char*>(mock::current->symbol.c_str()); }
    float getProperty(int, const char* = nullptr) { return mock::current->tick; }
    int getSecondsPerBar() { return mock::current->seconds; }
    struct tm* getLocaltime(RTDATE stamp, struct tm* t) { time_t v = (time_t)stamp; return gmtime_r(&v, t); }   // the test clock IS Central
    void setParameterVersion(int) {} void setParameterDialogHeight(int) {}
    RTX_RESULT setListParameter(const char*, short, const char*, short = 0, short = 0) { return RTX_OK; }
    int getListIndex(int) { return mock::current->listIndex; }
    RTX_RESULT setOutputParameter(const char*, int, CPEN*, COLOR, unsigned long = 0) { return RTX_OK; }
    void setArrayDrawingFlags(int, DRAW_FLAGS) {}
    void setFont(FONT& f) { mock::current->fontSize = f.size; mock::current->fontBold = f.style == BOLD; }
    void setTextColor(COLOR c) { mock::current->ink = c; }
    int getTextWidth(const char* t, int = -1) {
        int pt = mock::current->fontSize; if (pt < 6) pt = 6; if (pt > 14) pt = 14; int w = 0;
        for (const unsigned char* p = (const unsigned char*)t; *p; ++p) w += *p >= 32 ? TR_W[mock::current->fontBold ? 1 : 0][pt - 6][*p - 32] : 0;
        return w;
    }
    RTX_RESULT invalidateChart(RTBOOL = false) { ++mock::current->invalidates; return RTX_OK; }
    void setArrayCount(int) {} void setFlags(unsigned long f) { mock::current->flags = f; } void setDescription(const char*) {} void setVersion(const char*) {}
};
#endif
