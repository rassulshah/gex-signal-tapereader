// test_tr_host.cpp -- lsTapeReader 1.1.0 host tests (of140: version / default Bottom centre / OPTIONS instead of LEVELS updated) on the mock SDK (ASan / UBSan): TapeReader.cpp itself with the other plugins'
// files on disk. Candle-close finalising + logging once, the grace wait, no intrabar churn, the intrabar A trigger, hover as-of from
// the log, restart, missing / stale / other-contract inputs, the region (never past the last bar, clear of the profiles), the 9
// positions, the place file, the atomic status write, the log retry, two charts, a symbol change.
#include "irtsdk.h"
#include "../TapeReader.cpp"
#include "tr_scenario.h"
#include <cstdio>
#include <cstdlib>
#include <string>
#include <sys/stat.h>
#include <utime.h>
#include <unistd.h>

namespace mock { Host* current = nullptr; }
long long tr_test_now_ms = 1000000, tr_test_unix = 0; void* tr_test_cursor_wnd = nullptr; int tr_test_fail_rename = 0;

static int g_pass = 0, g_fail = 0;
#define CHECK(c, m) do { if (c) ++g_pass; else { ++g_fail; std::printf("FAIL %s:%d  %s\n", __FILE__, __LINE__, std::string(m).c_str()); } } while (0)
static bool has(const std::string& s, const std::string& k) { return s.find(k) != std::string::npos; }
static std::string DIR;
static void put(const std::string& rel, const std::string& text, long long mtime = 0) {
    const std::string p = DIR + "/" + rel; const size_t sl = p.rfind('/'); mkdir(p.substr(0, sl).c_str(), 0755);
    { std::ofstream f(p.c_str(), std::ios::binary | std::ios::trunc); f << text; }
    if (mtime > 0) { struct utimbuf u; u.actime = (time_t)mtime; u.modtime = (time_t)mtime; utime(p.c_str(), &u); }
}
static std::string get(const std::string& rel) { std::ifstream f((DIR + "/" + rel).c_str(), std::ios::binary); std::string s((std::istreambuf_iterator<char>(f)), std::istreambuf_iterator<char>()); return s; }
static int countLines(const std::string& s, const std::string& prefix) { int n = 0; size_t a = 0; while (a < s.size()) { size_t e = s.find('\n', a); if (e == std::string::npos) e = s.size(); if (s.compare(a, prefix.size(), prefix) == 0) ++n; a = e + 1; } return n; }
static void writeWorld(const std::string& dealerSym = "CLX6") {
    const long long u = tr_test_unix;
    put("LRA-KeyLevels-CL.csv", scen::keyLevels(u)); put("LRA-Levels-CL.csv", scen::mqLevels()); put("LRA-Touch-CL.csv", scen::touch());
    put("LRA-Dealer-CL.csv", scen::dealer(dealerSym, u)); put("LRA-LiqZones-CL.csv", scen::liqZones(u)); put("LiquidityProfile.status-CL-180.txt", scen::liqStatus("CLX6"));
    put("HodLod.status-CL-180.txt", scen::hodlod()); put("LRA-Turns-CL.csv", scen::turns());
    put("DeltaProfile/CL-CLX6-180-signals-20739.csv", scen::deltaRecord("QCL"));
    put("BidAskStats/CL-CLX6-180-20261013.csv", scen::basFile()); put("PullStats/CL-CLX6-180-20261013.csv", scen::pullFile()); put("StackStats/CL-CLX6-180-20261013.csv", scen::stackFile());
    put("DealerProfile.status.txt", "VERSION,3\nREACH,150\n"); put("DeltaProfile.status.txt", "VERSION,2.7.0\nWIDTH,50\nPLACE,Right\n");
    // (1.1.0) the bridge's options file: the 10:28 grid, written at 10:29 (it arrived on the 10:30 candle); the gates file (none proven yet)
    put("LRA-Options-CL.csv", "VERSION,1\nMARKET,CL\nASOF," + std::to_string(scen::ct(10, 28)) + "\nOHIT,92.5,P,2.4,2.0,dn,put sellers,1200\nOSTACK,PS,92.9,40,+,3,2.4,building\nOWALL,PS,92.9,2.4,+,40,building,-\nODEX,1200,111000000,2.1,0\nOHVL,92.6,above\n", scen::ct(10, 29));
    put("LRA-OrderFlow-CL.csv", "VERSION,1\nMARKET,CL\n");
}
static void hostBars(mock::Host& H, int extra) {   // the mockup's 50 closed bars + `extra` more (the last one forming)
    H.bars.clear(); const std::vector<tr::Bar> B = scen::bars(extra);
    for (const tr::Bar& b : B) { mock::Bar m; m.time = (unsigned long)b.raw; m.open = (float)b.o; m.high = (float)b.h; m.low = (float)b.l; m.close = (float)b.c; m.volume = (unsigned long)b.v; H.bars.push_back(m); }
}
static std::vector<mock::Draw> texts(const mock::Host& H) { std::vector<mock::Draw> v; for (const mock::Draw& d : H.draws) if (d.type == "text") v.push_back(d); return v; }
static const mock::Draw* textWith(const mock::Host& H, const std::string& k) { for (const mock::Draw& d : H.draws) if (d.type == "text" && has(d.text, k)) return &d; return nullptr; }
static const mock::Draw* boxOf(const mock::Host& H) { for (const mock::Draw& d : H.draws) if (d.type == "box") return &d; return nullptr; }
static void step(long long ms) { tr_test_now_ms += ms; }

int main() {
    char tmpl[] = "/tmp/trhostXXXXXX"; DIR = mkdtemp(tmpl); setenv("USERPROFILE", DIR.c_str(), 1);
    tr_test_unix = (long long)std::time(nullptr);
    writeWorld();
    mock::Host H; mock::current = &H; hostBars(H, 1);              // 50 closed (to 10:30) + the forming 10:33 bar
    TapeReader* x = static_cast<TapeReader*>(CreateExtension());
    CHECK((H.flags & TRACK_MOUSE) && (H.flags & OVERLAY) && (H.flags & POST_DRAWING), "flags: overlay, post drawing, track mouse");
    x->setup();
    // ---- load: the first read (10:30) is shown at once, not logged (its inputs are "now", not the candle's)
    x->calc(0);
    TRState* S = x->testState();
    CHECK(S && S->haveLive && S->live.ct == "10:30 AM" && S->live.biasText == "BULLISH 3 of 4", "load: the 10:30 read, BULLISH 3 of 4");
    CHECK(S->logWrites == 0 && S->logQueue.empty(), "load: the first read is not logged");
    CHECK(S->live.turn == "Turn up at LonLO 62%?   Swing 20+ ticks 41%?   Next: 93.20 PWH", "load: line 1 stats " + S->live.turn);
    CHECK(has(S->live.inputs, "delta:") && has(S->live.inputs, "bas:") && !has(S->live.inputs, "missing"), "inputs used: " + S->live.inputs);
    // ---- draw
    H.draws.clear(); x->draw();
    const mock::Draw* hd = textWith(H, "Tape Reader v1.1");
    CHECK(hd && hd->text == "Tape Reader v1.1.1  \xB7  CL  \xB7  10:30 AM" && hd->bold, "header text: the real version v1.1.1");
    const mock::Draw* bx = boxOf(H);
    const int priceEdge = H.x0 + (int)(H.bars.size() - 1) * H.ppb + H.ppb / 2, profiles = H.paneRight - 150 - 8 - (50 + 110);
    CHECK(bx && bx->r <= priceEdge && bx->r <= profiles && bx->l >= 96 + 6 && bx->b <= H.paneBottom - 2, "box: inside the region (never past the last bar or into the profiles; clear of the LQ column)");
    CHECK(bx && std::abs((bx->l + bx->r) / 2 - (S->lastRegion.l + S->lastRegion.r) / 2) <= 1 && bx->b == H.paneBottom - 2 - 4, "box: default Bottom centre (1.1.0)");
    CHECK(bx && bx->border == tr::C_BORDER && bx->fs == 1, "solid 1-px border");
    int insideOk = 1; for (const mock::Draw& d : texts(H)) if (d.l < bx->l || d.t < bx->t - 12 || d.b > bx->b + 12) insideOk = 0;
    CHECK(insideOk, "every text inside the box");
    CHECK(textWith(H, "BULLISH 3 of 4") && textWith(H, "BULLISH 3 of 4")->color == tr::C_GREEN, "bias drawn green");
    CHECK(!textWith(H, "LEVELS") && textWith(H, "OPTIONS") && textWith(H, "OPTIONS")->color == tr::C_BLUE && textWith(H, "BUYERS")->color == tr::C_GREEN, "labels coloured; OPTIONS blue; no LEVELS (1.1.0)");
    {   // (1.1.0) OPTIONS: the grid that arrived at 10:29, fresh at 10:30 - two blue lines, '?' (not proven)
        const mock::Draw* o1 = textWith(H, "PS 92.9 wall 2.4x (+) building ? \xB7 above HVL ?"); const mock::Draw* o2 = textWith(H, "Put buyers fading ?");
        CHECK(o1 && o2 && o1->color == tr::C_BLUE && o2->color == tr::C_BLUE && o2->t > o1->t && S->live.opt[1] == "Put buyers fading ?", "OPTIONS: the arrived, fresh grid in 2 blue lines (CL: the dealers' size is not shown - sign doubtful)");
        CHECK(has(S->live.inputs, "options:120s"), "inputs: the options grid 2 min old at the candle's end: " + S->live.inputs); }
    std::string st = get("TapeReader.status-CL.txt");
    CHECK(has(st, "VERSION,1.1.1") && has(st, ",spot ") && has(st, "INPUT,DeltaProfile,found") && has(st, "INPUT,PullStats,found") && has(st, "LAST_READ,10:30 AM,BULLISH 3 of 4") && has(st, "LAYOUT,drawn") && has(st, "OPTIONS,ok,grids 1") && has(st, "OPTIONS_1,PS 92.9 wall 2.4x"), "status file written (with the options)");
    // ---- no flicker: the forming bar moves, nothing new -> no recompute, no redraw request
    const long long rc0 = S->recomputes; const int inv0 = H.invalidates; const std::string b0 = S->live.buyers;
    for (int i = 0; i < 20; ++i) { H.bars.back().close = 92.95f + 0.01f * (float)(i % 4); H.bars.back().high = 93.0f; step(700); x->calc(0); }
    CHECK(S->recomputes == rc0 && H.invalidates == inv0 && S->live.buyers == b0 && !S->live.intrabar, "no intrabar churn while the forming candle moves");
    // ---- intrabar: a NEW A at a level in the forming candle recomputes once
    {   std::string rec = get("DeltaProfile/CL-CLX6-180-signals-20739.csv");
        rec += std::to_string(scen::ct(10, 31)) + "|" + std::to_string(scen::ct(10, 32)) + "|A|support|bullish|92.89|92.91|0.01|-900|2.4|" + std::to_string(scen::ct(10, 32)) + "|2.7.0|D|QCL|8|" + std::to_string(scen::ct(10, 31)) + "|" + std::to_string(scen::ct(10, 31)) + "|92.9|9289|9291|sell|node|0|0\n";
        put("DeltaProfile/CL-CLX6-180-signals-20739.csv", rec); }
    step(1100); x->calc(0);
    CHECK(S->recomputes == rc0 + 1 && S->live.intrabar && S->intraUpdates == 1 && H.invalidates == inv0 + 1, "intrabar: a new A at LonLO recomputes once");
    step(1100); x->calc(0); step(1100); x->calc(0);
    CHECK(S->recomputes == rc0 + 1, "intrabar: the same A does not recompute again");
    {   std::string rec = get("DeltaProfile/CL-CLX6-180-signals-20739.csv");   // an A far from every level: no trigger
        rec += std::to_string(scen::ct(10, 31)) + "|" + std::to_string(scen::ct(10, 32)) + "|A|support|bullish|95.5|95.6|0.01|-900|2.4|" + std::to_string(scen::ct(10, 32)) + "|2.7.0|D|QCL|9|" + std::to_string(scen::ct(10, 31)) + "|" + std::to_string(scen::ct(10, 31)) + "|95.5|9550|9560|sell|node|0|0\n";
        put("DeltaProfile/CL-CLX6-180-signals-20739.csv", rec); }
    step(1100); x->calc(0);
    CHECK(S->recomputes == rc0 + 1, "intrabar: an A away from the levels does not trigger");
    // ---- candle close 10:33: the active panes have not logged 10:33 yet -> wait (grace), then finalise and log once
    hostBars(H, 2); step(100); x->calc(0);
    CHECK(S->pendingRaw == (unsigned long long)scen::ct(10, 33) && S->live.intrabar && S->logWrites == 0, "10:33 closed: waiting for the panes' rows (the intrabar read stays up)");
    step(2000); x->calc(0); CHECK(S->logWrites == 0, "still waiting at 2 s");
    step(3100); x->calc(0);
    CHECK(S->live.ct == "10:33 AM" && S->logWrites == 1 && S->pendingRaw == 0, "grace 5 s: 10:33 finalised and logged");
    CHECK(S->live.intraUpdates == 1, "the candle's read carries its intrabar update count");
    const std::string logRel = "TapeReader/CL-CLX6-180-20261013.csv";
    std::string lg = get(logRel);
    CHECK(countLines(lg, std::to_string(scen::ct(10, 33)) + "|") == 1 && countLines(lg, "bar_raw|") == 1, "log: header + one line for 10:33");
    for (int i = 0; i < 5; ++i) { step(1100); x->calc(0); }
    CHECK(countLines(get(logRel), std::to_string(scen::ct(10, 33)) + "|") == 1, "log: once per candle");
    // ---- 10:36 closes with every active pane's row present -> finalised at once
    {   put("BidAskStats/CL-CLX6-180-20261013.csv", get("BidAskStats/CL-CLX6-180-20261013.csv") + scen::ofRow(scen::ct(10, 36), "10:36", scen::basNums(10, 10, {}), "", "", 0, 0, "neutral", "", "Normal activity - no spike", "x"));
        put("PullStats/CL-CLX6-180-20261013.csv", get("PullStats/CL-CLX6-180-20261013.csv") + scen::ofRow(scen::ct(10, 36), "10:36", scen::nums({}), "", "", 0, 0, "neutral", "", "Normal activity - no spike", "x"));
        put("StackStats/CL-CLX6-180-20261013.csv", get("StackStats/CL-CLX6-180-20261013.csv") + scen::ofRow(scen::ct(10, 36), "10:36", scen::nums({}), "", "", 0, 0, "neutral", "", "Normal activity - no spike", "x")); }
    hostBars(H, 3); step(1100); x->calc(0);
    CHECK(S->live.ct == "10:36 AM" && S->logWrites == 2, "10:36: all panes' rows in -> finalised without waiting");
    // ---- hover: the read logged for the candle under the mouse; the forming bar = live
    RTX_EVENT e; std::memset(&e, 0, sizeof(e)); e.type = E_MOUSE_MOVE; e.v.mouse.bar = 50;    // 10:33
    int inv1 = H.invalidates; tr_test_cursor_wnd = (void*)0x10; x->mouse(&e);
    CHECK(S->hover == 50 && H.invalidates == inv1 + 1, "hover: one redraw on a change");
    x->mouse(&e); CHECK(H.invalidates == inv1 + 1, "hover: the same bar = no redraw");
    H.draws.clear(); x->draw();
    CHECK(textWith(H, "Tape Reader v1.1") && has(textWith(H, "Tape Reader v1.1")->text, "10:33 AM"), "hover: the 10:33 read (header 10:33 AM)");
    e.v.mouse.bar = 49; x->mouse(&e); H.draws.clear(); x->draw();
    CHECK(textWith(H, "Tape Reader v1.1") && has(textWith(H, "Tape Reader v1.1")->text, "10:36 AM"), "hover over a candle with no logged read (10:30, the load read) = live");
    e.v.mouse.bar = (long)H.bars.size() - 1; x->mouse(&e); CHECK(S->hover == -1, "hover over the forming bar = live");
    e.v.mouse.bar = 50; x->mouse(&e); tr_test_cursor_wnd = (void*)0x99; inv1 = H.invalidates; x->calc(0);
    CHECK(S->hover == -1 && H.invalidates == inv1 + 1, "the mouse left the chart window: back to live with one redraw");
    {   // (1.1.1, Rassul 9:25 PM) the chart-wide hover: the Tape Reader PUBLISHES the candle under the mouse for the order-flow panes, and
        // FOLLOWS a candle published by one of them (the mouse over BidAskStats / StackStats / PullStats)
        const unsigned long long t0 = H.bars.front().time, t1 = H.bars.back().time;
        hb::fakeCursor() = 0x10; tr_test_cursor_wnd = (void*)0x10; e.v.mouse.bar = 50; x->mouse(&e);
        std::string v; hb::Pub pub; CHECK(hb::hbGet("LRA_HV_CLX6_180", v) && hb::decode(v, pub) && pub.wnd == 0x10 && pub.t == H.bars[50].time && pub.t0 == t0 && pub.t1 == t1, "the Tape Reader publishes its hovered candle for its chart");
        e.v.mouse.bar = -1; x->mouse(&e); tr_test_cursor_wnd = (void*)0x20;
        hb::fakeCursor() = 0x20; hb::publish("CLX6", 180, H.bars[48].time, t0, t1);   // StackStats' pane (window 0x20) under the mouse at candle 48
        inv1 = H.invalidates; x->calc(0);
        CHECK(S->hover == 48 && H.invalidates == inv1 + 1, "the mouse over an order-flow pane: the Tape Reader follows that candle (one redraw)");
        hb::fakeCursor() = 0x99; x->calc(0); CHECK(S->hover == -1, "the mouse off the chart: Live");
        hb::fakeCursor() = 0; tr_test_cursor_wnd = nullptr; unsetenv("LRA_HV_CLX6_180");
    }
    // ---- restart: a new copy reloads the session log (hover still works, nothing logged twice)
    x->destroy(); CHECK(H.data == nullptr, "destroy releases the slot");
    delete x; x = static_cast<TapeReader*>(CreateExtension()); x->setup(); x->calc(0); S = x->testState();
    CHECK(S && S->logLoaded == 2 && S->logged.count((unsigned long long)scen::ct(10, 33)) == 1 && S->logWrites == 0, "restart: 2 logged reads reloaded, none rewritten");
    hostBars(H, 4); step(100); x->calc(0); step(5100); x->calc(0);
    CHECK(countLines(get(logRel), std::to_string(scen::ct(10, 39)) + "|") == 1 && countLines(get(logRel), std::to_string(scen::ct(10, 36)) + "|") == 1, "after restart: 10:39 logged once, 10:36 not duplicated");
    // ---- log write failure: queued, not marked, retried
    {   const std::string lp = DIR + "/" + logRel; std::rename(lp.c_str(), (lp + ".keep").c_str()); mkdir(lp.c_str(), 0755);   // the log path is a folder: appends fail
        hostBars(H, 5); step(100); x->calc(0); step(5100); x->calc(0);
        CHECK(S->logFails >= 1 && S->logQueue.size() == 1 && !S->logged.count((unsigned long long)scen::ct(10, 42)), "log failure: queued, not marked logged");
        rmdir(lp.c_str()); std::rename((lp + ".keep").c_str(), lp.c_str()); step(2100); x->calc(0);
        CHECK(S->logQueue.empty() && S->logged.count((unsigned long long)scen::ct(10, 42)) && countLines(get(logRel), std::to_string(scen::ct(10, 42)) + "|") == 1, "log retried after the failure"); }
    // ---- status: atomic, a failed rename keeps the old file
    {   const std::string before = get("TapeReader.status-CL.txt"); hostBars(H, 6); step(100); x->calc(0); step(5100); x->calc(0);
        tr_test_fail_rename = 2; step(31000); H.draws.clear(); x->draw();
        CHECK(get("TapeReader.status-CL.txt").size() > 0 && tr::fileSig(DIR + "/TapeReader.status-CL.txt") >= 0, "status: a failed rename keeps a status file in place");
        tr_test_fail_rename = 0; step(31000); x->draw(); CHECK(has(get("TapeReader.status-CL.txt"), "10:45 AM") || has(get("TapeReader.status-CL.txt"), "LAST_READ"), "status: next write succeeds"); (void)before; }
    // ---- position file: Top right; garbage -> default
    put("TapeReader.place-CL.txt", "2\n"); step(1100); H.draws.clear(); x->draw();
    bx = boxOf(H); { const int pe = H.x0 + (int)(H.bars.size() - 1) * H.ppb + H.ppb / 2; CHECK(bx && bx->r <= std::min(pe, profiles) && bx->r >= std::min(pe, profiles) - 4 && (S->lastSpot == 2 ? bx->t == 2 + 4 : S->lastSpot % 3 == 2), "place file 2 = Top right at the last bar's edge ((1.1.1) moved down the same column only when the price candles fill the top)"); }
    put("TapeReader.place-CL.txt", "x\n"); step(1100); H.draws.clear(); x->draw(); bx = boxOf(H); CHECK(bx && std::abs((bx->l + bx->r) / 2 - (S->lastRegion.l + S->lastRegion.r) / 2) <= 1 && bx->b == H.paneBottom - 2 - 4, "garbage place file = Bottom centre (1.1.0)");
    // the 9 positions on the chart
    for (int p = 0; p < 9; ++p) {
        put("TapeReader.place-CL.txt", std::to_string(p) + "\n"); step(1100); H.draws.clear(); x->draw(); bx = boxOf(H);
        const int pe = H.x0 + (int)(H.bars.size() - 1) * H.ppb + H.ppb / 2;
        CHECK(bx && bx->l >= 102 && bx->r <= std::min(pe, profiles) && bx->t >= 2 && bx->b <= H.paneBottom - 2, "chart position " + std::to_string(p) + " inside the area up to the last bar");
    }
    std::remove((DIR + "/TapeReader.place-CL.txt").c_str());
    // savePos writes only a real dialog value
    H.listIndex = -1; x->parmsApply(); CHECK(tr::fileSig(DIR + "/TapeReader.place-CL.txt") < 0, "parmsApply with no dialog value writes nothing");
    H.listIndex = 4; x->parmsApply(); CHECK(get("TapeReader.place-CL.txt") == "4\n", "parmsApply saves the chosen position"); std::remove((DIR + "/TapeReader.place-CL.txt").c_str()); H.listIndex = -1;
    // ---- stale liquidity, other-contract dealer file (a roll), missing inputs
    put("LRA-LiqZones-CL.csv", scen::liqZones(tr_test_unix - 600)); put("LRA-Dealer-CL.csv", scen::dealer("CLZ6", tr_test_unix));
    hostBars(H, 7); step(100); x->calc(0); step(5100); x->calc(0);
    CHECK(has(S->live.inputs, "liq:stale") && !has(S->live.levels, "Bid LQ") && !has(S->live.levels, "Offer LQ"), "stale LiqZones (10 min): left out: " + S->live.levels);
    CHECK(has(S->live.inputs, "dealer:other contract") && has(S->live.levels, "Low trust (roll)") && !has(S->live.levels, "GEX"), "dealer file on another contract: no gamma, flagged roll");
    for (const char* f : { "LRA-KeyLevels-CL.csv", "LRA-Levels-CL.csv", "LRA-Touch-CL.csv", "LRA-Dealer-CL.csv", "LRA-LiqZones-CL.csv", "LiquidityProfile.status-CL-180.txt", "HodLod.status-CL-180.txt", "LRA-Turns-CL.csv",
                           "DeltaProfile/CL-CLX6-180-signals-20739.csv", "BidAskStats/CL-CLX6-180-20261013.csv", "PullStats/CL-CLX6-180-20261013.csv", "StackStats/CL-CLX6-180-20261013.csv" }) std::remove((DIR + "/" + f).c_str());
    hostBars(H, 8); step(100); x->calc(0); step(5100); x->calc(0); step(31000); H.draws.clear(); x->draw();
    st = get("TapeReader.status-CL.txt");
    CHECK(S->haveLive && S->live.ct == "10:51 AM" && boxOf(H) && S->live.buyers == "quiet", "every input missing: the box still draws (bars only): " + S->live.ct + " / " + S->live.buyers + (boxOf(H) ? " box" : " nobox"));
    CHECK(has(st, "INPUT,DeltaProfile,missing") && has(st, "INPUT,BidAskStats,missing") && has(st, "INPUT,Turns,missing") && has(st, "INPUT,Dealer,missing") && has(S->live.inputs, "delta:missing"), "status lists the missing inputs");
    // ---- garbled params file -> defaults, said in the status
    put("LRA-TapeReader-CL.csv", "VERSION,1\nMARKET,ES\n"); step(11000); x->calc(0); step(31000); x->draw();
    CHECK(S->P.src == "garbled" && has(get("TapeReader.status-CL.txt"), "PARAMS,garbled (wrong MARKET)"), "garbled params: defaults + status");
    // ---- (1.0.1) the REAL nightly LRA-Turns-CL.csv (file VERSION 2) through the host: read, bucket shown in the status, box "learning"
    {   writeWorld(); std::remove((DIR + "/LRA-TapeReader-CL.csv").c_str());
        std::ifstream rf((std::string(TR_TEST_DATA) + "LRA-Turns-CL.csv").c_str(), std::ios::binary); const std::string real((std::istreambuf_iterator<char>(rf)), std::istreambuf_iterator<char>());
        put("LRA-Turns-CL.csv", real); hostBars(H, 9); step(11000); x->calc(0); step(5100); x->calc(0); step(31000); H.draws.clear(); x->draw();
        const std::string st2 = get("TapeReader.status-CL.txt");
        CHECK(real.size() > 1000 && has(st2, "INPUT,Turns,found,file, 68 rows"), "real CL turns file: found, 68 rows");
        put("LRA-Turns-CL.csv", "VERSION,1\nMARKET,CL\nASOF,1791900000\nSWING_TICKS,20\nTURN,london,AE,up,0.62,0.41,18,31,40,35,?\n");
        hostBars(H, 10); step(11000); x->calc(0); step(5100); x->calc(0); step(31000); x->draw();
        CHECK(has(get("TapeReader.status-CL.txt"), "INPUT,Turns,not used,garbled: VERSION,2 must be first") && !has(S->live.turn, "%"), "old-draft turns file: garbled, no odds shown: " + S->live.turn);
    }
    // ---- (1.0.1) GAMMA feed: data time (ASOF / SRC), not file time; the index book's g = 0 -> MenthorQ net GEX $; else abstain
    {   const long long realNow = tr_test_unix;
        tr_test_unix = scen::ct(11, 0);                            // Tue 13 Oct 11:00 AM CT: inside CL RTH (8:00 - 1:30)
        writeWorld(); std::remove((DIR + "/LRA-TapeReader-CL.csv").c_str());
        int nb = 9;
        // the later flat bars (92.97) shrink the band below the 92.90 node, so each file also carries a node at price (92.97)
        auto run = [&](const std::string& dealerText, long long mtime) {
            const bool idx = has(dealerText, "SRC|SPX"), zero = has(dealerText, "NODE|92.90|0|0|0|0|0|0|||0|0|");
            const std::string at = idx ? (zero ? "NODE|92.97|0|0|0|0|0|0|||0|0|0\n" : "NODE|92.97|0|0|0|0|0|0|||0|5000000|0\n") : "NODE|92.97|20|20|20|20|-500|0|0.3|10.3|0|5000000|0\n";
            put("LRA-Dealer-CL.csv", dealerText + at, mtime); hostBars(H, nb++); step(2100); x->calc(0); step(5100); x->calc(0); };
        const long long now = tr_test_unix;
        run(scen::dealer("CLX6", now - 60), now - 20 * 3600);
        CHECK(has(S->live.inputs, "dealer:60s") && has(S->live.levels, "+GEX") && S->live.why[tr::V_GAMMA] != "" && S->live.why[tr::V_GAMMA].compare(0, 4, "+GEX") == 0,
              "fresh data in a file saved 20 h ago: used (data time, not file time): " + S->live.inputs + " / " + S->live.why[tr::V_GAMMA]);
        run(scen::dealer("CLX6", now - 18 * 3600), 0);
        CHECK(has(S->live.inputs, "dealer:stale data 18h") && S->live.votes[tr::V_GAMMA] == 0 && S->live.why[tr::V_GAMMA] == "stale 18h" && !has(S->live.levels, "GEX"),
              "data 18 h old in a file just saved: GAMMA abstains, 'stale 18h': " + S->live.inputs + " / " + S->live.why[tr::V_GAMMA]);
        x->draw(); step(31000); x->draw();
        CHECK(has(get("TapeReader.status-CL.txt"), "gamma 0 (stale 18h)"), "status LAST_READ says gamma stale 18h");
        run(scen::dealer("CLX6", now - 16 * 60), 0);
        CHECK(S->live.why[tr::V_GAMMA] == "stale 16m" && S->live.votes[tr::V_GAMMA] == 0, "RTH: data 16 min old -> stale 16m, abstains: " + S->live.why[tr::V_GAMMA]);
        run(scen::dealer("CLX6", now - 14 * 60), 0);
        CHECK(S->live.why[tr::V_GAMMA].compare(0, 4, "+GEX") == 0 && S->live.votes[tr::V_GAMMA] == tr::BULL, "RTH: data 14 min old -> fresh, votes: " + S->live.why[tr::V_GAMMA]);
        run(scen::dealer("CLX6", now - 5 * 60, 0, "10:40"), 0);
        CHECK(S->live.why[tr::V_GAMMA] == "stale 20m", "ASOF 5 min but the book's SRC time 10:40 (20 min): stale by the older time: " + S->live.why[tr::V_GAMMA]);
        run(scen::dealer("CLX6", now - 120, 1, "10:58"), 0);
        CHECK(has(S->live.inputs, "gex$") && S->live.votes[tr::V_GAMMA] == tr::BULL && S->live.why[tr::V_GAMMA] == "+GEX G 92.97" && has(S->live.levels, "+GEX G 92.97 (dlrs buy dips)"),
              "index book with g = 0 on every row: GAMMA reads MenthorQ net GEX $: " + S->live.inputs + " / " + S->live.why[tr::V_GAMMA]);
        run(scen::dealer("CLX6", now - 120, 2, "10:58"), 0);
        CHECK(has(S->live.inputs, "dealer:no gamma") && S->live.votes[tr::V_GAMMA] == 0 && S->live.why[tr::V_GAMMA] == "? no gamma data" && !has(S->live.levels, "GEX"),
              "g = 0 and GEX $ = 0: GAMMA abstains '?': " + S->live.why[tr::V_GAMMA]);
        run(scen::dealer("CLX6", -1), 0);
        CHECK(has(S->live.inputs, "dealer:no data time") && S->live.why[tr::V_GAMMA] == "? no gamma data", "no ASOF row: GAMMA abstains: " + S->live.inputs);
        // (MQG100) BOOKASOF = the grid's own time; ASOF = the build time
        auto book = [](long long u) { return "BOOK" + scen::asof(u); };
        run(scen::dealer("CLX6", now - 60) + book(now - 6 * 3600 - 5 * 60), 0);
        CHECK(S->live.why[tr::V_GAMMA] == "stale 6h" && S->live.votes[tr::V_GAMMA] == 0 && has(S->live.inputs, "dealer:stale data 6h") && !has(S->live.levels, "GEX"),
              "ASOF fresh (built 1 min ago) but BOOKASOF 4:55 AM: stale 6h, GAMMA abstains: " + S->live.why[tr::V_GAMMA]);
        run(scen::dealer("CLX6", now - 60) + book(now - 3 * 60), 0);
        CHECK(S->live.why[tr::V_GAMMA].compare(0, 4, "+GEX") == 0 && has(S->live.inputs, "dealer:180s"), "BOOKASOF 3 min old: fresh, votes: " + S->live.inputs);
        run(scen::dealer("CLX6", now - 20 * 60) + book(now - 3 * 60), 0);
        CHECK(S->live.why[tr::V_GAMMA].compare(0, 4, "+GEX") == 0, "BOOKASOF fresh wins over an older ASOF: " + S->live.why[tr::V_GAMMA]);
        run(scen::dealer("CLX6", now - 60, 1, "10:40") + book(now - 3 * 60), 0);
        CHECK(S->live.why[tr::V_GAMMA] == "stale 20m", "BOOKASOF fresh but the SPX book's SRC time 10:40: the older time, stale 20m: " + S->live.why[tr::V_GAMMA]);
        run(scen::dealer("CLX6", now - 60) + "BOOKASOF||\n", 0);
        CHECK(has(S->live.inputs, "dealer:no book time") && S->live.why[tr::V_GAMMA] == "? no gamma data", "BOOKASOF|| (no grid): GAMMA abstains: " + S->live.inputs);
        run(scen::dealer("CLX6", now - 60), 0);
        CHECK(has(S->live.inputs, "dealer:60s") && S->live.why[tr::V_GAMMA].compare(0, 4, "+GEX") == 0, "no BOOKASOF row: ASOF as before: " + S->live.inputs);
        tr_test_unix = scen::ct(15, 0);                            // 3:00 PM: CL RTH over, the 18 h allowance
        run(scen::dealer("CLX6", tr_test_unix - 2 * 3600), 0);
        CHECK(S->live.why[tr::V_GAMMA].compare(0, 4, "+GEX") == 0, "outside RTH: data 2 h old still used: " + S->live.why[tr::V_GAMMA]);
        std::remove((DIR + "/LRA-Dealer-CL.csv").c_str()); hostBars(H, nb++); step(2100); x->calc(0); step(5100); x->calc(0);
        CHECK(has(S->live.inputs, "dealer:missing") && S->live.why[tr::V_GAMMA] == "? no gamma data", "no Dealer file: GAMMA abstains '?'");
        tr_test_unix = realNow; writeWorld(); std::remove((DIR + "/LRA-TapeReader-CL.csv").c_str());
    }
    // ---- pane too narrow: a note, no box
    { const int pr = H.paneRight; H.paneRight = 420; H.draws.clear(); x->draw(); CHECK(!boxOf(H) || boxOf(H)->r - boxOf(H)->l < 0, "narrow pane: no box"); H.paneRight = pr; }
    // ---- two charts on one DLL: no cross-talk; a symbol change restarts the chart's state
    {   mock::Host H2; H2.symbol = "ESZ6"; H2.root = "EP"; H2.tick = 0.25f; mock::current = &H2; hostBars(H2, 1);
        TapeReader* y = static_cast<TapeReader*>(CreateExtension()); y->setup(); y->calc(0);
        TRState* S2 = y->testState();
        CHECK(S2 && S2 != S && S2->mkt == "ES" && S->mkt == "CL", "two charts: separate states");
        mock::current = &H; x->calc(0); CHECK(x->testState() == S && S->mkt == "CL", "chart 1 unchanged");
        mock::current = &H2; y->destroy(); delete y; mock::current = &H; }
    H.symbol = "CLZ6"; x->calc(0); CHECK(S->symbol == "CLZ6" && S->logPath.find("CLZ6") != std::string::npos && S->logged.empty(), "symbol change: the chart's state restarts (new contract's log)");
    // ---- fail-closed slot: a host that keeps no user data gets no state (and no crash)
    {   mock::Host H3; H3.noSlot = true; mock::current = &H3; hostBars(H3, 1); TapeReader* z = static_cast<TapeReader*>(CreateExtension()); z->setup(); z->calc(0); z->draw();
        CHECK(z->testState() == nullptr, "no host slot: fail closed"); delete z; mock::current = &H; }
    x->destroy(); delete x;
    std::printf("tr host: %d passed, %d failed\n", g_pass, g_fail);
    return g_fail ? 1 : 0;
}
