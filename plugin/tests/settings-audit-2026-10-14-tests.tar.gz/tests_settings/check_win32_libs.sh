#!/bin/sh
# check_win32_libs.sh (settings audit 2026-10-13, after of140's) -- every Win32 API the changed plugins import must be in a library
# the build links: kernel32 comes with the CRT (cl /MD); user32 needs #pragma comment(lib, "user32.lib") in the translation unit.
D=$(cd "$(dirname "$0")" && pwd); B=${BUILD:-/tmp/settings-build}; mkdir -p "$B"; SDK=${SDK:-/mnt/user-data/uploads/sdk/c++/include}
KERNEL32="GetFileAttributesExA CreateDirectoryA MoveFileExA GetLastError CreateFileA CloseHandle GetFileAttributesA DeleteFileA GetTickCount GetTickCount64 Sleep GetEnvironmentVariableA GetModuleFileNameA ReplaceFileA GetCurrentProcessId GetCurrentThreadId QueryPerformanceCounter QueryPerformanceFrequency FindFirstFileA FindNextFileA FindClose RemoveDirectoryA CopyFileA GetFileSizeEx ReadFile WriteFile SetFilePointerEx FlushFileBuffers GetSystemTimeAsFileTime"
USER32="GetSystemMetrics GetCursorPos WindowFromPoint GetForegroundWindow ScreenToClient GetAsyncKeyState MessageBoxA GetDC ReleaseDC GetClientRect GetWindowRect FindWindowA EnumWindows GetWindowTextA IsWindowVisible GetDesktopWindow ClientToScreen PostMessageA SendMessageA"
GDI32="CreateCompatibleDC CreateCompatibleBitmap SelectObject BitBlt GetDIBits DeleteObject DeleteDC"
bad=0
for N in SessionVWAP DealerSig DealerRead LiquidityProfile LiquidityFlow; do
  x86_64-w64-mingw32-g++ -std=c++17 -c -O0 -I"$SDK" -I"$D/.." "$D/wrap_$N.cpp" -o "$B/w32-$N.o" 2>/dev/null || { echo "win32 $N: compile failed"; bad=1; continue; }
  x86_64-w64-mingw32-g++ -std=c++17 -E -D_MSC_VER=1930 -I"$SDK" -I"$D/.." "$D/wrap_$N.cpp" 2>/dev/null > "$B/w32-$N.i"
  imps=$(x86_64-w64-mingw32-nm -u "$B/w32-$N.o" | grep "__imp_" | sed 's/.*__imp_//' | grep -E '^[A-Z]' | sort -u)
  need=""; unknown=""
  for f in $imps; do
    case " $KERNEL32 " in *" $f "*) continue;; esac
    case " $USER32 " in *" $f "*) need="$need user32"; continue;; esac
    case " $GDI32 " in *" $f "*) need="$need gdi32"; continue;; esac
    unknown="$unknown $f"
  done
  miss=""
  for l in $(echo $need | tr ' ' '\n' | sort -u); do grep -q "pragma comment(lib, \"$l.lib\")" "$B/w32-$N.i" || miss="$miss $l"; done
  if [ -n "$miss$unknown" ]; then bad=1; echo "win32 $N: FAIL missing pragma:$miss unmapped:$unknown"; else echo "win32 $N: ok ($(echo $imps | tr '\n' ' '))"; fi
done
exit $bad
