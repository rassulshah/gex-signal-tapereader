// test_lq_settings_host.cpp -- lsLiquidityProfile / lsLiquidityFlow 0.15.1: the Width / Font settings reach every chart of the
// market and survive a restart (saved by OK / Apply to <name>.size-<MKT>.txt, read back by every draw). Build twice:
//   g++ -std=c++17 -Itests_lqp -I. tests_settings/test_lq_settings_host.cpp            (Liquidity Profile)
//   g++ -std=c++17 -DLQ_FLOW -Itests_lqp -I. tests_settings/test_lq_settings_host.cpp  (Liquidity Flow: Font only)
#include "LiquidityProfile.cpp"
#include <cstdio>
#include <cstdlib>
#include <unistd.h>
namespace mock { Host* current = nullptr; Feed feed; }
static int fails = 0, passes = 0;
#define CHECK(c, m) do { if (c) ++passes; else { ++fails; std::printf("FAIL %d %s\n", __LINE__, m); } } while (0)
static std::string readAll(const std::string& p) { std::ifstream f(p.c_str()); std::stringstream s; s << f.rdbuf(); return s.str(); }
static void chart(mock::Host& h, const char* root) {
    h.tick = 0.01f; h.seconds = 180; h.symbol = std::string(root) + "Z26"; h.root = root;
    const unsigned long t0 = (unsigned long)(civilDays(2026, 10, 12) * 86400LL) + 9 * 3600;
    for (int i = 0; i < 6; ++i) { mock::Bar b; b.time = t0 - (5 - i) * 180; b.open = 80.05f; b.high = 80.12f; b.low = 79.98f; b.close = 80.03f; b.rows.push_back(mock::Price(80.03f, 50, 40, 90)); h.bars.push_back(b); }
    h.now = t0;
}
int main() {
    char tmpl[] = "/tmp/lqsXXXXXX"; const char* tmp = mkdtemp(tmpl); setenv("USERPROFILE", tmp, 1);
    const std::string flex = std::string(tmp) + "\\InvestorRT\\rtx\\lsFlexLevels";
#ifdef LQ_FLOW
    const std::string name = "LiquidityFlow";
#else
    const std::string name = "LiquidityProfile";
#endif
    LiquidityProfile* p = static_cast<LiquidityProfile*>(CreateExtension());
    mock::Host a; mock::current = &a; chart(a, "CL"); p->calc(0); p->draw();
    LQState* S = static_cast<LQState*>(a.data);
    CHECK(S && S->width == 70 && S->font == 11, "no file: the defaults 70 px / 11 pt");
    // the settings window (on chart a): Apply saves for the market
#ifdef LQ_FLOW
    CHECK(WIDTH_INDEX < 0 && FONT_INDEX == 0, "Flow: the window has Font only (row 0)");
    a.parms[0] = 14;
#else
    CHECK(WIDTH_INDEX == 0 && FONT_INDEX == 1, "Profile: Width row 0, Font row 1");
    a.parms[0] = 120; a.parms[1] = 13;
#endif
    p->parmsApply();
    const std::string file = flex + "\\" + name + ".size-CL.txt";
#ifdef LQ_FLOW
    CHECK(readAll(file) == "70,14\n", "Apply writes the market's size file (Flow: width stays 70)");
    CHECK(S && S->font == 14, "the chart follows at once");
#else
    CHECK(readAll(file) == "120,13\n", "Apply writes the market's size file");
    CHECK(S && S->width == 120 && S->font == 13, "the chart follows at once");
#endif
    // a second CL chart (and a restart: a fresh host) reads the file; it is not lost
    mock::Host b; mock::current = &b; chart(b, "CL"); b.parms[0] = 50; b.parms[1] = 0; p->calc(0); p->draw();
    LQState* T = static_cast<LQState*>(b.data);
#ifdef LQ_FLOW
    CHECK(T && T->font == 14, "another CL chart / a restart gets the saved font");
#else
    CHECK(T && T->width == 120 && T->font == 13, "another CL chart / a restart gets the saved width and font");
#endif
    // another market keeps its own (none: the defaults)
    mock::Host c; mock::current = &c; chart(c, "ES"); p->calc(0); p->draw();
    LQState* U = static_cast<LQState*>(c.data);
    CHECK(U && U->width == 70 && U->font == 11, "ES keeps the defaults (per market)");
    // garbage and out-of-range values in the file are refused: the last good size stays
    mock::current = &b;
    usleep(1100000); { std::ofstream f(file.c_str(), std::ios::trunc); f << "9999,1\n"; } p->draw();
#ifdef LQ_FLOW
    CHECK(T && T->font == 14, "out-of-range file refused");
#else
    CHECK(T && T->width == 120 && T->font == 13, "out-of-range file refused");
#endif
    usleep(1100000); { std::ofstream f(file.c_str(), std::ios::trunc); f << "200,12\n"; } p->draw();
    CHECK(T && T->font == 12, "a new good file is followed without a restart");
#ifndef LQ_FLOW
    CHECK(T && T->width == 200, "width followed too");
#endif
    // the window's garbage is clamped, never saved raw
    mock::current = &a;
#ifdef LQ_FLOW
    a.parms[0] = 0;
#else
    a.parms[0] = 5; a.parms[1] = 99;
#endif
    p->parmsApply();
    { const std::string t = readAll(file); std::printf("  clamped file: %s", t.c_str());
#ifdef LQ_FLOW
      CHECK(t == "70,11\n", "font 0 -> the 11 pt default");
#else
      CHECK(t == "70,16\n", "width 5 -> the 70 px default, font 99 -> the 16 pt cap");
#endif
    }
    mock::current = &a; p->destroy(); mock::current = &b; p->destroy(); mock::current = &c; p->destroy();
    (void)p;                                   // the one DLL object lives for the process, as in IRT
    std::string cmd = std::string("rm -rf ") + tmp; if (std::system(cmd.c_str())) {}
    std::printf("%s size settings: %d passed, %d failed\n", name.c_str(), passes, fails);
    return fails ? 1 : 0;
}
