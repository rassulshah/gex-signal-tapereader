"""lsSessionVWAP 1.5.0 render check: draws what the REAL plugin drew (render_dump.cpp -> TSV) in four settings states.
   python render_check.py <dump.tsv> <out.png>"""
import sys
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
bars, lines = [], {}
for ln in open(sys.argv[1]):
    f = ln.rstrip("\n").split("\t")
    if f[0] == "BAR": bars.append((int(f[1]), float(f[2]), float(f[3]), float(f[4]), float(f[5])))
    elif f[0] == "LINE": lines.setdefault(f[1], []).append((f[2], int(f[3]), int(f[4]), float(f[5]), int(f[6]), float(f[7])))
titles = {"A": "A  defaults (no settings file) = 1.4.2's look",
          "B": "B  +1 SD and -1 SD unticked: both lines gone (RTH and overnight)",
          "C": "C  +2 SD recoloured blue, -2 SD recoloured yellow, VWAP width 4 px",
          "D": "D  all four bands unticked: only the VWAP line is drawn"}
fig, axes = plt.subplots(4, 1, figsize=(13, 17), facecolor="#000000")
lo = min(b[2] for b in bars); hi = max(b[1] for b in bars)
for segs in lines.values():
    for _, _, _, p0, _, p1 in segs: lo = min(lo, p0, p1); hi = max(hi, p0, p1)
for ax, key in zip(axes, "ABCD"):
    ax.set_facecolor("#000000")
    for i, h, l, c, pc in bars:
        col = "#26a69a" if c >= pc else "#ef5350"
        ax.plot([i, i], [l, h], color=col, lw=0.6, zorder=1)
    segs = lines.get(key, [])
    by = {}
    for colr, w, b0, p0, b1, p1 in segs: by.setdefault((colr, w), []).append([(b0, p0), (b1, p1)])
    for (colr, w), s in by.items(): ax.add_collection(LineCollection(s, colors="#" + colr, linewidths=w * 0.9, zorder=2))
    ax.set_xlim(bars[0][0] - 2, bars[-1][0] + 2); ax.set_ylim(lo - 2, hi + 2)
    ax.set_title(titles[key] + f"   ({len(segs)} segments)", color="#e5e7eb", fontsize=11, loc="left")
    ax.tick_params(colors="#9ca3af", labelsize=8)
    for sp in ax.spines.values(): sp.set_color("#374151")
    legend = sorted({(colr, w) for colr, w, *_ in segs})
    ax.text(0.995, 0.02, "  ".join(f"#{c} {w}px" for c, w in legend), transform=ax.transAxes, ha="right", va="bottom", color="#d1d5db", fontsize=8)
fig.suptitle("lsSessionVWAP 1.5.0 render check - ES 3-min, overnight then RTH (the real plugin's draw calls on the mock SDK)", color="#f9fafb", fontsize=12)
fig.tight_layout(rect=(0, 0, 1, 0.97))
fig.savefig(sys.argv[2], dpi=90, facecolor="#000000")
