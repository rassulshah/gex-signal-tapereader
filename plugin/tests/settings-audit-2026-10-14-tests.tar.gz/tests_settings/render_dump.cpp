// render_dump.cpp -- lsSessionVWAP 1.5.0 render check: the REAL plugin draws on the mock SDK in three settings states and every
// line it drew (pen colour, width, bar / price ends) is written out with the bars; render_check.py turns it into the PNG.
//   render_dump <bars.csv> <out.tsv>
#include "irtsdk.h"
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <sstream>
namespace mock { Host* current = NULL; }
#include "../SessionVWAP.cpp"
int main(int argc, char** argv)
{
    if (argc < 3) return 2;
    char tmpl[] = "/tmp/svrenderXXXXXX"; char* dir = mkdtemp(tmpl); if (!dir) return 3;
    const std::string profile = std::string(dir) + "/u"; setenv("USERPROFILE", profile.c_str(), 1);
    std::ifstream in(argv[1]); std::string line; std::vector<unsigned long> T, V; std::vector<float> H, L, C;
    while (std::getline(in, line)) {
        std::stringstream ss(line); std::string a; std::vector<std::string> f; while (std::getline(ss, a, ',')) f.push_back(a);
        if (f.size() < 5) continue;
        T.push_back(strtoul(f[0].c_str(), 0, 10)); H.push_back(strtof(f[1].c_str(), 0)); L.push_back(strtof(f[2].c_str(), 0));
        C.push_back(strtof(f[3].c_str(), 0)); V.push_back(strtoul(f[4].c_str(), 0, 10));
    }
    const size_t n = T.size();
    mock::declared.clear();
    SessionVWAP x; mock::Host Hh; Hh.root = "ES"; mock::current = &Hh; x.setup();
    for (int a = 0; a < 14; a++) Hh.f[a].assign(n, 0.0f);
    for (int a = 0; a < 2; a++) Hh.i[a].assign(n, 0UL);
    for (size_t i = 0; i < n; i++) { Hh.i[(int)barDateTime][i] = T[i]; Hh.i[(int)barVolume][i] = V[i]; Hh.f[(int)barHigh][i] = H[i]; Hh.f[(int)barLow][i] = L[i]; Hh.f[(int)barClose][i] = C[i]; }
    x.fill(0);
    std::ofstream o(argv[2]);
    const int a0 = n > 300 ? (int)n - 300 : 0;
    for (size_t i = (size_t)a0; i < n; i++) o << "BAR\t" << i << "\t" << H[i] << "\t" << L[i] << "\t" << C[i] << "\t" << (i ? C[i - 1] : C[i]) << "\n";
    auto shot = [&](const char* name) {
        Hh.lines.clear(); x.draw();
        for (size_t k = 0; k < Hh.lines.size(); k++) { char b[160]; snprintf(b, sizeof(b), "LINE\t%s\t%06lX\t%d\t%d\t%.3f\t%d\t%.3f\n", name, (unsigned long)Hh.lines[k].c, (int)Hh.lines[k].w, Hh.lines[k].b0, Hh.lines[k].p0, Hh.lines[k].b1, Hh.lines[k].p1); o << b; }
    };
    shot("A");                                                              // defaults (no settings file) = 1.4.2's look
    Hh.dialog = true; x.parmsLoad();
    x.checkBox(x.P[svs::R_P1], false); x.checkBox(x.P[svs::R_M1], false);    // B: the 1 SD bands unticked
    x.parmsApply(); Hh.dialog = false; shot("B");
    Hh.dialog = true; x.checkBox(x.P[svs::R_P1], true); x.checkBox(x.P[svs::R_M1], true);
    x.setParameterColor(x.P[svs::R_M2_COL], 0x00FFD400); x.setParameterColor(x.P[svs::R_P2_COL], 0x0000C8FF);   // C: +-2 SD recoloured
    x.setListIndex(x.P[svs::R_VWAP_W], 3);                                  //    + VWAP 4 px
    x.parmsApply(); Hh.dialog = false; shot("C");
    Hh.dialog = true; x.parmsLoad();                                        // D: every band unticked - only the VWAP stays
    x.checkBox(x.P[svs::R_P1], false); x.checkBox(x.P[svs::R_M1], false); x.checkBox(x.P[svs::R_P2], false); x.checkBox(x.P[svs::R_M2], false);
    x.parmsApply(); Hh.dialog = false; shot("D");
    x.done();
    std::string cmd = std::string("rm -rf ") + dir; if (std::system(cmd.c_str())) {}
    return 0;
}
