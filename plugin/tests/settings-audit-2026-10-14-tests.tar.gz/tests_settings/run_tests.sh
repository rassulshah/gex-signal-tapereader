#!/bin/sh
# Settings audit 2026-10-13: every suite for the plugins changed tonight (ASan/UBSan), the MinGW syntax check against the real
# irtsdk.h, the Win32 library check and the SessionVWAP render dump. Any failure stops the run.   sh tests_settings/run_tests.sh
D=$(cd "$(dirname "$0")/.." && pwd); B=${BUILD:-/tmp/settings-build}; mkdir -p "$B"; cd "$D"
SDK=${SDK:-/mnt/user-data/uploads/sdk/c++/include}
SAN="-fsanitize=address,undefined -fno-sanitize-recover=undefined"; CXX="g++ -std=c++17 -g $SAN"
export ASAN_OPTIONS=detect_leaks=0      # the Liquidity host tests' 7 / 4 small leaks are in the existing mock (same on the 0.15.0 base)
step() { echo "== $1" >&2; shift; "$@" || { echo "FAILED: $*"; exit 1; }; }
# SessionVWAP 1.4.3
step "sv logic" $CXX -Wall -Wextra -Werror test_sessionvwap_logic.cpp -o "$B/svl"; step "run" "$B/svl"
step "sv regression" $CXX -Wall -Wextra -Werror -ISessionVWAP_test_support -I. -DSESSIONVWAP_SOURCE='"SessionVWAP.cpp"' test_sessionvwap_regression.cpp -o "$B/svr"; step "run" "$B/svr"
step "sv settings" $CXX -Wall -Wextra -Werror -ISessionVWAP_test_support -I. test_sessionvwap_settings.cpp -o "$B/svs"; step "run" "$B/svs"
step "vwap odds" $CXX -Wall -Wextra -Werror test_vwapodds_logic.cpp -o "$B/vo"; step "run" "$B/vo"
step "vwap trend" $CXX -Wall -Wextra -Werror test_vwaptrend_logic.cpp -o "$B/vt"; step "run" "$B/vt"
step "sv run_plugin" $CXX -ISessionVWAP_test_support -I. tests_sessionvwap/run_plugin.cpp -o "$B/rp"
# DealerSig 1.5.5
step "dealersig" $CXX -Wall -Wextra -Itest_dealersig_mock -I. test_dealersig_regression.cpp -o "$B/ds"; step "run" "$B/ds"
# DealerRead 4.5.8
step "dealerread" $CXX -include DealerRead_test_linux_sdk_compat.h -I"$SDK" -I. test_dealerread_regression.cpp -o "$B/dr" -Wl,--unresolved-symbols=ignore-all; step "run" "$B/dr"
step "dealerread contract" python3 -I test_dealerread_lifecycle_contract.py
# Liquidity Profile / Flow 0.15.1
step "lq logic" $CXX test_liquidityprofile_logic.cpp -o "$B/lql"; step "run" "$B/lql"
step "lq hover logic" $CXX test_liquidityhover_logic.cpp -o "$B/lhl"; step "run" "$B/lhl"
for T in test_liquidityprofile_host test_liquidityflow_host test_liquidityhover_host; do step "$T" $CXX -O1 -Itests_lqp -I. $T.cpp -o "$B/$T"; ( cd "$B" && ./$T > "$B/$T.out" 2>&1 ) || { tail -5 "$B/$T.out"; echo "FAILED: $T"; exit 1; }; tail -1 "$B/$T.out"; done
step "lq size (profile)" $CXX -O1 -Itests_lqp -I. tests_settings/test_lq_settings_host.cpp -o "$B/lqs"; step "run" "$B/lqs"
step "lq size (flow)" $CXX -O1 -DLQ_FLOW -Itests_lqp -I. tests_settings/test_lq_settings_host.cpp -o "$B/lqf"; step "run" "$B/lqf"
# static contract, real-SDK syntax, Win32 libraries
step "contract" python3 -I tests_settings/test_settings_contract.py .
for N in SessionVWAP DealerSig DealerRead LiquidityProfile LiquidityFlow; do
  x86_64-w64-mingw32-g++ -std=c++17 -fsyntax-only -Wall -Wextra -Wno-unknown-pragmas -I"$SDK" -I. tests_settings/wrap_$N.cpp > "$B/syntax-$N.log" 2>&1
  E=$(grep -c ' error' "$B/syntax-$N.log"); W=$(grep 'warning' "$B/syntax-$N.log" | grep -vc "$SDK")
  echo "syntax $N: $E errors, $W warnings outside the SDK"; [ "$E" = 0 ] && [ "$W" = 0 ] || { head -20 "$B/syntax-$N.log"; exit 1; }
done
BUILD="$B" sh tests_settings/check_win32_libs.sh || exit 1
# render check: SessionVWAP with bands on / off and a changed colour
step "render dump" g++ -std=c++17 -O1 -Wall -Wextra -Werror $SAN -ISessionVWAP_test_support -I. tests_settings/render_dump.cpp -o "$B/rd"
if [ -n "$BARS" ]; then step "render" "$B/rd" "$BARS" "$B/r.tsv"; step "png" python3 tests_settings/render_check.py "$B/r.tsv" "${PNG:-$B/sessionvwap-render.png}"; fi
echo "ALL SETTINGS-AUDIT SUITES PASSED"
