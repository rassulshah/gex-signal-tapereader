// test_tr_banner.cpp -- lsTapeReader 1.1.3 banner stability suite (CR5000, Rassul 07:18 "test them thoroughly ... dont shake ... dont
// have garbage values"), on the mock SDK under ASan / UBSan:
//   jitter      1,000 draws with a live forming bar, warning text lengths changing, mouse moves -> the banner rect changes ONLY on a
//               draw whose inputs changed (warning on / off, a longer text) or as the slow 60 s shrink; never because of the bar / mouse
//   hover       show / hide with the dead band (opens inside only, closes HOVER_BAND px outside), one redraw per transition, no box
//               when not hovered, the banner rect never moves because of the hover
//   board       the heartbeat: every draw refreshes the banner's entry (LRA_TRB_*), a removed Tape Reader clears it
//   round trip  dialog -> Apply -> file -> restart (a new extension) -> draw at the saved place; the dialog refilled from the file
//   fuzz        3,000 random place files and 1,000 random dialog values: never a crash, never outside the area, never garbage saved
//   two charts  two charts of the same symbol (3 min / 1 min, different panes, different chart labels): the per-market place applies
//               to both inside their own area, separate stable widths / hysteresis, each chart only its own Liquidity warning
#include "irtsdk.h"
#include "../TapeReader.cpp"
#include "tr_scenario.h"
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <sys/stat.h>
#include <unistd.h>

namespace mock { Host* current = nullptr; }
long long tr_test_now_ms = 1000000, tr_test_unix = 0; void* tr_test_cursor_wnd = nullptr; int tr_test_fail_rename = 0;

static int g_pass = 0, g_fail = 0;
#define CHECK(c, m) do { if (c) ++g_pass; else { ++g_fail; std::printf("FAIL %s:%d  %s\n", __FILE__, __LINE__, std::string(m).c_str()); } } while (0)
static bool has(const std::string& s, const std::string& k) { return s.find(k) != std::string::npos; }
static std::string DIR;
static void put(const std::string& rel, const std::string& text) {
    const std::string p = DIR + "/" + rel; const size_t sl = p.rfind('/'); mkdir(p.substr(0, sl).c_str(), 0755);
    std::ofstream f(p.c_str(), std::ios::binary | std::ios::trunc); f << text;
}
static std::string get(const std::string& rel) { std::ifstream f((DIR + "/" + rel).c_str(), std::ios::binary); std::string s((std::istreambuf_iterator<char>(f)), std::istreambuf_iterator<char>()); return s; }
static void writeWorld() {
    const long long u = tr_test_unix;
    put("LRA-KeyLevels-CL.csv", scen::keyLevels(u)); put("LRA-Levels-CL.csv", scen::mqLevels()); put("LRA-Touch-CL.csv", scen::touch());
    put("LRA-Dealer-CL.csv", scen::dealer("CLX6", u)); put("LRA-LiqZones-CL.csv", scen::liqZones(u)); put("LiquidityProfile.status-CL-180.txt", scen::liqStatus("CLX6"));
    put("HodLod.status-CL-180.txt", scen::hodlod()); put("LRA-Turns-CL.csv", scen::turns());
    put("DeltaProfile/CL-CLX6-180-signals-20739.csv", scen::deltaRecord("QCL"));
    put("BidAskStats/CL-CLX6-180-20261013.csv", scen::basFile()); put("PullStats/CL-CLX6-180-20261013.csv", scen::pullFile()); put("StackStats/CL-CLX6-180-20261013.csv", scen::stackFile());
    put("DealerProfile.status.txt", "VERSION,3\nREACH,150\n"); put("DeltaProfile.status.txt", "VERSION,2.7.0\nWIDTH,50\nPLACE,Right\n");
    put("LRA-OrderFlow-CL.csv", "VERSION,1\nMARKET,CL\n");
}
static void hostBars(mock::Host& H, int extra) {
    H.bars.clear(); const std::vector<tr::Bar> B = scen::bars(extra);
    for (const tr::Bar& b : B) { mock::Bar m; m.time = (unsigned long)b.raw; m.open = (float)b.o; m.high = (float)b.h; m.low = (float)b.l; m.close = (float)b.c; m.volume = (unsigned long)b.v; H.bars.push_back(m); }
}
static const mock::Draw* textWith(const mock::Host& H, const std::string& k) { for (const mock::Draw& d : H.draws) if (d.type == "text" && has(d.text, k)) return &d; return nullptr; }
static int boxCount(const mock::Host& H) { int n = 0; for (const mock::Draw& d : H.draws) if (d.type == "box") ++n; return n; }
static bool bannerRect(const mock::Host& H, int r[4]) { for (const mock::Draw& d : H.draws) if (d.type == "box") { r[0] = d.l; r[1] = d.t; r[2] = d.r; r[3] = d.b; return true; } return false; }
static void step(long long ms) { tr_test_now_ms += ms; }
static unsigned g_rng = 12345u;
static unsigned rnd() { g_rng = g_rng * 1103515245u + 12345u; return (g_rng >> 8) & 0xFFFFFF; }
static RTX_EVENT mv(int h, int v, long bar) { RTX_EVENT e; std::memset(&e, 0, sizeof(e)); e.type = E_MOUSE_MOVE; e.v.mouse.h = (short)h; e.v.mouse.v = (short)v; e.v.mouse.bar = bar; return e; }
static const char* const DETAILS[4] = { "buyers exhausted (0.4x)", "buyers exhausted (0.4x), but sellers are pulling their offers (92%)",
                                        "sellers pulling their offers (155%) while buyers keep lifting the offer", "bids thinning" };

static void testJitter(TapeReader* x, mock::Host& H) {
    TRState* S = x->testState();
    const int area_l = H.paneLeft + 4, area_t = H.paneTop + tr::TITLE_ROW;
    bb::Warn w; w.favour = -1; w.name = "SELLERS PULLING";
    bool wOn = false; int det = 0; int prev[4] = { 0, 0, 0, 0 }; bool havePrev = false;
    int changes = 0, unexplained = 0, badHeight = 0, badCorner = 0, shrinks = 0, badShrink = 0, hoverMoves = 0;
    long long lastGrowMs = tr_test_now_ms; const int inv0 = H.invalidates; int hoverOpen = 0;
    for (int i = 0; i < 1000; ++i) {
        step(100);
        // the live forming bar moves every draw (close / high / low), the closed bars do not
        mock::Bar& fb = H.bars.back(); fb.close = 92.95f + 0.01f * (float)(rnd() % 7); fb.high = std::max(fb.high, fb.close); fb.low = std::min(fb.low, fb.close); fb.volume += rnd() % 40;
        // inputs: the warning goes on / off every 97 draws, its text length changes every 41 draws
        bool inputChanged = false;
        if (i % 97 == 50) { wOn = !wOn; inputChanged = true; }
        if (i % 41 == 20) { det = (int)(rnd() % 4); inputChanged = wOn || inputChanged; }
        w.on = wOn; w.detail = DETAILS[det];
        bb::publishWarn(S->symbol, S->spb, H.chart, tr_test_now_ms, wOn ? w : bb::Warn());   // the Liquidity Profile publishes on every draw
        // the mouse wanders: mostly over the candles (live = the forming bar), sometimes over the banner (the hover opens)
        const bool overBanner = havePrev && (i % 113) >= 100;
        RTX_EVENT e = overBanner ? mv(prev[0] + 10 + (int)(rnd() % 30), prev[1] + 4, (long)H.bars.size() - 1)
                                 : mv(300 + (int)(rnd() % 600), 250 + (int)(rnd() % 300), (long)H.bars.size() - 1);
        x->mouse(&e); if (overBanner) ++hoverMoves;
        x->calc(0); H.draws.clear(); x->draw();
        if (S->inBanner) ++hoverOpen;
        int r[4]; if (!bannerRect(H, r)) { CHECK(false, "jitter: banner drawn on every draw (draw " + std::to_string(i) + ")"); continue; }
        if (r[0] != area_l || r[1] != area_t) ++badCorner;
        if (r[3] - r[1] != tr::bannerH(wOn)) ++badHeight;                 // the 1 -> 2 line change shows on the SAME draw (no lag)
        if (havePrev && (r[0] != prev[0] || r[1] != prev[1] || r[2] != prev[2] || r[3] != prev[3])) {
            ++changes;
            const bool shrink = r[2] < prev[2] && r[3] == prev[3];
            if (shrink) { ++shrinks; if (tr_test_now_ms - lastGrowMs < bp::StableW::SHRINK_MS) ++badShrink; }
            else if (!inputChanged) ++unexplained;
            if (r[2] > prev[2]) lastGrowMs = tr_test_now_ms;
        }
        std::memcpy(prev, r, sizeof(prev)); havePrev = true;
    }
    if (getenv("DBG")) std::printf("jitter: changes %d shrinks %d hoverOpen %d invalidates %d\n", changes, shrinks, hoverOpen, H.invalidates - inv0);
    CHECK(unexplained == 0, "jitter (1,000 draws): the banner rect never changes on a draw whose inputs did not change (bar / mouse): " + std::to_string(unexplained));
    CHECK(badCorner == 0, "jitter: the top-left corner never moves (Top left, offset 0)");
    CHECK(badHeight == 0, "jitter: the height always matches the warning on the same draw (1 <-> 2 lines without lag)");
    CHECK(badShrink == 0 && shrinks <= 2, "jitter: the width shrinks only after 60 s (" + std::to_string(shrinks) + " shrinks in 100 s)");
    CHECK(changes > 0 && changes <= 30, "jitter: a handful of real changes (" + std::to_string(changes) + "), not a shake");
    CHECK(hoverMoves > 0 && hoverOpen > 0, "jitter: the hover opened during the run and did not move the banner");
    CHECK(H.invalidates - inv0 <= 2 * 9 + 2, "jitter: redraw requests only for hover transitions (" + std::to_string(H.invalidates - inv0) + ")");
    // leave clean: mouse off, no warning
    { RTX_EVENT e = mv(900, 500, (long)H.bars.size() - 1); x->mouse(&e); bb::publishWarn(S->symbol, S->spb, H.chart, tr_test_now_ms, bb::Warn()); H.draws.clear(); x->draw(); }
}

static void testHover(TapeReader* x, mock::Host& H) {
    TRState* S = x->testState();
    H.draws.clear(); x->draw(); int r[4]; CHECK(bannerRect(H, r) && boxCount(H) == 1 && !textWith(H, "BUYERS"), "hover: no detail box while not hovered");
    const int inv = H.invalidates;
    RTX_EVENT e = mv(r[2] + 3, r[1] + 5, -1); x->mouse(&e);
    CHECK(!S->inBanner && H.invalidates == inv, "hover: 3 px right of the banner while closed = stays closed (opens only inside)");
    e = mv(r[0] + 20, r[1] + 5, -1); x->mouse(&e); H.draws.clear(); x->draw();
    int r2[4]; CHECK(S->inBanner && H.invalidates == inv + 1 && boxCount(H) == 2 && textWith(H, "BUYERS") && textWith(H, "SELLERS") && textWith(H, "OPTIONS"), "hover: inside = the detail opens (one redraw)");
    CHECK(bannerRect(H, r2) && std::memcmp(r, r2, sizeof(r)) == 0, "hover: the banner itself does not move");
    const mock::Draw* lab = textWith(H, "BUYERS"); if (getenv("DBG") && lab) std::printf("lab '%s' fs %d t %d r3 %d\n", lab->text.c_str(), lab->fs, lab->t, r[3]); int db = 0; const mock::Draw* dbx = nullptr; for (const mock::Draw& d : H.draws) if (d.type == "box" && ++db == 2) dbx = &d;
    CHECK(lab && lab->fs == tr::DET_PT && dbx && dbx->t == r[3] + 2 && dbx->l == r[0] && lab->t >= dbx->t - 8, "hover: the detail box right under the banner (2 px gap), 10 pt");
    int jig = 0; for (int k = 0; k < 200; ++k) { e = mv(r[2] - 2 + (int)(k % 6), r[1] + 5, -1); x->mouse(&e); if (!S->inBanner) ++jig; }
    CHECK(jig == 0 && H.invalidates == inv + 1, "hover: 200 moves across the right edge (+-3 px) - no flicker, no redraws");
    // the 2 px gap between the banner and the detail, then into the detail: stays open
    e = mv(r[0] + 30, r[3] + 1, -1); x->mouse(&e); const bool gap = S->inBanner;
    e = mv(r[0] + 30, r[3] + 20, -1); x->mouse(&e); CHECK(gap && S->inBanner && H.invalidates == inv + 1, "hover: through the gap into the detail - stays open");
    e = mv(r[2] + tr::HOVER_BAND + 400, r[3] + 300, -1); x->mouse(&e); H.draws.clear(); x->draw();
    CHECK(!S->inBanner && H.invalidates == inv + 2 && boxCount(H) == 1 && !textWith(H, "BUYERS"), "hover: the mouse leaves (past the dead band) = the detail is gone");
    e = mv(r[2] + tr::HOVER_BAND + 1, r[1] + 5, -1); x->mouse(&e); CHECK(!S->inBanner, "hover: just past the dead band = closed");
    e = mv(r[0] + 20, r[1] + 5, -1); x->mouse(&e); tr_test_cursor_wnd = (void*)0x99; S->hoverWnds.push_back((void*)0x10); x->calc(0); tr_test_cursor_wnd = nullptr;
    CHECK(!S->inBanner, "hover: the mouse left the chart window = closed");
}

static void testBoard(TapeReader* x, mock::Host& H) {
    TRState* S = x->testState(); std::string v1, v2;
    H.draws.clear(); x->draw(); const bool a = bb::bbGet(bb::key("LRA_TRB_", S->symbol, S->spb, H.chart), v1);
    step(250); H.draws.clear(); x->draw(); const bool b = bb::bbGet(bb::key("LRA_TRB_", S->symbol, S->spb, H.chart), v2);
    long long m1 = 0, m2 = 0; bb::num(bb::split(v1, '|', 5)[0], m1); bb::num(bb::split(v2, '|', 5)[0], m2);
    CHECK(a && b && m2 == m1 + 250, "board: every draw refreshes the banner's heartbeat (LRA_TRB_ stamp = the draw's time)");
    bb::Rect rr; CHECK(bb::readBanner(S->symbol, S->spb, H.chart, tr_test_now_ms, rr) && rr.b - rr.t == tr::bannerH(true), "board: the reserved rectangle is the 2-line height (the LIQ label never jumps)");
    CHECK(!bb::readBanner(S->symbol, S->spb, "another chart", tr_test_now_ms, rr), "board: another chart's label = no banner there");
    // the Liquidity Profile's heartbeat as the Tape Reader sees it: an idle gap of 10 min, then repaints in either order - never a frame
    // without line 2; LQ gone without clearing -> line 2 goes after 3 draws
    bb::Warn w; w.on = true; w.favour = 1; w.name = "BUYERS HOLDING"; w.detail = "bids refilled at LonLO";
    int missing = 0; bb::publishWarn(S->symbol, S->spb, H.chart, tr_test_now_ms, w);
    for (int k = 0; k < 40; ++k) {
        step(k % 10 == 9 ? 600000 : 300);                                // every 10th repaint after a 10-minute idle gap
        const bool lqFirst = (k % 3) != 0;
        if (lqFirst) bb::publishWarn(S->symbol, S->spb, H.chart, tr_test_now_ms, w);
        H.draws.clear(); x->draw(); if (!textWith(H, "BUYERS HOLDING")) ++missing;
        if (!lqFirst) bb::publishWarn(S->symbol, S->spb, H.chart, tr_test_now_ms, w);
    }
    CHECK(missing == 0, "board: 40 repaints in either draw order with 10-minute idle gaps - line 2 never drops (" + std::to_string(missing) + ")");
    step(6000); int gone = -1; for (int k = 0; k < 6; ++k) { H.draws.clear(); x->draw(); if (!textWith(H, "BUYERS HOLDING")) { gone = k; break; } }
    CHECK(gone == 3, "board: the Liquidity Profile stopped publishing (removed without clearing): its last stamp counts once, then 3 more draws, then line 2 goes (" + std::to_string(gone) + ")");
    bb::clearWarn(S->symbol, S->spb, H.chart); H.draws.clear(); x->draw();
}

static void testRoundTrip(TapeReader*& x, mock::Host& H) {
    H.ppb = 24;                                                            // a wider chart: the banner (853 px in the mock font) has room to move
    std::remove((DIR + "/TapeReader.place-CL.txt").c_str());
    // the dialog (no bar size): opened, changed, OK
    H.period = ""; x->parmsLoad(); CHECK(H.lists[0] == tr::POS_DEFAULT && H.ints[1] == 0 && H.ints[2] == 0 && H.boxes[3] == 1, "round trip: no file = the dialog shows the defaults (Top left, 0, 0, background on)");
    H.lists[0] = 2; H.ints[1] = -120; H.ints[2] = 35; H.boxes[3] = 0; x->parmsApply(); H.period = "3 min";
    CHECK(get("TapeReader.place-CL.txt") == "2,-120,35,0\n", "round trip: Apply writes the file \"2,-120,35,0\"");
    // restart: a new extension (IRT reopened)
    x->destroy(); delete x; H.lists[0] = -99; H.ints[1] = H.ints[2] = 0; H.boxes[3] = 1;
    x = static_cast<TapeReader*>(CreateExtension()); x->setup(); x->calc(0); step(1100); H.draws.clear(); x->draw();
    TRState* S = x->testState();
    const int pe = H.x0 + (int)(H.bars.size() - 1) * H.ppb + H.ppb / 2, profiles = H.paneRight - 150 - 8 - (50 + 110), right = std::min(pe, profiles);
    const mock::Draw* hd = textWith(H, "Tape Reader v1.1.3");
    CHECK(S && S->place.pos == 2 && S->place.dx == -120 && S->place.dy == 35 && !S->bg && boxCount(H) == 0, "round trip: after the restart the chart reads Top right, -120, 35, no background");
    if (getenv("DBG")) { std::printf("banW %d lastBox %d %d %d %d turn '%s' bias '%s'\n", S->banW.w, S->lastBox.l, S->lastBox.t, S->lastBox.r, S->lastBox.b, S->live.turn.c_str(), S->live.biasText.c_str()); for (const mock::Draw& d : H.draws) if (d.type == "text") std::printf("  T %d-%d '%s'\n", d.l, d.r, d.text.c_str()); }
    if (getenv("DBG") && hd) std::printf("hd l %d t %d r %d right %d\n", hd->l, hd->t, hd->r, right);
    CHECK(hd && S->lastOk && S->lastBox.r == right - 120 && S->lastBox.t == H.paneTop + tr::TITLE_ROW + 35 && hd->l > S->lastBox.l, "round trip: drawn at the saved offset from Top right (text only)");
    H.period = ""; H.lists[0] = 0; H.ints[1] = 0; H.ints[2] = 0; H.boxes[3] = 1; x->parmsLoad(); H.period = "3 min";
    CHECK(H.lists[0] == 2 && H.ints[1] == -120 && H.ints[2] == 35 && H.boxes[3] == 0, "round trip: the dialog reopens filled from the file");
    std::remove((DIR + "/TapeReader.place-CL.txt").c_str()); step(1100); H.draws.clear(); x->draw();
    CHECK(x->testState()->place.pos == 0 && x->testState()->bg, "round trip: file removed = back to the defaults");
    H.ppb = 14;
}

static void testFuzz(TapeReader* x, mock::Host& H) {
    TRState* S = x->testState();
    const int pe = H.x0 + (int)(H.bars.size() - 1) * H.ppb + H.ppb / 2, profiles = H.paneRight - 150 - 8 - (50 + 110), right = std::min(pe, profiles);
    static const char* const TOK[] = { "0", "8", "9", "-1", "600", "-600", "601", "-601", "nan", "NaN", "inf", "-inf", "1e3", "3.5", " 4", "4 ", "+4", "0x10", "", "--5",
                                       "99999999999999999999", "-0", "00", "0007", "1,", ",", "\t", "\xff\xfe", "1", "2", "abc", "4\r", "5;6", "\"3\"" };
    const int NT = (int)(sizeof(TOK) / sizeof(TOK[0]));
    int outside = 0, badPlace = 0, crashes = 0, quiet = 0;
    for (int i = 0; i < 3000; ++i) {
        std::string line; const int nf = (int)(rnd() % 6);
        for (int f = 0; f < nf; ++f) { if (f) line += ","; line += TOK[rnd() % (unsigned)NT]; }
        if (i % 50 == 7) { line.clear(); for (int k = 0; k < (int)(rnd() % 200); ++k) line += (char)(rnd() % 256); }
        if (i % 97 == 3) line = std::string(70000, '7');                    // oversized
        put("TapeReader.place-CL.txt", line + (rnd() % 2 ? "\n" : ""));
        step(1100); H.draws.clear();
        try { x->draw(); } catch (...) { ++crashes; }
        if (!bp::posOk(S->place.pos) || !bp::offOk(S->place.dx) || !bp::offOk(S->place.dy)) ++badPlace;
        int r[4]; const mock::Draw* hd = textWith(H, "Tape Reader v1.1.3");
        if (bannerRect(H, r)) { if (r[0] < H.paneLeft + 4 || r[2] > right || r[1] < H.paneTop + tr::TITLE_ROW || r[3] > H.paneBottom - 2) ++outside; }
        else if (!hd) ++quiet;
    }
    CHECK(crashes == 0 && badPlace == 0, "fuzz: 3,000 garbage place files - no crash, the place always a valid Position / offsets");
    CHECK(outside == 0 && quiet == 0, "fuzz: the banner always drawn inside the area up to the last bar (" + std::to_string(outside) + " outside, " + std::to_string(quiet) + " missing)");
    put("TapeReader.place-CL.txt", "nan,inf,-inf,0\n"); step(1100); x->draw();
    CHECK(S->place.pos == tr::POS_DEFAULT && S->place.dx == 0 && S->place.dy == 0 && has(S->placeWhy, "place file ignored"), "fuzz: NaN / inf = the defaults, the reason kept for the status file");
    step(31000); x->draw(); { const std::string st = get("TapeReader.status-CL.txt"); CHECK(has(st, "BANNER,") && has(st, "place file ignored"), "fuzz: the fallback is reported on the BANNER status line"); }
    put("TapeReader.place-CL.txt", "3,601,0,1\n"); step(1100); x->draw();
    CHECK(S->place.dx == 0 && bp::posOk(S->place.pos) && has(S->placeWhy, "place file ignored"), "fuzz: an out-of-range offset (601) never applied (defaults + reason)");
    // the dialog: random values (INT extremes, list out of range) never reach the file as garbage
    std::remove((DIR + "/TapeReader.place-CL.txt").c_str());
    static const int IV[] = { INT_MIN, -601, -600, -1, 0, 1, 599, 600, 601, 9999, INT_MAX };
    int bad = 0;
    for (int i = 0; i < 1000; ++i) {
        H.period = ""; x->parmsLoad();
        if (rnd() % 2) H.lists[0] = (int)(rnd() % 20) - 5;
        if (rnd() % 2) H.ints[1] = IV[rnd() % 11];
        if (rnd() % 2) H.ints[2] = IV[rnd() % 11];
        if (rnd() % 2) H.boxes[3] = (int)(rnd() % 2);
        x->parmsApply(); H.period = "3 min";
        const std::string f = get("TapeReader.place-CL.txt"); bp::Place p; std::string why; std::vector<std::string> rest;
        std::string l = f; if (!l.empty() && l.back() == '\n') l.pop_back();
        if (!f.empty() && (!bp::parse(l, tr::POS_DEFAULT, p, &why, &rest) || rest.size() != 1 || (rest[0] != "0" && rest[0] != "1"))) ++bad;
    }
    CHECK(bad == 0, "fuzz: 1,000 random dialog Applies - the file always holds a valid \"pos,dx,dy,bg\"");
    std::remove((DIR + "/TapeReader.place-CL.txt").c_str()); H.lists[0] = -99; step(1100); x->draw();
}

static void testTwoCharts(TapeReader* x, mock::Host& H) {
    TRState* S = x->testState();
    H.ppb = 24; mock::Host H2; H2.chart = "CL 1 min chart"; H2.seconds = 60; H2.paneRight = 1600; H2.paneBottom = 420; H2.ppb = 25; hostBars(H2, 1);
    mock::current = &H2; TapeReader* y = static_cast<TapeReader*>(CreateExtension()); y->setup(); y->calc(0); H2.draws.clear(); y->draw(); TRState* S2 = y->testState();
    CHECK(S2 && S2 != S && S2->mkt == "CL" && S->mkt == "CL", "two charts of the same symbol: separate states");
    // the place is per market: set from chart 2's dialog, used by both, each inside its own area
    H2.period = ""; y->parmsLoad(); H2.lists[0] = 8; H2.ints[1] = -30; H2.ints[2] = -20; H2.boxes[3] = 1; y->parmsApply(); H2.period = "1 min";
    step(1100); H2.draws.clear(); y->draw(); int r2[4]; const bool b2 = bannerRect(H2, r2);
    mock::current = &H; H.draws.clear(); x->draw(); int r1[4]; const bool b1 = bannerRect(H, r1);
    const int pe1 = H.x0 + (int)(H.bars.size() - 1) * H.ppb + H.ppb / 2, pe2 = H2.x0 + (int)(H2.bars.size() - 1) * H2.ppb + H2.ppb / 2;
    const int right1 = std::min(pe1, H.paneRight - 150 - 8 - (50 + 110)), right2 = std::min(pe2, H2.paneRight - 150 - 8 - (50 + 110));
    CHECK(b1 && b2 && S->place.pos == 8 && S2->place.pos == 8 && S->place.dx == -30 && S2->place.dy == -20, "two charts: the market's place (Bottom right, -30, -20) on both");
    if (getenv("DBG")) std::printf("r1 %d %d %d %d right1 %d pb %d | r2 %d %d %d %d right2 %d pb %d\n", r1[0], r1[1], r1[2], r1[3], right1, H.paneBottom, r2[0], r2[1], r2[2], r2[3], right2, H2.paneBottom);
    CHECK(r1[2] == right1 - 30 && r1[3] == H.paneBottom - 2 - 20 && r2[2] == right2 - 30 && r2[3] == H2.paneBottom - 2 - 20, "two charts: each banner at the offset from its OWN pane's bottom right / last bar");
    CHECK(r1[2] != r2[2] && r1[3] != r2[3], "two charts: different panes -> different rects (no shared geometry)");
    // each chart only its own Liquidity warning (keyed by the chart label); separate stable widths
    bb::Warn w; w.on = true; w.favour = 1; w.name = "BUYERS HOLDING"; w.detail = "bids refilled 3 times at LonLO (rebuilt 96%)";
    bb::publishWarn(S2->symbol, S2->spb, H2.chart, tr_test_now_ms, w);
    mock::current = &H2; H2.draws.clear(); y->draw(); const bool w2 = textWith(H2, "BUYERS HOLDING") != nullptr;
    mock::current = &H; H.draws.clear(); x->draw(); const bool w1 = textWith(H, "BUYERS HOLDING") != nullptr;
    CHECK(w2 && !w1, "two charts: the 1-min chart's warning shows only on the 1-min chart");
    CHECK(S->banW.w != S2->banW.w || S2->warnSeen != S->warnSeen, "two charts: separate stable widths / warnings");
    // chart 2 removed: its banner entry goes, chart 1's stays
    bb::Rect rr; mock::current = &H2; y->destroy(); delete y; mock::current = &H;
    CHECK(!bb::readBanner("CLX6", 60, H2.chart, tr_test_now_ms, rr) && bb::readBanner(S->symbol, S->spb, H.chart, tr_test_now_ms, rr), "two charts: removing one clears only its banner entry");
    std::remove((DIR + "/TapeReader.place-CL.txt").c_str()); step(1100); H.ppb = 14; H.draws.clear(); x->draw();
}

int main() {
    char tmpl[] = "/tmp/trbanXXXXXX"; DIR = mkdtemp(tmpl); setenv("USERPROFILE", DIR.c_str(), 1);
    tr_test_unix = (long long)std::time(nullptr);
    writeWorld();
    mock::Host H; mock::current = &H; hostBars(H, 1);
    TapeReader* x = static_cast<TapeReader*>(CreateExtension()); x->setup(); x->calc(0); H.draws.clear(); x->draw();
    CHECK(x->testState() && textWith(H, "Tape Reader v1.1.3"), "start: the banner is drawn");
    testJitter(x, H);
    testHover(x, H);
    testBoard(x, H);
    testRoundTrip(x, H);
    testFuzz(x, H);
    testTwoCharts(x, H);
    x->destroy(); delete x;
    std::string cmd = "rm -rf '" + DIR + "'"; if (std::system(cmd.c_str()) != 0) std::printf("note: temp dir left\n");
    std::printf("tr banner: %d passed, %d failed\n", g_pass, g_fail);
    return g_fail ? 1 : 0;
}
