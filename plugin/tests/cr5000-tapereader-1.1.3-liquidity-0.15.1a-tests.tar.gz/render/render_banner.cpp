// render_banner.cpp -- dumps lsTapeReader 1.1.3's banner items (tr::layoutBanner: the SAME function the plugin's draw() executes) for
// the ES 3-min chart of Rassul's 07:09 screenshot: A = line 1 only, B = + the Liquidity warning (line 2), C = B with the hover detail.
// Measured with the Liberation Sans advance table the mock SDK uses (metric-compatible with IRT's Helvetica / Arial).
#include "../tr/TapeReaderLogic.h"
#include "../tr/trtests_of/mock/tr_widths.h"
#include <cstdio>
static int meas(const std::string& s, int pt, bool bold) { if (pt < 6) pt = 6; if (pt > 14) pt = 14; int w = 0; for (unsigned char c : s) w += c >= 32 ? TR_W[bold ? 1 : 0][pt - 6][c - 32] : 0; return w; }
int main() {
    tr::Measure M = meas;
    tr::Read R; R.ok = true; R.ct = "7:09 AM"; R.bias = tr::NEUTRAL; R.biasText = "MIXED"; R.centreDir = 1;
    const std::string sep = trt::text("centre.sep");
    R.turn = "Turn up at PFH 83%" + sep + "Swing 52+ 34%" + sep + "Next: 7874.25 ONH";
    R.buyers = "Pulled 3170 bids, 4367 lots (2.3x) at MQ+CR0 - support leaving; defending MQ+CR0: 3550 bids, 4751 lots (2.1x) added, 96% rebuilt";
    R.sellers = ""; R.buyImpl = tr::BEAR; R.sellImpl = tr::NEUTRAL;
    R.opt[0] = "HVL0 7855 wall 0.5x (+) ? \xB7 above HVL ?"; R.opt[1] = "Dealers sell 1.1K ES ($436M) 7.3x ? \xB7 call volume 5.1x, fear up ?";
    const std::string head = std::string("Tape Reader v") + tr::VERSION + "  \xB7  " + R.ct;
    bb::Warn none, w; w.on = true; w.favour = -1; w.name = "SELLERS PULLING"; w.detail = "sellers pulling their offers (155%) while buyers keep lifting the offer";
    tr::Box area; area.l = 4; area.t = 66 + tr::TITLE_ROW; area.r = 724; area.b = 584;      // the screenshot's price pane: top 66, last bar x 724
    bp::Place pl;
    const int need = std::max(tr::bannerNeed(R, head, none, M), tr::bannerNeed(R, head, w, M));   // the stable width (StableW keeps the widest)
    struct Sc { const char* id; const bb::Warn* W; bool hover; } sc[3] = { { "A", &none, false }, { "B", &w, false }, { "C", &w, true } };
    for (const Sc& s : sc) {
        const tr::Banner B = tr::layoutBanner(R, head, *s.W, area, pl, need, true, s.hover, M);
        std::printf("scene|%s|%d|%d|%d|%d|%d\n", s.id, B.box.l, B.box.t, B.box.r, B.box.b, B.box.t + tr::bannerH(true));
        for (const tr::Item& it : B.L.items)
            std::printf("%s|%s|%d|%d|%d|%d|%06x|%06x|%d|%d|%s\n", s.id, it.k == tr::K_RECT ? "rect" : "text", it.l, it.t, it.r, it.b, it.c1 & 0xFFFFFF, it.c2 == 0xFFFFFFFFu ? 0x1000000 : (it.c2 & 0xFFFFFF), it.fs, it.bold ? 1 : 0, it.s.c_str());
    }
}
