# render_banner.py -- composes banner-final.png: Rassul's ES 3-min screenshot (07:09, top-left of the price pane) with the Tape Reader
# 1.1.3 banner items dumped by render_banner.cpp (tr::layoutBanner, the plugin's own layout) drawn over it, the old Liquidity warning /
# LIQ label removed (the hand-off) and the LIQ label redrawn where Liquidity 0.15.x puts it: under the banner's reserved 2-line rect.
import sys
from PIL import Image, ImageDraw, ImageFont
SHOT, DUMP, OUT = sys.argv[1], sys.argv[2], sys.argv[3]
D = '/usr/share/fonts/truetype/liberation/'
def font(pt, bold, s=1): return ImageFont.truetype(D + ('LiberationSans-Bold.ttf' if bold else 'LiberationSans-Regular.ttf'), round(pt * 4 / 3) * s)
def rgb(h): v = int(h, 16); return ((v >> 16) & 255, (v >> 8) & 255, v & 255)
rows = [l.rstrip('\n').split('|') for l in open(DUMP, encoding='cp1252')]
shot = Image.open(SHOT).convert('RGB')
CW, CH = 760, 330                                           # the top-left region of the price pane
titles = {'A': 'A  no Liquidity warning: one line (bias  ·  turn  ·  swing  ·  next)',
          'B': 'B  + the Liquidity warning handed over: line 2 (tag outlined in its colour, text grey)',
          'C': 'C  mouse over the banner: BUYERS / SELLERS / OPTIONS detail right under it (10 pt); gone when the mouse leaves'}
panels = []
for sid in 'ABC':
    sc = next(r for r in rows if r[0] == 'scene' and r[1] == sid)
    resv_b = int(sc[6])
    im = shot.crop((0, 0, CW, CH)).copy(); d = ImageDraw.Draw(im)
    # the hand-off: the Liquidity Profile no longer draws its warning (old y 86-113) nor its label at y 113; its column starts lower
    d.rectangle([0, 86, 724, 113], fill=(0, 0, 0))
    hdr = resv_b + 4; top = hdr + 18 + 2
    d.rectangle([0, 114, 110, top - 1], fill=(0, 0, 0))      # the column (book rows / the 294 zone) is clipped at its new top
    d.text((3, hdr + 9), 'LIQ TESTING', font=font(11, True), fill=(156, 163, 175), anchor='lm')
    for r in rows:
        if r[0] != sid: continue
        kind, l, t, rr, b = r[1], int(r[2]), int(r[3]), int(r[4]), int(r[5])
        if kind == 'rect':
            if r[7] == '1000000': d.rectangle([l, t, rr, b], outline=rgb(r[6]), width=1)
            else: d.rectangle([l, t, rr, b], fill=rgb(r[7]), outline=rgb(r[6]), width=1)
        else:
            d.text((l, (t + b) / 2), '|'.join(r[10:]), font=font(int(r[8]), r[9] == '1'), fill=rgb(r[6]), anchor='lm')
    panels.append((sid, im))
W = CW + 24; H = 40 + sum(CH + 34 for _ in panels) + 10
out = Image.new('RGB', (W, H), (24, 26, 31)); d = ImageDraw.Draw(out)
d.text((12, 12), 'Tape Reader 1.1.3 banner on ES 3-min (layout from tr::layoutBanner - the plugin\'s own code; chart = your 07:09 screenshot)', font=font(10, True), fill=(235, 238, 242))
y = 40
for sid, im in panels:
    d.text((12, y + 6), titles[sid], font=font(9, True), fill=(250, 204, 21)); y += 26
    out.paste(im, (12, y)); d.rectangle([11, y - 1, 12 + CW, y + CH], outline=(70, 75, 85)); y += CH + 8
out.save(OUT); print('saved', OUT, out.size)
