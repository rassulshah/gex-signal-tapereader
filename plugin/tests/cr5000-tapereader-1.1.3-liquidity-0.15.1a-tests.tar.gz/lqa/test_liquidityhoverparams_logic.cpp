// test_liquidityhoverparams_logic.cpp -- Liquidity Profile 0.15.2 (LH200 hover study, 2026-10-14): the LRA-LiqHover-<MKT>.csv parser
// (the six real files the nightly wrote tonight, plus malformed ones), how each market's verdicts resolve (PARAM line first, then the
// default-band READ line, 'reword' = measurement only), stale / future / missing / garbled files, and the hover text + colour per market
// and status (as price came / Hit . kept NN% (TT%) - absorbing).
//   g++ -std=c++17 -Wall -Wextra -I. test_liquidityhoverparams_logic.cpp -o thp && ./thp      (run from the folder with hp_fixtures/)
#include "LiquidityProfileLogic.h"
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>

static int fails = 0, passes = 0;
#define CHECK(cond, msg) do { if (cond) ++passes; else { ++fails; std::printf("FAIL %s:%d %s\n", __FILE__, __LINE__, msg); } } while (0)
using namespace lqp;
static const std::string DOT = "\xB7";
static std::string fixDir = "hp_fixtures";
static std::string readAll(const std::string& p) { std::ifstream f(p.c_str(), std::ios::binary); std::stringstream s; s << f.rdbuf(); return s.str(); }
static const long long NOW = 1791957600LL;          // 2026-10-14 ~01:00 CT (the files were written 00:53 CT)
static HoverParams real(const char* m) {
    const std::string body = readAll(fixDir + "/LRA-LiqHover-" + m + ".csv");
    return parseHoverParams(body, m, NOW - 600);
}
static bool near(double a, double b) { return std::fabs(a - b) < 1e-9; }
static const char* HEAD = "kind,name,value,source,status,n,rate,base,lift_x,t_build,t_validate,why\n";
static std::string file(const std::string& m, const std::string& rows) { return "# LRA-LiqHover-" + m + ".csv - test (liq_hover_params 1.0.0, 2026-10-14 00:53 CT)\n" + HEAD + rows; }

// ---- the six real files: what each market's hover may say (the study's statuses, resolved)
static void test_real_files() {
    HoverParams es = real("ES"), nq = real("NQ"), cl = real("CL"), gc = real("GC"), hg = real("HG"), eu = real("EU");
    for (const HoverParams* p : {&es, &nq, &cl, &gc, &hg, &eu}) CHECK(p->file == HP_OK && p->why == "ok", "real file parses clean");
    std::printf("  ES %s\n  NQ %s\n  CL %s\n  GC %s\n  HG %s\n  EU %s\n", hoverParamsText(es).c_str(), hoverParamsText(nq).c_str(), hoverParamsText(cl).c_str(),
                hoverParamsText(gc).c_str(), hoverParamsText(hg).c_str(), hoverParamsText(eu).c_str());
    // ES: came_band learning (READ building learning) / came_leave_band -0.3 proven / keep_line 0.8 '?'
    CHECK(es.build.status == RS_LEARNING && near(es.build.line, 0.10), "ES building: learning (measurement only)");
    CHECK(es.leave.status == RS_PROVEN && near(es.leave.line, 0.30) && es.leave.data, "ES leaving: -30% proven");
    CHECK(es.keep.status == RS_Q && near(es.keep.line, 0.80), "ES kept: 80% '?' (VALIDATE t +2.8, under the 3 for proven)");
    // NQ: came_band 0.2 '?' / came_leave_band -0.5 proven / keep_line learning (READ kept learning)
    CHECK(nq.build.status == RS_Q && near(nq.build.line, 0.20), "NQ building: +20% '?'");
    CHECK(nq.leave.status == RS_PROVEN && near(nq.leave.line, 0.50), "NQ leaving: -50% proven (the PARAM line)");
    CHECK(nq.keep.status == RS_LEARNING, "NQ kept: learning (measurement only)");
    // CL: everything learning
    CHECK(cl.build.status == RS_LEARNING && cl.leave.status == RS_LEARNING && cl.keep.status == RS_LEARNING, "CL: all learning");
    // GC: leave PARAM learning -> READ 'As price came: leaving' '?' at the default 10%; keep 0.5 proven
    CHECK(gc.build.status == RS_LEARNING, "GC building: learning");
    CHECK(gc.leave.status == RS_Q && near(gc.leave.line, 0.10) && !gc.leave.data, "GC leaving: -10% '?' (the default-band READ line)");
    CHECK(gc.keep.status == RS_PROVEN && near(gc.keep.line, 0.50), "GC kept: 50% proven");
    // HG: came_band 'reword' -> measurement only; keep 0.65 '?'
    CHECK(hg.build.status == RS_REWORD && !verdict(hg.build), "HG building: reword = measurement only");
    CHECK(hg.leave.status == RS_LEARNING, "HG leaving: learning");
    CHECK(hg.keep.status == RS_Q && near(hg.keep.line, 0.65), "HG kept: 65% '?'");
    // EU: keep 1.0 proven
    CHECK(eu.build.status == RS_LEARNING && eu.leave.status == RS_LEARNING, "EU building / leaving: learning");
    CHECK(eu.keep.status == RS_PROVEN && near(eu.keep.line, 1.00), "EU kept: 100% proven");
    // NG: no file at all -> measurement only
    const HoverParams ng = parseHoverParams(readAll(fixDir + "/LRA-LiqHover-NG.csv"), "NG", NOW);
    CHECK(ng.file == HP_GARBLED && !verdict(ng.build) && !verdict(ng.leave) && !verdict(ng.keep), "NG (no file): no verdicts");
    CHECK(HoverParams().file == HP_MISSING && !verdict(HoverParams().keep), "the default (missing) params have no verdicts");
}

// ---- the hover text per market and status (support zone unless said)
static void test_text_per_market() {
    const long long now = NOW;
    HoverParams es = hoverEffective(real("ES"), now), nq = hoverEffective(real("NQ"), now), cl = hoverEffective(real("CL"), now);
    HoverParams gc = hoverEffective(real("GC"), now), hg = hoverEffective(real("HG"), now), eu = hoverEffective(real("EU"), now);
    // Hit line
    HoverRow r = hitRow(BID, 140, 366, 420, es);    // 87%
    CHECK(r.text == "Hit 140 lots " + DOT + " kept 87% (80%) - absorbing ?" && r.ink == INK_GREEN, "ES: kept 87% (80%) - absorbing ?, green at support");
    r = hitRow(ASK, 140, 300, 420, es);              // 71%
    CHECK(r.text == "Hit 140 lots " + DOT + " kept 71% (80%)" && r.ink == INK_WHITE, "ES: under 80% -> numbers only, white");
    r = hitRow(BID, 90, 300, 420, nq);
    CHECK(r.text == "Hit 90 lots " + DOT + " kept 71%" && r.ink == INK_WHITE, "NQ: measurement only (learning), no (TT%)");
    r = hitRow(BID, 90, 400, 420, cl);
    CHECK(r.text == "Hit 90 lots " + DOT + " kept 95%" && r.ink == INK_WHITE, "CL: measurement only");
    r = hitRow(ASK, 60, 120, 200, gc);              // 60% >= 50%
    CHECK(r.text == "Hit 60 lots " + DOT + " kept 60% (50%) - absorbing" && r.ink == INK_RED, "GC: kept 60% (50%) - absorbing, red at resistance");
    r = hitRow(BID, 60, 90, 200, gc);
    CHECK(r.text == "Hit 60 lots " + DOT + " kept 45% (50%)" && r.ink == INK_WHITE, "GC: under the line, white");
    r = hitRow(BID, 40, 140, 200, hg);              // 70% >= 65%
    CHECK(r.text == "Hit 40 lots " + DOT + " kept 70% (65%) - absorbing ?" && r.ink == INK_GREEN, "HG: kept 70% (65%) - absorbing ?");
    r = hitRow(BID, 40, 199, 200, eu);              // 99.5% shows 100%: the shown number decides
    CHECK(r.text == "Hit 40 lots " + DOT + " kept 100% (100%) - absorbing" && r.ink == INK_GREEN, "EU: 199/200 shows 100% = absorbing (what he sees decides)");
    r = hitRow(BID, 40, 198, 200, eu);
    CHECK(r.text == "Hit 40 lots " + DOT + " kept 99% (100%)" && r.ink == INK_WHITE, "EU: 99% (100%) = under the line, white");
    r = hitRow(BID, 40, 200, 200, eu);
    CHECK(r.text == "Hit 40 lots " + DOT + " kept 100% (100%) - absorbing" && r.ink == INK_GREEN, "EU: exactly 100% = absorbing");
    // As price came
    r = cameRow(BID, 300, 330, 0.10, es);            // +10%: ES building learning -> measurement
    CHECK(r.text == "As price came: up 10%" && r.ink == INK_WHITE, "ES building: 'up 10%' white (no word)");
    r = cameRow(BID, 300, 200, 0.10, es);            // -33% >= 30% proven
    CHECK(r.text == "As price came: down 33% - leaving" && r.ink == INK_RED, "ES support leaving 33%: red, proven");
    r = cameRow(BID, 1000, 705, 0.10, es);          // -29.5% shows 30%: the shown number decides
    CHECK(r.text == "As price came: down 30% - leaving", "ES -29.5% shows 'down 30%' -> leaving at the 30% line");
    r = cameRow(BID, 1000, 706, 0.10, es);
    CHECK(r.text == "As price came: down 29%" && r.ink == INK_WHITE, "ES -29.4%: 'down 29%', no word");
    r = cameRow(BID, 300, 240, 0.10, es);            // -20%: under ES's 30% band
    CHECK(r.text == "As price came: down 20%" && r.ink == INK_WHITE, "ES -20%: under the -30% band, measurement only");
    r = cameRow(BID, 300, 290, 0.10, es);
    CHECK(r.text == "As price came: unchanged" && r.ink == INK_WHITE, "ES -3%: unchanged");
    r = cameRow(BID, 300, 360, 0.10, nq);            // +20% '?'
    CHECK(r.text == "As price came: up 20% - building ?" && r.ink == INK_GREEN, "NQ +20%: building ?, green at support");
    r = cameRow(ASK, 300, 360, 0.10, nq);
    CHECK(r.text == "As price came: up 20% - building ?" && r.ink == INK_RED, "NQ resistance building ?: red");
    r = cameRow(BID, 300, 345, 0.10, nq);            // +15%: under NQ's 20%
    CHECK(r.text == "As price came: up 15%" && r.ink == INK_WHITE, "NQ +15%: under its band, measurement only");
    r = cameRow(BID, 300, 120, 0.10, nq);            // -60%
    CHECK(r.text == "As price came: down 60% - leaving" && r.ink == INK_RED, "NQ -60%: leaving, red (proven at -50%)");
    r = cameRow(BID, 300, 210, 0.10, nq);            // -30%
    CHECK(r.text == "As price came: down 30%" && r.ink == INK_WHITE, "NQ -30%: under its -50% band, measurement only");
    r = cameRow(BID, 300, 255, 0.10, gc);            // -15% '?'
    CHECK(r.text == "As price came: down 15% - leaving ?" && r.ink == INK_RED, "GC -15%: leaving ?, red");
    r = cameRow(ASK, 300, 255, 0.10, gc);
    CHECK(r.text == "As price came: down 15% - leaving ?" && r.ink == INK_GREEN, "GC resistance leaving ?: green (offers leaving = good for buyers, as 0.15.1)");
    r = cameRow(BID, 300, 150, 0.10, cl);
    CHECK(r.text == "As price came: down 50%" && r.ink == INK_WHITE, "CL: measurement only");
    r = cameRow(BID, 300, 450, 0.10, hg);
    CHECK(r.text == "As price came: up 50%" && r.ink == INK_WHITE, "HG building is 'reword': measurement only");
    r = cameRow(BID, 300, 150, 0.10, eu);
    CHECK(r.text == "As price came: down 50%" && r.ink == INK_WHITE, "EU: measurement only");
    r = cameRow(BID, -1, 150, 0.10, es);
    CHECK(r.text.empty(), "no baseline: no line");
    r = cameRow(BID, 300, 0, 0.10, es);
    CHECK(r.text == "As price came: down 100% - leaving" && r.ink == INK_RED, "all gone: down 100% - leaving");
}

// ---- the parser: malformed files never give a verdict, odd-but-valid ones parse
static void test_parser() {
    HoverParams p = parseHoverParams(file("ES", "PARAM,came_band,0.2,data,?,,,,,1,2,\"a, quoted, why\"\r\nPARAM,keep_line,0.9,data,proven,,,,,1,2,\"x\"\r\n"), "ES", NOW);
    CHECK(p.file == HP_OK && p.build.status == RS_Q && near(p.build.line, 0.2) && p.keep.status == RS_PROVEN && near(p.keep.line, 0.9), "CRLF + quoted commas");
    p = parseHoverParams(file("ES", "PARAM,keep_line,0.9,data,PROVEN,,\nPARAM,came_band,0.2,data,?,,\n"), "ES", NOW);
    CHECK(p.file == HP_OK && p.keep.status == RS_LEARNING && p.why == "1 bad line(s) skipped", "unknown status word: that line ignored (counted)");
    p = parseHoverParams(file("ES", "PARAM,keep_line,0.9x,data,proven,,\nPARAM,came_band,0.2,data,?,,\n"), "ES", NOW);
    CHECK(p.file == HP_OK && p.keep.status == RS_LEARNING, "number with junk: ignored");
    p = parseHoverParams(file("ES", "PARAM,keep_line,nan,data,proven,,\nPARAM,came_band,inf,data,proven,,\nPARAM,came_leave_band,-0.3,data,proven\n"), "ES", NOW);
    CHECK(p.file == HP_OK && p.keep.status == RS_LEARNING && p.build.status == RS_LEARNING && p.leave.status == RS_PROVEN, "NaN / Inf ignored, the good line kept");
    p = parseHoverParams(file("ES", "PARAM,keep_line,5,data,proven,,\nPARAM,came_band,-0.2,data,proven,,\nPARAM,came_leave_band,0.3,data,proven,,\nPARAM,size_ratio,2.0,default,learning\n"), "ES", NOW);
    CHECK(p.file == HP_OK && !verdict(p.keep) && !verdict(p.build) && !verdict(p.leave), "out-of-range / wrong-sign values ignored (defaults)");
    p = parseHoverParams(file("ES", "PARAM,keep_line,0.8,data,proven,\"unterminated\n"), "ES", NOW);
    CHECK(p.file == HP_GARBLED, "the only PARAM line unterminated: garbled");
    p = parseHoverParams(file("NQ", "PARAM,keep_line,0.8,data,proven,,\n"), "ES", NOW);
    CHECK(p.file == HP_GARBLED && p.why == "not this market's file" && !verdict(p.keep), "NQ's file under ES's name: garbled, no verdict");
    p = parseHoverParams(std::string(HEAD) + "PARAM,keep_line,0.8,data,proven,,\n", "ES", NOW);
    CHECK(p.file == HP_GARBLED && p.why == "no LRA-LiqHover header", "no header comment: garbled");
    p = parseHoverParams("# LRA-LiqHover-ES.csv x\nPARAM,keep_line,0.8,data,proven,,\n", "ES", NOW);
    CHECK(p.file == HP_GARBLED && p.why == "no column header", "no column header: garbled");
    p = parseHoverParams(file("ES", "READ,\"As price came: building\",,,proven,1,1,1,1,1,1,x\n"), "ES", NOW);
    CHECK(p.file == HP_GARBLED && p.why == "no PARAM line", "no PARAM line: garbled");
    p = parseHoverParams("", "ES", NOW);
    CHECK(p.file == HP_GARBLED && !verdict(p.keep), "empty file: garbled");
    p = parseHoverParams(std::string("\xEF\xBB\xBF") + file("ES", "PARAM,keep_line,0.8,data,proven,,\n"), "ES", NOW);
    CHECK(p.file == HP_GARBLED, "a BOM before the header: refused (the nightly writes none)");
    p = parseHoverParams(file("ES", "PARAM,keep_line,0.8,data,proven\nPARAM,size_ratio,2.0,default,learning,,\n"), "ES", NOW);
    CHECK(p.file == HP_OK && p.keep.status == RS_PROVEN, "exactly 5 columns is enough; other PARAM names accepted");
    p = parseHoverParams(file("ES", "PARAM,came_leave_band,-0.3,default,learning,,\nREAD,\"As price came: leaving\",,,proven,1,1,1,1,1,1,x\n"), "ES", NOW);
    CHECK(p.leave.status == RS_PROVEN && near(p.leave.line, 0.10) && !p.leave.data, "PARAM learning -> the READ line's status at the default 10%");
    p = parseHoverParams(file("ES", "PARAM,came_leave_band,-0.3,data,reword,,\nREAD,\"As price came: leaving\",,,proven,1,1,1,1,1,1,x\n"), "ES", NOW);
    CHECK(p.leave.status == RS_REWORD && !verdict(p.leave), "PARAM reword wins over a proven READ: measurement only");
    p = parseHoverParams(file("ES", "PARAM,keep_line,0.8,default,learning,,\nREAD,\"Hit . zone kept 80%+ of its lots to the decision\",,,reword,1,1,1,1,1,1,x\n"), "ES", NOW);
    CHECK(p.keep.status == RS_REWORD && !verdict(p.keep), "READ reword: measurement only");
    {   std::string rows; for (int i = 0; i < 600; ++i) rows += "READ,\"x\",,,learning,1,1,1,1,1,1,x\n";
        rows += "PARAM,keep_line,0.8,data,proven,,\n";
        p = parseHoverParams(file("ES", rows), "ES", NOW);
        CHECK(p.file == HP_GARBLED, "only the first 512 lines are read (a PARAM line after them is not seen)"); }
    {   std::string q = "a"; std::vector<std::string> f;
        CHECK(csvFields("a,\"b,c\",\"d\"\"e\",", f) && f.size() == 4 && f[1] == "b,c" && f[2] == "d\"e" && f[3].empty(), "csvFields: quotes, doubled quotes, trailing empty");
        CHECK(!csvFields("a,\"b", f), "csvFields: unterminated quote = false"); (void)q; }
    CHECK(statusOf("proven") == RS_PROVEN && statusOf("?") == RS_Q && statusOf("learning") == RS_LEARNING && statusOf("-") == RS_LEARNING
          && statusOf("reword") == RS_REWORD && statusOf("") == -1 && statusOf("Proven") == -1, "status words");
}

// ---- stale / future / missing: the measurement only
static void test_staleness() {
    const HoverParams es = real("ES");
    CHECK(hoverEffective(es, es.fileSec + 3600).file == HP_OK, "1 hour old: ok");
    CHECK(hoverEffective(es, es.fileSec + 5 * 86400).file == HP_OK, "exactly 5 days: still ok (a missed night + a weekend)");
    HoverParams e = hoverEffective(es, es.fileSec + 5 * 86400 + 1);
    CHECK(e.file == HP_STALE && !verdict(e.keep) && !verdict(e.leave) && e.why == "stale", "older than 5 days: stale, no verdicts");
    CHECK(hitRow(BID, 140, 366, 420, e).text == "Hit 140 lots " + DOT + " kept 87%", "stale ES: kept 87%, no (TT%), no verdict");
    CHECK(cameRow(BID, 300, 200, 0.10, e).text == "As price came: down 33%", "stale ES: leaving word dropped");
    e = hoverEffective(es, es.fileSec - 2 * 86400);
    CHECK(e.file == HP_STALE, "a file stamped 2 days in the future (clock off): not trusted");
    CHECK(hoverEffective(es, 0).file == HP_OK, "no clock (0): the file's state as read");
    const HoverParams m; e = hoverEffective(m, NOW);
    CHECK(e.file == HP_MISSING && !verdict(e.build) && hoverParamsText(e).compare(0, 7, "missing") == 0, "missing stays missing");
    CHECK(hoverParamsText(hoverEffective(es, es.fileSec + 10)) == "ok (ok),building 0.10 learning,leaving 0.30 proven,kept 0.80 ?", "status text");
}

// ---- kept %
static void test_kept() {
    CHECK(keptPct(366, 420) == 87 && keptPct(0, 420) == 0 && keptPct(840, 420) == 200, "kept = now / arrival");
    CHECK(keptPct(1, 0) == -1 && keptPct(1, -5) == -1 && keptPct(-1, 10) == -1, "unknown arrival / bad now: -1");
    CHECK(keptPct(1e12, 1) == 999, "capped at 999 for the text");
    CHECK(keptPct(std::numeric_limits<double>::quiet_NaN(), 10) == -1 && keptPct(10, std::numeric_limits<double>::infinity()) == -1, "NaN / Inf: -1");
}

// ---- the whole hover per market (row order and the unchanged rows kept from 0.15.1)
static void test_rows_per_market() {
    HoverIn h; h.side = BID; h.lo = 31440; h.hi = 31448; h.tick = 0.25; h.lots = 366; h.bx = 1.6; h.feedReady = true;
    h.mk.ok = true; h.mk.orders = 96; h.mk.lots = 366; h.mk.top = 44; h.mk.coverage = 1.0;
    h.nearBase = 520; h.inZone = true; h.hit = 140; h.arrLots = 420; h.hp = hoverEffective(real("ES"), NOW);
    std::vector<HoverRow> v = hoverRows(h);
    CHECK(v.size() == 4, "ES support being hit: 4 rows");
    CHECK(v.size() == 4 && v[0].text == "Support 7,860.00 - 7,862.00 " + DOT + " 366 lots (1.6x)" && v[0].ink == INK_GREEN, "1 header unchanged (side colour; (1.6x) display only)");
    CHECK(v.size() == 4 && v[1].text == "Orders 96 " + DOT + " avg 3.8 lots " + DOT + " Top order 12%", "2 orders unchanged");
    CHECK(v.size() == 4 && v[2].text == "As price came: down 30% - leaving" && v[2].ink == INK_RED, "3 ES leaving 30% (its band), red");
    CHECK(v.size() == 4 && v[3].text == "Hit 140 lots " + DOT + " kept 87% (80%) - absorbing ?" && v[3].ink == INK_GREEN, "4 ES kept, absorbing ?");
    h.mk.top = 300; v = hoverRows(h);
    CHECK(v.size() == 5 && v[2].text == "Mostly one order - may not reload ?" && v[2].ink == INK_WHITE, "one-order line unchanged, same place");
    h.hp = HoverParams(); v = hoverRows(h);
    CHECK(v.size() == 5 && v[3].text == "As price came: down 30%" && v[4].text == "Hit 140 lots " + DOT + " kept 87%", "no file: the measurement only");
    for (auto& x : v) CHECK(x.ink != INK_GREEN || x.text.compare(0, 7, "Support") == 0, "no file: nothing green except the side header");
}

int main(int argc, char** argv) {
    if (argc > 1) fixDir = argv[1]; else if (const char* e = std::getenv("LQ_HP_FIX")) fixDir = e;
    test_real_files(); test_text_per_market(); test_parser(); test_staleness(); test_kept(); test_rows_per_market();
    std::printf("hover params: %d passed, %d failed\n", passes, fails);
    return fails ? 1 : 0;
}
