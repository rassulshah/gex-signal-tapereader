#!/usr/bin/env python3
# CR5000 common Liquidity patch (applied to lqa = 0.15.2-based and lqb = 0.15.1-based copies):
#  - the Tape Reader heartbeat (bb::Beat) instead of the 60 s age; publish-state kept; the warning entry cleared on done / destroy
#  - the LIQ label Offset X / Y (per market, in <name>.size-<MKT>.txt "w,f,dx,dy"), dialog filled from the file, DlgSnap on Apply
#  - versions
import sys, re
d, ver, oldver = sys.argv[1], sys.argv[2], sys.argv[3]
p = d + '/LiquidityProfile.cpp'
s = open(p, encoding='latin-1').read()

def rep(old, new, count=1):
    global s
    n = s.count(old)
    if n != count:
        raise SystemExit('pattern count %d != %d: %r' % (n, count, old[:120]))
    s = s.replace(old, new)

# versions + header comment (the comment mentions the hand-off; add the CR5000 line)
rep('#define LQ_VERSION "%s"' % oldver, '#define LQ_VERSION "%s"' % ver)
rep('p->setVersion("%s");' % oldver, 'p->setVersion("%s");' % ver)
first = s.index('lsLiquidityProfile  (') + len('lsLiquidityProfile  (')
s = s[:first] + ('%s, 2026-10-14, CR5000: the Tape Reader hand-off decided by a heartbeat (BannerBoard 1.0.1 bb::Beat: present while its '
                 'stamp moves / under 5 s old / for 3 draws - no flicker on an idle chart\'s first repaint), the warning entry cleared when '
                 'this indicator is removed, and the LIQ label gets Offset X / Y (px, -600..600, per market in LiquidityProfile.size-<MKT>.txt '
                 '"w,f,dx,dy"; the dialog is filled from the file and a control he did not touch keeps the file\'s value; setParameterVersion '
                 '2: IRT resets the saved rows once, the file keeps Width / Font); ' % ver) + s[first:]

rep('#include "BannerBoard.h"           // (0.15.3) the one top banner: the warning handed to the Tape Reader',
    '#include "BannerBoard.h"           // (0.15.3) the one top banner: the warning handed to the Tape Reader\n'
    '#include "BoxPlace.h"              // (CR5000) the LIQ label Offset X / Y: validation + clamping (shared, as is)')

# state
rep('    bool trBanner = false; bb::Rect trRect; long long handed = 0;',
    '    bool trBanner = false; bb::Rect trRect; long long handed = 0;\n'
    '    bb::Beat trBeat; std::string chartKey; bool published = false;   // (CR5000) the Tape Reader heartbeat; this chart\'s key; my warning entry is out\n'
    '    int labDx = 0, labDy = 0; std::string sizeWhy;                    // (CR5000) the LIQ label Offset X / Y (size file); why the file was refused')

# the hand-off read: heartbeat
rep('        bb::publishWarn(S.symbol, S.spb, chart, now, bw);\n        S.trBanner = bb::readBanner(S.symbol, S.spb, chart, now, S.trRect);',
    '        bb::publishWarn(S.symbol, S.spb, chart, now, bw); S.chartKey = chart; S.published = !S.symbol.empty();\n'
    '        bb::Rect rr; long long ms = -1; const bool seen = bb::peekBanner(S.symbol, S.spb, chart, rr, ms);   // (CR5000) the heartbeat\n'
    '        S.trBanner = S.trBeat.step(seen, ms, now); if (S.trBanner) S.trRect = rr;')

# done / destroy: clear my warning entry (profile only: the Flow pane never publishes and must not clear the profile's)
rep('    void release() { slot_.release(this); }',
    '    void release() { slot_.release(this); }\n'
    '    void unpublish() {                                                  // (CR5000) removed: the Tape Reader drops line 2 at once\n'
    '#ifndef LQ_FLOW\n'
    '        LQState* S = slot_.get(this, false); if (S && S->published) { bb::clearWarn(S->symbol, S->spb, S->chartKey); S->published = false; }\n'
    '#endif\n'
    '    }')
rep('int cppExtension::done(void)    { static_cast<LiquidityProfile*>(this)->release(); return RTX_OK; }',
    'int cppExtension::done(void)    { static_cast<LiquidityProfile*>(this)->unpublish(); static_cast<LiquidityProfile*>(this)->release(); return RTX_OK; }')
rep('int cppExtension::destroy(void) { static_cast<LiquidityProfile*>(this)->release(); return RTX_OK; }',
    'int cppExtension::destroy(void) { static_cast<LiquidityProfile*>(this)->unpublish(); static_cast<LiquidityProfile*>(this)->release(); return RTX_OK; }')

# settings rows
rep('''    setParameterVersion(1);
    setParameterDialogHeight(1);
    setIntegerParameter("Width px", 70, 50);
    setIntegerParameter("Font pt", 11, 50, kParmAppendSameLine);''',
'''    setParameterVersion(2);                       // (CR5000) + the LIQ label Offset X / Y rows (IRT resets the saved rows once; the size file keeps them)
    setParameterDialogHeight(2);
    setIntegerParameter("Width px", 70, 50);
    setIntegerParameter("Font pt", 11, 50, kParmAppendSameLine);
    setIntegerParameter("Label offset X", 0, 50);
    setIntegerParameter("Label offset Y", 0, 50, kParmAppendSameLine);''')
rep('static const int WIDTH_INDEX = 0, FONT_INDEX = 1;',
    'static const int WIDTH_INDEX = 0, FONT_INDEX = 1, OFFX_INDEX = 2, OFFY_INDEX = 3;   // (CR5000) the LIQ label Offset X / Y')
rep('static const int WIDTH_INDEX = -1, FONT_INDEX = 0;',
    'static const int WIDTH_INDEX = -1, FONT_INDEX = 0, OFFX_INDEX = -1, OFFY_INDEX = -1;')

# the class: parmsLoad + snapshot
rep('    virtual int parmsApply(void) { saveSize(); return RTX_OK; }',
    '    virtual int parmsApply(void) { saveSize(); return RTX_OK; }\n'
    '    virtual int parmsLoad(void);                                        // (CR5000) the dialog filled from the size file (never saves)\n'
    '    bp::DlgSnap snap_;                                                   // (CR5000) the dialog as it opened')

# saveSize / loadSize: 4 fields for the profile
old_save_start = s.index('void LiquidityProfile::saveSize() {')
old_load_end = s.index('int cppExtension::calc(int)')
new_size = r'''// (CR5000) the size file: "w,f" (0.15.1) or "w,f,dx,dy" (the profile's LIQ label offset). false = missing / garbled (why says which)
struct LqSize { int w = 70, f = 11, dx = 0, dy = 0; bool ok = false; std::string why; };
static LqSize readSize(const std::string& p) {
    LqSize z; std::ifstream in; std::string ln;
    long long st = -1; if (!statFile(p, &st) || st < 0) { z.why = "no size file"; return z; }
    if (!openBoundedInput(p, in) || !readBoundedLine(in, ln)) { z.why = "size file unreadable"; return z; }
    if (!ln.empty() && ln.back() == '\r') ln.pop_back();
    const std::vector<std::string> f = bp::fields(ln);
    long long w = 0, ft = 0; int dx = 0, dy = 0;
    if ((f.size() != 2 && f.size() != 4) || !parseLL(f[0], 40, 300, w) || !parseLL(f[1], 6, 16, ft)) { z.why = "size file garbled: '" + ln.substr(0, 40) + "' - last good kept"; return z; }
    if (f.size() == 4 && (!bp::intTok(f[2], dx) || !bp::intTok(f[3], dy) || !bp::offOk(dx) || !bp::offOk(dy))) { z.why = "bad label offset '" + f[2] + "," + f[3] + "' - 0,0"; dx = dy = 0; }
    z.w = (int)w; z.f = (int)ft; z.dx = dx; z.dy = dy; z.ok = true; return z;
}
static bool lqInDialog(cppExtension* x) { const char* pl = x->getPeriodicityLabel(); return !(pl && pl[0]); }   // the settings window's copy has no bar size
static std::string lqSizePath(cppExtension* x) {
    char rb[32]; std::memset(rb, 0, sizeof(rb)); const char* rs = x->getRootSymbol(rb); const char* sy = x->getSymbol();
    const std::string root = rs ? rs : "", mkt = marketName(root.empty() ? (sy ? sy : "") : root), dirp = flexDir();
    if (mkt.empty() || dirp.empty()) return std::string();
    return dirp + "\\" + LQ_SIZE_NAME + ".size-" + mkt + ".txt";
}
int LiquidityProfile::parmsLoad(void) {
#ifndef LQ_FLOW
    if (!lqInDialog(this)) return RTX_OK;
    const std::string p = lqSizePath(this); if (p.empty()) return RTX_OK;
    const LqSize z = readSize(p);
    if (z.ok) { setIntegerValue(WIDTH_INDEX, z.w); setIntegerValue(FONT_INDEX, z.f); setIntegerValue(OFFX_INDEX, z.dx); setIntegerValue(OFFY_INDEX, z.dy); }
    else { setIntegerValue(OFFX_INDEX, 0); setIntegerValue(OFFY_INDEX, 0); }
    std::vector<long long> v; v.push_back(getIntegerValue(WIDTH_INDEX)); v.push_back(getIntegerValue(FONT_INDEX)); v.push_back(getIntegerValue(OFFX_INDEX)); v.push_back(getIntegerValue(OFFY_INDEX));
    snap_.take(v);
#endif
    return RTX_OK;
}
// (0.15.1) the window's Width / Font -> lsFlexLevels\<name>.size-<MKT>.txt ("70,11"), for every chart of the market and after a restart;
// (CR5000) + the LIQ label Offset X / Y ("70,11,dx,dy"); a control he did not touch since the dialog opened keeps the file's value
void LiquidityProfile::saveSize() {
    int w = WIDTH_INDEX >= 0 ? clampWidth(getIntegerValue(WIDTH_INDEX)) : 70, f = clampFont(getIntegerValue(FONT_INDEX));
    const std::string p = lqSizePath(this), dirp = flexDir();
    LQState* S = slot_.get(this, false);
    int dx = 0, dy = 0;
#ifndef LQ_FLOW
    const LqSize z = p.empty() ? LqSize() : readSize(p);
    if (snap_.have) {
        const long long now[4] = { getIntegerValue(WIDTH_INDEX), getIntegerValue(FONT_INDEX), getIntegerValue(OFFX_INDEX), getIntegerValue(OFFY_INDEX) };
        const long long fv[4] = { z.w, z.f, z.dx, z.dy };
        long long v[4]; for (size_t k = 0; k < 4; ++k) v[k] = snap_.pick(k, now[k], fv[k]);
        w = clampWidth((int)std::max(-100000LL, std::min(100000LL, v[0]))); f = clampFont((int)std::max(-100000LL, std::min(100000LL, v[1])));
        dx = v[2] >= bp::OFF_MIN && v[2] <= bp::OFF_MAX ? (int)v[2] : z.dx; dy = v[3] >= bp::OFF_MIN && v[3] <= bp::OFF_MAX ? (int)v[3] : z.dy;   // garbage never reaches the file
    } else {
        const long long ox = getIntegerValue(OFFX_INDEX), oy = getIntegerValue(OFFY_INDEX);
        dx = ox >= bp::OFF_MIN && ox <= bp::OFF_MAX ? (int)ox : z.dx; dy = oy >= bp::OFF_MIN && oy <= bp::OFF_MAX ? (int)oy : z.dy;
    }
#endif
    if (S) { S->width = w; S->font = f; S->labDx = dx; S->labDy = dy; }
    if (p.empty()) return;
    makeDir(dirp);
#ifdef LQ_FLOW
    const std::string body = std::to_string(w) + "," + std::to_string(f) + "\n";
#else
    const std::string body = std::to_string(w) + "," + std::to_string(f) + "," + std::to_string(dx) + "," + std::to_string(dy) + "\n";
#endif
    if (publishFile(p, body)) {
        if (S) { S->sizeStamp = -2; S->sizeCheckMs = -1; }
#ifndef LQ_FLOW
        std::vector<long long> v; v.push_back(getIntegerValue(WIDTH_INDEX)); v.push_back(getIntegerValue(FONT_INDEX)); v.push_back(getIntegerValue(OFFX_INDEX)); v.push_back(getIntegerValue(OFFY_INDEX));
        snap_.take(v);
#endif
    }
}
void LiquidityProfile::loadSize(LQState& S) {
    const long long now = steadyMs();
    if (S.sizeMkt == S.market && S.sizeCheckMs >= 0 && now >= S.sizeCheckMs && now - S.sizeCheckMs < 1000) return;
    S.sizeCheckMs = now;
    const std::string dirp = flexDir();
    if (dirp.empty() || S.market.empty()) return;
    const std::string p = dirp + "\\" + LQ_SIZE_NAME + ".size-" + S.market + ".txt";
    long long st = -1; if (!statFile(p, &st)) st = -1;
    if (S.sizeMkt == S.market && st == S.sizeStamp) return;
    S.sizeMkt = S.market; S.sizeStamp = st;
    if (st < 0) { S.labDx = S.labDy = 0; S.sizeWhy.clear(); return; }    // no file: the window's / default size stays, no offset
    const LqSize z = readSize(p);
    S.sizeWhy = z.why;
    if (!z.ok) return;                                                    // garbled: keep (reason on the status file)
    S.width = clampWidth(z.w); S.font = clampFont(z.f); S.labDx = z.dx; S.labDy = z.dy;
}
'''
s = s[:old_save_start] + new_size + s[old_load_end:]

# the LIQ label at its offset (clamped inside the pane, left of the last bar, below the title row; under the Tape Reader banner)
rep('''        setTextColor(ok ? C_GREY : C_SELL);
        RCT r; r.set(coord(left + 2), coord(hdrTop), coord(left + std::max(full + 60, getTextWidth(h.c_str(), -1) + 4)), coord(hdrTop + rowH)); r.drawText(h.c_str(), false, false);''',
'''        setTextColor(ok ? C_GREY : C_SELL);
        // (CR5000) Offset X / Y moves the label only (the column stays): clamped inside the pane, left of the last bar, below the title row,
        // and never over the Tape Reader banner (then just under it)
        const int tw = getTextWidth(h.c_str(), -1) + 4;
        const bp::Box area = bp::mk(left, warnTop(pane.top), std::max(left + tw, lastX), bottom);
        bp::Box lb = bp::offset(bp::mk(left + 2, hdrTop, left + 2 + tw, hdrTop + rowH), S.labDx, S.labDy, area);
        if (S.trBanner && bp::overlap(lb, bp::mk(S.trRect.l, S.trRect.t, S.trRect.r, S.trRect.b + 4))) lb = bp::clampIn(bp::mk(lb.l, S.trRect.b + 4, lb.r, S.trRect.b + 4 + rowH), area);
        S.labBox = lb;
        RCT r; r.set(coord(lb.l), coord(lb.t), coord(lb.l + std::max(full + 58, tw - 2)), coord(lb.b)); r.drawText(h.c_str(), false, false);''')
rep('    int labDx = 0, labDy = 0; std::string sizeWhy;', '    int labDx = 0, labDy = 0; std::string sizeWhy; bp::Box labBox;')

# lastX must be known before the header: move the header block after lastX is computed? check order
i_hdr = s.index('        // (CR5000) Offset X / Y moves the label only')
i_lastx = s.index('    int lastX = paneRight;')
if i_lastx > i_hdr:
    raise SystemExit('lastX after header')

# status: the label offset on the BANNER line
rep('''<< ",handed " << S.handed''', '''<< ",handed " << S.handed << ",label offset " << S.labDx << "," << S.labDy << (S.sizeWhy.empty() ? std::string() : "," + S.sizeWhy)''')

open(p, 'w', encoding='latin-1').write(s)

# the logic header version
q = d + '/LiquidityProfileLogic.h'
t = open(q, encoding='latin-1').read()
old = 'static const char* const VERSION = "%s";' % oldver
assert t.count(old) == 1, 'logic version'
t = t.replace(old, 'static const char* const VERSION = "%s";   // (%s, CR5000) Tape Reader heartbeat, label Offset X / Y;' % (ver, ver) + ' //', 1)
open(q, 'w', encoding='latin-1').write(t)
print('patched', d, ver)
