// HL 2.0.0: the 1st Extreme model merged into lsHodLod (Rassul 2026-10-12 21:47 "combine the hod lod indicator and the first extreme").
// Real 3-min bars WITH volume (the research package's bars, END stamps) through the mock SDK:
//   1. 07-02 ES: the same immutable call as the native replay (HOD 7,661.50, called 72 min, formed 24, 0.7523), the header line and
//      the marker drawn, the marker box clear of the table, logs once per bar, the call once, restart adds only the new bar
//   2. 07-09 ES: WRONG at the close, shown on the header line
//   3. a 6-min chart: no model line (3-min only), HOD / LOD itself still drawn
//   4. short history: "warming up: N of 14 sessions"
//   5. PARITY: every weekday of the research test period, 6 markets, the plugin's calls at the close == the 244-call research ledger
//      (native_test_calls.csv) - same days, side, price, minute, formation, probability; no extra calls on other days
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <map>
#include <set>
#include <unistd.h>
#include "HodLod.cpp"
static int fails = 0, passes = 0;
#define CHECK(c, m) do { if (c) ++passes; else { ++fails; std::printf("FAIL %s (line %d)\n", std::string(m).c_str(), __LINE__); } } while (0)
static const std::string DATA = "/home/claude/fxe/data/";
struct Rows { std::vector<std::string> day; std::vector<RTDATE> t; std::vector<float> o, h, l, c; std::vector<unsigned long> v; };
static Rows readAll(const std::string& path)
{
    Rows R; std::ifstream f(path.c_str()); std::string ln; std::getline(f, ln);
    while (std::getline(f, ln)) { int Y, M, D, h, m, s; double o, H, L, c, v;
        if (sscanf(ln.c_str(), "%d-%d-%d %d:%d:%d,%lf,%lf,%lf,%lf,%lf", &Y, &M, &D, &h, &m, &s, &o, &H, &L, &c, &v) != 11) continue;
        R.day.push_back(ln.substr(0, 16)); R.t.push_back((RTDATE)(hl::daysFromCivil(Y, M, D) * 86400 + h * 3600 + m * 60 + s));
        R.o.push_back((float)o); R.h.push_back((float)H); R.l.push_back((float)L); R.c.push_back((float)c); R.v.push_back((unsigned long)v); }
    return R;
}
static void fill(mock::Chart& C, const Rows& R, const std::string& from, const std::string& upto, const std::string& root, float tick, int every = 1)
{
    C.root = root; C.tick = tick; C.t.clear(); C.o.clear(); C.h.clear(); C.l.clear(); C.c.clear(); C.vol.clear(); int k = 0;
    double lo = 1e18, hi = -1e18;
    for (size_t i = 0; i < R.t.size(); i++) { if (R.day[i] < from) continue; if (R.day[i] > upto) break; if (k++ % every) continue;
        C.t.push_back(R.t[i]); C.o.push_back(R.o[i]); C.h.push_back(R.h[i]); C.l.push_back(R.l[i]); C.c.push_back(R.c[i]); C.vol.push_back(R.v[i]);
        lo = std::min(lo, (double)R.l[i]); hi = std::max(hi, (double)R.h[i]); }
    C.lo = lo; C.hi = hi;
}
static std::string slurp(const std::string& p) { std::ifstream f(p.c_str()); std::stringstream s; s << f.rdbuf(); return s.str(); }
static int countLines(const std::string& s, const std::string& pre) { int n = 0; std::istringstream is(s); std::string l; while (std::getline(is, l)) if (l.compare(0, pre.size(), pre) == 0) n++; return n; }
static std::string texts(const mock::Chart& A) { std::string s; for (const auto& d : A.drawn) if (d.kind == 1) s += d.s + "|"; return s; }
static std::string dayBefore(const std::string& d, int n) { int Y, M, D; sscanf(d.c_str(), "%d-%d-%d", &Y, &M, &D); return hl::dateTxt(hl::daysFromCivil(Y, M, D) - n) + " 00:00"; }

int main() {
    char tmpl[] = "/tmp/hlfxXXXXXX"; std::string prof = mkdtemp(tmpl); setenv("USERPROFILE", prof.c_str(), 1);
    Rows ES = readAll(DATA + "bars_ES.csv");
    {   // 1. 07-02 10:33 (the forming bar): the HOD call
        HodLod x; x.setup(); mock::Chart A; fill(A, ES, "2026-05-15 00:00", "2026-07-02 10:33", "EPU26", 0.25f); mock::cur() = &A; x.draw();
        HLState* S = (HLState*)A.userData;
        CHECK(S && S->fxHave, "model ran: " + (S ? S->fxState : std::string("no state")));
        if (S) std::printf("  07-02: state %d called %d side %d price %.2f prob %.4f formed %d declared %d idx %d\n", (int)S->fxView.state, (int)S->fxView.called, S->fxView.side, S->fxView.price, S->fxView.prob, S->fxView.formed, S->fxView.declared, S->fxIdx);
        CHECK(S && S->fxView.called && S->fxView.side == 2 && std::fabs(S->fxView.price - 7661.5) < 1e-9 && S->fxView.declared == 72 && S->fxView.formed == 24, "the call = the replay (HOD 7,661.50, called 72, formed 24)");
        CHECK(S && std::fabs(S->fxView.prob - 0.7522951799747281) < 1e-6, "probability = the research ledger (0.7523)");
        std::string tx = texts(A);
        {   std::string fl; if (S) for (const auto& g : S->view.fxSegs) fl += g.s + "|";   // (2.0.2) computed + logged, no longer drawn in the table
            CHECK(fl.find("1st extreme  |HOD? 75%|") != std::string::npos && fl.find("formed 8:54") != std::string::npos && fl.find("called 9:42") != std::string::npos, "model line: 1st extreme HOD? 75% . formed 8:54 . called 9:42");
            CHECK(tx.find("1st extreme") == std::string::npos, "2.0.2: the model line is not drawn in the table"); }
        CHECK(tx.find("ES RTH 8:30-3:00") != std::string::npos, "the HOD / LOD table is still drawn");
        // the marker = the box whose 2nd line is exactly "called 9:42" (the header line's text is longer); the table = the biggest box
        int tl = 0, tt = 0, tr = -1, tb = -1; long long ta = -1; int ml = -1, mt = -1, mr = -1, mb = -1, nMark = 0;
        for (const auto& d : A.drawn) if (d.kind == 0 && (long long)(d.r - d.l) * (d.b - d.t) > ta) { ta = (long long)(d.r - d.l) * (d.b - d.t); tl = d.l; tt = d.t; tr = d.r; tb = d.b; }
        for (const auto& d : A.drawn) if (d.kind == 1 && d.s == "called 9:42") { ml = d.l; mt = d.t - 14; mr = d.r; mb = d.b; nMark++; }
        CHECK(nMark == 1, "one HOD? marker on the candle (" + std::to_string(nMark) + ")");
        CHECK(nMark == 1 && (mr < tl || ml > tr || mb < tt || mt > tb), "the marker is clear of the table");
        CHECK(tx.find("called 9:42|") != std::string::npos, "the marker says when it was called");
        std::string dl = slurp(x.flexPath("FirstExtreme.decisions-ES.csv")), cl = slurp(x.flexPath("FirstExtreme.calls-ES.csv"));
        int nd = countLines(dl, "2026-07-02");
        CHECK(S && nd == (int)S->fxView.decisions.size() && nd > 0, "one log line per assessed bar (" + std::to_string(nd) + ")");
        CHECK(countLines(cl, "2026-07-02,72,HOD,7661.5") == 1, "the call logged once: " + cl);
        std::string st = slurp(x.flexPath("FirstExtreme.status-ES.txt"));
        CHECK(st.find("inside lsHodLod 2.0.2") != std::string::npos && st.find("LINE,1st extreme  HOD? 75%") != std::string::npos, "model status file written");
        x.draw(); CHECK(countLines(slurp(x.flexPath("FirstExtreme.decisions-ES.csv")), "2026-07-02") == nd, "a redraw adds nothing");
        x.destroy();
        HodLod y; y.setup(); mock::Chart B; fill(B, ES, "2026-05-15 00:00", "2026-07-02 10:36", "EPU26", 0.25f); mock::cur() = &B; y.draw();
        CHECK(countLines(slurp(y.flexPath("FirstExtreme.decisions-ES.csv")), "2026-07-02") == nd + 1, "after a restart only the new bar is logged");
        CHECK(countLines(slurp(y.flexPath("FirstExtreme.calls-ES.csv")), "2026-07-02") == 1, "the call is not logged twice");
        y.destroy();
    }
    {   // 2. 07-09: WRONG at the close
        HodLod x; x.setup(); mock::Chart A; fill(A, ES, "2026-05-20 00:00", "2026-07-09 15:03", "EPU26", 0.25f); mock::cur() = &A; x.draw();
        HLState* S = (HLState*)A.userData;
        CHECK(S && S->fxView.called && S->fxView.side == 2 && S->fxView.declared == 51 && S->fxView.verdictKnown && S->fxView.verdict == -1, "07-09 HOD call at 51 min, WRONG");
        { std::string fl; if (S) for (const auto& g : S->view.fxSegs) fl += g.s; CHECK(S && (S->fxView.failed ? fl.empty() : fl.find("  WRONG") != std::string::npos), "WRONG kept in the log; a FAILED call has no line (2.0.2)"); }
        x.destroy();
    }
    {   // 3. 6-min chart: no model line, the table still drawn
        HodLod x; x.setup(); mock::Chart A; fill(A, ES, "2026-06-01 00:00", "2026-07-02 10:33", "EPU26", 0.25f, 2); mock::cur() = &A; x.draw();
        HLState* S = (HLState*)A.userData;
        CHECK(S && !S->fxHave && S->fxState.find("3-minute") != std::string::npos, "6-min chart: no model (" + (S ? S->fxState : std::string()) + ")");
        CHECK(texts(A).find("1st extreme") == std::string::npos && texts(A).find("ES RTH") != std::string::npos, "6-min chart: table without the model line");
        x.destroy();
    }
    {   // 4. short history
        HodLod x; x.setup(); mock::Chart A; fill(A, ES, "2026-06-22 00:00", "2026-07-02 10:33", "EPU26", 0.25f); mock::cur() = &A; x.draw();
        HLState* S4 = (HLState*)A.userData; std::string tx; if (S4) for (const auto& g : S4->view.fxSegs) tx += g.s;
        CHECK(tx.find("warming up: ") != std::string::npos && tx.find(" of 14 sessions") != std::string::npos, "short history: warming up N of 14 (model line)");
        x.destroy();
    }
    {   // 5. parity with the research ledger, every weekday of each market's test period
        std::map<std::string, std::map<std::string, std::string>> want;   // market -> day -> "elapsed,side,price,formed,prob"
        std::ifstream f((DATA + "native_test_calls.csv").c_str()); std::string ln; std::getline(f, ln);
        while (std::getline(f, ln)) { std::istringstream is(ln); std::string m, d, e, s, p, cp, cm; std::getline(is, m, ','); std::getline(is, d, ','); std::getline(is, e, ',');
            std::getline(is, s, ','); std::getline(is, p, ','); std::getline(is, cp, ','); std::getline(is, cm, ',');
            char b[160]; snprintf(b, sizeof b, "%s,%s,%.10g,%s,%.6f", e.c_str(), s.c_str(), atof(cp.c_str()), cm.c_str(), atof(p.c_str())); want[m][d] = b; }
        const char* MK[6] = { "ES", "NQ", "GC", "HG", "NG", "EU" }; const char* ROOT[6] = { "EPU26", "ENQU26", "GCZ6", "HGZ6", "NGX6", "6EZ6" };
        const float TK[6] = { 0.25f, 0.25f, 0.1f, 0.0005f, 0.001f, 0.00005f };
        int match = 0, total = 0, extra = 0, days = 0;
        for (int k = 0; k < 6; k++) {
            Rows R = readAll(DATA + "bars_" + MK[k] + ".csv");
            auto& W = want[MK[k]]; if (W.empty()) continue;
            std::string d0 = W.begin()->first, d1 = W.rbegin()->first;
            std::set<std::string> seen;
            for (size_t i = 0; i < R.day.size(); i++) { std::string d = R.day[i].substr(0, 10); if (d >= d0 && d <= d1) seen.insert(d); }
            for (const auto& d : seen) {
                int Y, M, D; sscanf(d.c_str(), "%d-%d-%d", &Y, &M, &D); if (fx2::weekdayMon0(hl::daysFromCivil(Y, M, D)) >= 5) continue;
                HodLod x; x.setup(); mock::Chart A; fill(A, R, dayBefore(d, 50), d + " 16:03", ROOT[k], TK[k]); mock::cur() = &A; x.draw();
                HLState* S = (HLState*)A.userData; days++;
                std::string got;
                if (S && S->fxHave && S->fxView.called) { char b[160]; snprintf(b, sizeof b, "%d,%d,%.10g,%d,%.6f", S->fxView.declared, S->fxView.side, S->fxView.price, S->fxView.formed, S->fxView.prob); got = b; }
                auto it = W.find(d);
                if (it != W.end()) { total++; if (got == it->second) match++; else std::printf("  %s %s: want %s got %s (%s)\n", MK[k], d.c_str(), it->second.c_str(), got.c_str(), S ? S->fxState.c_str() : "-"); }
                else if (!got.empty()) {
                    // the research universe leaves out short sessions (07-03 closed at noon); live, the plugin cannot know at the call that
                    // the day will close early - only a call on a FULL session that the ledger lacks is an error
                    if (S && S->fxView.complete) { extra++; std::printf("  %s %s: extra call %s\n", MK[k], d.c_str(), got.c_str()); }
                    else std::printf("  %s %s: call on a short session (not in the research universe): %s\n", MK[k], d.c_str(), got.c_str());
                }
                x.destroy();
            }
        }
        std::printf("  parity: %d / %d ledger calls matched, %d extra calls, %d sessions replayed\n", match, total, extra, days);
        CHECK(total > 200 && match == total, "every research-ledger call reproduced by the merged plugin (" + std::to_string(match) + "/" + std::to_string(total) + ")");
        CHECK(extra == 0, "no calls on days the ledger has none");
    }
    std::printf("%d passed, %d failed\n", passes, fails); return fails;
}
