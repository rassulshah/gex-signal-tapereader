// test_of140_logic.cpp -- of140 (BidAskStats 1.5.0 / PullStats 1.1.0 / StackStats 1.1.0 / OrderFlowFeed.h 1.2.0 / OptionsFlow.h 1.0.0):
// one test per SPEC line (SPEC: /home/claude/aud/of140/SPEC.md, approved 2026-10-13 4:49 PM CT). No SDK.
#include "PullStatsLogic.h"
#include "StackStatsLogic.h"
#include "BidAskStatsLogic.h"
#include "StopRun.h"
#include <cstdio>
#include <fstream>
#include <unistd.h>
static int fails = 0, passes = 0;
#define CHECK(c, m) do { if (c) ++passes; else { ++fails; std::printf("FAIL %d %s\n", __LINE__, m); } } while (0)
using namespace off;
static Ev ev(int a, int side, Tick px, long long size, long long id, long long ms = 0, long long st = 0, long long aggr = 0) {
    Ev e; e.action = a; e.side = side; e.px = px; e.size = size; e.id = id; e.arrMs = ms; e.stamp = st; e.aggr = aggr; return e;
}
static Engine eng(Tick ref = 1000, Tick near = 10) { Engine e; e.ref = ref; e.haveRef = true; e.near = near; return e; }
static int W6(const std::string& s) { return (int)s.size() * 6; }
// a pane bar on one side: n orders, lots, ratio, pace (x100, note), level; gate on
static PaneBar side(int s, long long n, long long lots, double ratio, long long p100, long long note, const std::string& level) {
    PaneBar b; b.ok = true; b.r.events = 10; b.level = level;
    for (int k = 0; k < 2; ++k) { b.m[0].ratioOk[k] = true; b.m[0].ratio[k] = 0.5; b.m[1].ratioOk[k] = true; b.m[1].ratio[k] = 0.5; b.r.pullN[k] = b.r.addN[k] = 1; b.r.pullC[k] = b.r.addC[k] = 2; b.r.addTop[k] = 1; b.r.pullMax[k] = 1; }
    b.m[0].ratio[s] = ratio; b.r.pullN[s] = b.r.addN[s] = n; b.r.pullC[s] = b.r.addC[s] = lots; b.r.addTop[s] = 1; b.r.pullMax[s] = 1; b.r.pullTraded[s] = 1;
    b.r.pace100[s] = p100; b.r.paceNote[s] = note; b.r.paceGate = ofo::GATE_ON;
    return b;
}
static std::string line(const std::string& ct, const nl::Msg& m) { return line1Of(ct, m.line1); }

int main() {
    CHECK(std::string(off::VERSION) == "1.5.0" && std::string(ofo::VERSION) == "1.1.0" && std::string(ps::VERSION) == "1.4.0" && std::string(st::VERSION) == "1.3.0" && std::string(bas::VERSION) == "1.6.0", "versions");
    Params P; P.gate[ofo::G_PACE] = ofo::GATE_ON; P.gate[ofo::G_REBUILT] = ofo::GATE_ON;
    // ================= SPEC: the message lines, EXACT (gates on, as the SPEC examples) =================
    {   // BidAskStats
        bas::Stat s; s.m.ok = true; s.m.bid = 240; s.m.ask = 60; s.bidRatioOk = s.askRatioOk = true; s.bidRatio = 3.4; s.askRatio = 1.0; s.bidSpike = true;
        off::Rec r; r.sweepLv[0] = 3; r.aggrMax[0] = 15; r.sweepIsMax[0] = 1; r.thrAggr = 20;
        const std::string let[2] = { "S", "" }; const int held[2] = { 1, 1 };
        bas::PaceIn pc; pc.p100[0] = 230; pc.note[0] = 1; pc.gate = ofo::GATE_ON;
        CHECK(line("10:24", bas::message(s, &r, let, "PDL", held, pc)) == "10:24 Sellers hit the bid with a 240-lot (3.4x) fast (p 2.3x), swept 3 levels into PDL - price held: buyers absorbing.", "SPEC BidAskStats line, exact");
        CHECK(bas::message(s, &r, let, "PDL", held, pc).impl == nl::BULL, "BidAskStats: bids hit + held = green");
    }
    {   // StackStats
        PaneBar a = side(BID, 42, 150, 4.4, 340, 1, "PDL"); a.r.hitC[BID] = 100; a.r.rebuildC[BID] = 90; st::Logic::decide(a, P, false);
        CHECK(line("10:27", a.msg) == "10:27 Buyers added 42 bids totaling 150 lots (4.4x) fast (p 3.4x) - rebuilt 90% after hits - defending PDL." && a.msg.impl == nl::BULL, "SPEC StackStats line 1 (green), exact");
        PaneBar b = side(ASK, 3, 140, 3.9, 0, 0, "PDH"); b.r.addTop[ASK] = 119; st::Logic::decide(b, P, false);
        CHECK(line("10:31", b.msg) == "10:31 Sellers added 3 offers totaling 140 lots (3.9x) - one order is 85% of it - may not reload ? at PDH." && b.msg.impl == nl::NEUTRAL, "SPEC StackStats line 2 (white), exact");
        CHECK(std::string(st::ONE_ORDER_TAIL) == "may not reload ?" && b.msg.line1.find("bait") == std::string::npos, "(6:40 PM) one constant holds the one-order words; StackStats never says bait");
        PaneBar c = side(BID, 18, 60, 2.2, 70, 2, "PDL"); st::Logic::decide(c, P, false);
        CHECK(line("10:46", c.msg) == "10:46 Buyers added 18 bids totaling 60 lots (2.2x) slowly (p 0.7x) - support building at PDL." && c.msg.impl == nl::BULL, "SPEC StackStats line 3 (green), exact");
        PaneBar d = side(ASK, 51, 210, 3.3, 290, 1, "PDH"); st::Logic::decide(d, P, false);
        CHECK(line("11:12", d.msg) == "11:12 Sellers added 51 offers totaling 210 lots (3.3x) fast (p 2.9x) - wall building above at PDH." && d.msg.impl == nl::BEAR, "SPEC StackStats line 4 (red), exact");
        PaneBar e = a; e.r.rebuildC[BID] = 89; st::Logic::decide(e, P, false);
        CHECK(e.msg.line1 == "Buyers added 42 bids totaling 150 lots (4.4x) fast (p 3.4x) - support building at PDL.", "rebuilt 89% < 90%: not named");
        Params Q = P; Q.gate[ofo::G_REBUILT] = ofo::GATE_Q; PaneBar f = a; st::Logic::decide(f, Q, false);
        CHECK(f.msg.line1 == "Buyers added 42 bids totaling 150 lots (4.4x) fast (p 3.4x) - rebuilt 90% after hits ? - defending PDL.", "REBUILT_SHOW ?: the rebuilt clause marked ?");
        Q.gate[ofo::G_REBUILT] = ofo::GATE_OFF; st::Logic::decide(f, Q, false); CHECK(f.msg.line1.find("rebuilt") == std::string::npos, "REBUILT_SHOW off: not in the message");
        PaneBar g = a; g.level = ""; st::Logic::decide(g, P, false); CHECK(g.msg.line1 == "Buyers added 42 bids totaling 150 lots (4.4x) fast (p 3.4x) - rebuilt 90% after hits - real support.", "no level near: no level named");
    }
    {   // PullStats
        PaneBar a = side(BID, 64, 410, 3.1, 260, 1, "PDL"); ps::Logic::decide(a, P, false);
        CHECK(line("10:41", a.msg) == "10:41 Buyers pulled 64 bids totaling 410 lots (3.1x) fast (p 2.6x) - support leaving at PDL." && a.msg.impl == nl::BEAR && a.kind == 1, "SPEC PullStats line 1 (red), exact");
        PaneBar b = side(ASK, 38, 95, 3.6, 280, 1, "PDH"); ps::Logic::decide(b, P, false);
        CHECK(line("10:33", b.msg) == "10:33 Sellers pulled 38 offers totaling 95 lots (3.6x) fast (p 2.8x) - resistance leaving at PDH." && b.msg.impl == nl::BULL, "SPEC PullStats line 2 (green), exact");
        CHECK(b.msg.line1.find("attackers") == std::string::npos, "resting sellers are passive: never 'attackers'");
        PaneBar c = side(BID, 4, 120, 2.4, 0, 0, "PDL"); c.r.pullMax[BID] = 100; c.r.pullTraded[BID] = 0; ps::Logic::decide(c, P, false);
        CHECK(line("10:52", c.msg) == "10:52 Buyers pulled 4 bids totaling 120 lots (2.4x) - one 100-lot pulled before it traded - bait gone at PDL." && c.msg.impl == nl::NEUTRAL && c.kind == 2, "SPEC PullStats line 3 (white), exact");
        PaneBar d = c; d.r.pullTraded[BID] = 1; ps::Logic::decide(d, P, false); CHECK(d.kind == 1 && d.msg.line1.find("support leaving") != std::string::npos, "the big order had traded first: not bait gone");
        CHECK(line("11:06", nl::Msg{ resetMessage(BID, 40, "11:05", "PDL"), "", nl::NEUTRAL }) == "11:06 Bids back within 40 s of the 11:05 pull - reset, not a retreat at PDL.", "SPEC PullStats reset line (white), exact");
        PaneBar e = side(ASK, 1, 30, 5.0, 0, 0, ""); ps::Logic::decide(e, P, false); CHECK(e.msg.line1 == "Sellers pulled 1 offer totaling 30 lots (5.0x) - resistance leaving.", "singular, no level");
    }
    // ================= (6:18 PM render check) a too-wide message keeps its verdict: optional words go first, the end is cut last =================
    {
        const std::string m = "3:12 Sellers hit the bid with a 240-lot (6.4x) fast (p 5.0x ?), swept 4 levels with one 120-lot order into LonLO - price held: buyers absorbing.";
        const std::vector<std::string> v = compactVariants(m);
        CHECK(v.size() == 4 && v[1] == "3:12 Sellers hit the bid with a 240-lot (6.4x) fast (p 5.0x ?), swept 4 levels into LonLO - price held: buyers absorbing."
              && v[2] == "3:12 Sellers hit the bid with a 240-lot (6.4x), swept 4 levels into LonLO - price held: buyers absorbing."
              && v[3] == "3:12 Sellers hit the bid with a 240-lot (6.4x), swept 4 lvls into LonLO - price held: buyers absorbing.", "variants: large-order clause, then pace, then short words");
        CHECK(fitMessage(m, W6(m), W6) == m, "fits: unchanged");
        CHECK(fitMessage(m, W6(v[1]), W6) == v[1] && fitMessage(m, W6(v[2]) + 3, W6) == v[2], "the first variant that fits; the verdict kept");
        CHECK(fitMessage(m, W6(v[3]) - 1, W6).find("absorbing") == std::string::npos && !fitMessage(m, W6(v[3]) - 1, W6).empty(), "only when even the shortest variant is too wide is the end cut");
        const std::string p = "10:41 Buyers pulled 64 bids totaling 410 lots (3.1x) fast (p 2.6x) - support leaving at PDL.";
        CHECK(compactVariants(p).size() == 3 && compactVariants(p)[2] == "10:41 Buyers pulled 64 bids, 410 lots (3.1x) - support leaving at PDL.", "PullStats: pace then 'totaling' go");
        CHECK(compactVariants("Sellers added 3 offers totaling 140 lots (3.9x) - one order is 85% of it - may not reload ? at PDH.")[1].find("one order is 85%") != std::string::npos, "the one-order clause is the verdict: never removed");
        const std::string l = "Buyers lifted the offer with a 300-lot (3.0x), plus one 90-lot order - price held: sellers absorbing.";
        CHECK(compactVariants(l)[1] == "Buyers lifted the offer with a 300-lot (3.0x) - price held: sellers absorbing.", "', plus one N-lot order' goes first");
    }
    // ================= SPEC: bars in LOTS =================
    {
        Rec r; r.pullN[BID] = 3; r.pullC[BID] = 90; r.addN[ASK] = 2; r.addC[ASK] = 40; r.refN[ASK] = 7;
        CHECK(ps::Logic::value(r, 0, BID) == 90 && st::Logic::value(r, 0, ASK) == 40 && st::Logic::value(r, 1, ASK) == 7, "Pull bar = lots pulled, Stack bar = lots added (refill metric stays a count)");
        Engine e = eng(); Acc a;
        e.apply(a, ev(NEW, BID, 1000, 30, 1)); e.apply(a, ev(NEW, BID, 1001, 5, 2)); e.apply(a, ev(DEL, BID, 1000, 30, 1)); e.apply(a, ev(DEL, BID, 1001, 5, 2));
        const Rec x = e.numbers(a, false, Params());
        CHECK(ps::Logic::value(x, 0, BID) == 35 && st::Logic::value(x, 0, BID) == 35 && x.pullN[BID] == 2 && x.addN[BID] == 2, "a 30-lot and a 5-lot: the bar is 35 lots, 2 orders");
        PaneBar s = side(BID, 2, 35, 3.0, 0, 0, ""); s.m[1].ratio[BID] = 2.5; s.r.refN[BID] = 4; s.r.refC[BID] = 12; st::Logic::decide(s, P, false);
        CHECK(s.dash[BID] == 12, "the refill dash is in lots too (refilled lots, never above the bar)");
    }
    // ================= SPEC: PACE vs the same-time-of-day norm =================
    {
        Params Q;
        CHECK(bucketOf(10 * 60 + 24) == 600 && bucketOf(10 * 60 + 30) == 630 && bucketOf(-1) == -1 && bucketOf(1440) == -1, "30-min CT buckets");
        ParamLoad L = parseParams(true, true, { "VERSION,1", "MARKET,ES", "PACE_NORM,PULL,1000,2.5", "PACE_NORM,AGGR,0830,40", "PACE_NORM,ADD,1015,3", "PACE_NORM,PULL,2400,1", "PACE_NORM,XYZ,1000,1", "PACE_NORM,ADD,1000,-1",
                                            "PACE_SHOW,on", "OHIT_SHOW,off", "OPULL_SHOW,maybe", "ODEX_SHOW,on", "PARAM,paceFastX,2.5", "PARAM,paceSlowX,0.6", "PARAM,rebuiltPct,85", "PARAM,resetWindowSec,45", "PARAM,resetPct,75" }, "ES");
        CHECK(fileNorm(L.p, PM_PULL, 10 * 60 + 24) == 2.5 && fileNorm(L.p, PM_AGGR, 8 * 60 + 59) == 40 && fileNorm(L.p, PM_ADD, 10 * 60 + 24) < 0 && fileNorm(L.p, PM_PULL, 10 * 60 + 30) < 0, "PACE_NORM rows by metric and bucket; a missing bucket = none");
        CHECK(L.notes.size() == 5, "bad PACE_NORM rows (bucket 2400, minute 15, unknown metric, value <= 0) and a bad gate value are noted and ignored");
        CHECK(L.p.gate[ofo::G_PACE] == ofo::GATE_ON && L.p.gate[ofo::G_OHIT] == ofo::GATE_OFF && L.p.gate[ofo::G_OPULL] == ofo::GATE_Q && L.p.gate[ofo::G_OSTACK] == ofo::GATE_Q && L.p.gate[ofo::G_REBUILT] == ofo::GATE_Q && L.p.gate[ofo::G_ODEX] == ofo::GATE_ON && L.p.gate[ofo::G_OHVL] == ofo::GATE_Q, "gates: on / off; bad or missing = ?");
        CHECK(L.p.paceFastT == 25 && L.p.paceSlowT == 6 && L.p.rebuiltPct == 85 && L.p.resetWindowSec == 45 && L.p.resetPct == 75, "pace / rebuilt / reset thresholds from the nightly");
        CHECK(paramsText(L.p).find("PACE_SHOW=on") != std::string::npos && paramsText(L.p).find("PACE_NORM_PULL=1,600:2.5") != std::string::npos, "status text shows the gates and the norms");
        std::vector<double> four(4, 1.0), five(5, 1.0); five.push_back(3.0);
        CHECK(rollingNorm(four) < 0 && std::fabs(rollingNorm(five) - 8.0 / 6.0) < 1e-9, "rolling norm needs 5 earlier candles");
        std::vector<double> many(100, 1.0); for (int i = 0; i < 60; ++i) many.push_back(2.0); CHECK(rollingNorm(many) == 2.0, "rolling norm: the last 60 only");
        const Pace a = paceOf(2.0, 1.0, 5.0, Q, false); CHECK(a.ok && a.x == 2.0 && a.fromFile && a.note == 1, "the nightly norm wins over the rolling one; exactly 2.0x = fast");
        const Pace b = paceOf(1.99, -1, 1.0, Q, true); CHECK(b.ok && !b.fromFile && b.note == 0, "1.99x = not notable (rolling norm)");
        CHECK(paceOf(0.7, 1.0, -1, Q, true).note == 2 && paceOf(0.7, 1.0, -1, Q, false).note == 0 && paceOf(0.71, 1.0, -1, Q, true).note == 0, "slowly: <= 0.7x and only on a spike bar");
        CHECK(!paceOf(1.0, -1, -1, Q, false).ok && pace100(paceOf(1.0, -1, -1, Q, false)) == 0, "no norm: no pace (n/a)");
        CHECK(paceWords(1, 260, ofo::GATE_ON) == " fast (p 2.6x)" && paceWords(2, 70, ofo::GATE_ON) == " slowly (p 0.7x)" && paceWords(1, 260, ofo::GATE_Q) == " fast (p 2.6x ?)"
              && paceWords(1, 260, ofo::GATE_OFF).empty() && paceWords(0, 150, ofo::GATE_ON).empty(), "pace words: only when notable; ? until PACE_SHOW,on; off = never");
        CHECK(paceHover(230, 20, ofo::GATE_ON) == "2.3x (2.0x)" && paceHover(230, 20, ofo::GATE_Q) == "2.3x (2.0x) ?" && paceHover(230, 20, ofo::GATE_OFF) == "2.3x (2.0x) off" && paceHover(0, 20, 1) == "n/a", "hover: Pace x (thr), ? until proven");
        CHECK(paceLabel(230) == "p 2.3x" && paceLabel(0).empty(), "spike label middle row");
        // the pane: per-side lots / s vs the norm, decided once (stored in the record numbers)
        PaneSeries<ps::Logic> s; Params R; R.gate[ofo::G_PACE] = ofo::GATE_Q;
        for (int i = 0; i < 6; ++i) { Rec r; r.events = 5; r.pullC[BID] = 60; r.pullC[ASK] = 60; s.bars[100000 + 60 * i] = s.make(100000 + 60 * i, r); }
        Rec x; x.events = 5; x.pullC[BID] = 180; x.pullC[ASK] = 30; PaneBar b2 = s.make(100000 + 60 * 6, x); panePace(b2, s, 100000 + 60 * 6, 60, 10 * 60 + 24, R);
        CHECK(b2.r.pace100[BID] == 300 && b2.r.paceNote[BID] == 1 && b2.r.pace100[ASK] == 50 && b2.r.paceGate == ofo::GATE_Q, "pane pace: 180 lots in 60 s vs 60 lots / 60 s = 3.0x fast; 30 = 0.5x");
        R.norm[PM_PULL][600] = 0.5; PaneBar b3 = s.make(100000 + 60 * 6, x); panePace(b3, s, 100000 + 60 * 6, 60, 10 * 60 + 24, R);
        CHECK(b3.r.pace100[BID] == 600, "with a nightly PACE_NORM: 3 lots / s vs 0.5 = 6.0x");
        PaneSeries<ps::Logic> old; for (int i = 0; i < 6; ++i) { Rec r; r.events = 5; r.pullC[BID] = 60; old.bars[100000 + 60 * i] = old.make(100000 + 60 * i, r); }
        PaneBar b4 = old.make(100000 + 5 * 3600, x); panePace(b4, old, 100000 + 5 * 3600, 60, 10 * 60, Params());
        CHECK(b4.r.pace100[BID] == 0, "candles older than 4 h are not in the rolling norm (none left: n/a)");
        s.bars[100000 + 60 * 6] = b2; Rec y; y.events = 5; y.pullC[BID] = 1; PaneBar later = s.make(100000 + 60 * 7, y); panePace(later, s, 100000 + 60 * 7, 60, 10 * 60 + 25, R);
        CHECK(s.bars[100000 + 60 * 6].r.pace100[BID] == 300, "a later candle never changes an earlier candle's pace (no repaint)");
    }
    // ================= SPEC: hover rows (Orders N · avg X lots, Top order NN%, Traded first, Before price, Rebuilt) =================
    {
        CHECK(ordersText(42, 150) == "42 \xB7 avg 3.6" && ordersText(20, 137) == "20 \xB7 avg 6.9" && ordersText(0, 0) == "-", "Orders N \xB7 avg X lots (rounded half up)");
        CHECK(pctOf(85, 100) == "85%" && pctOf(0, 10) == "-" && pctOf(5, 0) == "-", "Top order NN%");
        CHECK(rebuiltPctOf(90, 100) == 90 && rebuiltPctOf(500, 100) == 100 && rebuiltPctOf(5, 0) == -1, "Rebuilt %: (1.2.1) at most 100%, none without a hit");
        Engine e = eng(); Acc a;
        e.apply(a, ev(NEW, BID, 1000, 50, 1)); e.apply(a, ev(FILL, BID, 1000, 10, 1, 0, 0, 900)); e.apply(a, ev(MOD, BID, 1000, 40, 1)); e.apply(a, ev(DEL, BID, 1000, 40, 1));
        e.apply(a, ev(NEW, ASK, 1002, 30, 2)); e.apply(a, ev(DEL, ASK, 1002, 30, 2));
        Rec r = e.numbers(a, false, Params());
        CHECK(r.pullMax[BID] == 40 && r.pullTraded[BID] == 1 && r.pullMax[ASK] == 30 && r.pullTraded[ASK] == 0, "Traded first: the biggest pulled bid had a fill before it was pulled; the offer never traded");
        Engine f = eng(); Acc b;
        f.apply(b, ev(NEW, BID, 1000, 20, 1)); f.apply(b, ev(FILL, BID, 1000, 20, 1, 0, 0, 901)); f.apply(b, ev(DEL, BID, 1000, 0, 1));
        f.apply(b, ev(NEW, BID, 1000, 12, 2, 10, 5)); f.apply(b, ev(NEW, BID, 999, 30, 3, 20, 5)); f.apply(b, ev(NEW, BID, 1000, 6, 4, 30, 6));
        Rec q = f.numbers(b, false, Params());
        CHECK(q.hitC[BID] == 20 && q.rebuildC[BID] == 18 && rebuiltPctOf(q.rebuildC[BID], q.hitC[BID]) == 90, "Rebuilt: 18 of the 20 hit lots re-added at the hit price (the 30 at another price does not count) = 90%");
        CHECK(q.aggrN[BID] == 1 && q.aggrC[BID] == 20 && r.aggrN[BID] == 1 && r.aggrC[BID] == 10, "aggressor orders / lots per side (BidAskStats hover)");
        CHECK(b.addT[BID].size() == 3 && b.addT[BID][0] == std::make_pair(0LL, 20LL) && b.addT[BID][1] == std::make_pair(5LL, 62LL) && b.addT[BID][2] == std::make_pair(6LL, 68LL), "reset clock: cumulative added lots, one sample per stamp second");
    }
    // ================= SPEC: the reset is LATER, posted only when known (no look-ahead, never back-dated) =================
    {
        Params Q; ResetWatch w; Q.resetWindowSec = 120;                 // a 2-minute window: the reset can complete in the 2nd candle
        resetStart(w, BID, 1000, 100, Q, "11:05", "PDL");
        CHECK(w.on && w.target == 80, "watch: 80% of the 100 pulled lots");
        std::vector<std::pair<long long, long long> > s1 = { { 1010, 30 }, { 1030, 60 } };
        CHECK(resetStep(w, s1, 1060, Q) == -1 && w.on && w.cum == 60, "60 of 80 back in the next candle: not yet (the watch stays open)");
        std::vector<std::pair<long long, long long> > s2 = { { 1100, 25 } };
        CHECK(resetStep(w, s2, 1120, Q) == 100 && !w.on && w.resets == 1, "85 back by 11:05 + 100 s: reset in 100 s - decided at the LATER candle's close");
        Q.resetWindowSec = 60;
        ResetWatch one; resetStart(one, BID, 1000, 100, Q, "11:05", "PDL");
        CHECK(resetStep(one, { { 1010, 30 }, { 1040, 85 } }, 1060, Q) == 40 && !one.on, "the SPEC case: bids back within 40 s of the pull, known at the next candle's close");
        ResetWatch late; resetStart(late, ASK, 1000, 50, Q, "11:05", "");
        std::vector<std::pair<long long, long long> > s3 = { { 1070, 50 } };
        CHECK(resetStep(late, s3, 1120, Q) == -1 && !late.on, "back after the 60 s window: no reset, the watch closes");
        ResetWatch same; resetStart(same, BID, 1000, 50, Q, "11:05", "");
        CHECK(resetStep(same, { { 990, 50 } }, 1000, Q) == -1 && same.on, "the pull candle itself is never fed (no back-dating)");
        std::vector<std::pair<long long, long long> > s4 = { { 0, 45 } };
        ResetWatch nostamp; resetStart(nostamp, BID, 1000, 50, Q, "11:05", "");
        CHECK(resetStep(nostamp, s4, 1030, Q) == 30, "a sample without a stamp counts at the candle's end");
        ResetWatch q2; Params R; R.resetWindowSec = 30; resetStart(q2, BID, 1000, 50, R, "11:05", "");
        CHECK(resetStep(q2, { { 1040, 50 } }, 1060, R) == -1, "resetWindowSec from the nightly (30 s)");
        CHECK(resetMessage(ASK, 12, "9:31", "") == "Offers back within 12 s of the 9:31 pull - reset, not a retreat.", "offers / no level");
    }
    // ================= SPEC: options file (parse, stale, arrival, the lines) - incl. "Options content" (Rassul 5:49 PM) =================
    {
        const std::vector<std::string> good = { "VERSION,1", "MARKET,ES", "ASOF,1792000000", "OHIT,5800,P,2.4,2.0,dn,put sellers,1200", "OPULL,CR,5840,-30,dn,-",
            "OSTACK,PS,5790,40,+,3,2.4,building", "OWALL,PS,5790,2.4,+,40,building,12", "ODEX,1200,487000000,2.1,1", "OHVL,5780,above", "OSKEW,flat", "OLOG,absdex 1,vanna 2", "FUTURE,1,2" };
        ofo::Snap s = ofo::parse(good, "ES");
        CHECK(s.ok && s.asof == 1792000000 && s.hit.ok && s.hit.strike == 5800 && s.hit.type == 'P' && s.hit.dealers == 1200 && s.pull.ok && s.pull.gexPct == -30 && s.pull.sign == -1
              && s.stack.ok && s.stack.snaps == 3 && s.stack.wallX == 2.4 && s.stack.vsExp == 1, "parse: OHIT / OPULL (+ net sign) / OSTACK (+ wall x, building)");
        CHECK(s.wall.ok && s.wall.x == 2.4 && s.wall.sign == 1 && s.wall.chgPct == 40 && s.wall.vsExp == 1 && s.wall.oiOk && s.wall.oiPct == 12, "OWALL: wall size x normal, net sign, change vs expected, OI d/d");
        CHECK(s.dex.ok && s.dex.contracts == 1200 && s.dex.usd == 487000000 && s.dex.ratio == 2.1 && s.dex.sized && s.hvl.ok && s.hvl.above && s.hvl.px == 5780 && s.skewOk && s.skew == 0, "ODEX (contracts, $, ratio, sized), OHVL, OSKEW; OLOG logged only (ignored by the plugins)");
        int on[ofo::NGATE], qq[ofo::NGATE]; for (int g = 0; g < ofo::NGATE; ++g) { on[g] = ofo::GATE_ON; qq[g] = ofo::GATE_Q; }
        CHECK(ofo::hitLine(s, ofo::GATE_ON, "ES", ofo::GATE_ON) == "oHit: 5800 puts 2.4x \xB7 IV dn -> sellers \xB7 dealers buy 1.2K ES ($487M)", "SPEC oHit line (proven)");
        CHECK(ofo::hitLine(s, ofo::GATE_Q, "ES", ofo::GATE_Q) == "oHit: 5800 puts 2.4x \xB7 IV dn -> sellers ? \xB7 dealers buy 1.2K ES ($487M) ?", "oHit line, not proven yet: each part '?'");
        CHECK(ofo::pullLine(s, ofo::GATE_Q) == "oPull: CR 5840 wall -30% since open (-) \xB7 IV dn ?", "SPEC oPull line, exact");
        CHECK(ofo::stackLine(s, ofo::GATE_Q) == "oStack: PS 5790 wall 2.4x (+) building +40% \xB7 3 snaps ?", "SPEC oStack line, exact");
        CHECK(ofo::trLine1(s, on) == "PS 5790 wall 2.4x (+) building \xB7 above HVL" && ofo::trLine2(s, on, "ES", 1) == "Dealers buy 1.2K ES ($487M) 2.1x \xB7 put buyers fading", "SPEC Tape Reader OPTIONS lines, exact (proven)");
        CHECK(ofo::trLine1(s, qq) == "PS 5790 wall 2.4x (+) building ? \xB7 above HVL ?" && ofo::trLine2(s, qq, "ES", 1) == "Dealers buy 1.2K ES ($487M) 2.1x ? \xB7 put buyers fading ?", "Tape Reader OPTIONS: '?' on each unproven part");
        CHECK(ofo::hitLine(s, ofo::GATE_ON, "ES", ofo::GATE_OFF) == "oHit: 5800 puts 2.4x \xB7 IV dn -> sellers" && ofo::pullLine(s, ofo::GATE_OFF).empty(), "a gate off: that part hidden");
        { ofo::Snap d = s; d.dex.ratio = 1.49; CHECK(!ofo::dexShown(d, 2) && ofo::trLine2(d, on, "ES", 1) == "Put buyers fading", "dealers shown only at >= 1.5x their norm");
          d.dex.ratio = 1.5; CHECK(ofo::dexShown(d, 2), "exactly 1.5x = shown");
          d.dex.sized = false; CHECK(!ofo::dexShown(d, 2) && ofo::hitLine(d, 2, "CL", 2).find("dealers") == std::string::npos, "not sized (CL / NG: sign doubtful) = no size shown"); }
        { ofo::Snap k = s; k.skew = 1; CHECK(ofo::trLine2(k, on, "ES", 1) == "Dealers buy 1.2K ES ($487M) 2.1x \xB7 put buyers fading, fear up", "skew up = fear up");
          k.hvl.above = false; CHECK(ofo::trLine1(k, on) == "PS 5790 wall 2.4x (+) building \xB7 below HVL", "regime below HVL");
          k.hit.side = "?"; CHECK(ofo::hitLine(k, 2, "ES", 0) == "oHit: 5800 puts 2.4x \xB7 IV dn", "side not readable: no buyers / sellers named"); }
        { ofo::Snap w = s; w.hit.ratio = 1.0; w.hit.side = "put buyers";   // (6:18 PM, the real 13 Oct grids: "89 puts 1.0x, flat") no spike = no who
          CHECK(ofo::hitLine(w, 2, "ES", 0) == "oHit: 5800 puts 1.0x \xB7 IV dn" && ofo::trLine2(w, on, "ES", 1) == "Dealers buy 1.2K ES ($487M) 2.1x", "below 2.0x: buyers / sellers not named, no put-buyers words");
          w.hit.ratio = 2.0; CHECK(ofo::hitLine(w, 2, "ES", 0) == "oHit: 5800 puts 2.0x \xB7 IV dn -> buyers", "exactly 2.0x = a spike");
          ofo::Snap z = s; z.stack.snaps = 0; CHECK(ofo::stackLine(z, 1) == "oStack: PS 5790 wall 2.4x (+) building +40% ?", "0 snaps in a row: not written"); }
        CHECK(ofo::usdText(487000000) == "$487M" && ofo::usdText(-1200000000) == "$1.2B" && ofo::usdText(85000) == "$85K", "$ notional formats");
        { const ofo::Snap o10 = ofo::parse({ "VERSION,1", "MARKET,ES", "ASOF,1792000000", "OPULL,CR,5840,-30,dn", "OSTACK,PS,5790,40,+,3" }, "ES");
          CHECK(o10.pull.ok && o10.pull.sign == 0 && o10.stack.ok && o10.stack.wallX < 0 && ofo::pullLine(o10, 1) == "oPull: CR 5840 wall -30% since open \xB7 IV dn ?" && ofo::stackLine(o10, 1) == "oStack: PS 5790 wall (+) +40% \xB7 3 snaps ?", "a 1.0 file's rows still parse and draw"); }
        std::vector<std::string> bad = good; bad[3] = "OHIT,5800,X,2.4,2.0,dn,put sellers,1200"; bad[5] = "OSTACK,PS,5790,40,*,3"; bad[7] = "ODEX,12,4,x,1"; bad[8] = "OHVL,5780,middle"; bad[6] = "OWALL,PS,5790,2.4,+,40,maybe,12";
        ofo::Snap b = ofo::parse(bad, "ES"); CHECK(b.ok && !b.hit.ok && !b.stack.ok && !b.dex.ok && !b.hvl.ok && !b.wall.ok && b.pull.ok && b.notes.size() == 5 && ofo::hitLine(b, 2, "ES").empty(), "a bad row is dropped (its part hidden); the rest still counts");
        CHECK(!ofo::parse(good, "NQ").ok && !ofo::parse({ "VERSION,2", "MARKET,ES", "ASOF,1792000000" }, "ES").ok && !ofo::parse({ "VERSION,1", "MARKET,ES" }, "ES").ok && !ofo::parse({}, "ES").ok, "wrong market / VERSION / no ASOF / empty = not used");
        CHECK(ofo::fresh(s, 1792000000 + 1200) && !ofo::fresh(s, 1792000000 + 1201) && ofo::fresh(s, 1792000000 - 300) && !ofo::fresh(s, 1792000000 - 301), "stale after 20 min (hidden); not more than 5 min in the future");
        CHECK(ofo::kText(1200) == "1.2K" && ofo::kText(-850) == "850" && ofo::kText(25400) == "25K" && ofo::kText(1000) == "1K" && ofo::mktText("EU") == "6E" && ofo::strikeText(1.17250) == "1.1725", "number formats");
        // arrival: a snapshot is drawn from the bar it ARRIVED on, never earlier; each grid once
        ofo::History H; CHECK(H.add(s, 5000) && !H.add(s, 5060) && H.v.size() == 1, "a grid joins the history once, on its arrival bar");
        ofo::Snap s2 = s; s2.asof += 300; H.add(s2, 5300);
        CHECK(H.latest(4940) == nullptr && H.latest(5000)->asof == s.asof && H.latest(5240)->asof == s.asof && H.latest(5300)->asof == s2.asof, "a candle shows the latest grid that had ARRIVED by it (no look-ahead)");
        CHECK(H.at(5300, s2.asof + 60) != nullptr && H.at(5300, s2.asof + 1300) == nullptr, "stale at the reference time: hidden");
        // the cache: file stamp, unreadable, arrival bar
        char tmpl[] = "/tmp/optXXXXXX"; const std::string dir = mkdtemp(tmpl);
        OptCache C; CHECK(refreshOptions(C, dir, "ES", 0, [](long long) { return 7000LL; }) && C.why == "no file" && C.hist.v.empty(), "no file: no line");
        { std::ofstream f((dir + "\\LRA-Options-ES.csv").c_str()); for (auto& l : good) f << l << "\r\n"; }
        CHECK(!refreshOptions(C, dir, "ES", 1000, [](long long) { return 7060LL; }), "re-checked at most every 5 s");
        CHECK(refreshOptions(C, dir, "ES", 6000, [](long long mt) { return mt > 0 ? 7120LL : 0LL; }) && C.why == "ok" && C.hist.v.size() == 1 && C.hist.v[0].barKey == 7120, "read on its new stamp (CRLF); arrives on the bar the host maps its write time to");
        { std::ofstream f((dir + "\\LRA-Options-ES.csv").c_str()); f << "garbage\n"; }
        CHECK(refreshOptions(C, dir, "ES", 12000, [](long long) { return 7180LL; }) && C.why.find("VERSION") != std::string::npos && C.hist.v.size() == 1, "garbled: no new grid, the reason kept for the status");
        int g[ofo::NGATE]; ofo::parseGates({ "VERSION,1", "OHIT_SHOW,on", "PACE_SHOW,off", "OSTACK_SHOW,bogus", "ODEX_SHOW,on", "OHVL_SHOW,off" }, g);
        CHECK(g[ofo::G_OHIT] == 2 && g[ofo::G_PACE] == 0 && g[ofo::G_OSTACK] == 1 && g[ofo::G_OPULL] == 1 && g[ofo::G_ODEX] == 2 && g[ofo::G_OHVL] == 0 && g[ofo::G_REBUILT] == 1, "gate parser (Tape Reader): on / off / anything else ?; 7 gates incl. ODEX / OHVL");
        Params dp; bool allQ = true; for (int k = 0; k < ofo::NGATE; ++k) allQ = allQ && dp.gate[k] == ofo::GATE_Q; CHECK(allQ, "every gate defaults to ? (none silently off)");
    }
    // ================= SPEC: 3-row spike labels; the record keeps the new numbers (old records still load) =================
    {
        std::vector<SpikeIn> in(1); in[0].cx = 100; in[0].barTop = 200; in[0].q = "240"; in[0].x = "3.4x"; in[0].p = "p 2.3x";
        std::vector<SLabel> L = spikeLabels(in, 20, std::vector<LBox>(), W6);
        CHECK(L.size() == 1 && L[0].b == 198 && L[0].t == 198 - 3 * LABEL_LH + 1 && L[0].p == "p 2.3x", "3 rows: ratio / pace / lots, just above the bar");
        const int ph = 150, px = drawPx(ph, textReserve(ph));
        CHECK(ph - 6 - px >= LABEL_ROOM + TEXT_RESERVE && LABEL_ROOM == 3 * LABEL_LH + 2 && TEXT_RESERVE >= 30, "headroom for 3 label rows + the message line + the options line");
        Rec x; x.events = 3; x.pullTraded[1] = 1; x.hitC[0] = 20; x.rebuildC[0] = 18; x.aggrN[1] = 7; x.aggrC[1] = 90; x.pace100[0] = 230; x.paceNote[0] = 1; x.paceGate = 2;
        std::vector<long long> v; recNums(x, v); Rec y;
        CHECK((int)v.size() == REC_NUMS && REC_NUMS == 53 && recFrom(v, 0, y) && y.pullTraded[1] == 1 && y.rebuildC[0] == 18 && y.aggrC[1] == 90 && y.pace100[0] == 230 && y.paceNote[0] == 1 && y.paceGate == 2, "the 15 new numbers round-trip");
        CHECK(std::count(REC_COLS, REC_COLS + std::strlen(REC_COLS), '|') == REC_NUMS - 1, "the header names every number");
        Rec z = x; z.paceNote[0] = 3; std::vector<long long> w; recNums(z, w); CHECK(!recFrom(w, 0, y), "a bad pace note refused");
        Row r; r.t = 1791900060; r.ct = "10:24"; r.dbo = 1; for (int i = 0; i < REC_NUMS_V1; ++i) r.nums.push_back(i == 1 ? 5 : 0); r.impl = BULL; r.line1 = "old";
        Row o; CHECK(parseRow(rowLine(r), (size_t)REC_NUMS, o) && o.nums.size() == (size_t)REC_NUMS && o.nums[1] == 5 && o.nums[REC_NUMS - 1] == 0 && recFrom(o.nums, 0, y) && y.pace100[0] == 0, "a 1.0 / 1.1 record (38 numbers) still loads: the new numbers read 0");
        Row r4 = r; r4.nums.insert(r4.nums.begin(), 4, 7);
        CHECK(parseRow(rowLine(r4), (size_t)(4 + REC_NUMS), o) && o.nums.size() == (size_t)(4 + REC_NUMS) && o.nums[0] == 7, "BidAskStats' legacy 42-number record loads too");
        CHECK(!parseRow(rowLine(r), (size_t)REC_NUMS + 1, o), "any other count is refused");
    }
    // ================= the options file: a same-second, same-size rewrite is re-read within a minute =================
    {
        char tmpl[] = "/tmp/opuXXXXXX"; const std::string dir = mkdtemp(tmpl); const std::string f = dir + "\\LRA-Options-CL.csv";
        { std::ofstream o(f.c_str()); o << "VERSION,1\nMARKET,CL\nASOF,1792000000\nOPULL,CR,95,-30,dn\n"; }
        OptCache C; refreshOptions(C, dir, "CL", 0, [](long long) { return 100LL; });
        { std::ofstream o(f.c_str()); o << "VERSION,1\nMARKET,CL\nASOF,1792000300\nOPULL,CR,95,-30,dn\n"; }   // same size, same second
        refreshOptions(C, dir, "CL", 6000, [](long long) { return 160LL; }); const size_t n1 = C.hist.v.size();
        refreshOptions(C, dir, "CL", 61000, [](long long) { return 220LL; });
        CHECK(C.hist.v.size() == 2 && C.hist.v[1].barKey == 220 && n1 <= 2, "re-read once a minute even when the stamp did not change; the new grid arrives then");
    }
    // ================= R? STOP RUN (BidAskStats 1.4.0 code from /home/claude/aud/sr/out, tested here: it had no tests) =================
    {
        const double T = 0.25; sr::Params SP; std::vector<sr::KeyLevel> L(1); L[0].name = "PDL"; L[0].px = 100.0; int rk = 9; L[0].dir = sr::keyDir("PDL", rk); L[0].rank = rk;
        auto B = [](long long t, double h, double l, double c, bool spikeBid = false, bool sweepBid = false) { sr::Bar b; b.t = t; b.h = h; b.l = l; b.c = c; b.spike[0] = spikeBid; b.sweep[0] = sweepBid; b.ratioOk[0] = true; b.ratio[0] = 4.2; return b; };
        CHECK(L[0].dir == -1 && rk == 1 && sr::keyDir("LonHI", rk) == 1 && sr::keyDir("VWAP", rk) == 0, "key levels: highs +1, lows -1, others not used");
        { sr::Detector d; auto e1 = d.onClose(B(60, 100.5, 99.5, 99.75, true), true, 100.5, L, T, SP);
          CHECK(e1.empty() && d.pending.size() == 1, "a downside break with a spike on the sellers' bar: watched, nothing drawn yet");
          auto e2 = d.onClose(B(120, 100.75, 99.75, 100.25), true, 99.75, L, T, SP);
          CHECK(e2.size() == 1 && e2[0].dir == -1 && e2[0].breakT == 60 && e2[0].reclaimT == 120 && e2[0].bars == 1 && e2[0].ticks == 2 && e2[0].level == "PDL" && sr::markText(e2[0]) == "R?",
                "closed back above PDL the next bar: green R? (sellers trapped), decided at the reclaim bar's close, marked on the break bar");
          CHECK(sr::message(e2[0]) == "Stop run? below PDL - sellers trapped (4.2x spike, back inside in 1 bar)", "the stop-run message (? until SHOW,on)"); }
        { sr::Detector d; auto e = d.onClose(B(60, 100.5, 99.5, 99.75), true, 100.5, L, T, SP); e = d.onClose(B(120, 100.5, 99.75, 100.25), true, 99.75, L, T, SP);
          CHECK(e.empty() && d.noBurst == 1, "no sweep / spike on the break side: no R"); }
        { sr::Detector d; d.onClose(B(60, 100.5, 99.5, 99.75, false, true), true, 100.5, L, T, SP); d.onClose(B(120, 99.9, 99.5, 99.6), true, 99.75, L, T, SP);
          auto e0 = d.onClose(B(180, 99.9, 99.5, 99.7), true, 99.6, L, T, SP); auto e = d.onClose(B(240, 100.5, 99.5, 100.25), true, 99.7, L, T, SP);
          CHECK(e0.empty() && e.empty() && d.held == 1, "still outside after N = 2 bars: the break held, no R (a later close back inside is not a stop run)");
          sr::Detector d2; d2.onClose(B(60, 100.5, 99.5, 99.75, false, true), true, 100.5, L, T, SP); d2.onClose(B(120, 99.9, 99.5, 99.6), true, 99.75, L, T, SP);
          auto e2 = d2.onClose(B(180, 100.5, 99.5, 100.25), true, 99.6, L, T, SP);
          CHECK(e2.size() == 1 && e2[0].bars == 2 && e2[0].sweep && !e2[0].spike, "a sweep break back inside on the 2nd bar (N = 2): R"); }
        { sr::Detector d; auto e = d.onClose(B(60, 100.5, 99.5, 100.25, true), true, 100.5, L, T, SP);
          CHECK(e.size() == 1 && e[0].bars == 0, "back inside on the break bar itself: R at its close"); }
        { sr::Detector d; auto e = d.onClose(B(60, 100.5, 99.5, 100.25, true), true, 99.5, L, T, SP);
          CHECK(e.empty(), "approached from the wrong side (prior close below the low): no break"); }
        { sr::Detector d; auto e = d.onClose(B(60, 100.5, 99.80, 100.25, true), true, 100.5, L, T, SP);
          CHECK(e.empty(), "less than 1 tick beyond: no break"); }
        { sr::Detector d; d.onClose(B(60, 100.5, 99.5, 99.75, true), true, 100.5, L, T, SP);
          CHECK(d.onClose(B(60, 100.5, 99.5, 100.25), true, 99.75, L, T, SP).empty() && d.onClose(B(30, 100.5, 99.5, 100.25), true, 99.75, L, T, SP).empty(), "a bar fed twice / out of order is ignored (no repaint)"); }
        { sr::Params on = sr::parseParams({ "VERSION,1", "N,1", "SHOW,on" }); sr::Detector d;
          d.onClose(B(60, 100.5, 99.5, 99.75, true), true, 100.5, L, T, on); auto e = d.onClose(B(120, 100.5, 99.6, 99.7), true, 99.75, L, T, on);
          CHECK(on.n == 1 && on.show == sr::SHOW_ON && e.empty() && d.held == 1, "LRA-StopRun N,1: one bar to get back inside");
          sr::Detector d2; auto e2 = d2.onClose(B(60, 100.5, 99.5, 100.25, true), true, 100.5, L, T, on);
          CHECK(e2.size() == 1 && sr::markText(e2[0]) == "R" && sr::message(e2[0]).find("Stop run below") == 0, "SHOW,on: R without ?"); }
        CHECK(sr::parseParams({ "VERSION,2" }).source.find("defaults") == 0 && sr::parseParams({ "VERSION,1", "N,99" }).n == sr::N_DEFAULT && sr::parseParams({ "VERSION,1", "SHOW,maybe" }).show == sr::SHOW_Q
              && sr::parseParams({ "VERSION,1", "EXTRA,5", "SHOW,off" }).show == sr::SHOW_OFF, "params: bad file / value = the defaults (N 2, SHOW ?); unknown upper-case keys ignored");
        { std::vector<sr::KeyLevel> two = L; sr::KeyLevel pf; pf.name = "PFL"; pf.px = 100.0; int r2 = 9; pf.dir = sr::keyDir("PFL", r2); pf.rank = r2; two.push_back(pf);
          sr::Detector d; auto e = d.onClose(B(60, 100.5, 99.5, 100.25, true), true, 100.5, two, T, SP);
          CHECK(e.size() == 1 && e[0].level == "PFL/PDL", "two levels broken by the same bar: one R, the higher rank named first"); }
        { sr::Event e; e.breakT = 1791900060; e.reclaimT = 1791900120; e.dir = 1; e.level = "PDH"; e.px = 5800.25; e.ticks = 6; e.bars = 1; e.spike = true; e.ratioOk = true; e.ratio = 4.2; e.show = sr::SHOW_Q; e.n = 2;
          const std::string ln = sr::eventLine(e, "10:24"); sr::Event x; std::string ct;
          CHECK(sr::parseEvent(ln, x, &ct) && x.breakT == e.breakT && x.reclaimT == e.reclaimT && x.dir == 1 && x.level == "PDH" && x.ticks == 6 && x.ratio == 4.2 && x.show == sr::SHOW_Q && ct == "10:24", "SR| record line round trip (a restart shows the same R?)");
          CHECK(!sr::parseEvent(ln + "|x", x) && !sr::parseEvent("SR|1|0|x|up|PDH|1|1|1|-|spike|?|2|m", x), "a bad SR line is refused"); }
    }
    std::printf("of140 logic: %d passed, %d failed\n", passes, fails); return fails ? 1 : 0;
}
