// test_off_logic.cpp -- OrderFlowFeed.h (shared engine) + PullStatsLogic.h + StackStatsLogic.h + BidAskStatsLogic.h, no SDK.
// (of140) the PullStats / StackStats bars are LOTS (pullC / addC) and the messages follow the SPEC grammar: the expectations of the
// stats / message / info blocks were updated for those deliberate changes; the new SPEC-line tests are in test_of140_logic.cpp.
#include "PullStatsLogic.h"
#include "StackStatsLogic.h"
#include "BidAskStatsLogic.h"
#include <cstdio>
#include <fstream>
#include <unistd.h>
static int fails = 0, passes = 0;
#define CHECK(c, m) do { if (c) ++passes; else { ++fails; std::printf("FAIL %d %s\n", __LINE__, m); } } while (0)
using namespace off;
static Ev ev(int a, int side, Tick px, long long size, long long id, long long ms = 0, long long st = 0, long long aggr = 0) {
    Ev e; e.action = a; e.side = side; e.px = px; e.size = size; e.id = id; e.arrMs = ms; e.stamp = st; e.aggr = aggr; return e;
}
static Engine eng(Tick ref = 1000, Tick near = 10) { Engine e; e.ref = ref; e.haveRef = true; e.near = near; return e; }
static int W6(const std::string& s) { return (int)s.size() * 6; }
// a PaneBar with given numbers and ratios on metric 0 / 1
static PaneBar pb(int metricCount, const long long v0[2], const double r0[2], const long long v1[2] = nullptr, const double r1[2] = nullptr) {
    PaneBar b; b.ok = true; b.r.events = 10;
    for (int s = 0; s < 2; ++s) { b.m[0].ratioOk[s] = true; b.m[0].ratio[s] = r0[s]; b.r.pullN[s] = v0[s]; b.r.addN[s] = v0[s]; b.r.pullC[s] = v0[s] * 4; b.r.addC[s] = v0[s] * 3; b.r.addTop[s] = 3; }
    if (metricCount > 1) for (int s = 0; s < 2; ++s) { b.m[1].ratioOk[s] = true; b.m[1].ratio[s] = r1[s]; b.r.refN[s] = v1[s]; }
    return b;
}

int main() {
    CHECK(std::string(off::VERSION) == "1.5.0" && std::string(ps::VERSION) == "1.4.0" && std::string(st::VERSION) == "1.3.0" && std::string(bas::VERSION) == "1.6.0", "versions");
    // ================= DBO classification NEW / MOD / DEL / FILL =================
    {
        Engine e = eng(); Acc a;
        e.apply(a, ev(NEW, BID, 995, 5, 1)); e.apply(a, ev(NEW, ASK, 1004, 7, 2)); e.apply(a, ev(NEW, BID, 990, 3, 3));
        CHECK(a.addN[BID] == 2 && a.addC[BID] == 8 && a.addN[ASK] == 1 && a.addC[ASK] == 7, "NEW near -> added orders / contracts per side");
        e.apply(a, ev(DEL, BID, 995, 5, 1));
        CHECK(a.pullN[BID] == 1 && a.pullC[BID] == 5 && a.pullN[ASK] == 0, "DEL of a resting bid -> 1 bid pulled, its size");
        e.apply(a, ev(FILL, ASK, 1004, 7, 2)); e.apply(a, ev(DEL, ASK, 1004, 0, 2));
        CHECK(a.pullN[ASK] == 0 && a.pullC[ASK] == 0, "FILL then DEL is NOT a pull");
        e.apply(a, ev(FILL, BID, 990, 1, 3)); e.apply(a, ev(DEL, BID, 990, 2, 3));
        CHECK(a.pullN[BID] == 1, "DEL right after a partial FILL is not a pull");
        e.apply(a, ev(NEW, ASK, 1003, 4, 4)); e.apply(a, ev(FILL, ASK, 1003, 1, 4)); e.apply(a, ev(MOD, ASK, 1003, 3, 4)); e.apply(a, ev(DEL, ASK, 1003, 3, 4));
        CHECK(a.pullN[ASK] == 1 && a.pullC[ASK] == 3, "FILL -> MOD (the rest) -> DEL later = a pull of the rest");
        CHECK(e.perAction[NEW] == 4 && e.perAction[FILL] == 3 && e.perAction[DEL] == 4 && e.perAction[MOD] == 1, "action counters");
    }
    {   // MOD price move / size changes
        Engine e = eng(); Acc a;
        e.apply(a, ev(NEW, BID, 998, 6, 1)); e.apply(a, ev(MOD, BID, 996, 6, 1));
        CHECK(a.pullN[BID] == 1 && a.pullC[BID] == 6 && a.addN[BID] == 2 && a.addC[BID] == 12, "MOD to a new price: pull at the old + add at the new (both near)");
        e.apply(a, ev(MOD, BID, 900, 6, 1));
        CHECK(a.pullN[BID] == 2 && a.addN[BID] == 2, "MOD away to a far price: the pull counted, the far add not");
        e.apply(a, ev(MOD, BID, 999, 6, 1));
        CHECK(a.pullN[BID] == 2 && a.addN[BID] == 3, "MOD from far into the band: add only");
        e.apply(a, ev(MOD, BID, 999, 4, 1));
        CHECK(a.pullN[BID] == 2 && a.pullC[BID] == 14, "MOD smaller at the same price: contracts only (partial pull)");
        e.apply(a, ev(MOD, BID, 999, 9, 1));
        CHECK(a.addN[BID] == 3 && a.addC[BID] == 23, "MOD bigger at the same price: contracts only (+5)");
        e.apply(a, ev(FILL, BID, 999, 2, 1)); e.apply(a, ev(MOD, BID, 999, 5, 1));
        CHECK(a.pullC[BID] == 14, "MOD shrinking right after a FILL is not a pull");
        e.apply(a, ev(MOD, ASK, 1002, 5, 77));
        CHECK(e.unknownMod == 1 && a.addN[ASK] == 0 && e.book.count(77), "MOD of an unseen order: learned, nothing counted");
        e.apply(a, ev(DEL, ASK, 1002, 5, 77));
        CHECK(a.pullN[ASK] == 1 && a.pullC[ASK] == 5, "...its later DEL is a pull");
    }
    {   // unseen orders, near band
        Engine e = eng(); Acc a;
        e.apply(a, ev(DEL, ASK, 1005, 8, 50)); e.apply(a, ev(DEL, ASK, 1100, 8, 51));
        CHECK(a.pullN[ASK] == 1 && a.pullC[ASK] == 8 && e.unknownDel == 2, "unseen DEL near = a pull; far = nothing");
        e.apply(a, ev(FILL, BID, 999, 3, 52)); e.apply(a, ev(DEL, BID, 999, 0, 52));
        CHECK(a.pullN[BID] == 0 && e.unknownFill == 1, "unseen FILL then DEL: not a pull (tombstone)");
        Engine n = eng(1000, 10); Acc b;
        n.apply(b, ev(NEW, BID, 990, 1, 1)); n.apply(b, ev(NEW, BID, 989, 1, 2)); n.apply(b, ev(NEW, ASK, 1010, 1, 3)); n.apply(b, ev(NEW, ASK, 1011, 1, 4));
        CHECK(b.addN[BID] == 1 && b.addN[ASK] == 1, "near band inclusive: distance 10 in, 11 out (both sides)");
        Engine f; Acc c; f.near = 10; f.apply(c, ev(NEW, BID, 1000, 1, 1));
        CHECK(c.addN[BID] == 0, "no last price yet: nothing is near");
        f.fallbackRef(1000, 0); f.apply(c, ev(NEW, BID, 1000, 1, 2));
        CHECK(c.addN[BID] == 1, "the chart's close is the fallback last price");
        f.apply(c, ev(FILL, BID, 1000, 1, 2)); f.fallbackRef(500, 1000);
        CHECK(f.ref == 1000, "a fill in the last 5 s wins over the chart close");
        f.fallbackRef(500, 7000);
        CHECK(f.ref == 500, "no fill for 5 s: the chart close again");
        const nl::Zone es = nl::zoneFor("ES");
        CHECK(nl::nearBand(2.0, 0.25, es, 0) == 16 && nl::nearBand(10.0, 0.25, es, 0) == 40 && nl::nearBand(10.0, 0.25, es, 7) == 7, "near band = Liquidity Profile 0.14.0 rule (ES)");
        CHECK(nl::nearBand(0.30, 0.01, nl::zoneFor("CL"), 0) == 32 && nl::nearBand(0.60, 0.01, nl::zoneFor("CL"), 0) == 60, "CL: max(round(ATR/tick), 4 x hw)");
        CHECK(std::fabs(nl::atrOf({ 1, 2, 3 }, 60) - 2.0 * std::sqrt(3.0)) < 1e-9 && nl::atrOf({ 1, 2, 3 }, 180) == 2.0, "ATR scaled to a 3-min bar");
    }
    {   // pulled just before price got there (within closeTicks of the last trade)
        Engine e = eng(1000, 10); Acc a;
        e.apply(a, ev(NEW, ASK, 1002, 3, 1)); e.apply(a, ev(NEW, ASK, 1003, 3, 2)); e.apply(a, ev(NEW, ASK, 1006, 3, 3));
        e.apply(a, ev(DEL, ASK, 1002, 3, 1)); e.apply(a, ev(DEL, ASK, 1003, 3, 2)); e.apply(a, ev(DEL, ASK, 1006, 3, 3));
        CHECK(a.pullN[ASK] == 3 && a.pullClose[ASK] == 1, "within 2 ticks counts (1002), 3+ ticks not");
    }
    // ================= SWEEPS + LARGE AGGRESSOR =================
    {
        Engine e = eng(1000, 50); Acc a; Params P; P.largeBarMin = 0;   // (1.3.0) the per-order rule alone (no candle history needed)
        // aggressor 900 (a seller) hits bids at 999, 998, 997 = 3 prices; aggressor 901 hits bids at 2 prices
        e.apply(a, ev(FILL, BID, 999, 10, 11, 0, 0, 900)); e.apply(a, ev(FILL, BID, 998, 10, 12, 0, 0, 900)); e.apply(a, ev(FILL, BID, 997, 5, 13, 0, 0, 900));
        e.apply(a, ev(FILL, BID, 996, 4, 14, 0, 0, 901)); e.apply(a, ev(FILL, BID, 995, 4, 15, 0, 0, 901));
        e.apply(a, ev(FILL, ASK, 1001, 2, 16, 0, 0, 902)); e.apply(a, ev(FILL, ASK, 1002, 2, 17, 0, 0, 902));
        e.apply(a, ev(FILL, ASK, 1001, 1, 18, 0, 0, 0));
        Rec r = e.close(a, false, P);
        CHECK(r.sweepLv[BID] == 3 && r.sweepSize[BID] == 25 && r.aggrMax[BID] == 25 && r.sweepIsMax[BID] == 1, "one aggressor id at 3 prices = sweep levels 3, its 25 lots");
        CHECK(r.sweepLv[ASK] == 2 && bas::letters(r, 1, P).find('S') == std::string::npos, "2 prices: no S");
        CHECK(bas::letters(r, 0, P).find('S') != std::string::npos && r.thrAggr == 20 && bas::letters(r, 0, P) == "SL", "3 prices: S; 25 >= 20 (empty session: the 20-lot minimum) -> L too, priority S then L");
        CHECK(a.aggrUnknown == 1, "a fill without an aggressor id is counted, never a sweep");
        P.sweepLevels = 4; CHECK(bas::letters(r, 0, P) == "L", "sweepLevels from the params file (4)");
        CHECK(e.aggrDist.total == 3, "the candle's aggressor orders join the session distribution AFTER its threshold");
    }
    {   // large-lot percentile + min
        SizeDist d; for (int i = 1; i <= 100; ++i) d.add(i);
        CHECK(d.pct(99) == 99 && d.pct(50) == 50 && d.pct(100) == 100, "nearest-rank percentile");
        CHECK(largeThreshold(d, 0, 99, 20) == 99 && largeThreshold(d, 0, 50, 60) == 60 && largeThreshold(d, 35, 99, 20) == 35, "auto = max(min, p99); a fixed value wins");
        SizeDist e; CHECK(largeThreshold(e, 0, 99, 20) == 20, "nothing seen yet: the minimum");
        SizeDist f; for (int i = 0; i < 1000; ++i) f.add(2); f.add(500);
        CHECK(largeThreshold(f, 0, 99, 20) == 20, "99th pct of mostly 2-lots = 2 -> the 20-lot floor");
        SizeDist g; CHECK(g.load(d.save()) && g.total == 100 && g.pct(99) == 99, "distribution save / load round trip");
        CHECK(!g.load("1:2,x:3") && g.total == 100 && !g.load("0:1") && g.load("") && g.total == 0, "malformed distribution refused (unchanged); empty = cleared");
        SizeDist h; for (long long i = 1; i <= (long long)SizeDist::KEYS + 50; ++i) h.add(i);
        CHECK(h.n.size() == SizeDist::KEYS && h.total == (long long)SizeDist::KEYS + 50, "bounded: distinct sizes capped, counts kept");
        // L for resting orders: pulled / added with size >= the resting threshold (as of the candles before)
        Engine k = eng(1000, 10); Params P; P.largeBarMin = 0; Acc a1;   // (1.3.0) the per-order rule alone
        for (int i = 0; i < 99; ++i) k.apply(a1, ev(NEW, BID, 995, 5, 100 + i));
        k.apply(a1, ev(NEW, BID, 995, 40, 500));
        Rec r1 = k.close(a1, false, P);
        CHECK(r1.thrRest == 20 && r1.addMax[BID] == 40 && st::letters(PaneBar(), 0, P).empty(), "first candle: the 20-lot floor (nothing before it)");
        Acc a2; k.apply(a2, ev(NEW, ASK, 1003, 30, 600)); k.apply(a2, ev(DEL, ASK, 1003, 30, 600)); k.apply(a2, ev(DEL, BID, 995, 40, 500));
        Rec r2 = k.close(a2, false, P);
        CHECK(r2.thrRest == 20 && ps::letters(r2, ASK) == "L" && ps::letters(r2, BID) == "L" && r2.pullMax[ASK] == 30, "pulled 30-lot and 40-lot >= 20: L on both sides");
        Acc a3; for (int i = 0; i < 200; ++i) k.apply(a3, ev(NEW, BID, 996, 50, 1000 + i));
        k.close(a3, false, P); Acc a4; k.apply(a4, ev(NEW, ASK, 1004, 45, 5000)); Rec r4 = k.close(a4, false, P);
        CHECK(r4.thrRest >= 50 && r4.addMax[ASK] == 45 && ps::letters(r4, ASK).empty(), "after 200 x 50-lots the 99th pct is 50: a 45-lot is not large");
    }
    // ================= REFILLS, ICEBERG =================
    {
        Engine e = eng(); e.refillMs = 1000; Acc a;
        e.apply(a, ev(NEW, BID, 999, 5, 1, 0, 100)); e.apply(a, ev(FILL, BID, 999, 5, 1, 100, 100)); e.apply(a, ev(DEL, BID, 999, 0, 1, 110, 100));
        CHECK(a.refN[BID] == 0, "FILL then DEL: not a refill");
        e.apply(a, ev(NEW, BID, 999, 5, 2, 600, 100));
        CHECK(a.refN[BID] == 1 && a.refC[BID] == 5 && a.addN[BID] == 2, "NEW same side + price within 1000 ms of the fill = refill (also an add)");
        e.apply(a, ev(NEW, BID, 998, 5, 3, 650, 100)); CHECK(a.refN[BID] == 1, "different price: not a refill");
        e.apply(a, ev(NEW, ASK, 999, 5, 4, 650, 100)); CHECK(a.refN[ASK] == 0 && a.refN[BID] == 1, "other side at that price: not a refill");
        e.apply(a, ev(NEW, BID, 999, 5, 5, 1101, 101)); CHECK(a.refN[BID] == 1, "1101 ms after the fill: outside the window");
        e.apply(a, ev(NEW, BID, 999, 5, 55, 1100, 101)); CHECK(a.refN[BID] == 2, "exactly 1000 ms: inside (inclusive)");
        e.apply(a, ev(FILL, BID, 999, 5, 2, 2000, 200)); e.apply(a, ev(MOD, BID, 999, 9, 5, 2500, 200));
        CHECK(a.refN[BID] == 3 && a.refC[BID] == 14, "a size increase after a fill at that price = refill (+4 contracts)");
        e.apply(a, ev(FILL, BID, 999, 1, 5, 3000, 300)); e.apply(a, ev(NEW, BID, 999, 2, 6, 3100, 305));
        CHECK(a.refN[BID] == 3, "stamps 5 s apart (a drained backlog) are never a refill");
        e.refillMs = 300; e.apply(a, ev(FILL, BID, 999, 1, 6, 4000, 400)); e.apply(a, ev(NEW, BID, 999, 2, 7, 4400, 400));
        CHECK(a.refN[BID] == 3, "refillWindowMs 300 from the params file: 400 ms = outside");
    }
    {   // iceberg confirmed only at refill prices: traded more than ever displayed there
        Engine e = eng(); Acc a; Params P;
        e.apply(a, ev(NEW, ASK, 1001, 10, 1, 0, 1)); e.apply(a, ev(FILL, ASK, 1001, 10, 1, 10, 1)); e.apply(a, ev(DEL, ASK, 1001, 0, 1, 11, 1));
        e.apply(a, ev(NEW, ASK, 1001, 10, 2, 100, 1)); e.apply(a, ev(FILL, ASK, 1001, 10, 2, 200, 1));          // refill, traded 20 vs shown 10
        e.apply(a, ev(NEW, BID, 999, 30, 3, 0, 1)); e.apply(a, ev(FILL, BID, 999, 10, 3, 300, 1)); e.apply(a, ev(NEW, BID, 999, 5, 4, 350, 1));   // refill, 10 of 35 = not
        e.apply(a, ev(NEW, ASK, 1003, 4, 9, 0, 1)); e.apply(a, ev(FILL, ASK, 1003, 4, 9, 400, 1)); e.apply(a, ev(FILL, ASK, 1003, 6, 99, 400, 1));   // traded > shown but no refill
        const Rec r = e.close(a, false, P);
        CHECK(r.ice[ASK] == 1 && r.iceShown[ASK] == 10 && r.iceTraded[ASK] == 20 && r.ice[BID] == 0, "iceberg at the refill price 1001: 20 traded vs 10 shown; 10 of 35 not");
        CHECK(r.refN[ASK] == 1 && r.refN[BID] == 1, "refills counted on both sides");
    }
    {   // concentration, garbage, bounded memory
        Engine e = eng(); Acc a; Params P;
        e.apply(a, ev(NEW, BID, 999, 18, 1)); e.apply(a, ev(NEW, BID, 999, 1, 2)); e.apply(a, ev(NEW, BID, 999, 6, 3)); e.apply(a, ev(MOD, BID, 999, 21, 3));
        const Rec r = e.close(a, false, P);
        CHECK(r.addTop[BID] == 21 && r.addC[BID] == 40 && st::concText(r.addTop[BID], r.addC[BID], r.addN[BID]) == "1 order = 53%  avg 13.3 cts", "concentration 21/40 = 53%, avg 13.3");
        Engine g = eng(); Acc b;
        g.apply(b, ev(7, BID, 999, 1, 1)); g.apply(b, ev(NEW, BID, 0, 1, 2)); g.apply(b, ev(NEW, BID, 999, -1, 3));
        g.apply(b, ev(NEW, BID, 999, SIZE_MAX_SANE + 1, 4)); g.apply(b, ev(NEW, -1, 999, 1, 5)); g.apply(b, ev(DEL, -1, 999, 1, 6));
        CHECK(g.garbage == 6 && g.events == 0 && b.events == 0 && g.book.empty(), "bad action / price / size / unknown side: ignored, counted");
        g.apply(b, ev(NEW, ASK, 1001, 2, 8)); g.apply(b, ev(DEL, -1, 1001, 2, 8));
        CHECK(b.pullN[ASK] == 1, "a DEL with an unknown side uses the order's own side");
        g.apply(b, ev(NEW, ASK, 1001, 2, 9)); g.apply(b, ev(NEW, ASK, 1001, 2, 9));
        CHECK(b.addN[ASK] == 2 && g.dupNew == 1, "a duplicate NEW is never counted twice");
        Engine h = eng(1000, 10); Acc c;
        for (long long i = 0; i < (long long)BOOK_CAP; ++i) h.apply(c, ev(NEW, BID, 1000 - 50 - (i % 100), 1, i + 1));
        for (long long i = 0; i < 100; ++i) h.apply(c, ev(NEW, BID, 995, 1, 1000000 + i));
        CHECK(h.book.size() < BOOK_CAP && h.bookDrops >= (long long)BOOK_CAP - 100 && h.book.count(1000000 + 99) && h.bookResets == 0, "order map cap: far orders dropped first, near kept");
        Engine k = eng(1000, 1000000); Acc d;
        for (long long i = 0; i <= (long long)BOOK_CAP; ++i) k.apply(d, ev(NEW, BID, 999, 1, i + 1));
        CHECK(k.bookResets == 1 && k.book.empty(), "all near and still over the cap: forgotten (bounded)");
        Engine m = eng(1000, 100000); Acc q; for (long long i = 0; i < (long long)AGGR_CAP + 5; ++i) m.apply(q, ev(FILL, BID, 999, 1, i + 1, 0, 0, i + 1));
        CHECK(q.aggr.size() == AGGR_CAP && q.aggrCap, "aggressor map capped");
        Engine z = eng(); Acc y; for (int i = 0; i < (int)FILLMEM_CAP + 10; ++i) z.apply(y, ev(FILL, ASK, 2000 + i, 1, i + 1, 5000 + i, 1));
        CHECK(z.lastFill[ASK].size() <= FILLMEM_CAP, "fill memory bounded");
    }
    // ================= STATS (spike boundaries, partial, floor) =================
    {
        SpikeCfg c;
        CHECK(isSpike(20, 10, 13, c) && !isSpike(19, 10, 12, c), "spike: exactly 2.0x the average and >= 1.5x the prior biggest; 19 not");
        CHECK(isSpike(15, 7.5, 10, c) && !isSpike(14, 7.0, 10, c), "exactly 1.5x the prior biggest = spike; 1.4x not");
        SpikeCfg o; o.lookback = 0; CHECK(!isSpike(100, 1, 1, o), "lookback 0 = off");
        PaneSeries<ps::Logic> s;
        for (int i = 0; i < 10; ++i) { Rec r; r.events = 5; r.pullC[BID] = 10; r.pullC[ASK] = 10; s.bars[100 + i] = s.make(100 + i, r); }
        Rec big; big.events = 5; big.pullC[BID] = 30; big.pullC[ASK] = 5; s.bars[200] = s.make(200, big);
        CHECK(s.bars[200].m[0].ratio[BID] == 3.0 && s.bars[200].m[0].spike[BID] && !s.bars[200].m[0].spike[ASK], "30 vs avg 10 / prior 10 = spike 3.0x");
        Rec more; more.events = 5; more.pullC[BID] = 1; s.bars[300] = s.make(300, more);
        CHECK(s.bars[200].m[0].spike[BID], "later bars never change an earlier one");
        PaneSeries<ps::Logic> p; Rec part; part.events = 5; part.partial = true; part.pullC[BID] = 1000; p.bars[50] = p.make(50, part);
        for (int i = 0; i < 5; ++i) { Rec r; r.events = 5; r.pullC[BID] = 10; r.pullC[ASK] = 10; p.bars[100 + i] = p.make(100 + i, r); }
        Rec x; x.events = 5; x.pullC[BID] = 20; const PaneBar bx = p.make(200, x);
        CHECK(bx.m[0].ratio[BID] == 2.0 && bx.m[0].priorMax == 10, "a partial bar is in no average / lookback");
        Rec none; CHECK(!p.make(250, none).ok, "no events = n/a");
        PaneSeries<ps::Logic> q; for (int i = 0; i < 6; ++i) { Rec r; r.events = 5; r.pullC[BID] = i % 2; q.bars[i + 1] = q.make(i + 1, r); }
        Rec y; y.events = 5; y.pullC[BID] = 3; const PaneBar by = q.make(20, y);
        CHECK(by.m[0].ratio[BID] == 3.0 && by.m[0].mean[BID] == 1.0, "mean floored at 1 lot (0.5 average -> 3 lots = 3.0x, not 6x)");
        CHECK(effectiveSpike(SpikeCfg(), Params()) == SpikeCfg(), "no params file: the dialog's spike settings");
        Params P; P.spikeAvgT = 30; P.fromFile.insert("spikeAvgX"); SpikeCfg d; d.jumpT = 12;
        const SpikeCfg ef = effectiveSpike(d, P); CHECK(ef.avgT == 30 && ef.jumpT == 12, "params file wins where it sets a value");
        SpikeCfg d0; d0.avgT = 0; CHECK(!effectiveSpike(d0, P).on(), "the dialog's 0 = off always wins");
    }
    // ================= PARAMS FILE =================
    {
        auto L = [](const std::vector<std::string>& v) { return parseParams(true, true, v, "CL"); };
        ParamLoad a = L({ "VERSION,1", "MARKET,CL", "# comment", "PARAM,sweepLevels,4", "PARAM,refillNotableX,2.5", "PARAM,largeLotAggr,50" });
        CHECK(a.p.sweepLevels == 4 && a.p.refillNotableT == 25 && a.p.largeLotAggr == 50 && a.p.file("sweepLevels") && !a.p.file("spikeAvgX") && a.notes.empty() && a.source.find("file") == 0, "valid file parsed");
        ParamLoad b = L({ "VERSION,1", "MARKET,CL", "PARAM,sweepLevels,1", "PARAM,largeLotPct,abc", "PARAM,bogus,3", "PARAM,spikeJumpX,1.7" });
        CHECK(b.p.sweepLevels == 3 && b.p.largeLotPct == 99 && b.p.spikeJumpT == 17 && b.notes.size() == 3, "bad values -> defaults with reasons, unknown names noted, good ones used");
        CHECK(b.notes[0].find("sweepLevels: bad value '1' (2..20) - default 3") != std::string::npos, "the reason says what and the default");
        CHECK(L({ "VERSION,2", "MARKET,CL", "PARAM,sweepLevels,4" }).p.sweepLevels == 3 && L({ "VERSION,1", "MARKET,ES", "PARAM,sweepLevels,4" }).source.find("MARKET mismatch") != std::string::npos, "bad VERSION / wrong MARKET = whole file ignored");
        CHECK(L({ "MARKET,CL", "VERSION,1" }).source.find("VERSION line missing") != std::string::npos && L({}).source.find("empty") != std::string::npos && L({ "VERSION,1" }).source.find("MARKET line missing") != std::string::npos, "missing VERSION / MARKET");
        CHECK(parseParams(false, false, {}, "CL").source == "defaults (no params file)" && parseParams(true, false, {}, "CL").source.find("unreadable") != std::string::npos, "no file / unreadable");
        CHECK(paramsText(a.p).find("sweepLevels=4(file)") != std::string::npos && paramsText(a.p).find("refillNotableX=2.5x(file)") != std::string::npos && paramsText(a.p).find("spikeAvgX=2.0x(default)") != std::string::npos, "status text shows the source of each value");
        char tmpl[] = "/tmp/offpXXXXXX"; const char* dir = mkdtemp(tmpl);
        ParamCache C; CHECK(refreshParams(C, dir, "NG", 0) && C.load.source == "defaults (no params file)", "cache: missing file");
        { std::ofstream f((std::string(dir) + "\\LRA-OrderFlow-NG.csv").c_str()); f << "VERSION,1\r\nMARKET,NG\r\nPARAM,closeTicks,3\r\n"; }
        CHECK(!refreshParams(C, dir, "NG", 1000), "re-checked at most every 5 s");
        CHECK(refreshParams(C, dir, "NG", 6000) && C.load.p.closeTicks == 3, "CRLF file read on its new stamp");
        { std::ofstream f((std::string(dir) + "\\LRA-OrderFlow-NG.csv").c_str()); for (int i = 0; i < 500; ++i) f << "PARAM,closeTicks,3\n"; }
        CHECK(refreshParams(C, dir, "NG", 20000) && C.load.source.find("unreadable") != std::string::npos, "a file over 400 lines: defaults (bounded read)");
    }
    // ================= SESSION FILE =================
    {
        Row r; r.t = 1791900060; r.ct = "10:24"; r.dbo = 1; r.nums = { 1, 2, 3 }; r.let[0] = "SL"; r.let[1] = ""; r.spike[0] = 1; r.dash[1] = 7;
        r.impl = BULL; r.level = "LonLO"; r.line1 = "Sellers hit | the bid"; r.line2 = "BBid 240";
        Row b; CHECK(parseRow(rowLine(r), 3, b) && b.t == r.t && b.let[0] == "SL" && b.spike[0] == 1 && b.dash[1] == 7 && b.dash[0] == -1 && b.impl == BULL && b.level == "LonLO" && b.line1 == "Sellers hit   the bid", "row round trip ('|' cleaned)");
        CHECK(!parseRow(rowLine(r), 4, b) && !parseRow(rowLine(r) + "|x", 3, b) && !parseRow("x" + rowLine(r), 3, b), "wrong field count / garbage refused");
        Row bad = r; bad.let[0] = "Q"; CHECK(!parseRow(rowLine(bad), 3, b), "unknown letter refused");
        { Row lg = r; lg.let[0] = "RL"; lg.let[1] = "R"; Row o; CHECK(parseRow(rowLine(lg), 3, o) && o.let[0] == "IL" && o.let[1] == "I", "1.0.1: a 1.0.0 record's legacy R reads back as I");
          Row ni = r; ni.let[0] = "IL"; CHECK(parseRow(rowLine(ni), 3, o) && o.let[0] == "IL" && rowLine(o) == rowLine(ni), "I accepted and round-trips"); }
        Rec x; x.events = 9; x.pullN[1] = 4; x.addTop[0] = 2; x.addC[0] = 5; x.sweepLv[0] = 3; x.ice[1] = 1; x.iceShown[1] = 4; x.iceTraded[1] = 9; x.thrAggr = 20; x.thrRest = 30;
        std::vector<long long> v; recNums(x, v); Rec y;
        CHECK((int)v.size() == REC_NUMS && recFrom(v, 0, y) && y.events == 9 && y.pullN[1] == 4 && y.sweepLv[0] == 3 && y.iceTraded[1] == 9 && y.thrRest == 30, "Rec numbers round trip");
        Rec z = x; z.addTop[0] = 6; std::vector<long long> w; recNums(z, w); CHECK(!recFrom(w, 0, y), "top > contracts refused");
        CHECK(std::count(REC_COLS, REC_COLS + std::strlen(REC_COLS), '|') == REC_NUMS - 1, "the header names every number");
        char tmpl[] = "/tmp/offsXXXXXX"; const std::string dir = mkdtemp(tmpl);
        SessionFile f; f.open("20261013", dir + "/s.csv", dir + "/s-sizes.txt", "# h\nbar_time|...\n", 3);
        f.put(r); Row r2 = r; r2.t += 60; f.put(r2); Row r3 = r; r3.line1 = "changed"; f.put(r3); f.save();
        CHECK(f.rows.size() == 2 && f.rows[r.t].line1 == r.line1 && f.writes == 1, "each candle written once (a second put of the same candle ignored)");
        SizeDist ad, rd; ad.add(5); ad.add(50); rd.add(7); f.sizes(ad, rd); f.save();
        SessionFile g; g.open("20261013", dir + "/s.csv", dir + "/s-sizes.txt", "# h\n", 3);
        SizeDist a2, r2d;
        CHECK(g.load() && g.rows.size() == 2 && g.loaded == 2 && g.loadSizes(a2, r2d) && a2.total == 2 && r2d.total == 1, "reload: rows and the size distributions");
        { std::ofstream o((dir + "/s.csv").c_str(), std::ios::app); o << "garbage|line\n" << rowLine(r).substr(0, 20) << "\n"; }
        SessionFile h; h.open("x", dir + "/s.csv", "", "# h\n", 3); h.load(); CHECK(h.rows.size() == 2 && h.rejected == 2, "malformed lines rejected, good ones kept");
        { std::ofstream o((dir + "/big.csv").c_str()); for (size_t i = 0; i < SESSION_MAX_LINES + 10; ++i) o << "#\n"; }
        SessionFile k; k.open("x", dir + "/big.csv", "", "", 3); CHECK(!k.load(), "bounded read: a file over 6,000 lines is refused");
        std::ifstream t((dir + "/s.csv.tmp").c_str()); CHECK(!t.good(), "atomic: no temporary file left");
    }
    // ================= TIME, BAR KEYS =================
    {
        CHECK(sessionOf(2026, 10, 13, 16) == "20261013" && sessionOf(2026, 10, 13, 17) == "20261014" && sessionOf(2026, 12, 31, 18) == "20270101" && sessionOf(2028, 2, 28, 17) == "20280229", "17:00 CT trading day (year end, leap day)");
        CHECK(sessionOf(2026, 13, 1, 1).empty(), "bad date -> none");
        std::map<long long, int> ends; for (int i = 0; i < 5; ++i) ends[1000 + 60 * i] = i;   // bar ENDS 1000..1240
        CHECK(eventKey(ends, 1240, 60, 940) == 1000 && eventKey(ends, 1240, 60, 999) == 1000 && eventKey(ends, 1240, 60, 1000) == 1060, "bucketing by candle: [end-60, end)");
        CHECK(eventKey(ends, 1240, 60, 1240) == 1300 && eventKey(ends, 1240, 60, 1500) == -1 && eventKey(ends, 1240, 60, 800) == -1 && eventKey(ends, 1240, 60, 0) == -1, "past the forming bar: the predicted next end (<= 3 ahead); too old / no stamp: none");
    }
    // ================= LAYOUT: letters, spike labels, headroom =================
    {
        // letters at the bottom, priority letter on top, never overlapping, inside the slot
        std::vector<LBox> b = letterBoxes(100, 129, 108, 121, 300, 0, "SL", "I", 9, 11);
        CHECK(b.size() == 3 && b[0].c == 'L' && b[0].b == 300 && b[1].c == 'S' && b[1].b < b[0].t && b[2].c == 'I' && b[2].b == 300, "wide slot: two columns, bottom-up L then S; I at the bottom of its own bar");
        bool ok = true; for (size_t i = 0; i < b.size(); ++i) { if (b[i].l < 100 || b[i].r > 129) ok = false; for (size_t j = i + 1; j < b.size(); ++j) if (overlaps(b[i], b[j])) ok = false; }
        CHECK(ok, "no overlap, inside the slot");
        std::vector<LBox> n = letterBoxes(100, 111, 103, 108, 300, 0, "SL", "LR", 9, 11);
        bool ok2 = n.size() == 4; for (size_t i = 0; i < n.size(); ++i) { if (n[i].l < 100 || n[i].r > 111) ok2 = false; for (size_t j = i + 1; j < n.size(); ++j) if (overlaps(n[i], n[j])) ok2 = false; }
        CHECK(ok2 && n[0].l == n[3].l, "narrow slot: one centred column, still no overlap");
        CHECK(letterBoxes(100, 105, 101, 104, 300, 0, "S", "L", 9, 11).empty(), "slot narrower than a box: no letters (zoomed out)");
        CHECK(letterBoxes(100, 129, 108, 121, 300, 285, "SL", "", 9, 11).size() == 1, "letters stop at the top limit");
        CHECK(letterBoxes(100, 129, 108, 121, 300, 0, "SLR", "", 9, 11).size() == 2, "at most 2 letters per side");
        // spike labels: above, ratio over quantity, stagger, never on letters / the box, dropped at the top
        std::vector<SpikeIn> in(2); in[0].cx = 100; in[0].barTop = 200; in[0].q = "240"; in[0].x = "4.1x"; in[1].cx = 108; in[1].barTop = 210; in[1].q = "78"; in[1].x = "2.0x"; in[1].side = 1;
        std::vector<SLabel> L = spikeLabels(in, 20, std::vector<LBox>(), W6);
        CHECK(L.size() == 2 && L[0].b == 198 && L[0].t == 198 - 2 * LABEL_LH + 1 && L[0].l <= 100 && L[0].r >= 100, "label just above the bar top, centred");
        CHECK(L[1].b < L[0].t && L[1].l < L[0].r, "two adjacent spikes collide -> the second is staggered up");
        std::vector<LBox> boxes(1, LBox{ 80, 150, 140, 199, 0, 0 });
        std::vector<SLabel> M = spikeLabels(std::vector<SpikeIn>(1, in[0]), 20, boxes, W6);
        CHECK(M.size() == 1 && M[0].b < 150, "never over a letter / the info box: moved above it");
        std::vector<SLabel> N = spikeLabels(std::vector<SpikeIn>(1, in[0]), 190, std::vector<LBox>(), W6);
        CHECK(N.empty(), "no room under the message line: not drawn (never overlapping)");
        // headroom: the tallest bar <= 69% of the drawing height and leaves room for 2 label lines + the message line
        const int ph = 150, px = drawPx(ph, textReserve(ph));
        CHECK(px <= (int)((ph - 6) / 1.45) && ph - 6 - px >= LABEL_ROOM + TEXT_RESERVE, "headroom for labels and the message line");
        double mn, mx; axisFor(100, ph, px, mn, mx);
        CHECK(std::fabs((ph - 1) - (100 - mn) / (mx - mn) * ph - (ph - 1 - px)) < 1.0 + 1e-9 && mx > 100 * 1.4, "axis: the tallest value sits at its bar top; axis max >= 1.45x the tallest bar");
        Pair p = pairIn(100, 20); CHECK(p.l[0] < p.r[0] && p.r[0] <= p.l[1] && p.l[1] < p.r[1], "two bars per candle: left then right");
        Box a = { 0, 0, 400, 200 }; CHECK(placeIn(a, 100, 50, 99).l == 0 && placeIn(a, 100, 50, 1).l == 150, "9-spot placement, bad -> default top left");
    }
    // ================= PullStats messages / letters / info (1.1.0: lots, SPEC grammar) =================
    {
        const long long v[2] = { 10, 92 }; const double r[2] = { 0.5, 4.4 };
        PaneBar b = pb(1, v, r); b.r.pullC[ASK] = 356; b.r.pullC[BID] = 41; b.r.pullMax[ASK] = 80; b.r.thrRest = 20; Params P;
        ps::Logic::decide(b, P, false);
        CHECK(b.let[ASK] == "L" && b.let[BID].empty() && b.dash[0] == -1, "L on the offers side (80 >= 20)");
        CHECK(b.msg.line1 == "Sellers pulled 92 offers totaling 356 lots (4.4x) - resistance leaving." && b.msg.impl == nl::BULL && b.msgSide == ASK && b.kind == 1, "offers pulled = bullish green, resistance leaving");
        CHECK(b.msg.line2 == "AskPull 356 (4.4x)  92 orders  Top 22%  Traded first no  Before price no  Large 80   |   BidPull 41 (0.5x)  10 orders  Top -  Traded first no  Before price no", "line 2 numbers (the record)");
        b.level = "LonHI"; b.r.pullClose[ASK] = 30; ps::Logic::decide(b, P, false);
        CHECK(b.msg.line1 == "Sellers pulled 92 offers totaling 356 lots (4.4x) - resistance leaving at LonHI.", "level suffix (just before stays in the hover)");
        const long long v2[2] = { 31, 4 }; const double r2[2] = { 3.1, 0.4 }; PaneBar c = pb(1, v2, r2); ps::Logic::decide(c, P, false);
        CHECK(c.msg.line1 == "Buyers pulled 31 bids totaling 124 lots (3.1x) - support leaving." && c.msg.impl == nl::BEAR && c.let[BID].empty(), "bids pulled = bearish red; no large -> no L (threshold 0 = none decided)");
        const long long v3[2] = { 12, 11 }; const double r3[2] = { 1.2, 1.9 }; PaneBar d = pb(1, v3, r3); ps::Logic::decide(d, P, false);
        CHECK(d.msg.line1 == "Normal activity - no spike" && d.msg.impl == nl::NEUTRAL && d.msgSide < 0, "1.9x and no spike = neutral");
        PaneBar e = pb(1, v3, r3); e.m[0].spike[BID] = true; ps::Logic::decide(e, P, false);
        CHECK(e.msg.impl == nl::BEAR && e.spike[BID], "a spike makes the side high even under 2.0x");
        PaneBar na; ps::Logic::decide(na, P, false); CHECK(na.msg.line1 == "No order data for this candle", "n/a candle");
        const Info I = ps::info(&b, P);
        CHECK(I.rows.size() == 5 && I.colHead[0] == "Bids" && I.rows[0].label == "Pulled" && I.rows[0].v[1] == "356 (4.4x)" && I.rows[0].v[0] == "41 (0.5x)"
              && I.rows[1].label == "Before price" && I.rows[1].v[1] == "yes" && I.rows[1].v[0] == "no" && I.rows[2].label == "Traded first" && I.rows[2].v[1] == "no"
              && I.rows[3].label == "Pace" && I.rows[3].v[1] == "n/a" && I.rows[4].label == "Crowd" && I.rows[4].v[1] == "92 \xB7 avg 3.9 \xB7 top 22%",
              "(1.1.1) info box order: Pulled, Before price, Traded first, Pace, Crowd (orders \xB7 avg \xB7 top)");
        CHECK(ps::info(nullptr, P).rows[0].v[0] == "n/a", "info box n/a without data");
    }
    // ================= StackStats messages / dash / letters / info (1.1.0: lots, SPEC grammar) =================
    {
        Params P;
        const long long v[2] = { 105, 12 }, f[2] = { 44, 1 }; const double r[2] = { 4.1, 0.5 }, rf[2] = { 5.2, 0.3 };
        PaneBar b = pb(2, v, r, f, rf); b.level = "LonLO"; b.r.ice[BID] = 1; b.r.iceShown[BID] = 6; b.r.iceTraded[BID] = 40; b.r.addC[BID] = 325; b.r.addTop[BID] = 39; b.r.refC[BID] = 44;
        st::Logic::decide(b, P, false);
        CHECK(b.dash[BID] == 44 && b.dash[ASK] == -1, "dash at min(refilled lots, added lots) = 44, only where notable");
        CHECK(b.let[BID] == "I" && b.let[ASK].empty(), "I = notable refills + iceberg (1.0.1: was R)");
        CHECK(b.msg.line1 == "Buyers added 105 bids totaling 325 lots (4.1x) - support building at LonLO." && b.msg.impl == nl::BULL, "bids added = bullish, support building at the level");
        CHECK(b.msg.line2 == "BidStack 325 (4.1x)  105 orders  BidRefill 44 (5.2x)  1 order = 12%  avg 3.1 cts   |   AskStack 36 (0.5x)  12 orders", "line 2 numbers");
        PaneBar c = b; c.m[1].ratio[BID] = 1.99; st::Logic::decide(c, P, false);
        CHECK(c.dash[BID] == -1 && c.let[BID].empty() && c.msg.line1 == "Buyers added 105 bids totaling 325 lots (4.1x) - support building at LonLO.", "refills 1.99x: no dash, no I; adds only");
        PaneBar d = b; d.m[1].ratio[BID] = 2.0; d.r.ice[BID] = 0; d.r.addMax[BID] = 50; d.r.thrRest = 20; st::Logic::decide(d, P, false);
        CHECK(d.dash[BID] == 44 && d.let[BID] == "L", "exactly 2.0x = notable (dash); no iceberg -> no I; L for a 50-lot");
        d.r.ice[BID] = 1; st::Logic::decide(d, P, false); CHECK(d.let[BID] == "IL", "priority I then L");
        CHECK(b.let[BID].find('R') == std::string::npos && d.let[BID].find('R') == std::string::npos && st::Logic::version() == std::string("1.3.0"), "StackStats never produces R (R = stop run, BidAskStats)");
        PaneBar g = b; g.r.refC[BID] = 400; st::Logic::decide(g, P, false); CHECK(g.dash[BID] == 325, "dash never above the bar (min)");
        const long long va[2] = { 10, 38 }, fa[2] = { 1, 1 }; const double ra[2] = { 0.9, 3.8 }, rfa[2] = { 1.0, 1.0 };
        PaneBar e = pb(2, va, ra, fa, rfa); st::Logic::decide(e, P, false);
        CHECK(e.msg.line1 == "Sellers added 38 offers totaling 114 lots (3.8x) - wall building above." && e.msg.impl == nl::BEAR, "offers added = bearish");
        e.r.addC[ASK] = 100; e.r.addTop[ASK] = 70; st::Logic::decide(e, P, false);
        CHECK(e.msg.line1 == "Sellers added 38 offers totaling 100 lots (3.8x) - one order is 70% of it - may not reload ?." && e.msg.impl == nl::NEUTRAL, "70% in one order = may not reload ? (white; 6:40 PM wording)");
        e.r.addTop[ASK] = 69; st::Logic::decide(e, P, false); CHECK(e.msg.line1.find("reload") == std::string::npos && e.msg.line1.find("bait") == std::string::npos, "69% = not");
        const long long vr[2] = { 10, 10 }, fr[2] = { 9, 0 }; const double rr[2] = { 1.0, 1.0 }, rfr[2] = { 4.5, 0 };
        PaneBar h = pb(2, vr, rr, fr, rfr); st::Logic::decide(h, P, false);
        CHECK(h.msg.line1 == "Buyers reloaded bids 9 times (4.5x) after hits - hidden support.", "refills only = hidden support");
        P.refillNotableT = 50; st::Logic::decide(h, P, false); CHECK(h.dash[BID] == -1 && h.msg.line1 == "Normal activity - no spike", "refillNotableX 5.0 from the params file");
        P.refillNotableT = 20;
        const Info I = st::info(&b, P);
        CHECK(I.rows.size() == 5 && I.rows[0].label == "Added" && I.rows[0].v[0] == "325 (4.1x)" && I.rows[1].label == "Rebuilt" && I.rows[1].v[0] == "-" && I.rows[2].label == "Pace" && I.rows[2].v[0] == "n/a"
              && I.rows[3].label == "Crowd" && I.rows[3].v[0] == "105 \xB7 avg 3.1 \xB7 top 12%" && I.rows[4].label == "Refills (I)" && I.rows[4].v[0] == "44 (5.2x)",
              "(1.1.1) info box order: Added, Rebuilt, Pace, Crowd, Refills (I)");
    }
    // ================= BidAskStats messages (1.5.0 SPEC grammar) =================
    {
        bas::Stat s; s.m.ok = true; s.m.bid = 240; s.m.ask = 78; s.bidRatioOk = s.askRatioOk = true; s.bidRatio = 4.1; s.askRatio = 1.0; s.priorMax = 104; s.bidSpike = true;
        const std::string none[2]; int held[2] = { 1, 1 };
        nl::Msg m = bas::message(s, nullptr, none, "", held);
        CHECK(m.line1 == "Sellers hit the bid with a 240-lot (4.1x) - price held: buyers absorbing." && m.impl == nl::BULL, "bid spike + held = buyers absorbing (green)");
        CHECK(m.line2 == "BBid 240  BidRatio 4.1x  Jump 2.3x   |   BAsk 78  AskRatio 1.0x", "line 2 with Jump on the message side");
        held[0] = 0; m = bas::message(s, nullptr, none, "", held);
        CHECK(m.line1 == "Sellers hit the bid with a 240-lot (4.1x) - price giving way." && m.impl == nl::BEAR, "broke lower = giving way (red)");
        off::Rec r; r.sweepLv[0] = 4; r.aggrMax[0] = 120; r.sweepSize[0] = 120; r.sweepIsMax[0] = 1; r.thrAggr = 20; r.aggrN[0] = 30; r.aggrC[0] = 400; Params P;
        const std::string let[2] = { bas::letters(r, 0, P), bas::letters(r, 1, P) }; held[0] = 1;
        m = bas::message(s, &r, let, "LonLO", held);
        CHECK(let[0] == "SL" && m.line1 == "Sellers hit the bid with a 240-lot (4.1x), swept 4 levels with one 120-lot order into LonLO - price held: buyers absorbing.", "sweep + large into a level");
        CHECK(m.line2 == "BBid 240  BidRatio 4.1x  Jump 2.3x  Sweep 4 lvls  Large 120   |   BAsk 78  AskRatio 1.0x", "line 2 with Sweep / Large");
        r.sweepIsMax[0] = 0; m = bas::message(s, &r, let, "", held); CHECK(m.line1 == "Sellers hit the bid with a 240-lot (4.1x), swept 4 levels, plus one 120-lot order - price held: buyers absorbing.", "sweep + a different large order");
        const std::string lOnly[2] = { "L", "" }; m = bas::message(s, &r, lOnly, "", held);
        CHECK(m.line1 == "Sellers hit the bid with a 240-lot (4.1x), one 120-lot order - price held: buyers absorbing.", "large only");
        bas::Stat a = s; a.bidSpike = false; a.bidRatio = 1.0; a.askRatio = 3.2; a.m.ask = 300; int h2[2] = { 1, 1 };
        m = bas::message(a, nullptr, none, "", h2); CHECK(m.line1 == "Buyers lifted the offer with a 300-lot (3.2x) - price held: sellers absorbing." && m.impl == nl::BEAR, "offers lifted + held = sellers absorbing (red)");
        h2[1] = 0; m = bas::message(a, nullptr, none, "LonHI", h2); CHECK(m.line1 == "Buyers lifted the offer with a 300-lot (3.2x) into LonHI - price giving way." && m.impl == nl::BULL, "broke higher = giving way (green)");
        bas::Stat n = s; n.bidSpike = false; n.bidRatio = 1.99; m = bas::message(n, &r, let, "LonLO", h2);
        CHECK(m.line1 == "Normal activity - no spike" && m.impl == nl::NEUTRAL, "1.99x no spike: neutral (no level suffix)");
        CHECK(bas::held(0, 99.75, 100, 101, 0.25, true) == 1 && bas::held(0, 99.5, 100, 101, 0.25, true) == 0 && bas::held(1, 101.25, 100, 101, 0.25, true) == 1 && bas::held(1, 101.5, 100, 101, 0.25, true) == 0, "held: within 1 tick of the prior low / high");
        CHECK(bas::message(bas::Stat(), nullptr, none, "", held).line1 == "No volume data for this candle", "n/a candle");
        const std::vector<bas::Row2> I = bas::infoRows(&s, &r, let, true, bas::PaceIn(), 20);
        CHECK(I.size() == 5 && I[0].label == "Lots" && I[0].v[0] == "240 (4.1x)" && I[0].v[1] == "78 (1.0x)" && I[1].label == "Pace" && I[1].v[0] == "n/a"
              && I[2].label == "Sweep" && I[2].v[0] == "4 lvls" && I[2].v[1] == "-" && I[3].label == "Large" && I[3].v[0] == "120" && I[3].v[1] == "-"
              && I[4].label == "Crowd" && I[4].v[0] == "30 \xB7 avg 13.3 \xB7 top 30%", "(1.5.1) info box: Lots, Pace, Sweep, Large, Crowd (the plugin adds StopRun before Crowd, Burst last)");
        CHECK(bas::infoRows(&s, nullptr, none, false, bas::PaceIn(), 20)[4].v[0] == "n/a" && bas::infoRows(&s, nullptr, none, false, bas::PaceIn(), 20)[2].v[0] == "n/a" && bas::infoRows(&s, &r, none, true, bas::PaceIn(), 20)[3].v[0] == "-", "no order feed: n/a (Crowd too); none found: -");
        CHECK(off::crowdText(0, 0, 0) == "-" && off::crowdText(96, 365, 44) == "96 \xB7 avg 3.8 \xB7 top 12%" && off::crowdText(3, 10, 0) == "3 \xB7 avg 3.3", "(1.2.1) Crowd text");
        // fitText truncation
        CHECK(nl::fitText("abcdefghij", 60, W6) == "abcdefghij" && nl::fitText("abcdefghij", 42, W6) == "abcd..." && nl::fitText("abc", 10, W6).empty(), "truncation with ...");
    }
    std::printf("logic (shared + panes + 1.3.0): %d passed, %d failed\n", passes, fails); return fails ? 1 : 0;
}
