// test_zone_logic.cpp -- ZoneRule.h 1.0.0 (the zone held / broke state machine, the lagged ADR, the level files) and ZoneRead.h 1.0.0
// (the one-line reads of the order-flow panes). g++ -std=c++17 -Wall -Wextra -Werror -fsanitize=address,undefined
#include "ZoneRead.h"
#include <cstdio>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>

static int pass = 0, fail = 0;
#define CHECK(c, msg) do { if (c) ++pass; else { ++fail; std::printf("FAIL %s:%d %s\n", __FILE__, __LINE__, msg); } } while (0)

using namespace zrule;

static Outcome feed(bool support, double centre, double adr, const std::vector<double>& closes, bool end = false) {
    Outcome o = makeOutcome(support, centre, adr, 180);
    long long t = 1000;
    for (size_t i = 0; i < closes.size() && !o.resolved(); ++i) { o.onClose(closes[i], t); t += 180; }
    if (end) o.endSession();
    return o;
}

static void testOutcome() {
    // ES-like: ADR 60 -> zone +/- 3.6, X = 6.0; support at 7750 (zone 7746.4 - 7753.6), came down into it
    const double c = 7750, adr = 60;
    // 1) a first touch: a close in the zone -> nothing yet (no label)
    { Outcome o = feed(true, c, adr, {7751}); CHECK(!o.resolved(), "first touch inside the zone: no label"); }
    // 2) a tick through (low far below) but every close inside / back -> NOT a break. Closes are what count: 7747 is inside.
    { Outcome o = feed(true, c, adr, {7749, 7747, 7748}); CHECK(!o.resolved(), "tick-through, closes inside: still in zone"); }
    // 3) a close beyond the far edge by X (7746.4 - 6 = 7740.4) then a close back inside within 5 bars -> failed break, not CONT
    { Outcome o = feed(true, c, adr, {7749, 7740, 7742, 7748}); CHECK(!o.resolved() && o.failed == 1, "close beyond, reclaimed in 15 min: failed break, no label"); }
    // 4) close beyond + no close back inside for 5 bars -> CONT, known only when the window passed
    { Outcome o = makeOutcome(true, c, adr, 180); long long t = 0; const double cl[] = {7749, 7740, 7739, 7738, 7737, 7736, 7735};
      bool r[7]; for (int i = 0; i < 7; ++i) { r[i] = o.onClose(cl[i], t += 180); }
      CHECK(!r[1] && !r[2] && !r[3] && !r[4] && !r[5], "CONT not decided inside the 15-min reclaim window");
      CHECK(r[6] && o.res == CONT && o.kb == 1, "CONT decided once 5 more closes stayed beyond (study: bars k+1..k+5)"); }
    // 5) REV: a close 0.10 ADR beyond the NEAR edge (7753.6 + 6 = 7759.6)
    { Outcome o = feed(true, c, adr, {7749, 7752, 7760}); CHECK(o.res == REV && o.nRes == 2, "REV on the close 0.10 ADR back out"); }
    // 5b) a close just over the near edge but under X: still in zone (not REV)
    { Outcome o = feed(true, c, adr, {7749, 7758}); CHECK(!o.resolved(), "a close out by less than 0.10 ADR: in zone"); }
    // 6) resistance mirrored (came up): REV below, CONT above
    { Outcome o = feed(false, c, adr, {7751, 7740}); CHECK(o.res == REV, "resistance REV below"); }
    { Outcome o = feed(false, c, adr, {7751, 7760, 7761, 7762, 7763, 7764, 7765}); CHECK(o.res == CONT, "resistance CONT above"); }
    // 7) PIN after the 2-h horizon (40 bars on a 3-min chart)
    { std::vector<double> v(41, 7750.0); Outcome o = feed(true, c, adr, v); CHECK(o.res == PIN, "PIN after 40 bars in the zone"); }
    // 8) session end inside a reclaim window: counts as CONT (the study's i_end), else PIN
    { Outcome o = feed(true, c, adr, {7749, 7740}, true); CHECK(o.res == CONT, "session end with a break candidate = CONT"); }
    { Outcome o = feed(true, c, adr, {7749}, true); CHECK(o.res == PIN, "session end in the zone = PIN"); }
    // 9) a feed gap > 6 min: CENSORED
    { Outcome o = makeOutcome(true, c, adr, 180); o.onClose(7749, 1000); o.onClose(7748, 1000 + 600); CHECK(o.res == CENSORED, "gap > 6 min censors"); }
    // 10) no repaint: once resolved, later closes never change it
    { Outcome o = feed(true, c, adr, {7749, 7760}); const int r = o.res; o.onClose(7700, 99999); o.onClose(7800, 99999 + 180); CHECK(o.res == r && r == REV, "resolved never changes"); }
    // 11) rule for other bar sizes
    { const Rule r1 = ruleFor(60); CHECK(r1.accept == 15 && r1.horizon == 120, "1-min chart: 15 / 120 bars"); const Rule r3 = ruleFor(180); CHECK(r3.accept == 5 && r3.horizon == 40, "3-min chart: 5 / 40 bars"); }
}

// parity with the study's own zone_outcome (python, extracted verbatim; gen_parity.py) on 400 random series
static void testParity(const char* path) {
    std::ifstream in(path); std::string ln; int n = 0, ok = 0;
    while (std::getline(in, ln)) {
        std::istringstream s(ln); std::string side; double lo, hi, x; int cnt; s >> side >> lo >> hi >> x >> cnt;
        std::vector<double> C(cnt); for (int i = 0; i < cnt; ++i) s >> C[i];
        int res, kres, failed; s >> res >> kres >> failed;
        Outcome o; o.support = side == "above"; o.lo = lo; o.hi = hi; o.x = x; o.rule = ruleFor(180);
        long long t = 0; for (int i = 0; i < cnt && !o.resolved(); ++i) o.onClose(C[i], t += 180);
        o.endSession();
        bool same = o.res == res && o.failed == failed;
        if (res == REV) same = same && o.nRes == kres;
        if (res == CONT) same = same && o.kb == kres;
        ++n; if (same) ++ok; else if (n - ok <= 5) std::printf("  parity diff case %d: study %d k %d f %d / ours %d n %d kb %d f %d\n", n, res, kres, failed, o.res, o.nRes, o.kb, o.failed);
    }
    std::printf("  parity: %d / %d identical to lra.level_confluence.zone_outcome\n", ok, n);
    CHECK(n >= 400 && ok == n, "every case identical to the study");
}

static void testAdr() {
    Adr a; // 12 sessions, range 10 each, closes flat -> ADR 10; the current session never counts
    for (int d = 1; d <= 12; ++d) { a.add(d, 110, 100, 105); a.add(d, 108, 101, 105); }
    a.add(13, 200, 50, 100);                                   // today's huge range: must not count
    int n = 0; const double v = a.adrFor(13, n);
    CHECK(n == 11 && std::fabs(v - 10) < 1e-9, "ADR = mean TR of prior sessions (first day has no prior close)");
    int m = 0; CHECK(a.adrFor(5, m) < 0, "fewer than 10 prior sessions: no ADR at the study minimum");
    CHECK(a.adrFor(5, m, 3) > 0 && m == 3, "a caller floor of 3 works (labelled)");
    // the true range uses the previous close (gap)
    Adr g; for (int d = 1; d <= 11; ++d) g.add(d, 110, 100, 100); g.add(12, 125, 120, 122); int k = 0; const double gv = g.adrFor(13, k);
    CHECK(std::fabs(gv - (10 * 10 + 25) / 11.0) < 1e-9 && k == 11, "TR includes the gap from the prior close; 20-day window");
    const long long D = 20000LL * 86400; CHECK(sessionKey(D + 17 * 3600) == 20001 && sessionKey(D + 17 * 3600 - 1) == 20000, "17:00 CT starts the next session");
}

static void testFiles() {
    std::vector<Level> k, m, g;
    CHECK(parseKey("KEYLV,1,1000\nL|PDL|7741.00|0\nL|PWL|7760.25|0\nL|bad|x|0\n", 1000, 3600, k) && k.size() == 2, "key levels parsed, bad row skipped");
    CHECK(parseKey("KEYLV,1,1000\nL|PDL|7741|0\n", 1000 + 20 * 3600, 18 * 3600, k) && k.empty(), "stale key file: valid, no levels");
    CHECK(!parseKey("garbage", 0, 0, k), "garbled key file rejected");
    CHECK(parseMq("MARKET|ES\nLEVEL|VWAP-1|VWAP-1|7757.75|vwap|\nLEVEL|G8|G8|7770.0|gamma|\n", "ES", m) && m.size() == 1 && m[0].kind == 2, "MenthorQ levels: VWAP bands skipped");
    CHECK(!parseMq("MARKET|NQ\nLEVEL|G8|G8|7770|gamma\n", "ES", m), "wrong market rejected");
    CHECK(parseMq("MARKET|ES\nSTATE|STALE\nLEVEL|G8|G8|7770|gamma\n", "ES", m) && m.empty(), "STALE = no levels");
    const std::string gx = "VERSION|2\nMARKET|ES\nASOF|1000|4:00 PM|15:55\nSTR|1|7750|7750|9.5|28.86|F|1.66|58|G6|3\nSTR|2|7725|7725|4.3|12.96|F|1.81|72|-|7\n";
    CHECK(parseGex(gx, "ES", 1000, 3600, g) && g.size() == 2 && g[0].name == "G6" && g[1].name == "G 7725", "GEX nodes from STR rows");
    CHECK(parseGex(gx, "ES", 1000 + 19 * 3600, 18 * 3600, g) && g.empty(), "stale GEX file: no nodes");
    CHECK(parseGex(gx, "ES", 1000, 3600, g), "re-read");
    const std::vector<Level> all = mergeLevels(k.empty() ? std::vector<Level>{Level{"PDL", 7750, 0}} : k, m, g, 1.0);
    bool joined = false; for (size_t i = 0; i < all.size(); ++i) if (all[i].name.find("G6") != std::string::npos && all[i].kind == 0) joined = true;
    CHECK(joined, "a gamma node on a key level joins it (key first)");
}

// ---- ZoneRead: the read lines -------------------------------------------------------------------------------------------------
using namespace zread;
static Engine mk(double tick = 0.25) {
    Engine e; e.market = "ES"; e.tick = tick;
    std::string t = "VERSION|1\nMARKET|ES\nNORM|pull_def|ALL|0.30|0.10|100\nNORM|fill_def|ALL|100|40|100\nNORM|added|ALL|1000|400|100\nNORM|aggr|ALL|500|200|100\nNORM|pull_app|ALL|0.20|0.06|100\n";
    Norms n; parseNorms(t, "ES", n); e.norms = n;
    e.setGeometry(60.0, 20, 4);                                  // zone +/- 3.6 pts = 14 ticks; band +/- 4 ticks
    e.setLevels(std::vector<zrule::Level>{ zrule::Level{"PDL", 7750.0, 0} });
    return e;
}
static Tick T(double px) { return (Tick)std::llround(px / 0.25); }

static void testNoLineOutside() {
    Engine e = mk();
    e.onPrice(0, T(7770)); e.step(0, 0, 600);
    for (int p = 0; p < P_N; ++p) CHECK(!e.line(p, 0).show, "outside every zone: no line in any pane");
    // in the zone but never armed (no closed bar outside): nothing
    e.onPrice(1000, T(7751)); e.step(1000, 0, 600);
    CHECK(!e.line(P_PULLING, 1000).show, "in the zone without a close outside first: no read");
}

static void testPullingStateMachine() {
    Engine e = mk();
    // the feed is live before; bids rest at the level
    for (int i = 0; i < 10; ++i) e.onEvent(0, NEW, BID, 100 + i, T(7750), 10);   // 100 lots in the band
    e.onBarClose(T(7760));                                        // a close above the zone: armed as SUPPORT
    e.onPrice(60000, T(7753)); e.step(60000, 36000, 600);         // inside the zone (14 ticks), not at the band yet
    Line l = e.line(P_PULLING, 60000);
    CHECK(l.show && l.text.find("level not reached") != std::string::npos && l.impl == 0, "approach: grey 'level not reached yet ?'");
    // ARRIVAL: the first trade in the band (a fill on a bid at 7751 = within 4 ticks)
    e.onEvent(70000, FILL, BID, 100, T(7750), 2); e.step(70000, 36010, 600);
    CHECK(e.cur.state == MEASURE && e.cur.shown == 100, "arrival on the first trade in the band; cohort = 100 lots of bids");
    l = e.line(P_PULLING, 70000 + 80000);
    CHECK(l.show && l.text.find("measuring 1:20 of 3:00") != std::string::npos, "measuring m:ss of 3:00");
    // 62 lots cancelled, 8 traded during the window
    for (int i = 1; i < 7; ++i) e.onEvent(80000 + i, DEL, BID, 100 + i, T(7750), 10);
    e.onEvent(80100, MOD, BID, 107, T(7750), 8);   // a size cut of 2 (not after a fill) = 2 cancelled
    e.onPrice(200000, T(7751)); e.step(250000 - 1, 36100, 600);
    CHECK(e.cur.state == MEASURE, "still measuring before 3 min");
    e.step(250000, 36190, 600);
    CHECK(e.cur.state == FROZEN, "locked at arrival + 3 min");
    l = e.line(P_PULLING, 250000);
    CHECK(l.show && l.impl == -1 && l.text.find("bids pulled, not filled (62% in 3 min)") != std::string::npos && l.text.find("less support ?") != std::string::npos, "pulled: red 'bids pulled, not filled (62% in 3 min) - less support ?'");
    const std::string frozenText = l.text;
    // NO REPAINT: later events never change the locked line
    e.onEvent(260000, FILL, BID, 108, T(7750), 10); e.onEvent(260001, DEL, BID, 109, T(7750), 10); e.step(260002, 36200, 600);
    CHECK(e.line(P_PULLING, 260002).text == frozenText, "locked: later events do not change it");
    CHECK(e.recPending.size() == (size_t)P_N, "one record line per pane");
    // price leaves the zone: nothing shown; comes back (no close outside): the locked read comes back, unchanged
    e.onPrice(300000, T(7770)); e.step(300000, 36300, 600);
    CHECK(!e.line(P_PULLING, 300000).show, "out of the zone: no line");
    e.onPrice(310000, T(7752)); e.step(310000, 36310, 600);
    CHECK(e.line(P_PULLING, 310000).text == frozenText, "back in the zone (same encounter): the same locked read");
    // restore round trip (a restart): the record line brings the same text back
    Engine r = mk(); for (size_t i = 0; i < e.recPending.size(); ++i) r.restore(e.recPending[i], P_PULLING, 400000, 36400);
    r.onPrice(400000, T(7751)); r.step(400000, 36400, 600);
    CHECK(r.line(P_PULLING, 400000).text == frozenText && r.line(P_PULLING, 400000).locked, "restart: restored from the record, identical");
}

static void testTradedAndMixed() {
    {   Engine e = mk();                                          // TRADED, held: 150 lots filled (1.5x the 100-lot normal), price stays
        for (int i = 0; i < 20; ++i) e.onEvent(0, NEW, BID, 200 + i, T(7750), 10);
        e.onBarClose(T(7760)); e.onPrice(1000, T(7752)); e.step(1000, 36000, 600);
        e.onEvent(2000, FILL, BID, 200, T(7750), 5); e.step(2000, 36001, 600);
        for (int i = 1; i < 16; ++i) e.onEvent(3000 + i, FILL, BID, 200 + i, T(7750), 10);
        e.onPrice(150000, T(7751)); e.step(183000, 36200, 600);
        const Line l = e.line(P_PULLING, 183000);
        CHECK(l.impl == 1 && l.text.find("bids traded, held (1.6x normal)") != std::string::npos && l.text.find("support holding ?") != std::string::npos, "traded + held: green 'bids traded, held (1.6x normal) - support holding ?'");
        const Line b = e.line(P_BAS, 183000);
        CHECK(b.show && b.text.find("sellers hitting 0.3x normal, price held ?") != std::string::npos && b.impl == 0, "BidAsk: light hitting, held = grey");
    }
    {   Engine e = mk();                                          // MIXED: 20% cancelled, 30% traded
        for (int i = 0; i < 10; ++i) e.onEvent(0, NEW, BID, 300 + i, T(7750), 10);
        e.onBarClose(T(7760)); e.onPrice(1000, T(7752)); e.step(1000, 36000, 600);
        e.onEvent(2000, FILL, BID, 300, T(7750), 10); e.step(2000, 36001, 600);
        e.onEvent(3000, DEL, BID, 300, T(7750), 0);                  // a DEL right after its fill: not a cancel
        e.onEvent(3001, FILL, BID, 301, T(7750), 10); e.onEvent(3002, FILL, BID, 302, T(7750), 10);
        e.onEvent(4000, DEL, BID, 303, T(7750), 10); e.onEvent(4001, DEL, BID, 304, T(7750), 10);
        e.step(183000, 36200, 600);
        const Line l = e.line(P_PULLING, 183000);
        CHECK(l.impl == 0 && l.text.find("bids: 20% pulled, 30% traded in 3 min ?") != std::string::npos, "mixed: grey 'bids: 20% pulled, 30% traded in 3 min ?'");
    }
    {   Engine e = mk();                                          // RESISTANCE mirrored: offers pulled = green (bullish)
        for (int i = 0; i < 10; ++i) e.onEvent(0, NEW, ASK, 400 + i, T(7750), 10);
        e.onBarClose(T(7740)); e.onPrice(1000, T(7748)); e.step(1000, 36000, 600);
        e.onEvent(2000, FILL, ASK, 400, T(7750), 1); e.step(2000, 36001, 600);
        for (int i = 1; i < 8; ++i) e.onEvent(3000 + i, DEL, ASK, 400 + i, T(7750), 10);
        e.step(183000, 36200, 600);
        const Line l = e.line(P_PULLING, 183000);
        CHECK(l.impl == 1 && l.text.find("offers pulled, not filled (70% in 3 min)") != std::string::npos && l.text.find("less resistance ?") != std::string::npos, "resistance: green 'offers pulled ... less resistance ?'");
    }
}

static void testStackBasPre() {
    Engine e = mk();
    // 5+ minutes of history: 20 bids x 10 at the level, 9 cancelled before price arrives
    for (int i = 0; i < 20; ++i) e.onEvent(0, NEW, BID, 500 + i, T(7750), 10);
    for (int k = 1; k <= 20; ++k) e.onEvent(k * 15000, NEW, BID, 50 + k, T(7700), 1);   // the feed keeps coming (far from the level)
    for (int i = 0; i < 9; ++i) e.onEvent(310000 + i, DEL, BID, 500 + i, T(7750), 10);
    e.onBarClose(T(7760)); e.onPrice(320000, T(7752)); e.step(320000, 36000, 600);
    e.onEvent(330000, FILL, BID, 510, T(7750), 4); e.step(330000, 36010, 600);
    Line pre = e.line(P_PULLSTATS, 331000);
    CHECK(pre.show && pre.text.find("bids pulled before touch (45%) ?") != std::string::npos && pre.impl == -1, "PullStats pre-touch: red 'bids pulled before touch (45%) ?' locked at arrival");
    // stacking: 2,300 lots of new bids at the level (2.3x the 1,000 normal, z (2300-1000)/(1.4826*400) = 2.2)
    for (int i = 0; i < 23; ++i) e.onEvent(340000 + i, NEW, BID, 600 + i, T(7750), 100);
    // heavy selling: 1,550 lots hit (3.1x the 500 normal), price still at the level
    for (int i = 0; i < 31; ++i) e.onEvent(350000 + i, FILL, BID, 600 + (i % 23), T(7750), 50);
    e.onPrice(500000, T(7750)); e.step(510000, 36200, 600);
    const Line s = e.line(P_STACK, 510000), b = e.line(P_BAS, 510000);
    CHECK(s.impl == 1 && s.text.find("bids stacking 2.3x normal ?") != std::string::npos, "StackStats: green 'bids stacking 2.3x normal ?'");
    bool stackCaveat = false; for (size_t i = 0; i < s.hover.size(); ++i) if (s.hover[i].find("mostly reflects a weak attack") != std::string::npos) stackCaveat = true;
    CHECK(stackCaveat, "StackStats hover says stacking alone mostly reflects a weak attack");
    CHECK(b.impl == 1 && b.text.find("sellers hitting 3.1x normal, price held ?") != std::string::npos, "BidAsk: green 'sellers hitting 3.1x normal, price held ?'");
    CHECK(e.line(P_PULLSTATS, 510000).text == pre.text, "pre-touch read unchanged after the window");
    bool preCaveat = false; for (size_t i = 0; i < pre.hover.size(); ++i) if (pre.hover[i].find("NO clear sign yet") != std::string::npos) preCaveat = true;
    CHECK(preCaveat, "PullStats hover says the study showed no clear sign yet");
    // price through: a new encounter on another level
    Engine f = mk();
    for (int i = 0; i < 4; ++i) f.onEvent(0, NEW, BID, 700 + i, T(7750), 10);
    f.onBarClose(T(7760)); f.onPrice(1000, T(7752)); f.step(1000, 36000, 600);
    f.onEvent(2000, FILL, BID, 700, T(7750), 10); f.step(2000, 36000, 600);
    for (int i = 0; i < 40; ++i) f.onEvent(3000 + i, FILL, BID, 701, T(7750), 50);
    f.onPrice(150000, T(7748)); f.step(183000, 36200, 600);                     // 8 ticks under the level: beyond the 4-tick band
    const Line t = f.line(P_BAS, 183000);
    CHECK(t.impl == -1 && t.text.find("sellers hitting 4.0x, price through ?") != std::string::npos, "BidAsk: red 'sellers hitting 4.0x, price through ?'");
    CHECK(f.line(P_STACK, 183000).text.find("no new bids ?") != std::string::npos, "StackStats: 'no new bids ?'");
    // the pre-touch read without 5 minutes of history: says so
    CHECK(f.line(P_PULLSTATS, 183000).text.find("pre-touch book not known") != std::string::npos, "pre-touch without 5 min of feed: 'not known'");
}

static void testNormsAndText() {
    Norms n;
    CHECK(!parseNorms("VERSION|2\nMARKET|ES\n", "ES", n), "bad version rejected");
    CHECK(!parseNorms("VERSION|1\nMARKET|NQ\n", "ES", n), "wrong market rejected");
    CHECK(parseNorms("VERSION|1\nMARKET|ES\nNORM|aggr|570|10|2|9\nNORM|aggr|ALL|20|5|20\nNORM|aggr|600|1|1|3\nNORM|x|615|1|1|30\n", "ES", n), "normals parsed");
    CHECK(n.get("aggr", 575).med == 10 && n.get("aggr", 575).slot, "same 30-min slot (n >= 8)");
    CHECK(n.get("aggr", 610).med == 20 && !n.get("aggr", 610).slot, "thin slot -> ALL (n >= 15)");
    CHECK(!n.get("x", 615).ok(), "slot not on a 30-min boundary skipped");
    CHECK(std::fabs(zOf(12.9652, Norm{10, 2, 9, true}) - 1.0) < 1e-3, "robust z = (x - med) / (1.4826 MAD)");
    CHECK(pxText(31000, 0.25) == "7750" && pxText(9290, 0.01) == "92.90" && pxText(23250, 0.00005) == "1.16250", "level price text");
    CHECK(clock12(570) == "9:30 AM" && clock12(780) == "1:00 PM" && clock12(0) == "12:00 AM", "12-hour CT clock");
    CHECK(ratioText(2.04) == "2.0x" && ratioText(3.45) == "3.5x" && ratioText(12) == "12x", "ratios as 2.0x");
    // every frozen line ends with "?" in every pane
    Engine e = mk(); for (int i = 0; i < 3; ++i) e.onEvent(0, NEW, BID, 900 + i, T(7750), 10);
    e.onBarClose(T(7760)); e.onPrice(1000, T(7752)); e.step(1000, 36000, 600); e.onEvent(2000, FILL, BID, 900, T(7750), 1); e.step(2000, 36000, 600); e.step(183000, 36200, 600);
    for (int p = 0; p < P_N; ++p) { const Line l = e.line(p, 183000); CHECK(l.show && !l.text.empty() && l.text.back() == '?', "every pane's line ends with ?"); CHECK(l.text.compare(0, 8, "ES 7750 ") == 0, "line starts 'ES 7750'"); }
}

int main(int argc, char** argv) {
    testOutcome(); testAdr(); testFiles();
    testParity(argc > 1 ? argv[1] : "parity.txt");
    testNoLineOutside(); testPullingStateMachine(); testTradedAndMixed(); testStackBasPre(); testNormsAndText();
    std::printf("zone logic (ZoneRule %s, ZoneRead %s): %d passed, %d failed\n", zrule::VERSION, zread::VERSION, pass, fail);
    return fail ? 1 : 0;
}
