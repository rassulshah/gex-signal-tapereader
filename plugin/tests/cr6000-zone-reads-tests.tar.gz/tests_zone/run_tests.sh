#!/bin/sh
# ZoneRule.h 1.0.0 + ZoneRead.h 1.0.0 (2026-10-14 night): the zone held / broke state machine (+ 400-case parity with the study's own
# lra.level_confluence.zone_outcome, parity.txt from gen_parity.py), the lagged ADR, the level files, the four read lines. ASan/UBSan.
D=$(cd "$(dirname "$0")" && pwd); B=${BUILD:-/tmp/zone-build}; mkdir -p "$B"
g++ -std=c++17 -g -Wall -Wextra -Werror -fsanitize=address,undefined -fno-sanitize-recover=undefined -I"$D/.." "$D/test_zone_logic.cpp" -o "$B/tz" || { echo "FAILED: build"; exit 1; }
"$B/tz" "$D/parity.txt" || { echo "FAILED: zone logic"; exit 1; }
rm -f "$B/tz"; echo "ALL ZONE SUITES PASSED"
