# CR6000 - zone rule labels + one read line per order-flow pane (2026-10-14 night, Rassul approved 18:25 CT)

| Plugin | Version | What changed |
|---|---|---|
| ZoneRule.h (new) | 1.0.0 | Rassul's zone rule from lra.level_confluence (zone +/- 0.06 ADR, REV 0.10 ADR back out, CONT 0.10 ADR beyond + no close back inside in 15 min, PIN 2 h, CENSORED gap > 6 min), lagged ADR from the chart's bars, level files (KeyLevels / Levels / GexNodes) |
| ZoneRead.h (new) | 1.0.0 | the one-line reads: Pulling (arrival cohort cancelled vs traded in 3 min), StackStats (added), BidAskStats (hitting + price held / through), PullStats (pre-touch pulled); normals LRA-ZoneReadNorms-<MKT>.csv (seeded from the MBO study cache, tools/seed_zoneread_norms.py) |
| lsLiquidityProfile / Flow | 0.16.1 -> 0.17.0 | Held / Broke by the zone rule (labels only when final; -zonerule-chart- / -panes- record; attempts + 5 columns); audit wording (re-added ?, LQ?, Bids / Offers, no Absorbed / exhausted / defending; Flow statistic Eaten) |
| OrderFlowFeed.h | 1.4.0 -> 1.5.0 | READ box -> planLine / drawLine (one line at Position / Offset, hover detail box), zoneTickFor, I -> I? |
| lsBidAskStats | 1.5.3 -> 1.6.0 | zone read line; options line "Unsigned put volume 2.1x pace ? - buyer / seller unknown" (Numbers mode) |
| lsPullStats | 1.3.0 -> 1.4.0 | zone read line (pre-touch) |
| lsStackStats | 1.2.0 -> 1.3.0 | zone read line (stacking), I? |
| lsPulling | 0.2.1 -> 0.3.0 | header readout -> zone read line, TRACK_MOUSE hover, description reworded |

Tests (Linux, ASan/UBSan): tests_zone/run_tests.sh (79, parity 400/400), tests_lq/run_tests.sh (logic 190, hover 138, profile host 68, flow host 30, hover host 39, columns 32, sizes 19 + 9, MinGW 0/0 x2, win32 ok), tests_of/run_tests.sh (155, 124, 28, 61, 103, 51, 47, panel host 28/28/27, label persist 17/18/18/18, pull host 71, stack host 58, feed clock 21, mborecord 24, MinGW 0/0 x3, win32 ok; W32_PANES env narrows check_win32_libs), tests_pulling/run_tests.sh (14, 16, zone host 12, MinGW 0/0).
Not verified - needs his IRT: the lines on live charts, the LP zone-rule labels on a real session (ADR from the chart's bars needs 10+ sessions loaded; 5-9 labelled short), the GexNodes file freshness on Monday, CPU of the per-order band book at the open.
