#!/bin/sh
# lsPulling 0.3.0 (2026-10-14 night): logic + host (two lines, record, restart) + the zone read line end to end (ASan/UBSan), the MinGW
# syntax check against the REAL irtsdk.h, and the Win32 import check (user32 calls need their pragma). Binaries removed after the run.
D=$(cd "$(dirname "$0")" && pwd); B=${BUILD:-/tmp/pl-build}; SDK=${SDK:-/mnt/user-data/uploads/sdk/c++/include}; mkdir -p "$B"
SAN="-fsanitize=address,undefined -fno-sanitize-recover=undefined"; CXX="g++ -std=c++17 -g -Wall -Wextra -Werror $SAN"
step() { echo "== $1" >&2; shift; "$@" || { echo "FAILED: $*"; exit 1; }; }
export ASAN_OPTIONS=detect_leaks=0
step "logic" $CXX -I"$D/.." "$D/test_pulling_logic.cpp" -o "$B/tl"; step "run" "$B/tl"
step "host" $CXX -I"$D/mock" -I"$D/.." "$D/test_pulling_host.cpp" -o "$B/th"; step "run" "$B/th"
step "zone host" $CXX -I"$D/mock" -I"$D/.." "$D/test_pulling_zone_host.cpp" -o "$B/tz"; step "run" "$B/tz"
rm -f "$B/tl" "$B/th" "$B/tz"
x86_64-w64-mingw32-g++ -std=c++17 -fsyntax-only -Wall -Wextra -Wno-unknown-pragmas -I"$SDK" -I"$D/.." "$D/wrap_Pulling.cpp" > "$B/syntax-Pulling.log" 2>&1
E=$(grep -c ' error' "$B/syntax-Pulling.log"); W=$(grep 'warning' "$B/syntax-Pulling.log" | grep -vc "$SDK")
echo "syntax Pulling: $E errors, $W warnings outside the SDK"; [ "$E" = 0 ] && [ "$W" = 0 ] || { head -20 "$B/syntax-Pulling.log"; exit 1; }
x86_64-w64-mingw32-g++ -std=c++17 -c -O0 -I"$SDK" -I"$D/.." "$D/wrap_Pulling.cpp" -o "$B/w32-Pulling.o" 2>/dev/null || { echo "win32 Pulling: compile failed"; exit 1; }
imps=$(x86_64-w64-mingw32-nm -u "$B/w32-Pulling.o" | grep "__imp_" | sed 's/.*__imp_//' | grep -E '^[A-Z]' | sort -u | tr '\n' ' ')
for f in GetCursorPos WindowFromPoint ScreenToClient GetAsyncKeyState MessageBoxA; do case " $imps " in *" $f "*) echo "win32 Pulling: user32 $f needs a pragma"; exit 1;; esac; done
echo "win32 Pulling: ok ($imps)"; rm -f "$B/w32-Pulling.o"
echo "ALL PULLING SUITES PASSED"
