// test_bas_logic.cpp -- BidAskStatsLogic.h unit tests. g++ -std=c++17 -I.. test_bas_logic.cpp -o tl && ./tl
#include "BidAskStatsLogic.h"
#include <cstdio>
static int fails = 0, passes = 0;
#define CHECK(c, m) do { if (c) ++passes; else { ++fails; std::printf("FAIL %d %s\n", __LINE__, m); } } while (0)
using namespace bas;
static Row R(double p, long long b, long long a) { Row r; r.price = p; r.bid = b; r.ask = a; return r; }
static BarMax M(long long b, long long a) { BarMax m; m.ok = true; m.bid = b; m.ask = a; return m; }
static BarMax NA() { return BarMax(); }
int main() {
    // ---- per-bar max
    {
        std::vector<Row> rows = { R(7000.00, 12, 3), R(7000.25, 40, 9), R(7000.50, 7, 55), R(7000.75, 0, 20) };
        BarMax m = maxOf(rows, .25);
        CHECK(m.ok && m.bid == 40 && m.bidPx == 7000.25 && m.ask == 55 && m.askPx == 7000.50, "max bid / ask and their prices");
    }
    {   // ties: bid -> lowest price, ask -> highest; independent of row order
        std::vector<Row> a = { R(10.5, 30, 8), R(10.0, 30, 8), R(10.25, 1, 8) };
        std::vector<Row> b = { R(10.25, 1, 8), R(10.0, 30, 8), R(10.5, 30, 8) };
        BarMax x = maxOf(a, .25), y = maxOf(b, .25);
        CHECK(x.bid == 30 && x.bidPx == 10.0 && x.ask == 8 && x.askPx == 10.5, "ties: bid at the lowest, ask at the highest price");
        CHECK(y.bidPx == x.bidPx && y.askPx == x.askPx, "ties do not depend on row order");
    }
    {   // rows of the same tick (float noise) are summed on the tick grid
        std::vector<Row> rows = { R(7000.2499, 10, 1), R(7000.2501, 15, 2), R(7000.5, 20, 1) };
        BarMax m = maxOf(rows, .25);
        CHECK(m.ok && m.bid == 25 && m.bidPx == 7000.25, "same-tick rows summed on the chart tick grid");
    }
    {   // malformed rows -> the whole bar n/a, never a partial answer
        std::vector<Row> neg = { R(1, 5, 5), R(2, -1, 3) };
        std::vector<Row> nan = { R(1, 5, 5), R(0.0 / 0.0, 1, 1) };
        CHECK(!maxOf(neg, .25).ok && !maxOf(nan, .25).ok, "negative volume / NaN price -> n/a");
        CHECK(!maxOf(neg, 0).ok && !maxOf(std::vector<Row>{R(1, 1, 1)}, -1).ok, "bad tick -> n/a");
        BarMax e = maxOf(std::vector<Row>(), .25);
        CHECK(e.ok && e.bid == 0 && e.ask == 0, "no rows (a bar that traded nothing) is a valid 0 / 0");
    }
    {   // volumes above 2^31 (lesson 2)
        std::vector<Row> rows = { R(1, 3000000000LL, 1), R(1, 3000000000LL, 1) };
        CHECK(maxOf(rows, .25).bid == 6000000000LL, "long long volumes, no overflow");
    }
    // ---- BBid / BAsk counts
    {
        bool cap = false;
        CHECK(countBiggest({}, 5, cap) == 1 && !cap, "first bar: biggest of 1");
        CHECK(countBiggest({ 1, 2, 3 }, 5, cap) == 4, "bigger than all 3 prior: 4");
        CHECK(countBiggest({ 9, 1, 2 }, 5, cap) == 3, "stops at the first bar that is not smaller");
        CHECK(countBiggest({ 1, 5 }, 5, cap) == 1, "equal is not smaller: 1");
        CHECK(countBiggest({ 7 }, 5, cap) == 1, "smaller than the previous: 1");
        std::vector<long long> many(2000, 1);
        int n = countBiggest(many, 5, cap);
        CHECK(n == COUNT_CAP && cap && fmtCount(n, cap, true) == "999+", "capped at 999 -> 999+");
        std::vector<long long> some(23 - 1, 1);
        const int n23 = countBiggest(some, 5, cap); CHECK(n23 == 23 && fmtCount(n23, cap, true) == "23", "biggest in 23 candles = 23");
    }
    // ---- ratios
    {
        bool ok = true;
        ratioOf({ 1, 2, 3, 4 }, 10, 20, ok); CHECK(!ok, "< 5 prior bars -> n/a");
        double r = ratioOf({ 10, 10, 10, 10, 10 }, 35, 20, ok); CHECK(ok && fmtRatio(ok, r) == "3.5x", "5 prior bars: 35 / 10 = 3.5x");
        std::vector<long long> p(30, 100); for (int i = 0; i < 10; ++i) p[i] = 1000;   // old big bars outside the last 20
        r = ratioOf(p, 250, 20, ok); CHECK(ok && fmtRatio(ok, r) == "2.5x", "only the last 20 prior bars are averaged");
        r = ratioOf(p, 250, 30, ok); CHECK(ok && std::fabs(r - 250.0 / 400.0) < 1e-12, "Ratio bars 30 averages 30");
        ratioOf({ 0, 0, 0, 0, 0 }, 5, 20, ok); CHECK(!ok, "zero mean -> n/a, not infinity");
        CHECK(fmtRatio(false, 1) == "n/a" && fmtRatio(true, 3.46) == "3.5x" && fmtRatio(true, 12.04) == "12.0x", "one decimal + x");
        CHECK(clampRatioBars(4) < 0 && clampRatioBars(201) < 0 && clampRatioBars(20) == 20, "Ratio bars 5-200");
    }
    // ---- the series: n/a bars excluded from counts and averages, stats frozen
    {
        Series s;
        for (int i = 0; i < 6; ++i) s.add(100 + i, M(10, 20), 20);
        s.add(200, NA(), 20);                      // n/a in the middle
        const Stat& x = s.add(300, M(30, 5), 20);
        CHECK(x.m.ok && x.bBid == 7 && x.bAsk == 1, "n/a bar skipped by the count (7 = itself + 6 valid prior)");
        CHECK(x.bidRatioOk && std::fabs(x.bidRatio - 3.0) < 1e-12 && x.askRatioOk && std::fabs(x.askRatio - .25) < 1e-12, "n/a bar excluded from the averages");
        CHECK(!s.bars[200].m.ok && boxLines(&s.bars[200])[0].value == "n/a", "the n/a bar itself shows n/a");
        Series f; f.add(1, M(5, 5), 20); const Stat& y = f.add(2, M(9, 1), 20);
        CHECK(y.bBid == 2 && !y.bidRatioOk && boxLines(&y)[2].value == "n/a", "second bar: BBid 2, ratio n/a (< 5 prior)");
        Series big; for (int i = 0; i < 1200; ++i) big.add(i, M(1, 1), 20);
        const Stat& z = big.add(5000, M(9, 1), 20);
        CHECK(boxLines(&z)[0].value == "999+" && z.bAsk == 1, "series cap at 999");
        const long long before = big.computed; big.add(5001, M(1, 1), 20);
        CHECK(big.computed == before + 1, "one new bar = one computation");
        // reratio: only ratios change
        s.reratio(5);
        CHECK(s.bars[300].bBid == 7 && std::fabs(s.bars[300].bidRatio - 3.0) < 1e-12, "reratio keeps counts");
    }
    // ---- box and layout helpers
    {
        CHECK(boxLines(nullptr).size() == 4 && boxLines(nullptr)[0].label == "BBid" && boxLines(nullptr)[3].label == "AskRatio", "box lines in order");
        CHECK(boxLines(nullptr)[0].side < 0 && boxLines(nullptr)[1].side > 0 && boxLines(nullptr)[2].side < 0 && boxLines(nullptr)[3].side > 0, "bid lines red, ask lines green");
        Box a = { 0, 0, 400, 200 };
        Box tl = placeIn(a, 100, 50, 0), br = placeIn(a, 100, 50, 8), mc = placeIn(a, 100, 50, 4), bad = placeIn(a, 100, 50, 42);
        CHECK(tl.l == 0 && tl.t == 0 && br.r == 400 && br.b == 200 && mc.l == 150 && mc.t == 75 && bad.l == 0 && bad.t == 0, "9-spot position, bad -> top left");
        Box tiny = placeIn(Box{ 0, 0, 50, 20 }, 100, 50, 8); CHECK(tiny.l == 0 && tiny.t == 0, "clamped inside a small area");
        for (int slot = 1; slot <= 40; ++slot) {
            Pair p = pairIn(100, slot);
            const bool inside = p.redL >= 100 - (slot < 2 ? 2 : slot) / 2 - 1 && p.greenR <= 100 + (slot < 2 ? 2 : slot) / 2 + 1;
            if (!(p.redL < p.redR && p.greenL < p.greenR && p.redR <= p.greenL && inside)) { CHECK(false, "pair inside its slot"); break; }
            if (slot == 40) CHECK(true, "pair inside its slot, red left of green, all slot widths 1-40");
        }
        CHECK(barHeight(0, 10, 100) == 0 && barHeight(10, 10, 100) == 100 && barHeight(1, 1000, 100) == 1 && barHeight(5, 10, 100) == 50, "shared scale heights");
    }
    std::printf("logic: %d passed, %d failed\n", passes, fails); return fails ? 1 : 0;
}
