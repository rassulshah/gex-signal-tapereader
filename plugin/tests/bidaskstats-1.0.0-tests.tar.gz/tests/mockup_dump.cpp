// mockup_dump.cpp -- runs lsBidAskStats against the mock host and prints its draw calls (rendered by render_mockup.py)
#include "BidAskStats.cpp"
#include <cstdio>
#include <unistd.h>
namespace mock { Host* current = nullptr; }
long long bas_test_now_ms = 1000000;
int main() {
    char tmpl[] = "/tmp/basmXXXXXX"; setenv("USERPROFILE", mkdtemp(tmpl), 1);
    mock::Host h; mock::current = &h; h.tick = .25f; h.symbol = "ESZ6"; h.root = "ES"; h.paneTop = 0; h.paneBottom = 220; h.paneLeft = 0; h.paneRight = 560; h.ppb = 10;
    unsigned x = 2026; auto rnd = [&]() { x = x * 1103515245u + 12345u; return (int)((x >> 16) % 1000); };
    for (int i = 0; i < 41; ++i) {
        mock::Bar b; b.time = 1791900000UL + 60UL * i;
        const double trend = i < 22 ? -1 : 1;                   // a sell-off into a low, then the turn
        for (int k = 0; k < 10; ++k) {
            long bid = 20 + rnd() % 60, ask = 20 + rnd() % 60;
            if (trend < 0) bid += rnd() % 40; else ask += rnd() % 40;
            if (i == 21 && k == 2) bid = 420;                   // capitulation print at the low
            if (i == 24 && k == 7) ask = 260;
            if (i == 39 && k == 5) bid = 310;                   // the last closed bar: a big bid
            b.rows.push_back(mock::Price(6990.0f + .25f * k, ask, bid, ask + bid)); b.volume += (unsigned long)(ask + bid);
        }
        h.bars.push_back(b);
    }
    h.bars[12].failStats = 1;                                   // an n/a candle: no bars drawn
    BidAskStats* p = static_cast<BidAskStats*>(CreateExtension()); p->calc(0); h.draws.clear(); p->draw();
    for (auto& d : h.draws) std::printf("%s|%d|%d|%d|%d|%06lx|%06lx|%s\n", d.type.c_str(), d.x, d.y, d.r, d.b, d.color, d.border, d.text.c_str());
    p->destroy(); p->~BidAskStats(); ::operator delete(p); return 0;
}
