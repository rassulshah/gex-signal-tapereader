// test_bas_host.cpp -- lsBidAskStats 1.0.0 against the mock host.
// g++ -std=c++17 -DBAS_TEST_CLOCK -Imock -I.. test_bas_host.cpp -o th && ./th
#include "BidAskStats.cpp"
#include <cstdio>
#include <unistd.h>
namespace mock { Host* current = nullptr; }
long long bas_test_now_ms = 1000000;
static int fails = 0, passes = 0;
#define CHECK(c, m) do { if (c) ++passes; else { ++fails; std::printf("FAIL %d %s\n", __LINE__, m); } } while (0)
static std::string readAll(const std::string& p) { std::ifstream f(p.c_str()); std::stringstream s; s << f.rdbuf(); return s.str(); }
static void dispose(BidAskStats* p) { p->destroy(); p->~BidAskStats(); ::operator delete(p); }
static BidAskStats* make() { return static_cast<BidAskStats*>(CreateExtension()); }
// a bar: rows (price, ask = buyVolume, bid = sellVolume)
static mock::Bar bar(unsigned long t, std::vector<std::pair<long, long>> bidAsk, float p0 = 7000.0f) {
    mock::Bar b; b.time = t; b.volume = 0;
    for (size_t k = 0; k < bidAsk.size(); ++k) {
        const long bid = bidAsk[k].first, ask = bidAsk[k].second;
        b.rows.push_back(mock::Price(p0 + 0.25f * (float)k, ask, bid, ask + bid)); b.volume += (unsigned long)(ask + bid);
    }
    return b;
}
static unsigned long T0 = 1791900000UL;   // 2026-10-13
static void fill(mock::Host& h, int n, unsigned seed) {
    h.bars.clear(); unsigned x = seed;
    for (int i = 0; i < n; ++i) {
        std::vector<std::pair<long, long>> r;
        for (int k = 0; k < 6; ++k) { x = x * 1103515245u + 12345u; const long b = (long)(x >> 20) % 90 + 1; x = x * 1103515245u + 12345u; const long a = (long)(x >> 20) % 90 + 1; r.push_back(std::make_pair(b, a)); }
        h.bars.push_back(bar(T0 + 60UL * (unsigned long)i, r));
    }
}
// reference: the stats recomputed from scratch with the logic (closed bars 0..n-2)
static bas::Series reference(mock::Host& h, int ratioBars) {
    bas::Series s;
    for (size_t i = 0; i + 1 < h.bars.size(); ++i) {
        mock::Bar& b = h.bars[i]; std::vector<bas::Row> r;
        for (auto& p : b.rows) r.push_back(bas::Row{ p.price, p.sell, p.buy });
        s.add((long long)b.time, b.failStats ? bas::BarMax() : bas::maxOf(r, h.tick), ratioBars);
    }
    return s;
}
static bool same(const bas::Stat& a, const bas::Stat& b) {
    return a.m.ok == b.m.ok && a.m.bid == b.m.bid && a.m.ask == b.m.ask && a.m.bidPx == b.m.bidPx && a.m.askPx == b.m.askPx && a.bBid == b.bBid && a.bAsk == b.bAsk
        && a.bidRatioOk == b.bidRatioOk && a.askRatioOk == b.askRatioOk && a.bidRatio == b.bidRatio && a.askRatio == b.askRatio;
}
static std::string boxValue(mock::Host& h, const std::string& label, COLOR* color = nullptr) {
    for (size_t i = 0; i + 1 < h.draws.size(); ++i) if (h.draws[i].type == "text" && h.draws[i].text == label) { if (color) *color = h.draws[i + 1].color; return h.draws[i + 1].text; }
    return "?";
}
static int rects(mock::Host& h, COLOR c) { int n = 0; for (auto& d : h.draws) if (d.type == "box" && d.color == c) ++n; return n; }

int main() {
    char tmpl[] = "/tmp/basXXXXXX"; const char* tmp = mkdtemp(tmpl); setenv("USERPROFILE", tmp, 1);
    const std::string flex = std::string(tmp) + "\\InvestorRT\\rtx\\lsFlexLevels";
    mock::Host h; mock::current = &h; h.tick = 0.25f; h.seconds = 60; h.symbol = "ESZ6"; h.root = "ES"; h.paneBottom = 300; h.paneRight = 1200;
    CHECK(std::string(BAS_VERSION) == "1.0.0" && std::string(bas::VERSION) == BAS_VERSION, "version 1.0.0 everywhere");
    fill(h, 41, 7);                                                         // 40 closed + 1 forming
    BidAskStats* p = make(); p->calc(0);
    BASState* S = p->testState();
    CHECK(S && S->ser.bars.size() == 40 && S->lastClosedTime == (long long)h.bars[39].time, "40 closed bars computed; the forming bar is not");
    {
        bas::Series ref = reference(h, 20); bool all = true;
        for (auto& kv : ref.bars) if (!S->ser.bars.count(kv.first) || !same(S->ser.bars[kv.first], kv.second)) all = false;
        CHECK(all, "host stats equal the logic reference on every closed bar");
    }
    {   // a known last closed bar: the biggest bid of the session and a 3.5x ask
        h.bars.clear(); for (int i = 0; i < 30; ++i) h.bars.push_back(bar(T0 + 60UL * i, { {10, 20}, {5, 1} }));
        h.bars.push_back(bar(T0 + 60UL * 30, { {3, 70}, {50, 2}, {1, 1} }));  // last closed: bid 50 @7000.25, ask 70 @7000.00
        h.bars.push_back(bar(T0 + 60UL * 31, { {900, 900} }));               // forming: huge, must not reach the box
        dispose(p); h.data = nullptr; p = make(); p->calc(0); S = p->testState();
        const bas::Stat& st = S->ser.bars[(long long)h.bars[30].time];
        CHECK(st.m.bid == 50 && st.m.bidPx == 7000.25 && st.m.ask == 70 && st.m.askPx == 7000.0, "VAP: bid = sellVolume, ask = buyVolume, per price");
        CHECK(st.bBid == 31 && st.bAsk == 31, "BBid / BAsk 31 = the biggest of every bar available");
        h.draws.clear(); p->draw();
        COLOR c1 = 0, c2 = 0, c3 = 0, c4 = 0;
        CHECK(boxValue(h, "BBid", &c1) == "31" && boxValue(h, "BAsk", &c2) == "31" && boxValue(h, "BidRatio", &c3) == "5.0x" && boxValue(h, "AskRatio", &c4) == "3.5x",
              "box: BBid 31, BAsk 31, BidRatio 5.0x (50/10), AskRatio 3.5x (70/20) - the last CLOSED bar, not the forming one");
        CHECK(c1 == C_BID && c3 == C_BID && c2 == C_ASK && c4 == C_ASK, "bid values red, ask values green");
        bool labelsWhite = true; for (auto& d : h.draws) if (d.type == "text" && (d.text == "BBid" || d.text == "BAsk" || d.text == "BidRatio" || d.text == "AskRatio") && d.color != C_LABEL) labelsWhite = false;
        CHECK(labelsWhite, "labels white");
        const mock::Draw* box = nullptr; for (auto& d : h.draws) if (d.type == "box" && d.color == C_BLACK) box = &d;
        CHECK(box && box->border == C_BORDER && box->width == 1 && box->x == 3 && box->y == 3, "solid black box with a solid border at the top left of the pane");
        CHECK(rects(h, C_BID) == 32 && rects(h, C_ASK) == 32, "a red and a green bar for every candle, the forming one included");
        // shared scale: the forming bar (900) is the tallest; the closed 50 bid is 50/900 of it
        int hForm = 0, h50 = 0;
        for (auto& d : h.draws) if (d.type == "box" && d.color == C_BID) { const int x = d.b - d.y; if (d.x > 50 + 31 * 10 - 10) hForm = x; else if (d.x > 50 + 30 * 10 - 10) h50 = x; }
        CHECK(hForm == 300 - 6 && std::abs(h50 - (int)(294.0 * 50 / 900 + .5)) <= 1, "both bars on one shared scale");
        bool order = true; for (size_t i = 0; i + 1 < h.draws.size(); ++i) if (h.draws[i].type == "box" && h.draws[i].color == C_BID && h.draws[i + 1].type == "box" && h.draws[i + 1].color == C_ASK && !(h.draws[i].r <= h.draws[i + 1].x)) order = false;
        CHECK(order, "red left of green inside the slot");
    }
    {   // closed values never change as new bars arrive; the bar that was forming is read fresh when it closes
        std::map<long long, bas::Stat> before = S->ser.bars;
        h.bars.back() = bar(h.bars.back().time, { {40, 10} });                // the forming bar finishes differently
        h.bars.push_back(bar(T0 + 60UL * 32, { {1, 1} }));
        bas_test_now_ms += 10; p->calc(0);
        bool frozen = true; for (auto& kv : before) if (!same(S->ser.bars[kv.first], kv.second)) frozen = false;
        CHECK(frozen && S->ser.bars.size() == before.size() + 1, "closed bars never change as new bars arrive");
        CHECK(S->ser.bars[(long long)h.bars[31].time].m.bid == 40, "the newly closed bar is read as closed (not its forming snapshot)");
        // incremental: one more bar = one new computation and 2 VAP reads (the new closed bar + the forming bar)
        const long long comp = S->ser.computed; const int calls = h.statsCalls;
        h.bars.push_back(bar(T0 + 60UL * 33, { {2, 2} })); bas_test_now_ms += 10; p->calc(0);
        CHECK(S->ser.computed == comp + 1 && h.statsCalls == calls + 2, "a new bar = 1 stats computation, 2 VAP reads");
        if (!(S->ser.computed == comp + 1 && h.statsCalls == calls + 2)) std::printf("  computed +%lld, reads +%d\n", S->ser.computed - comp, h.statsCalls - calls);
        const int c2 = h.statsCalls; p->draw(); p->draw(); p->calc(0);
        CHECK(h.statsCalls == c2, "repaints in the same 250 ms touch no VAP");
        bas_test_now_ms += 300; p->draw();
        CHECK(h.statsCalls == c2 + 1 && S->ser.computed == comp + 1, "after 250 ms only the forming bar is re-read");
    }
    {   // a failed VAP read = n/a, not 0; excluded from counts; retried and recovered without revising later bars
        dispose(p); h.data = nullptr; fill(h, 41, 11);
        for (auto& b : h.bars) b.rows[0].sell = 10;                          // flat bids: every bar's biggest bid >= 10
        h.bars[20].rows[0].sell = 500; h.bars[20].failStats = 1;            // the big bar cannot be read
        h.bars[21].rows.clear();                                            // statistics say 0 prices but the bar traded: missing
        p = make(); p->calc(0); S = p->testState();
        const bas::Stat& na = S->ser.bars[(long long)h.bars[20].time];
        CHECK(!na.m.ok && na.m.bid == 0 && S->vapFailures >= 2, "failed read -> n/a (counted), never 0");
        CHECK(!S->ser.bars[(long long)h.bars[21].time].m.ok, "0 prices with bar volume -> n/a");
        bas::Series ref = reference(h, 20); ref.bars[(long long)h.bars[21].time] = bas::Stat();
        // the reference with 20 and 21 n/a: recompute 22.. from scratch
        bas::Series r2; for (size_t i = 0; i + 1 < h.bars.size(); ++i) { mock::Bar& b = h.bars[i]; std::vector<bas::Row> rr; for (auto& q : b.rows) rr.push_back(bas::Row{ q.price, q.sell, q.buy });
            r2.add((long long)b.time, (i == 20 || i == 21) ? bas::BarMax() : bas::maxOf(rr, h.tick), 20); }
        bool excl = true; for (auto& kv : r2.bars) if (!same(S->ser.bars[kv.first], kv.second)) excl = false;
        CHECK(excl, "n/a bars excluded from every later count and average");
        h.draws.clear(); p->draw();
        CHECK(rects(h, C_BID) == 39 && rects(h, C_ASK) == 39, "no histogram bars for the two n/a candles");
        const bas::Stat later = S->ser.bars[(long long)h.bars[30].time];
        h.bars[20].failStats = 0; bas_test_now_ms += 200; p->calc(0);
        CHECK(!S->ser.bars[(long long)h.bars[20].time].m.ok, "retry waits at least 1 s");
        bas_test_now_ms += 1000; p->calc(0);
        CHECK(S->ser.bars[(long long)h.bars[20].time].m.ok && S->ser.bars[(long long)h.bars[20].time].m.bid == 500, "back-filled VAP: the n/a bar recovers its own value");
        CHECK(same(S->ser.bars[(long long)h.bars[30].time], later), "later bars' stats are not revised (no repaint)");
        for (int k = 0; k < 12; ++k) { bas_test_now_ms += 1100; p->calc(0); }
        CHECK(S->naTries.empty() && !S->ser.bars[(long long)h.bars[21].time].m.ok, "a bar still missing after 10 tries stays n/a for good");
        const int calls = h.statsCalls; bas_test_now_ms += 5000; p->calc(0);
        CHECK(h.statsCalls == calls + 1, "no more retries after that (only the forming bar is read)");
    }
    {   // status file: content, atomic, at most once a minute
        const std::string sp = flex + "\\BidAskStats.status-ES-ESZ6-60.txt";
        const std::string t = readAll(sp);
        CHECK(t.find("VERSION,1.0.0\n") != std::string::npos && t.find("MARKET,ES\n") != std::string::npos && t.find("SYMBOL,ESZ6\n") != std::string::npos
              && t.find("LAST_CLOSED_BAR,") != std::string::npos && t.find("BIGGEST_BID,") != std::string::npos && t.find("BBID,") != std::string::npos
              && t.find("BID_RATIO,") != std::string::npos && t.find("VAP_FAILURES,") != std::string::npos, "status file has every field");
        CHECK(readAll(sp + ".tmp").empty(), "no temporary file left behind");
        h.bars.push_back(bar(h.bars.back().time + 60, { {1, 1} })); bas_test_now_ms += 1000; p->calc(0);
        const std::string t1 = readAll(sp);
        bas_test_now_ms += 61000; p->calc(0);
        const std::string t2 = readAll(sp);
        CHECK(t1 != t2 || t1.find("LAST_CLOSED_BAR," + std::to_string(S->lastClosedTime)) != std::string::npos, "a change is published within a minute");
        h.bars.push_back(bar(h.bars.back().time + 60, { {1, 1} })); bas_test_now_ms += 1000; p->calc(0);
        CHECK(readAll(sp) == t2, "not rewritten again inside the minute");
        bas_test_now_ms += 60000; p->calc(0);
        CHECK(readAll(sp).find("LAST_CLOSED_BAR," + std::to_string(S->lastClosedTime) + ",") != std::string::npos, "rewritten after the minute with the last closed bar");
        // 2026-10-13 stamp printed on the chart clock
        CHECK(readAll(sp).find(",2026-10-") != std::string::npos, "readable bar stamp");
    }
    {   // two charts on one DLL: independent state and status files
        mock::Host h2 = h; h2.data = nullptr; h2.symbol = "NQZ6"; h2.root = "NQ"; fill(h2, 25, 99);
        mock::current = &h2; BidAskStats* q = make(); q->calc(0); BASState* Q = q->testState();
        mock::current = &h; p->calc(0);
        CHECK(Q && Q != S && Q->market == "NQ" && S->market == "ES" && Q->ser.bars.size() == 24 && S->ser.bars.size() == 42, "two charts keep their own state");
        mock::current = &h2; bas_test_now_ms += 61000; q->calc(0);
        CHECK(!readAll(flex + "\\BidAskStats.status-NQ-NQZ6-60.txt").empty() && readAll(flex + "\\BidAskStats.status-ES-ESZ6-60.txt").find("MARKET,ES") != std::string::npos, "status files per market + contract");
        dispose(q); mock::current = &h;
        mock::Host h3; h3.noSlot = true; mock::current = &h3; fill(h3, 10, 1); BidAskStats* z = make(); z->calc(0); z->draw();
        CHECK(z->testState() == nullptr, "no host slot: fail closed (nothing shared)");
        dispose(z); mock::current = &h;
    }
    {   // settings: per-market file written only from Apply with valid values, read back by stamp
        const std::string pp = flex + "\\BidAskStats.place-ES.txt";
        h.parms[0] = 30; h.listIndex = -1; p->parmsApply();
        CHECK(readAll(pp).empty(), "an invalid list index never writes the file");
        p->parmsLoad(); CHECK(readAll(pp).empty(), "loading never saves");
        h.parms[0] = 30; h.listIndex = 8; p->parmsApply();
        CHECK(readAll(pp) == "30,8\n", "Apply writes 'Ratio bars,Position'");
        const bas::Stat b0 = S->ser.bars[S->lastClosedTime];
        bas_test_now_ms += 1100; p->calc(0);
        CHECK(S->ratioBars == 30 && S->pos == 8, "settings picked up");
        const bas::Stat& b1 = S->ser.bars[S->lastClosedTime];
        CHECK(b1.bBid == b0.bBid && b1.m.bid == b0.m.bid, "Ratio bars change keeps the counts");
        h.draws.clear(); p->draw();
        const mock::Draw* box = nullptr; for (auto& d : h.draws) if (d.type == "box" && d.color == C_BLACK) box = &d;
        cppExtension::PNT e; e.set((int)h.bars.size() - 1, 0.0f, cppExtension::kBarRight);
        CHECK(box && box->b == h.paneBottom - 3 && box->r <= e.h - 3, "Position bottom right: inside the area up to where price ends");
        { std::ofstream f(pp.c_str()); f << "3,9\n"; }
        bas_test_now_ms += 1100; p->calc(0);
        CHECK(S->ratioBars == 20 && S->pos == 0, "a malformed settings file -> defaults (20, top left)");
        { std::ofstream f(pp.c_str()); f << "20,0\n"; }
        h.parms[0] = 500; h.listIndex = 3; p->parmsApply();
        CHECK(readAll(pp) == "20,0\n", "an out-of-range Ratio bars is not saved");
    }
    {   // a long chart loads in bounded slices; replay equals live; the box waits until done
        dispose(p); h.data = nullptr; fill(h, 1500, 3); h.statsCalls = 0;
        p = make(); p->calc(0); S = p->testState();
        CHECK(h.statsCalls <= READS_PER_PASS + 1 && S->backlog, "first pass bounded to 600 VAP reads");
        h.draws.clear(); p->draw();
        CHECK(boxValue(h, "BBid") == "n/a", "box n/a while loading");
        for (int k = 0; k < 4; ++k) { bas_test_now_ms += 10; p->calc(0); }
        CHECK(!S->backlog && S->ser.bars.size() == 1499, "all closed bars in after a few passes");
        bas::Series ref = reference(h, 20); bool all = true;
        for (auto& kv : ref.bars) if (!same(S->ser.bars[kv.first], kv.second)) all = false;
        CHECK(all, "sliced load equals one straight pass");
        // replay: the same chart added bar by bar equals the one-shot load
        mock::Host r = h; r.data = nullptr; r.bars.resize(2); mock::current = &r;
        BidAskStats* rp = make(); rp->calc(0);
        for (size_t i = 2; i < h.bars.size(); ++i) { r.bars.push_back(h.bars[i]); bas_test_now_ms += 10; rp->calc(0); }
        BASState* RS = rp->testState(); bool eq = RS->ser.bars.size() == S->ser.bars.size();
        for (auto& kv : S->ser.bars) if (!RS->ser.bars.count(kv.first) || !same(RS->ser.bars[kv.first], kv.second)) eq = false;
        CHECK(eq, "bar-by-bar replay equals the one-shot load");
        dispose(rp); mock::current = &h;
    }
    {   // geometry: tiny pane draws nothing; no tick -> nothing computed, state says so
        h.paneBottom = 10; h.draws.clear(); p->draw(); CHECK(h.draws.empty(), "pane too short: nothing drawn");
        h.paneBottom = 300;
        mock::Host t = h; t.data = nullptr; t.tick = 0; mock::current = &t; BidAskStats* tp = make(); tp->calc(0);
        CHECK(tp->testState()->ser.bars.empty() && tp->testState()->state == "native tick size unavailable", "no tick size: nothing computed");
        dispose(tp); mock::current = &h;
    }
    {   // the visible range from IRT: only those candles get bars
        h.bars.resize(60); bas_test_now_ms += 300; p->calc(0);
        h.visFrom = (int)h.bars.size() - 20; h.visTo = (int)h.bars.size() - 1; h.draws.clear(); bas_test_now_ms += 300; p->draw();
        CHECK(rects(h, C_BID) == 20 && rects(h, C_ASK) == 20, "only visible candles drawn");
        h.visFrom = h.visTo = -1;
    }
    dispose(p);
    std::printf("host: %d passed, %d failed\n", passes, fails); return fails ? 1 : 0;
}
