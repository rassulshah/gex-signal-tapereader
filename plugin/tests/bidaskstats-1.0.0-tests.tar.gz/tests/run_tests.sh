#!/bin/sh
# lsBidAskStats 1.0.0: logic + host tests under ASan/UBSan, real-SDK syntax check (MinGW), mockup render
set -e
D=$(cd "$(dirname "$0")" && pwd); B=${BUILD:-/tmp/bas-build}; mkdir -p "$B"; SAN="-fsanitize=address,undefined -fno-sanitize-recover=undefined"
g++ -std=c++17 -Wall -Wextra -Werror -g $SAN -I"$D/.." "$D/test_bas_logic.cpp" -o "$B/tl" && "$B/tl"
g++ -std=c++17 -Wall -Wextra -Werror -g $SAN -DBAS_TEST_CLOCK -I"$D/mock" -I"$D/.." "$D/test_bas_host.cpp" -o "$B/th" && "$B/th"
SDK=${SDK:-/mnt/user-data/uploads/sdk/c++/include}
x86_64-w64-mingw32-g++ -std=c++17 -fsyntax-only -Wall -Wextra -I"$SDK" -I"$D/.." "$D/wrap_real_sdk.cpp" 2>"$B/syntax.log"
echo "syntax: $(grep -c ' error' "$B/syntax.log" || true) errors, $(grep warning "$B/syntax.log" | grep -vc "$SDK" || true) warnings outside the SDK"
g++ -std=c++17 -DBAS_TEST_CLOCK -I"$D/mock" -I"$D/.." "$D/mockup_dump.cpp" -o "$B/md" && "$B/md" > "$B/draws.txt" && python3 "$D/render_mockup.py" "$B/draws.txt" "$D/../bidaskstats-mockup.png"
