# render_mockup.py -- draws lsBidAskStats' own draw calls (from mockup_dump) as a PNG: the price pane is context only.
import sys, random
from PIL import Image, ImageDraw, ImageFont
draws = [l.rstrip('\n').split('|', 7) for l in open(sys.argv[1])]
S = 2                                   # 2x for a crisp picture
PW, PH, TOP = 560, 220, 250             # indicator pane size (as drawn), price pane height above
img = Image.new('RGB', (PW * S, (TOP + PH + 8) * S), (13, 17, 23))
d = ImageDraw.Draw(img)
F = '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
font = ImageFont.truetype(F, 9 * S); small = ImageFont.truetype(F, 8 * S)
# price pane (context): a sell-off into a low at bar 21, then the turn
random.seed(4); px = 7000.0; bars = []
for i in range(41):
    drift = -1.6 if i < 22 else 1.3
    o = px; c = o + drift + random.uniform(-2.2, 2.2); h = max(o, c) + random.uniform(.3, 1.6); l = min(o, c) - random.uniform(.3, 1.6)
    if i == 21: l -= 4
    bars.append((o, h, l, c)); px = c
hi = max(b[1] for b in bars) + 1; lo = min(b[2] for b in bars) - 1
y = lambda v: int((8 + (hi - v) / (hi - lo) * (TOP - 30)) * S)
for i, (o, h, l, c) in enumerate(bars):
    x = (50 + i * 10) * S; col = (34, 197, 94) if c >= o else (239, 68, 68)
    d.line([(x, y(h)), (x, y(l))], fill=col, width=S)
    d.rectangle([x - 3 * S, min(y(o), y(c)), x + 3 * S, max(y(o), y(c)) + 1], fill=col)
d.text((6 * S, 4 * S), 'ESZ6  1 min  (price - context only)', font=small, fill=(120, 130, 145))
d.line([(0, (TOP - 6) * S), (PW * S, (TOP - 6) * S)], fill=(51, 65, 85), width=S)
oy = TOP * S
def rgb(h): v = int(h, 16); return ((v >> 16) & 255, (v >> 8) & 255, v & 255)
for t, x, y0, r, b, col, border, text in draws:
    x, y0, r, b = int(x), int(y0), int(r), int(b)
    if t == 'box':
        fill = rgb(col)
        if fill == (0, 0, 0): d.rectangle([x * S, oy + y0 * S, r * S, oy + b * S], fill=fill, outline=rgb(border), width=S)
        else: d.rectangle([x * S, oy + y0 * S, r * S - 1, oy + b * S], fill=fill)
    elif t == 'text':
        c = rgb(col)
        if c == (255, 255, 255): d.text((x * S, oy + (y0 - 6) * S), text, font=font, fill=c)
        else:                   # values: right edge where the indicator put it (x + its measured width, 6 px a character in the mock)
            w = d.textlength(text, font=font); d.text(((x + 6 * len(text)) * S - w, oy + (y0 - 6) * S), text, font=font, fill=c)
img.save(sys.argv[2])
print('saved', img.size)
