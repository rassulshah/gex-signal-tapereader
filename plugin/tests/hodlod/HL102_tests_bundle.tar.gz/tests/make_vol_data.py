"""dump END-stamped 3-min bars WITH volume (the read agent's own loader) for the timing cross-check"""
import sys, importlib.util
spec = importlib.util.spec_from_file_location("hr", sys.argv[1] + "/hodlod_read.py"); hr = importlib.util.module_from_spec(spec); spec.loader.exec_module(hr)
repo, m, out, since = sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5]
b = hr.load_bars(repo, m); b = b[b.t >= since]
with open(out, "w") as f:
    for r in b.itertuples(index=False):
        f.write(f"{r.t:%Y-%m-%d %H:%M:%S},{r.o!r},{r.h!r},{r.l!r},{r.c!r},{r.v!r}\n")
print(m, len(b), b.t.min(), b.t.max())
