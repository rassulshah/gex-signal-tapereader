// Mock Investor/RT SDK for the lsHodLod / lsSessionInfo lifecycle tests (Linux). NOT the real SDK: it models only what the two
// plugins call - several charts sharing ONE extension object (each with its own user-data slot), bars, the price -> pixel map,
// text measurement (Liberation Sans = Helvetica metrics at 96 dpi) and a record of everything drawn.
#pragma once
#include <string>
#include <vector>
#include <map>
#include <cstring>
#include <cstdio>
#include <ctime>
#include <cmath>
#include <new>
#include <stdexcept>
#include "../test_font_metrics.h"

typedef unsigned long COLOR;
typedef unsigned long RTDATE;
typedef unsigned short RTBOOL;
typedef int RTX_RESULT;
static const RTX_RESULT RTX_OK = 0, RTX_FAIL = -1;
static const short PLAIN = 0, BOLD = 1, HELVETICA = 0;
static const short kParmAppendSameLine = 1;
static const short NUMW = 50;
enum { DRAW_OPAQUE = 0, DRAW_TRANSLUCENT = 1 };
enum { PAT_SOLID = 0 };
enum PEN_STYLE { P_SOLID = 0, P_DASH = 1 };
enum : unsigned long { POST_DRAWING = 1UL << 18, OVERLAY = 1UL << 19, NO_UI = 1UL << 12, INSTRUMENT_SCALE = 1UL << 30, FRONT_DRAWING = 1UL << 29 };
enum { DRAW_INVISIBLE = 0 };
enum : unsigned long { CALL_CONTINUOUSLY = 1UL };
enum { OUTPUT_NO_UI = 2 };
enum DRAW_FLAGS { CONNECT_CNONZERO = 1, NO_AUTOSCALE = 2 };
enum fARRAY { barOpen = 0, barHigh, barLow, barClose };
enum iARRAY { barDateTime = 0, barVolume = 1 };
enum SYMBOL_PROPERTY_ID { SYM_TICKINCR = 1 };
struct FONT { short id = 0, size = 0, style = 0; };
struct CPEN { CPEN(COLOR, int, int) {} };

namespace mock {
struct Drawn { int kind; int l, t, r, b; std::string s; COLOR c; };   // 0 fill/rect, 1 text, 2 line
struct Chart {
    std::string root;
    std::vector<RTDATE> t; std::vector<float> o, h, l, c;
    std::vector<unsigned long> vol;          // bar volume (empty = the array is unavailable)
    float tick = 0.25f;
    void* userData = nullptr;
    double lo = 0, hi = 1; short pl = 0, pt = 0, pr = 1170, pb = 740;
    std::vector<Drawn> drawn;
    bool throwOnArrays = false;
};
inline Chart*& cur() { static Chart* c = nullptr; return c; }
inline std::vector<std::string>& params() { static std::vector<std::string> v; return v; }
inline int& arrayReads() { static int n = 0; return n; }
inline int& curFontSize() { static int n = 8; return n; }
inline bool& curBold() { static bool b = false; return b; }
inline int& widthCalls() { static int n = 0; return n; }
inline std::vector<int>& lists() { static std::vector<int> v(16, -1); return v; }
inline std::vector<int>& ints() { static std::vector<int> v(16, -1); return v; }
}

struct RCT {
    short top = 0, left = 0, bottom = 0, right = 0;
    void set(short l, short t, short r, short b) { left = l; top = t; right = r; bottom = b; }
    void getPaneRect(RTBOOL = false) { mock::Chart* c = mock::cur(); left = c ? c->pl : 0; top = c ? c->pt : 0; right = c ? c->pr : 1400; bottom = c ? c->pb : 800; }
    void draw(short = 0, COLOR = 0, COLOR fill = 0, int = 0, int = 0) { if (mock::cur()) mock::cur()->drawn.push_back(mock::Drawn{ 0, left, top, right, bottom, "", fill }); }
    void drawText(const char* s, RTBOOL = true, RTBOOL = false) { if (mock::cur()) mock::cur()->drawn.push_back(mock::Drawn{ 1, left, top, right, bottom, s ? s : "", 0 }); }
};
struct PNT {
    short v = 0, h = 0;
    RTX_RESULT set(int, float, int = 0) { return RTX_OK; }
    void setDrawPosition() { last() = *this; }
    void drawLineTo() { if (mock::cur()) mock::cur()->drawn.push_back(mock::Drawn{ 2, last().h, last().v, h, v, "", 0 }); last() = *this; }
    static PNT& last() { static PNT p; return p; }
};
class RTARRAY {
public:
    explicit RTARRAY(fARRAY w) : which(w) { mock::Chart* c = mock::cur(); if (c && c->throwOnArrays) throw std::runtime_error("mock array fault"); count = c ? (long)c->t.size() : 0; mock::arrayReads()++; }
    float operator[](int i) const { mock::Chart* c = mock::cur(); const std::vector<float>& v = which == barOpen ? c->o : which == barHigh ? c->h : which == barLow ? c->l : c->c; return v[(size_t)i]; }
    long count;
private:
    fARRAY which;
};
class RTARRAYI {
public:
    explicit RTARRAYI(iARRAY a) : which(a) { mock::Chart* c = mock::cur(); count = c ? (long)(a == barVolume ? c->vol.size() : c->t.size()) : 0; }
    unsigned long operator[](int i) const { return which == barVolume ? mock::cur()->vol[(size_t)i] : mock::cur()->t[(size_t)i]; }
    iARRAY which;
    long count;
};

class cppExtension {
public:
    cppExtension() {}
    virtual ~cppExtension() {}
    virtual int init(void);
    virtual int setup(void);
    virtual int calc(int);
    virtual int done(void);
    virtual int destroy(void);
    virtual int draw(void) { return RTX_OK; }
    virtual int parmsLoad(void) { return RTX_OK; }
    virtual int parmsApply(void) { return RTX_OK; }
    virtual int parmsUpdt(unsigned int) { return RTX_OK; }
    void* getUserData(void) { return mock::cur() ? mock::cur()->userData : nullptr; }
    void setUserData(void* p) { if (mock::cur()) mock::cur()->userData = p; }
    long getBarCount(void) { return mock::cur() ? (long)mock::cur()->t.size() : 0; }
    char* getRootSymbol(char* b = nullptr, const char* = nullptr) { static std::string r; r = mock::cur() ? mock::cur()->root : ""; if (b) { std::strncpy(b, r.c_str(), 31); b[31] = 0; } return const_cast<char*>(r.c_str()); }
    struct tm* getLocaltime(RTDATE dt, struct tm* p) { time_t x = (time_t)dt; gmtime_r(&x, p); return p; }   // mock RTDATE = local wall-clock seconds
    float getProperty(SYMBOL_PROPERTY_ID, const char* = nullptr) { return mock::cur() ? mock::cur()->tick : 0.0f; }
    short getVerticalDrawPosition(float p) { mock::Chart* c = mock::cur(); return (short)std::lround(c->pt + (c->hi - p) / (c->hi - c->lo) * (c->pb - c->pt)); }
    RTX_RESULT setFont(FONT& f) { mock::curFontSize() = f.size; mock::curBold() = f.style == BOLD; return RTX_OK; }
    int getTextWidth(const char* s, int = -1) { mock::widthCalls()++; double w = 0; for (const char* p = s; p && *p; p++) w += (mock::curBold() ? ADV_BOLD : ADV_REG)[(unsigned char)*p]; return (int)(w * mock::curFontSize() * 96.0 / 72.0 / 1000.0 + 0.999); }
    void setTextColor(COLOR) {}
    void setPen(COLOR, short, PEN_STYLE) {}
    void setArrayCount(int) {}
    void setFlags(unsigned long f) { flags = f; }
    void setExtendedFlags(unsigned long f) { xflags = f; }
    void setDescription(const char*) {}
    void setVersion(const char* v) { version = v; }
    void setParameterVersion(unsigned) {}
    void setParameterDialogHeight(int, int = 22) {}
    RTX_RESULT setListParameter(const char* n, short, const char*, short = 0, short = 0) { mock::params().push_back(n); return RTX_OK; }
    RTX_RESULT setIntegerParameter(const char* n, int, short = 0, short = 0) { mock::params().push_back(n); return RTX_OK; }
    RTX_RESULT setOutputParameter(const char* n, int, CPEN*, COLOR, unsigned long fl = 0) { mock::params().push_back(std::string("output:") + n + (fl == OUTPUT_NO_UI ? ":NO_UI" : "")); return RTX_OK; }
    void setArrayDrawingFlags(int, DRAW_FLAGS) {}
    int getListIndex(int i) { return i >= 0 && i < 16 ? mock::lists()[(size_t)i] : -1; }
    int getIntegerValue(int i) { return i >= 0 && i < 16 ? mock::ints()[(size_t)i] : -1; }
    unsigned long flags = 0, xflags = 0; std::string version;
};
#ifndef _WIN32
inline int localtime_s(struct tm* out, const time_t* in) { return localtime_r(in, out) ? 0 : 1; }
#endif
