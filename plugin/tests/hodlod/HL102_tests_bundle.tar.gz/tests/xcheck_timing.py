"""compare the plugin's 14 timing features (xcheck_timing.cpp) with hodlod_read.py tstates() on the same bars"""
import sys, importlib.util, numpy as np, pandas as pd
spec = importlib.util.spec_from_file_location("hr", sys.argv[1] + "/hodlod_read.py"); hr = importlib.util.module_from_spec(spec); spec.loader.exec_module(hr)
repo, m, cppf, d0 = sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5]
import os
EVF = os.environ.get("HL_EVENTS")      # the calendar the plugin's HodLodEvents.h was generated from (both sides must use the same one)
if EVF:
    E = pd.read_csv(EVF); ev = {}
    for r in E.itertuples(index=False): ev.setdefault(str(r.date)[:10], set()).add(r.event)
else:
    ev = hr.load_events(repo)
bars = hr.load_bars(repo, m)
if len(sys.argv) > 6:      # the plugin works on the tick grid (IRT gives float32 prices): round the store's prices the same way
    tk = float(sys.argv[6])
    for c in "ohlc":
        bars[c] = (bars[c] / tk).round() * tk
S = hr.sessions(bars, m, ev)
S = [s for s in S if s["date"] >= d0]
N = hr.DEFAULT_DESIGN["N"]
import json
N = json.load(open(sys.argv[1] + "/design.json")).get(m, {}).get("N", N) if isinstance(json.load(open(sys.argv[1] + "/design.json")), dict) else N
st = hr.tstates(S, m, 0, step=1)
cols = ["date", "now", "side"] + hr.TFEATS + ["pLater", "pClose", "elseFrom", "elseTo"]
c = pd.read_csv(cppf, names=cols, header=None)
c = c[c.date >= d0]
x = c.merge(st[["date", "now", "side"] + hr.TFEATS], on=["date", "now"], suffixes=("", "_py"))
bad = 0
for f in ["side"] + hr.TFEATS:
    d = np.abs(x[f].astype(float) - x[f + "_py"].astype(float))
    k = int((d > 1e-6).sum())
    if k:
        bad += k; print(f"  {f}: {k} mismatches, e.g.", x.loc[d > 1e-6, ["date", "now", f, f + "_py"]].head(3).values.tolist())
print(f"{m}: {len(x)} bars on {x.date.nunique()} sessions compared ({len(c)} C++ rows, {len(st)} Python rows), {bad} feature mismatches")
