
// selftest: hle::expect == the Python reference (fit_expected.py py_expect) on every vector
#include "HodLodExpectedV2.h"
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <string>
#include <vector>

static double num(const std::string& s) {
  if (s == "nan") {
    return NAN;
  }
  if (s == "inf") {
    return INFINITY;
  }
  if (s == "-inf") {
    return -INFINITY;
  }
  char* end = nullptr;
  const double v = std::strtod(s.c_str(), &end);
  if (!end || *end) {
    std::fprintf(stderr, "bad number %s\n", s.c_str());
    std::exit(2);
  }
  return v;
}

static std::vector<double> split(const std::string& s) {
  std::vector<double> v;
  size_t a = 0;
  while (true) {
    const size_t b = s.find(',', a);
    v.push_back(num(s.substr(a, b == std::string::npos ? std::string::npos : b - a)));
    if (b == std::string::npos) {
      break;
    }
    a = b + 1;
  }
  return v;
}

static bool same(double a, double b) {
  if (std::isnan(a) || std::isnan(b)) {
    return std::isnan(a) && std::isnan(b);
  }
  return std::fabs(a - b) <= 1e-7 * (1.0 + std::fabs(b));
}

int main(int argc, char** argv) {
  FILE* f = std::fopen(argc > 1 ? argv[1] : "hle_vectors.txt", "r");
  if (!f) {
    return 3;
  }
  char line[16384];
  int n = 0, bad = 0;
  const size_t nin = 8 + hle::kMaxMarks + 5;
  while (std::fgets(line, sizeof line, f)) {
    std::string s(line);
    while (!s.empty() && (s.back() == '\n' || s.back() == '\r')) {
      s.pop_back();
    }
    const size_t bar = s.find('|');
    const std::vector<double> in = split(s.substr(0, bar));
    const std::vector<double> out = split(s.substr(bar + 1));
    if (in.size() != nin || out.size() != 17) {
      std::printf("bad vector line %d\n", n + 1);
      return 4;
    }
    hle::State st;
    st.market = (int)in[0]; st.dow = (int)in[1]; st.mso = (int)in[2]; st.atr14 = in[3]; st.open = in[4];
    st.hi = in[5]; st.lo = in[6]; st.last = in[7];
    for (int k = 0; k < hle::kMaxMarks; ++k) {
      st.rngAt[k] = in[8 + k];
    }
    st.onRange = in[8 + hle::kMaxMarks]; st.prevRange = in[9 + hle::kMaxMarks]; st.prevClose = in[10 + hle::kMaxMarks];
    st.news = (int)in[11 + hle::kMaxMarks]; st.firstSide = (int)in[12 + hle::kMaxMarks];
    const hle::Expect e = hle::expect(st);
    const double got[17] = {(double)e.valid, (double)e.stage, e.range, e.rangeLo, e.rangeHi, e.pRange1Atr, e.roomLeft,
                            e.pMore025, e.pUp, (double)e.closeSide, e.closeLoc, e.closePx, e.t1, e.t2, e.wick,
                            e.pGapFill, (double)e.sources};
    ++n;
    for (int k = 0; k < 17; ++k) {
      if (!same(got[k], out[k])) {
        if (bad < 20) {
          std::printf("vector %d field %d: c++ %.12g python %.12g\n", n, k, got[k], out[k]);
        }
        ++bad;
        break;
      }
    }
  }
  std::fclose(f);
  std::printf("%d vectors, %d mismatches, %s\n", n, bad, hle::version());
  return bad ? 1 : 0;
}
