// checklist #18 / #40: the work per new bar is bounded - the worst case (40,000 closed 1-min bars, 21 days) in one recompute.
#include "HodLodLogic.h"
#include <chrono>
#include <cstdio>
int main()
{
    std::vector<hl::Bar> B; long long d0 = hl::daysFromCivil(2026, 9, 18) * 86400;
    double p = 7800;
    for (int i = 0; i < 40000; i++) { hl::Bar b; b.absEnd = d0 + 60LL * (i + 1); double o = p; p += ((i * 7919) % 13 - 6) * 0.25; b.o = o; b.c = p; b.h = std::max(o, p) + 0.5; b.l = std::min(o, p) - 0.5; B.push_back(b); }
    hl::Cfg c; c.mkt = 0; c.per = 60; c.tick = 0.25; c.readOpen = hl::readOpenFor(0); c.readN = hl::readNFor(0);
    double worst = 0;
    for (int k = 0; k < 20; k++) {
        auto t0 = std::chrono::steady_clock::now();
        std::vector<hl::ReadRow> rows; hl::Tracker T = hl::runBars(c, B, B.size(), &rows); hl::View v = hl::buildView(T, rows.empty() ? hl::ReadOut() : rows.back().out);
        double ms = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count(); if (ms > worst) worst = ms;
        if (!v.has) return 2;
    }
    std::printf("40,000 bars per recompute: worst %.1f ms of 20 runs (budget 200 ms slice)\n", worst);
    return worst < 200 ? 0 : 1;
}
