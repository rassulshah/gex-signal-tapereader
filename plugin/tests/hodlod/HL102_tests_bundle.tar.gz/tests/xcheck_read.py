"""Cross-check: the plugin's read inputs + hlr::read output vs the read model's own Python (states + py_read) on one session.
usage: xcheck_read.py <hodlod_read dir> <cpp rows csv: hh:mm,side,pIn,afterT,afterP,byT,byP> <bars.csv> [MKT] [date] [store months]"""
import sys, json, gzip, csv, datetime as dt
sys.path.insert(0, sys.argv[1])
import pandas as pd, numpy as np
import hodlod_read as H
D = dt.datetime
rows = []
MK = sys.argv[4] if len(sys.argv) > 4 else 'ES'; DAY = sys.argv[5] if len(sys.argv) > 5 else '2026-10-09'
for f in (['/mnt/user-data/uploads/level-reversal-analytics/data/irt/bars/ES/3m_2026-09.csv.gz'] if MK == 'ES' and len(sys.argv) <= 6 else []):
    for r in csv.DictReader(gzip.open(f, 'rt')):
        rows.append((D.fromisoformat(r['t_ct']) + dt.timedelta(minutes=3), float(r['o']), float(r['h']), float(r['l']), float(r['c'])))
for ln in open(sys.argv[3]):
    t, o, h, l, c = ln.strip().split(','); rows.append((D.fromisoformat(t), float(o), float(h), float(l), float(c)))
b = pd.DataFrame(rows, columns=['t', 'o', 'h', 'l', 'c']).drop_duplicates('t', keep='last').sort_values('t').reset_index(drop=True)
b['v'] = 0.0; b['src'] = 'irt'
T = json.load(open(sys.argv[1] + '/tables.json'))[MK]
S = H.sessions(b, MK, {})
st = H.states(S, MK, T['design']['N'])
st = st[st.date == DAY]
cpp = {}
for ln in open(sys.argv[2]):
    p = ln.strip().split(','); cpp[p[0]] = p
bad = n = 0
for r in st.itertuples():
    x = H.py_read(T, int(r.mso), int(r.side), float(r.dist), float(getattr(r, {'or': 'orN', 'atr': 'atr', 'rng': 'rng'}[T['design']['norm']])), int(r.now), float(r.rng))
    k = '%02d:%02d' % (r.now // 60, r.now % 60)
    c = cpp.get(k)
    n += 1
    r6 = lambda v: round(float(v), 6) if v == v else None
    want = (int(r.side), r6(x['pIn']), x['afterT'], r6(x['afterP']) if x['afterT'] >= 0 else None, x['byT'], r6(x['byP']) if x['byT'] >= 0 else None)
    got = (int(c[1]), r6(c[2]), int(c[3]), r6(c[4]) if int(c[3]) >= 0 else None, int(c[5]), r6(c[6]) if int(c[5]) >= 0 else None) if c else None
    if want != got:
        bad += 1
        if bad <= 5: print('MISMATCH', k, 'python', want, 'plugin', got)
print('%d bars compared, %d mismatches' % (n, bad))
sys.exit(1 if bad or n == 0 else 0)
