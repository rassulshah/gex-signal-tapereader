// HL101 leak / lifecycle stress for lsSessionInfo + proof that the HOD/LOD side (E-LOD / E-HOD slider ticks) does not depend on the
// LRA bridge files: 50 cycles, 3 charts, bridge file present / missing / oversized / garbage, symbol switches, destroy, delete.
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <unistd.h>
#include <sys/stat.h>
#include "SessionInfo.cpp"
static int passes = 0, failures = 0;
#define CHECK(c, msg) do { if (c) ++passes; else { ++failures; std::printf("  FAIL  %s (line %d)\n", std::string(msg).c_str(), __LINE__); } } while (0)
static std::string sessionPath(const std::string& profile, const std::string& market)
{ return profile + "\\InvestorRT\\rtx\\lsFlexLevels\\LRA-Session-" + market + ".csv"; }
static void loadBars(mock::Chart& C, const std::string& path, const std::string& root, float tick)
{
    C.root = root; C.tick = tick;
    std::ifstream f(path.c_str()); std::string ln;
    while (std::getline(f, ln)) {
        int Y, M, D, h, m, s; double o, H, L, c;
        if (std::sscanf(ln.c_str(), "%d-%d-%d %d:%d:%d,%lf,%lf,%lf,%lf", &Y, &M, &D, &h, &m, &s, &o, &H, &L, &c) != 10) continue;
        C.t.push_back((RTDATE)(hl::daysFromCivil(Y, M, D) * 86400 + h * 3600 + m * 60 + s)); C.o.push_back((float)o); C.h.push_back((float)H); C.l.push_back((float)L); C.c.push_back((float)c);
    }
}
int main(int argc, char** argv)
{
    std::string data = argc > 1 ? argv[1] : "../data";
    char tmpl[] = "/tmp/silk-XXXXXX"; char* dir = mkdtemp(tmpl); std::string profile(dir); setenv("USERPROFILE", profile.c_str(), 1);
    const std::string good = "EXP|15:00\nWIN|ACTIVE|08:30|10:30\nCAL|09:00|High|ISM\nEM|7838.25|7790|7890|7850\n";
    mock::Chart A, B, H; loadBars(A, data + "/es_long.csv", "ESZ26", 0.25f); loadBars(B, data + "/es_chart.csv", "ESZ26", 0.25f); loadBars(H, data + "/hg_chart.csv", "CPEZ26", 0.0005f);
    mock::Chart* charts[3] = { &A, &B, &H };
    // 1) the E-LOD / E-HOD ticks: identical with the bridge file good / missing / oversized / garbage (they come from the bars only)
    double e[4][2]; bool have[4];
    for (int mode = 0; mode < 4; mode++) {
        std::remove(sessionPath(profile, "ES").c_str());
        if (mode == 0) { std::ofstream o(sessionPath(profile, "ES").c_str()); o << good; }
        if (mode == 2) { std::ofstream o(sessionPath(profile, "ES").c_str()); o << std::string(70 * 1024, 'x'); }
        if (mode == 3) { std::ofstream o(sessionPath(profile, "ES").c_str()); o << "EM|nan|-1|zz\nWIN|ACTIVE|25:99|x\n\x01\x02garbage\n"; }
        SessionInfo* x = new SessionInfo(); x->setup(); mock::cur() = &A; x->draw();
        SIState* S = x->st(false); have[mode] = S && S->haveE; e[mode][0] = S ? S->eLod : NAN; e[mode][1] = S ? S->eHod : NAN;
        x->destroy(); delete x; A.drawn.clear();
    }
    CHECK(have[0] && have[1] && have[2] && have[3], "E-LOD / E-HOD computed with the bridge file good, missing, oversized and garbage");
    CHECK(e[0][0] == e[1][0] && e[0][0] == e[2][0] && e[0][0] == e[3][0] && e[0][1] == e[1][1] && e[0][1] == e[2][1] && e[0][1] == e[3][1],
          "the slider ticks are identical in all four cases (no dependence on the LRA bridge files)");
    std::printf("    E-LOD %.2f  E-HOD %.2f (chart bars + compiled-in headers only)\n", e[0][0], e[0][1]);
    // 2) 50 create / destroy cycles with symbol switches and a file that changes under it
    { std::ofstream o(sessionPath(profile, "ES").c_str()); o << good; }
    int cycles = argc > 2 ? atoi(argv[2]) : 50, freed = 0, made = 0;
    for (int k = 0; k < cycles; k++) {
        SessionInfo* x = new SessionInfo(); x->setup();
        for (int c = 0; c < 3; c++) { mock::cur() = charts[c]; x->draw(); if (charts[c]->userData) made++; }
        A.root = "NQZ26"; mock::cur() = &A; x->draw(); A.root = "ESZ26"; x->draw();
        H.root = "ZBZ26"; mock::cur() = &H; x->draw(); H.root = "CPEZ26"; x->draw();
        if (k % 10 == 5) { std::ofstream o(sessionPath(profile, "ES").c_str()); o << good << "CAL|10:00|High|cycle " << k << "\n"; }
        x->parmsApply();
        for (int c = 0; c < 3; c++) { mock::cur() = charts[c]; x->destroy(); if (!charts[c]->userData) freed++; charts[c]->drawn.clear(); }
        delete x;
    }
    CHECK(made == 3 * cycles && freed == 3 * cycles, "every chart's state created on draw and freed by destroy (" + std::to_string(made) + " / " + std::to_string(freed) + ")");
    std::printf("%d create/destroy cycles x 3 charts with symbol switches\n%d passed, %d failed\n", cycles, passes, failures);
    return failures ? 1 : 0;
}
