// Simulates MSVC windows.h macros (min / max / far / near) being defined before our code (checklist #3).
#include <string>
#include <vector>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <cctype>
#include <climits>
#include <ctime>
#include <algorithm>
#include <functional>
#include <fstream>
#include <exception>
#include <new>
#include <chrono>
#include <deque>
#include <map>
#include <limits>
#include <sstream>
#include <iostream>
#include <cstdint>
#include "irtsdk.h"
#define min(a,b) (((a)<(b))?(a):(b))
#define max(a,b) (((a)>(b))?(a):(b))
#define far
#define near
#include WRAP_TARGET
