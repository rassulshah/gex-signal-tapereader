// prints the hle::State the plugin builds at every closed RTH bar of the last session (for xcheck_hle.py)
#include "HodLodLogic.h"
#include <fstream>
using namespace hl;
int main(int argc, char** argv)
{
    std::vector<Bar> B; std::ifstream f(argv[1]); std::string ln;
    while (std::getline(f, ln)) { int Y, M, D, h, m, s; double o, H, L, c; if (std::sscanf(ln.c_str(), "%d-%d-%d %d:%d:%d,%lf,%lf,%lf,%lf", &Y, &M, &D, &h, &m, &s, &o, &H, &L, &c) == 10) { Bar b; b.absEnd = daysFromCivil(Y, M, D) * 86400 + h * 3600 + m * 60 + s; b.o = o; b.h = H; b.l = L; b.c = c; B.push_back(b); } }
    Cfg c; c.mkt = mktIndex(argv[2]); c.tick = std::atof(argv[3]); c.per = 180; c.readOpen = readOpenFor(c.mkt); c.readN = readNFor(c.mkt);
    for (size_t k = 1; k + 1 <= B.size(); k++) {
        Tracker T = runBars(c, B, k, nullptr);
        if (!T.cur.any || T.cur.lastSeq != T.seq || dateTxt(T.cur.sid) != argv[4]) continue;
        std::string why; hle::State s = hleState(T, T.cur, why); hle::Expect e = hle::expect(s);
        std::printf("%d,%d,%.10g,%.10g,%.10g,%.10g,%.10g", s.mso, s.dow, s.atr14, s.open, s.hi, s.lo, s.last);
        for (int i = 0; i < hle::kMaxMarks; i++) std::printf(",%.10g", s.rngAt[i]);
        ReadIn ri = T.readIn(readNormKind(c.mkt), 0); ReadOut ro = evalRead(ri);
        std::printf(",%.10g,%.10g,%.10g,%d,%d|%.10g,%.10g,%.10g|%s,%d,%s,%d,%s,%d,%s\n", s.onRange, s.prevRange, s.prevClose, s.news, s.firstSide, e.range, e.pUp, e.t1,
                    hhmm(ri.now).c_str(), ro.side, ro.state == 1 ? fmtP(ro.pIn).c_str() : "nan", ro.afterT, fmtP(ro.afterP).c_str(), ro.byT, fmtP(ro.byP).c_str());
    }
}
