// test_hodlod_logic.cpp - unit / replay / layout / file tests for HodLodLogic.h (no SDK).
//   g++ -std=c++14 -Wall -Wextra -I../src test_hodlod_logic.cpp -o t && ./t <data dir> <out dir>
// data dir: es_chart.csv (today's ES from ChartView/ES_180.json, bar END), es_combined.csv (+ the LRA store back to 10-05 17:00)
#include "HodLodLogic.h"
#include <cstdio>
#include <map>
#include <sstream>
#include <fstream>
#include <set>

using namespace hl;
static int passes = 0, failures = 0;
#define CHECK(c, msg) do { if (c) ++passes; else { ++failures; std::printf("  FAIL  %s (line %d)\n", std::string(msg).c_str(), __LINE__); } } while (0)
#define EQ(a, b, msg) do { std::string _a = (a), _b = (b); if (_a == _b) ++passes; else { ++failures; std::printf("  FAIL  %s: got [%s] want [%s] (line %d)\n", std::string(msg).c_str(), _a.c_str(), _b.c_str(), __LINE__); } } while (0)

#include "test_font_metrics.h"
// the 1st-Time cell: hlr::stage1 when the read tables are built in, else the static median (+-30m)
#if HL_HAVE_READ
#define E1_ES "8:57 \xB1" "24m  63%  either"
#define E1_ES_HOD "8:57 \xB1" "24m  63%  either"
#define TOOK_ES "~27m"
#define GAP_ES "~4h03"
#else
#define E1_ES "8:51 \xB1" "30m  either"
#define E1_ES_HOD "8:57 \xB1" "30m  either"
#define TOOK_ES "~21m"
#define GAP_ES "~3h54"
#endif
// IRT FONT sizes are points: at 96 dpi a 9 pt font is 12 px. Liberation Sans has Helvetica / Arial advance widths.
static double SCALE = 1.0;
static int measure(const std::string& s, int fs, bool bold)
{
    double w = 0; for (size_t i = 0; i < s.size(); i++) w += (bold ? ADV_BOLD : ADV_REG)[(unsigned char)s[i]];
    w = w * fs * 96.0 / 72.0 / 1000.0 * SCALE; return (int)(w + 0.999);
}

static std::vector<Bar> loadCsv(const std::string& p)
{
    std::vector<Bar> v; std::ifstream f(p.c_str()); std::string ln;
    while (std::getline(f, ln)) {
        int Y, M, D, h, m, s; double o, H, L, c, vol = NAN;
        int n = std::sscanf(ln.c_str(), "%d-%d-%d %d:%d:%d,%lf,%lf,%lf,%lf,%lf", &Y, &M, &D, &h, &m, &s, &o, &H, &L, &c, &vol);
        if (n < 10) continue;
        Bar b; b.absEnd = daysFromCivil(Y, M, D) * 86400 + h * 3600 + m * 60 + s; b.o = o; b.h = H; b.l = L; b.c = c; b.v = n >= 11 ? vol : NAN; v.push_back(b);
    }
    return v;
}
static std::string lineTxt(const Line& L) { std::string s; for (size_t i = 0; i < L.size(); i++) s += L[i].s; return s; }
static std::string groupTxt(const std::vector<Line>& G) { std::string s; for (size_t i = 0; i < G.size(); i++) { if (i) s += "|"; s += lineTxt(G[i]); } return s; }
static std::string rowTxt(const Cell* c) { std::string s; for (int i = 0; i < NCOL; i++) { if (i) s += "|"; s += cellTxt(c[i]); } return s; }
static Cfg cfgFor(const char* m, double tick = 0.25, long long per = 180)
{ Cfg c; c.mkt = mktIndex(m); c.tick = tick; c.per = per; c.readOpen = readOpenFor(c.mkt); c.readN = readNFor(c.mkt); return c; }
static long long at(int Y, int M, int D, int h, int m) { return daysFromCivil(Y, M, D) * 86400 + h * 3600 + m * 60; }

// the state line the Python reference prints, from the C++ tracker (latest session)
static std::string stateLine(const Tracker& T)
{
    const Rth& R = T.cur; if (!R.any) return "";
    View v = buildView(T, ReadOut());
    double t = T.C.tick;
    char b[400];
    std::string first = v.side == 1 ? "L" : v.side == 2 ? "H" : "?";
    std::string rec = v.side == 0 ? "" : (v.reclaimed ? hhmm(v.reclMod) : "none");
    std::string second = v.side == 0 ? "" : (v.secondPrinted ? hhmm(v.side == 1 ? v.hodMod : v.lodMod) : "pending");
    std::string took = v.side == 0 ? "" : std::to_string(v.took), wick = (v.side == 0 || !v.reclaimed) ? "" : std::to_string(v.took + v.recTook);   // the reference prints open -> reclaim
    std::string gap = (v.side == 0 || !v.secondPrinted) ? "" : std::to_string(v.gap);
    snprintf(b, sizeof b, "%s|%g|%g@%s|%g@%s|%s|%s|%s|%s|%s|%s|%g", hhmm(v.lastMod).c_str(), (double)v.open * t, (double)v.hod * t, hhmm(v.hodMod).c_str(),
             (double)v.lod * t, hhmm(v.lodMod).c_str(), first.c_str(), rec.c_str(), second.c_str(), took.c_str(), wick.c_str(), gap.c_str(), (double)v.rangeT * t);
    return b;
}

static std::vector<Bar> mirror(const std::vector<Bar>& B, double pivot)
{
    std::vector<Bar> o; for (size_t i = 0; i < B.size(); i++) { Bar b = B[i]; b.o = 2 * pivot - B[i].o; b.c = 2 * pivot - B[i].c; b.h = 2 * pivot - B[i].l; b.l = 2 * pivot - B[i].h; o.push_back(b); }
    return o;
}

static void dumpLayout(const Layout& L, const Box& pane, const std::string& path, const std::string& title)
{
    std::ofstream f(path.c_str());
    f << "{\"title\":\"" << title << "\",\"pane\":[" << pane.l << "," << pane.t << "," << pane.r << "," << pane.b << "],\"items\":[\n";
    for (size_t i = 0; i < L.items.size(); i++) {
        const Item& it = L.items[i];
        std::string s; for (size_t k = 0; k < it.s.size(); k++) { unsigned char ch = (unsigned char)it.s[k]; if (ch == 0xB7) s += "\\u00b7"; else if (ch == 0xB1) s += "\\u00b1"; else if (ch >= 0x80) s += "?"; else if (ch == '"' || ch == '\\') { s += '\\'; s += (char)ch; } else s += (char)ch; }
        f << (i ? ",\n" : "") << "{\"k\":" << it.k << ",\"l\":" << it.l << ",\"t\":" << it.t << ",\"r\":" << it.r << ",\"b\":" << it.b
          << ",\"c1\":" << it.c1 << ",\"c2\":" << it.c2 << ",\"s\":\"" << s << "\",\"fs\":" << it.fs << ",\"bold\":" << (it.bold ? 1 : 0) << ",\"w\":" << it.w << "}";
    }
    f << "]}\n";
}

// every text block inside the pane, none overlapping another or the table; the candle inside its area
static bool layoutClean(const Layout& L, const Box& pane, std::string& why)
{
    for (size_t i = 0; i < L.items.size(); i++) {
        const Item& it = L.items[i];
        int l = std::min(it.l, it.r), r = std::max(it.l, it.r), t = std::min(it.t, it.b), b = std::max(it.t, it.b);
        if (l < pane.l || r > pane.r || t < pane.t || b > pane.b) { why = "item outside the pane: " + it.s; return false; }
        if (it.role == R_CANDLE && L.candleOk && (t < L.area.t || b > L.area.b)) { why = "candle outside its area"; return false; }
    }
    for (size_t i = 0; i < L.blocks.size(); i++) for (size_t j = i + 1; j < L.blocks.size(); j++)
        if (overlap(L.blocks[i], L.blocks[j])) { char b[160]; snprintf(b, sizeof b, "blocks %zu and %zu overlap (%d,%d,%d,%d)/(%d,%d,%d,%d)", i, j, L.blocks[i].l, L.blocks[i].t, L.blocks[i].r, L.blocks[i].b, L.blocks[j].l, L.blocks[j].t, L.blocks[j].r, L.blocks[j].b); why = b; return false; }
    // text items of one block must not overlap text of another block
    for (size_t i = 0; i < L.items.size(); i++) for (size_t j = i + 1; j < L.items.size(); j++) {
        const Item& a = L.items[i]; const Item& b = L.items[j];
        if (a.k != K_TEXT || b.k != K_TEXT) continue;
        if (a.role == R_TABLE && b.role == R_TABLE) continue;
        if (a.block == b.block && a.role == b.role) continue;
        Box x = { a.l, a.t, a.r, a.b }, y = { b.l, b.t, b.r, b.b };
        if (overlap(x, y)) { why = "text overlap: [" + a.s + "] / [" + b.s + "]"; return false; }
    }
    return true;
}

int main(int argc, char** argv)
{
    std::string dir = argc > 1 ? argv[1] : ".", out = argc > 2 ? argv[2] : ".";
    std::vector<Bar> chart = loadCsv(dir + "/es_chart.csv"), comb = loadCsv(dir + "/es_combined.csv");
    CHECK(chart.size() == 300, "today's ES chart export has 300 bars");
    CHECK(comb.size() > 1500, "combined ES history loaded");

    // ---------------------------------------------------------------- 1 today's ES, every definition
    std::printf("[1] ES 2026-10-09 definitions\n");
    {
        std::vector<ReadRow> rows;
        Tracker T = runBars(cfgFor("ES"), chart, chart.size() - 1, &rows);   // the last bar (16:00) is forming
        View v = buildView(T, rows.back().out, &rows);
        EQ(v.session, "2026-10-09", "session");
        EQ(pxTxt(v.open * 0.25, 2), "7,838.25", "open");
        EQ(pxTxt(v.lod * 0.25, 2), "7,826.75", "LOD price");
        EQ(hhmm(v.lodMod), "08:51", "LOD at the bar ENDING 8:51");
        CHECK(v.side == 1, "LOD printed first");
        CHECK(v.took == 21, "took 21m");
        EQ(trimNum(v.sizeT * 0.25, 2), "11.5", "size 11.5p"); EQ(usd(v.sizeUsd), "$575", "size $575");
        CHECK(v.reclaimed && v.reclMod == 9 * 60 + 9, "reclaim at the bar ending 9:09");
        CHECK(v.recTook == 18, "Rec. Took 18m (8:51 -> 9:09, v12)"); CHECK(v.took + v.recTook == 39, "open -> reclaim 39m");
        EQ(pxTxt(v.hod * 0.25, 2), "7,870.50", "HOD price");
        EQ(hhmm(v.hodMod), "13:54", "HOD at the bar ending 13:54"); EQ(clkPm(v.hodMod), "1:54pm", "HOD shown 1:54pm");
        CHECK(v.secondPrinted && v.gap == 303, "gap 5h03m (303 min)"); EQ(durC(v.gap), "5h03m", "gap text");
        EQ(trimNum(v.rangeT * 0.25, 2), "43.75", "range 43.75p"); EQ(usd(v.rangeUsd), "$2,188", "range $2,188 (2187.5 rounds up)");
        CHECK(v.complete, "RTH complete (15:00 bar closed)");
        CHECK(v.usedPct == 67, "range used 67% of the up model's 65.05p");
        CHECK(v.bodyCol == C_GREEN, "close 7,861.25 >= open: green");
        // chart-only history: Lon is complete (chart starts 01:00), ON / PD / PF are not -> LonLO / LonHI only
        EQ(groupTxt(v.top), "HOD \xB7 LonHI|1:54pm|5h03m", "candle top labels (chart history only)");
        EQ(groupTxt(v.bottom), "LOD \xB7 LonLO|8:51|21m|11.5p", "candle bottom labels (chart history only)");
        EQ(groupTxt(v.bodyMid), "5h03m|43.75p|$2,188", "candle body labels");
        EQ(groupTxt(v.bodyRecl), "9:09|18m", "candle body-bottom labels: reclaim + Rec. Took (v12)");
        // (v12) the chart alone holds no 14 prior sessions -> no ATR14 -> hle falls back (flagged), the v1 range is used
        CHECK(!v.haveHle && v.hleWhy.find("ATR14 needs 14") != std::string::npos, "no ATR14 on a 300-bar chart: hle fallback, flagged");
        // (v15) the table: 1st Time | Reclaim | 2nd Time (every other value stays in the status file)
#if HL_HAVE_READ
        EQ(rowTxt(v.E), "E|8:57 \xB1" "24m  63%  either|8:51 - 9:21  76%|after 11:00 80%  HOD|~4h03|~27m|~12.25p|~6m|-|~65p||either|HOD",
           "E row at the close (HL101): stage1 window + its delivered 63%; reclaim static (the LOD was not IN before 9:09); 2nd = the last QUALIFIED stage-3 call before 1:54 (10:57, LOD IN), shown at kShow3 80%");
        EQ(rowTxt(v.A), "A|8:51 LOD  in|9:09  in|1:54 HOD  in|5h03|21m|11.5p|18m||43.75p  67%||LOD|HOD", "A row (v15): 8:51 in, 9:09 in (within 30m), 1:54 in (after 1:30)");
        EQ(v.header, "RTH complete   \xB7   at the close: LOD IN 98%   \xB7   expect HOD after 11:00 80%", "header after the close: the IN read (live, pInShow) + the SAME 2nd call as the cell");
        CHECK(v.secondFinal && v.firstFinal && v.A[K_2ND].col2 == C_GREEN, "at the close both extremes are final: HOD green");
#else
        EQ(rowTxt(v.E), "E|8:51 \xB1" "30m  either|8:51 - 9:21  76%|~12:58  either|~3h54|~21m|~12.25p|~6m|-|~65p||either|either", "E row (v15, no read model)");
        EQ(rowTxt(v.A), "A|8:51 LOD  in|9:09  in|1:54 HOD|5h03|21m|11.5p|18m||43.75p  67%||LOD|HOD", "A row (v15, no read model: no 2nd call to tag)");
        EQ(v.header, "RTH complete   \xB7   at the close: read: building", "header after the close (read not built in)");
#endif
        CHECK(v.A[K_1ST].col == C_SLATE && v.A[K_1ST].col2 == C_RED && v.A[K_1ST].col3 == C_SLATE && v.A[K_2ND].col2 == C_GREEN && v.E[K_1ST].col == C_GREY && v.A[K_RANGE].col == C_SLATE,
              "colours: time slate, LOD red, HOD green, in slate, E grey");
        #if HL_HAVE_READ
        CHECK(v.win1a == 513 && v.win1b == 561 && v.recFrom == 531 && v.recTo == 561, "E windows: 1st 8:33-9:21 (hlr::stage1), reclaim 8:51-9:21 (static)");
        EQ(v.src1st + "|" + v.srcRecl + "|" + v.src2nd, "hlr::stage1|static|hlr::stage3 (in test)", "each E cell's source (ES stage 3 in test: grey)");
#endif
        {   // the 3 drawn columns, the status file keeps all 12 values
            Box pane = { 0, 0, 1170, 740 };
            Layout L = layoutAll(v, pane, [&](long long tk) { double p = tk * 0.25; return (int)std::lround((7892 - p) / 100.0 * 740); }, measure);
            std::string st = statusText(v, L, T, rows.back().out, 180, "ok"); int heads = 0;
            for (size_t i = 0; i < L.items.size(); i++) if (L.items[i].k == K_TEXT && (L.items[i].s == "1st Time" || L.items[i].s == "Reclaim" || L.items[i].s == "2nd Time" || L.items[i].s == "Gap")) heads++;
            CHECK(heads == 3, "the table draws 1st Time | Reclaim | 2nd Time only");
            CHECK(st.find(std::string("E_Gap,") + GAP_ES) != std::string::npos && st.find("A_Took,21m") != std::string::npos && st.find("E_Range,~65p") != std::string::npos
                  && st.find("E_SOURCES,1st=") != std::string::npos && st.find("E_RECLAIM_WINDOW,30 min") != std::string::npos, "status keeps every value + its source");
        }
        // the forming bar: with every bar treated as closed nothing in RTH changes (16:00 is post-RTH), and the first RTH bar ends 8:33
        Tracker T2 = runBars(cfgFor("ES"), chart, chart.size(), nullptr);
        CHECK(T2.cur.openStartAbs == at(2026, 10, 9, 8, 30) && T2.cur.n == 130, "RTH = 130 bars, the bar ending 8:30 is NOT RTH");
    }
    // ---------------------------------------------------------------- 2 swept levels with the full history
    std::printf("[2] swept levels (store + chart: PF / PD / ON / Lon all complete)\n");
    {
        Tracker T = runBars(cfgFor("ES"), comb, comb.size() - 1, nullptr);
        View v = buildView(T, ReadOut());
        CHECK(T.pf.ok && T.pd.ok, "PF and PD complete");
        EQ(pxTxt(T.pf.hi * .25, 2) + " " + pxTxt(T.pf.lo * .25, 2), "7,858.25 7,783.00", "PF 10-08 (10-07 17:00 -> 10-08 16:00)");
        EQ(pxTxt(T.pd.hi * .25, 2) + " " + pxTxt(T.pd.lo * .25, 2), "7,849.75 7,783.00", "PD 10-08 RTH");
        EQ(pxTxt(T.curOn.hi * .25, 2) + " " + pxTxt(T.curOn.lo * .25, 2), "7,853.75 7,817.00", "ON 10-08 17:00 -> 10-09 08:30");
        EQ(pxTxt(T.curLon.hi * .25, 2) + " " + pxTxt(T.curLon.lo * .25, 2), "7,853.75 7,838.25", "London 02:00-07:30");
        CHECK(v.lodLvl == LV_LON, "LOD 7,826.75 swept only LonLO 7,838.25 (ONL 7,817 / PDL / PFL untouched)");
        CHECK(v.hodLvl == LV_PF, "HOD 7,870.50 swept PFH 7,858.25 (also PDH / ONH / LonHI) -> the most significant, PF");
        EQ(groupTxt(v.bottom), "LOD \xB7 LonLO|8:51|21m|11.5p", "LOD 8:51 \xB7 LonLO");
        EQ(groupTxt(v.top), "HOD \xB7 PFH|1:54pm|5h03m", "HOD \xB7 PFH");
        CHECK(v.top[0][1].col == 0x00008A8A && v.bottom[0][1].col == 0x00F59E0B, "level colours: PF teal, Lon amber");
        // same definitions with longer history
        CHECK(v.took == 21 && v.recTook == 18 && v.gap == 303 && v.rangeT == 175, "definitions unchanged with the longer history");
        {   // hle 2.0 needs 14 prior sessions on the chart: the LRA store from 09-01 + today's export (28 sessions)
            std::vector<Bar> lng = loadCsv(dir + "/es_long.csv");
            std::vector<ReadRow> rl; Tracker TL = runBars(cfgFor("ES"), lng, lng.size() - 1, &rl); View vl = buildView(TL, rl.back().out, &rl);
            CHECK(TL.prevRanges.size() >= 14 && vl.haveHle && vl.ex.valid && (vl.ex.sources & hle::SRC_RANGE), "28 prior sessions: hle 2.0 valid (ATR14 from the chart)");
            CHECK(cellTxt(vl.E[K_ROOM]).size() > 1 && cellTxt(vl.E[K_RANGE]).find("(") != std::string::npos, "hle: room left + the 25-75% range band in the status cells");
            EQ(cellTxt(vl.E[K_1ST]) + "|" + cellTxt(vl.E[K_RECL]), E1_ES "|8:51 - 9:21  76%", "the drawn cells are the same with or without hle (stage1 / reclaim window)");
        }
        EQ(groupTxt(v.bodyRecl), "9:09|18m", "candle body: reclaim time + Rec. Took (v12)");
    }
    {   // the open on the far side is required: a level already through at the open is not "swept"
        Cfg c = cfgFor("ES"); std::vector<Bar> B;
        long long d = daysFromCivil(2026, 10, 6);
        for (int m = 17 * 60 + 3; m <= 24 * 60 + 8 * 60 + 30; m += 3) { Bar b; b.absEnd = (d - 1) * 86400 + m * 60LL; b.o = b.c = 100; b.h = 101; b.l = 99; B.push_back(b); }  // ON 99-101
        Bar o; o.absEnd = d * 86400 + (8 * 60 + 33) * 60; o.o = 98; o.h = 98.5; o.l = 97; o.c = 98; B.push_back(o);   // opens below ONL 99
        Bar x; x.absEnd = o.absEnd + 180; x.o = 98; x.h = 98; x.l = 95; x.c = 96; B.push_back(x);
        Bar z; z.absEnd = x.absEnd + 180; z.o = 96; z.h = 97; z.l = 96; z.c = 97; B.push_back(z);
        Tracker T = runBars(c, B, B.size(), nullptr);
        CHECK(T.cur.lod.lvl == -1, "ONL already below at the open: not named");
        // and the London window is used only after 07:30: a GC LOD at 07:24 cannot name Lon
        Cfg g = cfgFor("GC", 0.1); std::vector<Bar> G;
        for (int m = 60; m <= 7 * 60 + 21; m += 3) { Bar b; b.absEnd = d * 86400 + m * 60LL; b.o = b.c = 4000; b.h = 4001; b.l = 3999; G.push_back(b); }
        Bar g1; g1.absEnd = d * 86400 + (7 * 60 + 24) * 60; g1.o = 4000; g1.h = 4000.5; g1.l = 3990; g1.c = 3995; G.push_back(g1);
        Bar g2; g2.absEnd = g1.absEnd + 180; g2.o = 3995; g2.h = 4002; g2.l = 3994; g2.c = 4001; G.push_back(g2);
        Tracker TG = runBars(g, G, G.size(), nullptr);
        CHECK(TG.cur.lod.lvl == -1, "GC LOD at 07:24 (London still open): no Lon name");
        CHECK(TG.cur.openStartAbs == d * 86400 + (7 * 60 + 21) * 60, "GC RTH opens with the bar starting 07:21 (3-min grid, open 07:20)");
    }
    // ---------------------------------------------------------------- 3 the HOD-first mirror
    std::printf("[3] HOD-first mirror\n");
    {
        std::vector<Bar> M = mirror(chart, 7838.25);
        Tracker T = runBars(cfgFor("ES"), M, M.size() - 1, nullptr);
        View v = buildView(T, ReadOut());
        CHECK(v.side == 2, "HOD printed first");
        EQ(pxTxt(v.hod * .25, 2), "7,849.75", "HOD = open + 11.5");
        CHECK(v.took == 21 && v.recTook == 18 && v.gap == 303 && v.reclMod == 549, "took / rec. took / gap / reclaim mirror");
        CHECK(v.bodyCol == C_RED, "close below the open: red");
        EQ(groupTxt(v.top), "HOD \xB7 LonHI|8:51|21m|11.5p", "top = the first extreme (HOD) with took / size");
        EQ(groupTxt(v.bottom), "LOD \xB7 LonLO|1:54pm|5h03m", "bottom = the second (LOD) with the gap");
        EQ(cellTxt(v.A[K_1ST]) + "|" + cellTxt(v.A[K_RECL]) + "|" + cellTxt(v.A[K_2ND]).substr(0, 8), "8:51 HOD  in|9:09  in|1:54 LOD", "A row mirrored");
        CHECK(v.A[K_1ST].col2 == C_GREEN && v.A[K_2ND].col2 == C_RED, "HOD green, LOD red");
        EQ(cellTxt(v.E[K_1ST]) + "|" + cellTxt(v.E[K_TOOK]) + "|" + cellTxt(v.E[K_RECTOOK]) + "|" + cellTxt(v.E[K_RECL]), E1_ES_HOD "|~27m|~12m|8:51 - 9:21  76%", "E: stage1 window; HOD-first rec. took median 12m; reclaim window anchored on the actual 8:51");
        EQ(v.A[K_RANGE].s, "43.75p  61%", "range used of the v1 down range 71.83p (no ATR14)");
    }
    // ---------------------------------------------------------------- 4 pending second / the reference over every prefix
    std::printf("[4] every prefix vs the independent Python reference + pending\n");
    {
        std::ofstream f((out + "/cpp_prefix_states.txt").c_str());
        for (size_t k = 1; k <= chart.size(); k++) {
            Tracker T = runBars(cfgFor("ES"), chart, k, nullptr);
            if (T.cur.any && T.cur.lastSeq == T.seq) f << stateLine(T) << "\n";
        }
        f.close();
        Tracker T = runBars(cfgFor("ES"), chart, 0, nullptr);
        size_t k845 = 0; for (size_t i = 0; i < chart.size(); i++) if (chart[i].absEnd == at(2026, 10, 9, 8, 45)) k845 = i + 1;
        Tracker P = runBars(cfgFor("ES"), chart, k845, nullptr);
        View v = buildView(P, ReadOut());
        CHECK(v.side == 2 && !v.secondPrinted, "at 8:45 the HOD (8:36) came first and the LOD is pending (reclaim not before it)");
        EQ(groupTxt(v.bottom), "LOD|pending", "pending label");
        EQ(cellTxt(v.A[K_2ND]) + "|" + cellTxt(v.A[K_DIR2]), "pending|", "table 2nd = pending, 2nd Dir blank until both exist"); EQ(v.A[K_ROOM].s, "", "Room blank in the A row"); EQ(cellTxt(v.A[K_GAP]), "9m...", "A Gap while pending: running time since the 1st extreme (8:36 -> 8:45)"); CHECK(v.A[K_GAP].col == C_GREY, "running gap grey");
        CHECK(v.A[K_RANGE].col == C_GREY, "range grey until the 2nd extreme prints");
        EQ(groupTxt(v.bodyMid).substr(0, 12), "typical gap ", "body gap line = the typical gap (no skill: candle only, coordinator 20:30)");
    }
    // ---------------------------------------------------------------- 5 no reclaim / gap through the open / one-bar session
    std::printf("[5] no-reclaim day, gap through the open, first bar\n");
    {
        Cfg c = cfgFor("ES"); long long d = daysFromCivil(2026, 10, 7);
        auto bar = [&](int hm, double o, double h, double l, double cl) { Bar b; b.absEnd = d * 86400 + hm * 60LL; b.o = o; b.h = h; b.l = l; b.c = cl; return b; };
        std::vector<Bar> B;
        B.push_back(bar(8 * 60 + 33, 100, 100.5, 99, 99.5));
        B.push_back(bar(8 * 60 + 36, 99.5, 99.5, 95, 96));        // LOD 95
        B.push_back(bar(8 * 60 + 39, 96, 100.75, 96, 99.75));     // wick above the open, close below: NOT a reclaim; HOD 100.75
        B.push_back(bar(8 * 60 + 42, 99.75, 99.75, 97, 98));
        Tracker T = runBars(c, B, B.size(), nullptr); View v = buildView(T, ReadOut());
        CHECK(v.side == 1 && !v.reclaimed && !v.secondPrinted, "LOD first, a wick through the open is no reclaim, HOD pending");
        EQ(v.A[K_RECL].s, "pending", "no reclaim yet: pending"); EQ(v.A[K_RECTOOK].s, "", "rec. took blank");
        EQ(groupTxt(v.bodyRecl), "no reclaim", "candle says no reclaim");
        // to the close without a reclaim: the second extreme is final at the close
        for (int m = 8 * 60 + 45; m <= 15 * 60; m += 3) B.push_back(bar(m, 98, 98.25, 97.75, 98));
        Tracker T2 = runBars(c, B, B.size(), nullptr); View v2 = buildView(T2, ReadOut());
        CHECK(v2.complete && v2.secondPrinted && !v2.reclaimed && v2.gap == 3, "no-reclaim day: HOD 8:39 final at the close, gap 3m");
        EQ(v2.A[K_RECL].s, "none", "no-reclaim day at the close: none");
        // gap through the open: a bar that OPENS above the open and closes above is the reclaim
        std::vector<Bar> G;
        G.push_back(bar(8 * 60 + 33, 100, 100.25, 98, 98.5));
        G.push_back(bar(8 * 60 + 36, 98.5, 98.75, 97, 97.25));    // LOD 97
        G.push_back(bar(8 * 60 + 39, 101, 102, 100.5, 101.5));    // gaps through the open: reclaim (and HOD 102)
        Tracker T3 = runBars(c, G, G.size(), nullptr); View v3 = buildView(T3, ReadOut());
        CHECK(v3.reclaimed && v3.reclMod == 8 * 60 + 39 && v3.recTook == 3, "gap bar is the reclaim, 3m after the LOD");
        CHECK(!v3.secondPrinted, "HOD on the reclaim bar itself is not after the reclaim: pending (research: reclaim strictly precedes)");
        G.push_back(bar(8 * 60 + 42, 101.5, 103, 101, 102.5));
        Tracker T4 = runBars(c, G, G.size(), nullptr); View v4 = buildView(T4, ReadOut());
        CHECK(v4.secondPrinted && v4.gap == 6, "next higher high prints the HOD");
        // a close exactly AT the open counts
        std::vector<Bar> A2; A2.push_back(bar(8 * 60 + 33, 100, 100, 99, 99)); A2.push_back(bar(8 * 60 + 36, 99, 99.5, 98, 98.5)); A2.push_back(bar(8 * 60 + 39, 98.5, 100.25, 98.25, 100));
        Tracker T5 = runBars(c, A2, A2.size(), nullptr); CHECK(T5.cur.lodRecl.seq >= 0, "close exactly at the open = reclaim");
        // one bar: not clear, the E row shows the more common model with its share
        std::vector<Bar> O; O.push_back(bar(8 * 60 + 33, 100, 101, 99, 100.5));
        Tracker T6 = runBars(c, O, 1, nullptr); View v6 = buildView(T6, ReadOut());
        CHECK(v6.side == 0 && v6.modelByShare && v6.modelUp && v6.sharePct == 55, "first bar: not clear, ES up model is more common (100 of 183 = 55%)");
        EQ(cellTxt(v6.E[K_DIR1]) + "|" + cellTxt(v6.E[K_DIR2]) + "|" + v6.E[K_1ST].s3 + "|" + v6.E[K_2ND].s3, "either|either|either|either", "(1) before the first is IN: both side words 'either'");
        EQ(cellTxt(v6.E[K_1ST]) + "|" + cellTxt(v6.E[K_TOOK]) + "|" + cellTxt(v6.E[K_RECL]), E1_ES "|" TOOK_ES "|<=30m after 1st  76%", "unclear side: stage1 window; reclaim before the 1st prints");
        EQ(rowTxt(v6.A).substr(0, 4), "A|||", "A row empty until clear");
    }
    // ---------------------------------------------------------------- 6 time: DST, midnight, session ids, forming bar, bad input
    std::printf("[6] time, DST, malformed input\n");
    {
        CHECK(Tracker::sidOf(at(2026, 10, 8, 17, 0)) == daysFromCivil(2026, 10, 9), "17:00 starts the next session");
        CHECK(Tracker::sidOf(at(2026, 10, 8, 16, 57)) == daysFromCivil(2026, 10, 8), "16:57 is still today's session");
        CHECK(Tracker::sidOf(at(2026, 10, 11, 17, 0)) == daysFromCivil(2026, 10, 12), "Sunday 17:00 -> Monday's session");
        CHECK(weekday(daysFromCivil(2026, 10, 9)) == 5, "2026-10-09 is a Friday");
        // DST fall-back (2026-11-01 01:00-02:00 local repeats): duplicated wall-clock bars overnight do not disturb Monday's RTH
        Cfg c = cfgFor("ES"); std::vector<Bar> B; long long d = daysFromCivil(2026, 11, 2);
        for (int m = 17 * 60 + 3; m < 24 * 60; m += 3) { Bar b; b.absEnd = (d - 1) * 86400 + m * 60LL; b.o = b.c = 100; b.h = 100.5; b.l = 99.5; B.push_back(b); }
        for (int rep = 0; rep < 2; rep++) for (int m = 63; m <= 120; m += 3) { Bar b; b.absEnd = d * 86400 + m * 60LL; b.o = b.c = 100; b.h = 100.5; b.l = 99.5; B.push_back(b); }
        for (int m = 123; m <= 15 * 60; m += 3) { Bar b; b.absEnd = d * 86400 + m * 60LL; b.o = b.c = 100; b.h = 100.25 + (m == 600 ? 2 : 0); b.l = 99.75 - (m == 540 ? 2 : 0); B.push_back(b); }
        Tracker T = runBars(c, B, B.size(), nullptr); View v = buildView(T, ReadOut());
        CHECK(v.lodMod == 540 && v.hodMod == 600 && v.took == 30 && v.complete, "DST night: RTH values exact");
        // malformed bars are ignored
        Tracker X(cfgFor("ES"));
        Bar n; n.absEnd = at(2026, 10, 9, 8, 33); n.o = NAN; n.h = 1; n.l = 0; n.c = 1; CHECK(!X.push(n), "NaN price rejected");
        n.o = 1; n.h = 0; n.l = 1; CHECK(!X.push(n), "high < low rejected");
        n.o = 1e300; n.h = 1e300; n.l = 1e300; n.c = 1e300; CHECK(!X.push(n), "out-of-range price rejected");
        long long tk; CHECK(!toTicks(1.0, 0.0, tk) && !toTicks(1.0, NAN, tk), "invalid tick size rejected");
        // big prices / long long (checklist #2): NQ at 30,000 in ticks is 120,000; a 1e9-tick price still exact
        CHECK(toTicks(250000000.25, 0.25, tk) && tk == 1000000001LL, "ticks above 2^31 stay exact");
    }
    // ---------------------------------------------------------------- 7 formats
    std::printf("[7] formats\n");
    {
        EQ(durC(303), "5h03m", "durC"); EQ(durC(21), "21m", "durC <60"); EQ(durT(65), "1h05", "durT"); EQ(durT(39), "39m", "durT <60");
        EQ(clk(549), "9:09", "clk"); EQ(clkPm(834), "1:54pm", "clkPm"); EQ(clkPm(531), "8:51", "clkPm morning"); EQ(clkAmPm(780), "1:00 PM", "clkAmPm");
        EQ(usd(2187.5), "$2,188", "half up"); EQ(usd(575), "$575", "usd"); EQ(usd(1234567.4), "$1,234,567", "commas");
        EQ(trimNum(43.75, 2), "43.75", "trim"); EQ(trimNum(65.0, 2), "65", "trim zeros"); EQ(trimNum(0.00368, 5), "0.00368", "EU");
        EQ(ptsMean(16.7602, 0.25, 2), "16.75p", "E size to the tick");
        EQ(marketForRoot("EPZ26"), "ES", "EP -> ES"); EQ(marketForRoot("CPEZ26"), "HG", "CPE -> HG"); EQ(marketForRoot("EU6Z26"), "EU", "EU6 -> EU");
        EQ(marketForRoot("QGC"), "GC", "QGC -> GC"); EQ(marketForRoot("NQZ26"), "NQ", "NQ"); EQ(marketForRoot("CLX26"), "CL", "CL"); EQ(marketForRoot("NGX26"), "NG", "NG");
        EQ(marketForRoot("ZB"), "", "unknown root -> no market");
    }
    // ---------------------------------------------------------------- 8 no-repaint replay: one pass == every prefix, restart after every bar
    std::printf("[8] replay\n");
    {
        Cfg c = cfgFor("ES");
        std::vector<ReadRow> one; runBars(c, comb, comb.size() - 1, &one);
        CHECK(one.size() == 130, "one read row per closed RTH bar of the latest session");
        bool same = true; size_t checked = 0;
        for (size_t k = comb.size() - 1 - 140; k < comb.size(); k++) {
            std::vector<ReadRow> pre; runBars(c, comb, k, &pre);
            for (size_t i = 0; i < pre.size() && i < one.size(); i++) {
                if (scorerLine("ES", pre[i]) != scorerLine("ES", one[i]) || readLogLine("ES", 180, pre[i], false, .25, 2) != readLogLine("ES", 180, one[i], false, .25, 2)) same = false;
                checked++;
            }
        }
        CHECK(same && checked > 1000, "every prefix reproduces the one-pass rows exactly (no repaint)");
        // the logger: restart after every bar (prime from the file each time) == one straight pass
        std::string p1 = out + "/replay_straight.csv", p2 = out + "/replay_restart.csv";
        std::remove(p1.c_str()); std::remove(p2.c_str());
        FileOps F;
        { LogState S; primeFromFile(S, p1, "2026-10-09", 4, 5, "OUTCOME"); for (size_t i = 0; i < one.size(); i++) if (one[i].barEnd > S.lastBarEnd) { if (F.write(p1, readLogLine("ES", 180, one[i], true, .25, 2) + "\n", true)) S.lastBarEnd = one[i].barEnd; } }
        for (size_t k = comb.size() - 1 - 140; k < comb.size(); k++) {
            std::vector<ReadRow> pre; runBars(c, comb, k, &pre);
            LogState S; primeFromFile(S, p2, pre.empty() ? "" : pre[0].session, 4, 5, "OUTCOME");
            for (size_t i = 0; i < pre.size(); i++) if (pre[i].barEnd > S.lastBarEnd) { if (F.write(p2, readLogLine("ES", 180, pre[i], true, .25, 2) + "\n", true)) S.lastBarEnd = pre[i].barEnd; }
        }
        std::ifstream a(p1.c_str()), b(p2.c_str()); std::stringstream sa, sb; sa << a.rdbuf(); sb << b.rdbuf();
        CHECK(sa.str() == sb.str() && !sa.str().empty(), "restart after every bar writes the identical log");
#if HL_HAVE_READ
        { std::ofstream rf((out + "/cpp_reads_es.csv").c_str());
          for (size_t i = 0; i < one.size(); i++) if (one[i].out.state == 1) rf << hhmm(one[i].barEnd) << "," << one[i].out.side << "," << fmtP(one[i].out.pIn) << "," << one[i].out.afterT << "," << fmtP(one[i].out.afterP) << "," << one[i].out.byT << "," << fmtP(one[i].out.byP) << "\n"; }
        CHECK(one[40].out.state == 1 && one[5].out.state == 2, "read valid from minute 30 (bar 10), 'read from' before");
#endif
        // the read line, every bar: building (no tables yet in this build) or a value
        std::string rl = readLogLine("ES", 180, one.back(), true, .25, 2);
#if HL_HAVE_READ
        CHECK(rl.find(",ok,") != std::string::npos || rl.find(",not_yet,") != std::string::npos || rl.find(",na,") != std::string::npos, "read state logged");
#else
        CHECK(rl.find(",building,") != std::string::npos && rl.find("read: building") != std::string::npos, "read: building logged");
#endif
    }
#if HL_HAVE_READ
    {   // (3) the first extreme broken AFTER it was called IN: the live cells go back, the logged reads never change
        std::printf("[8b] first extreme broken after the IN call\n");
        Cfg c = cfgFor("ES");
        size_t k = 0; for (size_t i = 0; i < comb.size(); i++) if (comb[i].absEnd == at(2026, 10, 9, 10, 30)) k = i + 1;
        std::vector<Bar> B(comb.begin(), comb.begin() + (long)k);
        std::vector<ReadRow> r0; Tracker T0 = runBars(c, B, B.size(), &r0); View v0 = buildView(T0, r0.back().out, &r0);
        CHECK(r0.back().out.callIn && cellTxt(v0.E[K_DIR2]) == "HOD", "10:30: LOD called IN, E 2nd Dir HOD");
        Bar nb; nb.absEnd = at(2026, 10, 9, 10, 33); nb.o = 7840; nb.h = 7840.25; nb.l = 7820; nb.c = 7821; B.push_back(nb);   // a new low
        std::vector<ReadRow> r1; Tracker T1 = runBars(c, B, B.size(), &r1); View v1 = buildView(T1, r1.back().out, &r1);
        bool same = r1.size() == r0.size() + 1; for (size_t i = 0; same && i < r0.size(); i++) same = readLogLine("ES", 180, r0[i], true, .25, 2) == readLogLine("ES", 180, r1[i], true, .25, 2);
        CHECK(same, "every read logged before the break is unchanged (no repaint of a logged read)");
        CHECK(v1.lodMod == 633 && v1.side == 2 && !v1.secondPrinted, "the new LOD 10:33 makes the HOD (earlier) the 1st extreme, the LOD pending");
        std::printf("    after the break: %s | %s | state %d callIn %d pIn %.3f side %d\n", cellTxt(v1.E[K_2ND]).c_str(), cellTxt(v1.A[K_2ND]).c_str(), r1.back().out.state, (int)r1.back().out.callIn, r1.back().out.pIn, r1.back().out.side);
        CHECK(r1.back().out.side == 1 && cellTxt(v1.A[K_2ND]) == "pending" && cellTxt(v1.A[K_1ST]).find("HOD") != std::string::npos && v1.E[K_2ND].s3 != "HOD",
              "live cells re-read: the 1st is now the HOD, the 2nd is pending again, the E 2nd side no longer says HOD");
        CHECK(r1.back().shown != r0.back().shown, "the new read is logged as its own row");
    }
#endif
#if HL_HAVE_READ
    {   // stage2 wiring: a read with the 1st IN before the reclaim shows the stage's window; the A tag uses it
        std::printf("[8c] stage2 window\n");
        size_t k = 0; for (size_t i = 0; i < chart.size(); i++) if (chart[i].absEnd == at(2026, 10, 9, 9, 6)) k = i + 1;
        Tracker T = runBars(cfgFor("ES"), chart, k, nullptr);
        hlr::Stage2 s2 = hlr::stage2(0, 531, 0.2, 546);
        ReadOut ro; ro.state = 1; ro.pIn = 0.8; ro.side = 0; ro.callIn = true; ro.s2 = s2.valid && s2.w > 0; ro.s2from = s2.from; ro.s2to = s2.to; ro.s2p = s2.p;
        ro.s2show = shownP(s2.qualified, s2.p, s2.show);
        View vs = buildView(T, ro);
        char want[64]; snprintf(want, sizeof want, "%s - %s  %d%%", clk(s2.from).c_str(), clk(s2.to).c_str(), (int)std::llround(ro.s2show * 100));
        CHECK(!s2.qualified || std::fabs(ro.s2show - hlr::es_ch::kShow2) < 1e-12, "a qualified reclaim window shows the delivered % (kShow2), not the raw P");
        CHECK(s2.valid && s2.from == 531, "hlr::stage2(ES, 8:51, depth 0.2) is valid and anchored on 8:51");
        EQ(cellTxt(vs.E[K_RECL]) + "|" + vs.srcRecl, std::string(want) + "|hlr::stage2", "E Reclaim = stage2's window once the 1st is IN");
    }
#endif
    // ---------------------------------------------------------------- 9 file safety
    std::printf("[9] atomic status write, failing append\n");
    {
        FileOps F; std::string p = out + "/atomic_status.txt";
        CHECK(writeAtomic(F, p, "one\n"), "first write");
        CHECK(writeAtomic(F, p, "two\n"), "replace");
        FileOps bad = F; int n = 0;
        bad.rename = [&](const std::string& a, const std::string& b) { if (++n == 2) return false; return std::rename(a.c_str(), b.c_str()) == 0; };   // tmp -> final fails
        CHECK(!writeAtomic(bad, p, "three\n"), "rename failure reported");
        std::ifstream f(p.c_str()); std::string s; std::getline(f, s);
        EQ(s, "two", "the good copy is restored from .bak");
        FileOps nw = F; nw.write = [](const std::string&, const std::string&, bool) { return false; };
        LogState S; S.lastBarEnd = 500;
        if (nw.write(p + ".log", "x\n", true)) S.lastBarEnd = 600;
        CHECK(S.lastBarEnd == 500, "a failed append does not advance the log mark");
        EQ(lastLine(out + "/replay_straight.csv").substr(0, 5), "READ,", "lastLine reads the tail only");
        LogState P; primeFromFile(P, out + "/replay_straight.csv", "2026-10-09", 4, 5, "OUTCOME");
        CHECK(P.lastBarEnd == 900, "primed from the file: last logged bar 15:00");
        LogState Q; primeFromFile(Q, out + "/replay_straight.csv", "2026-10-10", 4, 5, "OUTCOME");
        CHECK(Q.lastBarEnd == -1, "another session starts empty");
    }
    // ---------------------------------------------------------------- 10 layout: 3 zooms, overlap, too short / narrow
    std::printf("[10] layout\n");
    {
        std::vector<ReadRow> rows10; Tracker T = runBars(cfgFor("ES"), comb, comb.size() - 1, &rows10);
        View v = buildView(T, rows10.empty() ? ReadOut() : rows10.back().out, &rows10);
        struct Z { const char* name; double lo, hi; int w, h; } zooms[] = {
            { "normal", 7792, 7892, 1170, 740 }, { "zoomed_in", 7835, 7850, 1170, 740 }, { "zoomed_out", 7600, 8100, 1170, 740 },
            { "short", 7792, 7892, 1170, 150 }, { "narrow", 7792, 7892, 520, 600 } };
        for (double sc = 1.0; sc <= 1.21; sc += 0.2) {
            SCALE = sc;
            for (size_t z = 0; z < sizeof zooms / sizeof zooms[0]; z++) {
                Box pane = { 0, 0, zooms[z].w, zooms[z].h };
                double lo = zooms[z].lo, hi = zooms[z].hi;
                auto yOf = [&](long long tk) { double p = tk * 0.25; return (int)std::lround(pane.t + (hi - p) / (hi - lo) * (pane.b - pane.t)); };
                Layout L = layoutAll(v, pane, yOf, measure);
                std::string why; bool ok = layoutClean(L, pane, why);
                CHECK(ok, std::string("layout clean at ") + zooms[z].name + (sc > 1 ? " (+20% text)" : "") + ": " + why);
                if (sc == 1.0) dumpLayout(L, pane, out + "/layout_" + zooms[z].name + ".json", zooms[z].name);
                if (std::string(zooms[z].name) == "normal") CHECK(L.tableOk && L.candleOk && L.note.empty(), "normal: table + candle");
                if (std::string(zooms[z].name) == "short") CHECK(L.tableOk && L.candleOk, "150 px pane: the table sits beside the candle, both fit");
            }
        }
        SCALE = 1.0;
        Box tiny = { 0, 0, 300, 120 };
        Layout L = layoutAll(v, tiny, [](long long) { return 50; }, measure);
        std::string why; CHECK(layoutClean(L, tiny, why) && !L.note.empty(), "tiny pane: no forced drawing, a note instead");
        // mirror day + pending day layouts are clean too
        std::vector<Bar> M = mirror(chart, 7838.25); Tracker TM = runBars(cfgFor("ES"), M, M.size() - 1, nullptr); View vm = buildView(TM, ReadOut());
        Box pane = { 0, 0, 1170, 740 };
        auto yM = [&](long long tk) { double p = tk * 0.25; return (int)std::lround((7884 - p) / 100.0 * 740); };
        Layout LM = layoutAll(vm, pane, yM, measure); CHECK(layoutClean(LM, pane, why), "mirror layout clean: " + why);
        dumpLayout(LM, pane, out + "/layout_mirror.json", "HOD-first mirror");
        Layout LN0 = layoutAll(v, pane, [&](long long tk) { double p = tk * 0.25; return (int)std::lround((7892 - p) / 100.0 * 740); }, measure);
        // live at 10:30 (the read in the header) and at 9:00 (second pending)
        for (int hhmmLive : { 10 * 60 + 30, 9 * 60 + 0, 11 * 60 + 30, 13 * 60, 14 * 60 + 30 }) {
            size_t k = 0; for (size_t i = 0; i < comb.size(); i++) if (comb[i].absEnd == at(2026, 10, 9, hhmmLive / 60, hhmmLive % 60)) k = i + 1;
            std::vector<ReadRow> rr; Tracker TL = runBars(cfgFor("ES"), comb, k, &rr);
            View vl = buildView(TL, rr.empty() ? ReadOut() : rr.back().out, &rr);
            Layout LL = layoutAll(vl, pane, [&](long long tk) { double p = tk * 0.25; return (int)std::lround((7892 - p) / 100.0 * 740); }, measure);
            CHECK(layoutClean(LL, pane, why), "live layout clean: " + why);
            dumpLayout(LL, pane, out + "/layout_live_" + hhmm(hhmmLive).substr(0, 2) + hhmm(hhmmLive).substr(3) + ".json", "live");
#if HL_HAVE_READ
            // (HL101 clock) the call is re-queried with now on every bar: T >= now, never the stale 11:00 at 11:30
            if (rr.back().out.callSrc == 3 && rr.back().out.callT >= 0) CHECK(rr.back().out.callT >= hhmmLive, "T >= now at " + clk(hhmmLive));
            if (hhmmLive == 690) {
                EQ(vl.header, "LOD IN 92%   \xB7   expect HOD after 11:30 79%", "11:30 header: IN live + stage3 re-read at now (not qualified: honest P, grey)");
                EQ(cellTxt(vl.E[K_2ND]), "after 11:30 79%  HOD", "(2) LOD IN -> HOD; the cell = the header's time and P (one source: stage3)");
                CHECK(vl.headTailCol == C_DIM && vl.E[K_2ND].col == C_DIM, "11:30: a call that is not qualified (and ES stage 3 in test) is grey");
                // (HL101 running extreme) the HOD so far printed 11:21; final only at the close (1:54)
                EQ(cellTxt(vl.A[K_2ND]), "high so far 11:21", "11:30 A 2nd Time = the running high, grey, no tag");
                CHECK(vl.A[K_2ND].col == C_GREY && vl.A[K_2ND].s3.empty() && !vl.secondFinal && vl.secondPrinted, "running: grey, no in/early/late, not final");
                CHECK(groupTxt(vl.top).find("high 11:21") == 0 && vl.top[0][0].col == C_GREY, "candle top 'high 11:21 ...' in grey until the close (" + groupTxt(vl.top) + ")");
                EQ(cellTxt(vl.A[K_1ST]), "8:51 LOD  in", "the LOD was called IN (10:21) -> named LOD with its tag");
                std::string st = statusText(vl, layoutAll(vl, pane, [](long long) { return 100; }, measure), TL, rr.back().out, 180, "ok");
                CHECK(st.find("SECOND_STATE,running") != std::string::npos && st.find("SECOND_RUNNING,high,7,") != std::string::npos && st.find("SECOND_FINAL,\n") != std::string::npos, "status keeps the running value; the final is empty until the close");
            }
            if (hhmmLive == 630) EQ(cellTxt(vl.E[K_2ND]) + "|" + vl.src2nd, "after 11:00 80%  HOD|hlr::stage3 (in test)", "10:30: stage3 since the reclaim, shown at kShow3 (80%), not the raw 90%");
            if (hhmmLive == 780) { EQ(cellTxt(vl.E[K_2ND]), "after 1:00 45%  HOD", "1:00: T = 1:00 (>= now), the honest P"); EQ(vl.headTail, "   \xB7   expect HOD after 1:00 45%", "1:00 header = the cell"); }
            if (hhmmLive == 870) { EQ(cellTxt(vl.E[K_2ND]), "after 2:30 22%  HOD", "2:30: T = 2:30 (>= now), the honest P"); CHECK(rr.back().out.callT >= 870 && !rr.back().out.callQ, "2:30: not qualified, never an earlier T"); }
            if (hhmmLive == 540) EQ(vl.E[K_2ND].s3, "either", "9:00: HOD NOT IN -> the 2nd side word is 'either'");
#endif
        }
        {   // (v9) the table never touches the candle: its left edge is right of every candle item
            int candR = 0; for (size_t i = 0; i < LN0.items.size(); i++) if (LN0.items[i].role == R_CANDLE || LN0.items[i].role == R_LABEL) candR = std::max(candR, std::max(LN0.items[i].l, LN0.items[i].r));
            CHECK(LN0.tableOk && LN0.table.l >= candR + 12, "table left edge clear of the candle (>= 12 px)");
        }
        {   // too short for anything: notes, nothing forced
            Box p75 = { 0, 0, 1170, 75 }; Layout L75 = layoutAll(v, p75, [](long long) { return 30; }, measure);
            std::string w2; CHECK(!L75.tableOk && !L75.candleOk && !L75.note.empty() && layoutClean(L75, p75, w2), "75 px pane: notes only " + w2);
        }
        {   // an EARLY tag (amber): a GC LOD at 7:30 against the model window 8:21-9:21
            Cfg g = cfgFor("GC", 0.1); std::vector<Bar> G; long long d = daysFromCivil(2026, 10, 6);
            for (int m = 7 * 60 + 24; m <= 9 * 60; m += 3) { Bar b; b.absEnd = d * 86400 + m * 60LL; b.o = b.c = 4000; b.h = 4000.5 + (m == 8 * 60 + 45 ? 5 : 0); b.l = 3999.5 - (m == 8 * 60 + 30 ? 5 : 0); G.push_back(b); }
            ReadOut gin; gin.state = 1; gin.side = 0; gin.callIn = true;      // (HL101) the LOD called IN -> it is named LOD and tagged
            View vg = buildView(runBars(g, G, G.size(), nullptr), gin);
            CHECK(cellTxt(buildView(runBars(g, G, G.size(), nullptr), ReadOut()).A[K_1ST]) == "low so far 8:30", "not called IN yet: 'low so far 8:30', no tag");
#if HL_HAVE_READ
            EQ(cellTxt(vg.A[K_1ST]), "8:30 LOD  late", "GC LOD 8:30 vs the stage1 window 7:24-8:12 = late"); CHECK(vg.A[K_1ST].col3 == C_AMBER, "late is amber");
#else
            EQ(cellTxt(vg.A[K_1ST]), "8:30 LOD  in", "GC LOD 8:30 vs the static 7:30-8:30 window (median 40m) = in");
#endif
        }
        // status text carries every drawn value
        Layout LN = layoutAll(v, pane, [&](long long tk) { double p = tk * 0.25; return (int)std::lround((7892 - p) / 100.0 * 740); }, measure);
        std::string st = statusText(v, LN, T, ReadOut(), 180, "ok");
        CHECK(st.find("LOD,7,826.75,08:51,LonLO") != std::string::npos && st.find("HOD,7,870.50,13:54,PFH") != std::string::npos, "status: extremes + levels");
        CHECK(st.find("A_1st Time,8:51 LOD  in") != std::string::npos && st.find("E_WINDOW_1ST,") != std::string::npos && st.find("AFTER_THR,0.75 floor") != std::string::npos && st.find("HLE,hle 2.0.0") != std::string::npos && st.find("LABEL,") != std::string::npos, "status: table cells, windows, every label");
        std::ofstream sf((out + "/HodLod.status-ES-180.sample.txt").c_str()); sf << st;
        std::ofstream ol((out + "/outcome.sample.txt").c_str()); ol << outcomeLine(v, 180, .25) << "\n";
    }
    // ---------------------------------------------------------------- 11 all markets: tick grids, models, E-LOD / E-HOD
    std::printf("[11] markets + E-LOD / E-HOD\n");
    {
        const char* mk[7] = { "ES", "NQ", "CL", "GC", "HG", "NG", "EU" };
        for (int i = 0; i < 7; i++) { bool up, bs; int sh; const hlx::Model* m = modelFor(i, 0, up, bs, sh); CHECK(m && m->rangePts > 0 && sh >= 50, std::string("model for ") + mk[i]); }
        Tracker T = runBars(cfgFor("ES"), chart, chart.size() - 1, nullptr); View v = buildView(T, ReadOut());
        EQ(pxTxt(v.eLod, 2), "7,826.00", "E-LOD = open - 12.25 (the LOD-first median size; no hle without ATR14)"); EQ(pxTxt(v.eHod, 2), "7,891.05", "E-HOD = E-LOD + 65.05 (v1 range)");
        bool up, bs; int sh; modelFor(mktIndex("EU"), 0, up, bs, sh); CHECK(!up && sh == 57, "EU: the down model is more common (105 of 185)");
    }
#if HL_HAVE_READ
    // ---------------------------------------------------------------- 12 HL101: close-push form, calibrated %, FOMC pause, news flags
    std::printf("[12] HL101 chain display, calibration, calendar\n");
    {
        std::vector<Bar> V = loadCsv(dir + "/es_vol.csv");     // the IRT store WITH volume (2026-08-16 .. 2026-10-09 06:24)
        Cfg c = cfgFor("ES"); Tracker T(c); int nk = readNormKind(0);
        int nClose = 0, nCloseOk = 0, nQ3 = 0, nQ3Show = 0, nNowOk = 0, nCalls = 0, nPauseRows = 0, nPauseOk = 0, nSidesOk = 0;
        std::string sampleClose; size_t kSample = 0;
        for (size_t i = 0; i < V.size(); i++) {
            if (!T.push(V[i]) || !(T.cur.any && T.cur.lastSeq == T.seq)) continue;
            ReadIn ri = T.readIn(nk, 0); ReadOut o = evalRead(ri);
            if (o.state != 1) continue;
            std::string ds = dateTxt(T.cur.sid);
            if (o.callSrc == 2) {          // before the reclaim: "close push P% . else a-b" from hlr::timing, P = pClose
                nClose++; std::string t = callTxt(o);
                char want[96]; snprintf(want, sizeof want, "close push %d%%", (int)std::llround(o.pClose * 100));
                if (t.compare(0, strlen(want), want) == 0 && (o.elseFrom < 0 || t.find(" \xB7 else " + clk(o.elseFrom) + "-" + clk(o.elseTo)) != std::string::npos)) nCloseOk++;
                if (sampleClose.empty() && o.elseFrom >= 0) { sampleClose = t; kSample = i + 1; }
            }
            if (o.callSrc == 3 && o.callT >= 0) {
                nCalls++; if (o.callT >= ri.now) nNowOk++;
                if (o.callQ) { nQ3++; if (std::fabs(o.callShow - hlr::es_ch::kShow3) < 1e-12) nQ3Show++; }
                else if (o.callShow <= hlr::es_ch::kShow3 + 1e-12) nQ3Show += 0;   // not qualified: min(raw, show), checked below
            }
            if (ds == "2026-09-16") {        // FOMC (events file): no IN / NOT IN call before 1:30 PM in ES
                nPauseRows++;
                bool want = ri.now < 810;
                if (o.fomcPause == want && (!want || (!o.callIn && readLine(o, 510, 30).find("so far \xB7 FOMC pause") != std::string::npos))) nPauseOk++;
            }
            if (o.callSrc == 3 && !o.callQ && o.callT >= 0 && o.callShow <= (std::min)(o.callP, hlr::es_ch::kShow3) + 1e-12) nSidesOk++;
        }
        CHECK(nClose > 5 && nClose == nCloseOk, "before the reclaim the 2nd call is 'close push P% \xB7 else a-b' from hlr::timing on " + std::to_string(nCloseOk) + "/" + std::to_string(nClose) + " bars");
        CHECK(nCalls > 100 && nNowOk == nCalls, "stage 3 re-read with now: T >= now on every one of " + std::to_string(nCalls) + " bars");
        CHECK(nQ3 > 0 && nQ3 == nQ3Show, "every qualified stage-3 call shows kShow3 (" + std::to_string(nQ3) + " bars), never the raw P");
        CHECK(nSidesOk > 0, "a call that is not qualified shows min(raw, kShow3)");
        CHECK(nPauseRows > 100 && nPauseRows == nPauseOk, "FOMC 2026-09-16: no IN call before 1:30 PM, 'so far \xB7 FOMC pause' (" + std::to_string(nPauseOk) + "/" + std::to_string(nPauseRows) + ")");
        std::printf("    sample close-push call: %s\n", sampleClose.c_str());
        {   // the header tail and the E cell say the same thing, from the same row
            std::vector<ReadRow> rr; Tracker TS = runBars(c, V, kSample, &rr); View vs = buildView(TS, rr.back().out, &rr);
            CHECK(rr.back().out.callSrc == 2 && vs.headTail.find(cellTxt(vs.E[K_2ND]).substr(0, cellTxt(vs.E[K_2ND]).find("  "))) != std::string::npos,
                  "close-push form: the header tail contains the E 2nd Time text (" + vs.headTail + " | " + cellTxt(vs.E[K_2ND]) + ")");
        }
        {   // checklist #2 / #26: volumes above 2^31 per bar (and sums far above) - the VWAP weights are doubles: the same features
            std::vector<Bar> big = V, small = V;
            for (size_t i = 0; i < big.size(); i++) { if (std::isfinite(V[i].v)) { big[i].v = V[i].v * 3.0e6 + 2147483648.0; small[i].v = V[i].v * 3.0 + 2147.483648; } }
            Tracker TB(c), TS(c); size_t same = 0, n = 0;
            for (size_t i = 0; i < big.size(); i++) {
                TB.push(big[i]); TS.push(small[i]);
                if (!(TB.cur.any && TB.cur.lastSeq == TB.seq)) continue;
                int j = (TB.cur.ringAt + 19) % 20;    // this bar's VWAP / SD
                double d1 = std::fabs(TB.cur.ring[j].vw - TS.cur.ring[j].vw) / TS.cur.ring[j].vw, d2 = std::fabs(TB.cur.ring[j].sd - TS.cur.ring[j].sd);
                n++; if (d1 < 1e-12 && d2 < 1e-3 && TB.cur.sv > 2147483648.0) same++;
            }
            CHECK(n > 4000 && same == n, "volumes above 2^31 per bar: VWAP / SD equal the 1e6-times smaller volumes on " + std::to_string(same) + "/" + std::to_string(n) + " RTH bars (double sums, no overflow; SD within 0.001 pt: the model's own E[x^2]-E[x]^2 form, kept to match hodlod_read.py)");
        }
        // news flags: CPI 2026-09-11 -> hle news 1; 2026-09-10 -> 0; after the events file ends -> unknown, 0, flagged
        bool kn = false;
        CHECK(hlev::newsDay(0, hlev::bitsOn(20260911, kn)) && kn && !hlev::newsDay(0, hlev::bitsOn(20260910, kn)), "calendar: CPI 9/11 is a news day, 9/10 is not");
        CHECK(hlev::fomcDay(hlev::bitsOn(20260916, kn)) && hlev::amNews(hlev::bitsOn(20260904, kn)), "calendar: FOMC 9/16, NFP 9/4 (amnews)");
        unsigned eb = hlev::bitsOn(20250430, kn);
        CHECK(!hlev::newsDay(0, eb) && hlev::newsDay(2, eb), "EIA crude counts as news for CL only");
        unsigned b9 = hlev::bitsOn(20261009, kn); CHECK(kn && !hlev::newsDay(0, b9), "2026-10-09 is covered (extended file 1009): known, no ES news");
        CHECK(hlev::fomcDay(hlev::bitsOn(20261028, kn)) && hlev::amNews(hlev::bitsOn(20261014, kn)) && hlev::amNews(hlev::bitsOn(20261002, kn)), "extended calendar: FOMC 10/28, CPI 10/14, NFP 10/2");
        hlev::bitsOn(20270104, kn); CHECK(!kn, "2027-01-04 is past the events file: unknown (flagged, news 0)");
        for (int dd : { 8, 2 }) {   // 10/08: EIA gas only (news for NG, not ES) -> 0; 10/02: NFP -> 1; both covered, no flag
            size_t k = 0; for (size_t i = 0; i < V.size(); i++) if (V[i].absEnd <= at(2026, 10, dd, 11, 0)) k = i + 1;
            Tracker TS = runBars(c, V, k, nullptr); std::string why; hle::State hs = hleState(TS, TS.cur, why);
            CHECK(TS.cur.any && hs.news == (dd == 2 ? 1 : 0) && why.find("calendar") == std::string::npos, "hle news on 2026-10-0" + std::to_string(dd) + " = " + std::to_string(hs.news) + ", no calendar flag");
        }
        {   size_t k = 0; for (size_t i = 0; i < V.size(); i++) if (V[i].absEnd <= at(2026, 9, 11, 10, 0)) k = i + 1;
            Tracker TS = runBars(c, V, k, nullptr); std::string why; hle::State hs = hleState(TS, TS.cur, why);
            CHECK(hs.news == 1 && why.find("calendar") == std::string::npos, "hle news = 1 on CPI day 2026-09-11"); }
        // the scorer line: hlr::kLogHeader's 18 columns, timing columns filled on a 3-min chart with ATR
        {   std::vector<ReadRow> rr; size_t k = 0; for (size_t i = 0; i < V.size(); i++) if (V[i].absEnd <= at(2026, 10, 8, 11, 0)) k = i + 1;
            runBars(c, V, k, &rr); std::string L = scorerLine("ES", rr.back());
            int commas = 0; for (char ch : L) commas += ch == ',';
            int hc = 0; for (const char* q = hlr::kLogHeader; *q; q++) hc += *q == ',';
            CHECK(commas == hc && L.find(",,") == std::string::npos, "scorer line: " + std::to_string(commas + 1) + " columns = kLogHeader, timing filled: " + L); }
    }
    // ---------------------------------------------------------------- 13 HL101 previews: ES 2026-10-09 with 28 prior sessions (es_long)
    std::printf("[13] previews\n");
    {
        std::vector<Bar> lng = loadCsv(dir + "/es_long.csv"), mir = mirror(lng, 7838.25);
        { std::ofstream mf((out + "/es_long_mirror.csv").c_str());
          for (size_t i = 0; i < mir.size(); i++) { char b2[160]; long long d = floorDiv(mir[i].absEnd, 86400); int y, mo, dd; civilFromDays(d, y, mo, dd); int sod = (int)(mir[i].absEnd - d * 86400);
              snprintf(b2, sizeof b2, "%04d-%02d-%02d %02d:%02d:%02d,%.2f,%.2f,%.2f,%.2f\n", y, mo, dd, sod / 3600, sod / 60 % 60, sod % 60, mir[i].o, mir[i].h, mir[i].l, mir[i].c); mf << b2; } }
        Box pane = { 0, 0, 1170, 740 };
        struct P { const char* name; int hm; bool mirrored; } ps[] = { { "live_0900", 540, false }, { "live_1030", 630, false }, { "live_1130", 690, false },
                                                                         { "live_1300", 780, false }, { "close", 900, false }, { "mirror_1130", 690, true }, { "mirror_close", 900, true } };
        for (size_t q = 0; q < sizeof ps / sizeof ps[0]; q++) {
            const std::vector<Bar>& B = ps[q].mirrored ? mir : lng;
            size_t k = 0; for (size_t i = 0; i < B.size(); i++) if (B[i].absEnd <= at(2026, 10, 9, ps[q].hm / 60, ps[q].hm % 60)) k = i + 1;
            if (ps[q].hm == 900) k = B.size() - 1;     // the 16:00 bar forming: the 15:00 bar is closed
            std::vector<ReadRow> rr; Tracker TP = runBars(cfgFor("ES"), B, k, &rr); View vp = buildView(TP, rr.empty() ? ReadOut() : rr.back().out, &rr);
            double hi = ps[q].mirrored ? 7884.5 : 7892.0;
            Layout LP = layoutAll(vp, pane, [&](long long tk) { double p = tk * 0.25; return (int)std::lround((hi - p) / 100.0 * 740); }, measure);
            std::string why; CHECK(layoutClean(LP, pane, why), std::string("preview ") + ps[q].name + " clean: " + why);
            dumpLayout(LP, pane, out + "/preview_" + ps[q].name + ".json", ps[q].name);
            std::printf("    %-13s %s | E %s | A %s\n", ps[q].name, vp.header.c_str(), rowTxt(vp.E).substr(0, 90).c_str(), rowTxt(vp.A).substr(0, 70).c_str());
            if (std::string(ps[q].name) == "mirror_1130") {
                CHECK(cellTxt(vp.A[K_2ND]) == "low so far 11:21" && vp.A[K_2ND].col == C_GREY, "mirror 11:30: 'low so far 11:21' grey");
                CHECK(vp.header.find("HOD IN") == 0 && vp.header.find("expect LOD after") != std::string::npos, "mirror 11:30: HOD IN, expect LOD after T");
            }
        }
    }
    // ---------------------------------------------------------------- 14 HL102: every candle label inside the reserved left column
    std::printf("[14] labels inside the candle column (3 zooms, short pane, flat body)\n");
    {
        std::vector<Bar> lng = loadCsv(dir + "/es_long.csv"), mir = mirror(lng, 7838.25);
        // a flat-body day: open 7800, low 7790 at 9:00, high 7812 at 12:00, close back at 7800.25 (open ~ close)
        std::vector<Bar> flat; long long d0 = daysFromCivil(2026, 10, 7);
        for (int hm = 8 * 60 + 33; hm <= 15 * 60; hm += 3) {
            double base = hm < 540 ? 7800 - (hm - 510) / 3.0 : (hm < 720 ? 7790 + (hm - 540) / 180.0 * 22 : 7812 - (hm - 720) / 180.0 * 11.75);
            base = std::floor(base * 4) / 4; Bar b; b.absEnd = d0 * 86400 + hm * 60LL; b.o = hm == 513 ? 7800 : base; b.h = base + 0.5; b.l = base - 0.25; b.c = hm == 900 ? 7800.25 : base;
            if (hm == 513) { b.h = (std::max)(b.h, 7800.5); b.l = (std::min)(b.l, 7799.5); }
            flat.push_back(b);
        }
        { Bar b; b.absEnd = d0 * 86400 + 15 * 3600 + 180; b.o = b.h = b.l = b.c = 7800.25; flat.push_back(b); }
        struct S { const char* name; const std::vector<Bar>* B; int hm; double mid; } ss[] = {
            { "ES close", &lng, 900, 7845 }, { "ES 11:30", &lng, 690, 7845 }, { "mirror close", &mir, 900, 7832 }, { "flat body", &flat, 900, 7801 } };
        int checked = 0, outside = 0, overl = 0; std::string bad;
        for (size_t q = 0; q < sizeof ss / sizeof ss[0]; q++) {
            const std::vector<Bar>& B = *ss[q].B;
            size_t k = 0;
            if (ss[q].B == &flat) k = B.size() - 1;
            else { for (size_t i = 0; i < B.size(); i++) if (B[i].absEnd <= at(2026, 10, 9, ss[q].hm / 60, ss[q].hm % 60)) k = i + 1; if (ss[q].hm == 900) k = B.size() - 1; }
            std::vector<ReadRow> rr; Tracker TP = runBars(cfgFor("ES"), B, k, &rr); View vp = buildView(TP, rr.empty() ? ReadOut() : rr.back().out, &rr);
            if (ss[q].B == &flat) CHECK(vp.complete && std::llabs(vp.close - vp.open) <= 1, "flat-body day built (open ~ close)");
            struct Z { const char* z; double half; int h; } zs[] = { { "normal", 50, 740 }, { "zoomed in", 8, 740 }, { "zoomed out", 250, 740 }, { "short pane", 50, 220 } };
            for (double sc = 1.0; sc <= 1.21; sc += 0.2) for (size_t zi = 0; zi < 4; zi++) {
                SCALE = sc;
                Box pane = { 0, 0, 1170, zs[zi].h }; double hi = ss[q].mid + zs[zi].half, span = 2 * zs[zi].half;
                Layout LP = layoutAll(vp, pane, [&](long long tk) { double p = tk * 0.25; return (int)std::lround((hi - p) / span * (pane.b - pane.t)); }, measure);
                int colR = pane.l + 8 + candleColW(vp, measure);
                for (size_t i = 0; i < LP.items.size(); i++) {
                    const Item& it = LP.items[i];
                    if (it.role != R_LABEL && it.role != R_CANDLE) continue;
                    checked++;
                    int l = (std::min)(it.l, it.r), r = (std::max)(it.l, it.r);
                    if (l < pane.l || r > colR) { outside++; if (bad.empty()) bad = std::string(ss[q].name) + " / " + zs[zi].z + ": '" + it.s + "' x " + std::to_string(l) + "-" + std::to_string(r) + " > column " + std::to_string(colR); }
                }
                std::string why; if (!layoutClean(LP, pane, why)) { overl++; if (bad.empty()) bad = std::string(ss[q].name) + " / " + zs[zi].z + ": " + why; }
                // the body labels, when drawn, sit inside the body rectangle
                for (size_t i = 0; i < LP.items.size(); i++) if (LP.items[i].role == R_CANDLE && LP.items[i].k == K_RECT) {
                    const Item& bx = LP.items[i];
                    for (size_t j = 0; j < LP.items.size(); j++) { const Item& t = LP.items[j];
                        if (t.k != K_TEXT || t.role != R_LABEL) continue;
                        bool isBody = t.body;
                        if (isBody && (t.l < bx.l || t.r > bx.r || t.t < bx.t || t.b > bx.b)) { outside++; if (bad.empty()) bad = std::string(ss[q].name) + " / " + zs[zi].z + ": body label '" + t.s + "' outside the body"; }
                    }
                }
                if (sc == 1.0 && zi == 0) dumpLayout(LP, pane, out + "/hl102_" + std::to_string(q) + ".json", ss[q].name);
            }
            SCALE = 1.0;
        }
        CHECK(checked > 500 && outside == 0, "no candle / label pixel outside the reserved column and no body label outside the body (" + std::to_string(checked) + " items): " + bad);
        CHECK(overl == 0, "every case is overlap-free: " + bad);
    }
#endif
    std::printf("\n%d passed, %d failed\n", passes, failures);
    return failures ? 1 : 0;
}
