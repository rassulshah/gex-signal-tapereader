#!/usr/bin/env python3
"""Render a draw list (written by the C++ layout code, the same list the plugin executes) to a PNG, optionally over the day's
3-min candles so it can be compared with the mockup.
    render_preview.py <layout.json> <out.png> [bars.csv lo hi first_hhmm last_hhmm skip_left_px]"""
import json, sys, datetime as dt
from PIL import Image, ImageDraw, ImageFont

BG = (11, 15, 23)
FONT = "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf"
FONTB = "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf"


def rgb(c):
    return ((c >> 16) & 255, (c >> 8) & 255, c & 255)


def main():
    L = json.load(open(sys.argv[1]))
    l, t, r, b = L["pane"]
    im = Image.new("RGB", (r - l + 1, b - t + 1), BG)
    d = ImageDraw.Draw(im)
    if len(sys.argv) > 3:
        path, lo, hi, a, z, skip = sys.argv[3], float(sys.argv[4]), float(sys.argv[5]), sys.argv[6], sys.argv[7], int(sys.argv[8])
        bars = [ln.strip().split(",") for ln in open(path)]
        bars = [x for x in bars if x[0][:10] == "2026-10-09" and a <= x[0][11:16] <= z]
        n = len(bars); w = (r - l - skip - 10) / max(n, 1)
        y = lambda p: (hi - p) / (hi - lo) * (b - t)
        for i, x in enumerate(bars):
            o, h, lw, c = map(float, x[1:5]); col = (34, 197, 94) if c >= o else (239, 68, 68)
            cx = skip + (i + 0.5) * w
            d.line([(cx, y(h)), (cx, y(lw))], fill=col)
            d.rectangle([cx - w * 0.33, y(max(o, c)), cx + w * 0.33, y(min(o, c)) + 1], fill=col)
    fonts = {}
    for it in L["items"]:
        k = it["k"]
        if k == 0:
            d.rectangle([it["l"], it["t"], it["r"], it["b"]], fill=rgb(it["c1"]))
        elif k == 1:
            fill = None if it["c2"] == 0xFFFFFFFF else rgb(it["c2"])
            d.rectangle([it["l"], it["t"], it["r"], it["b"]], outline=rgb(it["c1"]), fill=fill, width=it["w"])
        elif k == 2:
            d.line([(it["l"], it["t"]), (it["r"], it["b"])], fill=rgb(it["c1"]), width=it["w"])
        elif k == 3:
            key = (it["fs"], it["bold"])
            if key not in fonts:
                fonts[key] = ImageFont.truetype(FONTB if it["bold"] else FONT, int(round(it["fs"] * 96 / 72)))
            f = fonts[key]
            yc = (it["t"] + it["b"]) / 2
            d.text((it["l"], yc), it["s"], fill=rgb(it["c1"]), font=f, anchor="lm")
    im.save(sys.argv[2])
    print("wrote", sys.argv[2], im.size)


if __name__ == "__main__":
    main()
