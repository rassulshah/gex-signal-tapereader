// SessionInfo 1.7.0 tests: the 1.6.x regressions (strict parsing, bounds, missing-file cache, market restore, unavailable source,
// logarithmic fit) on the new per-chart state, plus the wide layout, the coloured slider with the E-HOD / E-LOD ticks, the removed
// Background setting, two charts on one object, and a preview draw list.
//   g++ -std=c++14 -I mock_sdk -I ../src test_sessioninfo_170.cpp
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <unistd.h>
#include <sys/stat.h>
#include "SessionInfo.cpp"

static int passes = 0, failures = 0;
#define CHECK(c, msg) do { if (c) ++passes; else { ++failures; std::printf("  FAIL  %s (line %d)\n", std::string(msg).c_str(), __LINE__); } } while (0)

static std::string sessionPath(const std::string& profile, const std::string& market)
{ return profile + "\\InvestorRT\\rtx\\lsFlexLevels\\LRA-Session-" + market + ".csv"; }
static bool drew(const mock::Chart& C, const std::string& s) { for (size_t i = 0; i < C.drawn.size(); i++) if (C.drawn[i].kind == 1 && C.drawn[i].s == s) return true; return false; }
static std::string slurp(const std::string& p) { std::ifstream f(p.c_str()); std::stringstream s; s << f.rdbuf(); return s.str(); }
static int measure(const std::string& s, int fs, bool bold)
{ double w = 0; for (size_t i = 0; i < s.size(); i++) w += (bold ? ADV_BOLD : ADV_REG)[(unsigned char)s[i]]; return (int)(w * fs * 96.0 / 72.0 / 1000.0 + 0.999); }
static void loadBars(mock::Chart& C, const std::string& path, const std::string& root, float tick)
{
    C.root = root; C.tick = tick;
    std::ifstream f(path.c_str()); std::string ln;
    while (std::getline(f, ln)) {
        int Y, M, D, h, m, s; double o, H, L, c;
        if (std::sscanf(ln.c_str(), "%d-%d-%d %d:%d:%d,%lf,%lf,%lf,%lf", &Y, &M, &D, &h, &m, &s, &o, &H, &L, &c) != 10) continue;
        C.t.push_back((RTDATE)(hl::daysFromCivil(Y, M, D) * 86400 + h * 3600 + m * 60 + s)); C.o.push_back((float)o); C.h.push_back((float)H); C.l.push_back((float)L); C.c.push_back((float)c);
    }
}
static void dumpLayout(const hl::Layout& L, const hl::Box& pane, const std::string& path)
{
    std::ofstream f(path.c_str());
    f << "{\"title\":\"SessionInfo\",\"pane\":[" << pane.l << "," << pane.t << "," << pane.r << "," << pane.b << "],\"items\":[\n";
    for (size_t i = 0; i < L.items.size(); i++) {
        const hl::Item& it = L.items[i]; std::string s;
        for (size_t k = 0; k < it.s.size(); k++) { unsigned char ch = (unsigned char)it.s[k]; if (ch == 0xB7) s += "\\u00b7"; else if (ch == 0xB1) s += "\\u00b1"; else if (ch == '"' || ch == '\\') { s += '\\'; s += (char)ch; } else s += (char)ch; }
        f << (i ? ",\n" : "") << "{\"k\":" << it.k << ",\"l\":" << it.l << ",\"t\":" << it.t << ",\"r\":" << it.r << ",\"b\":" << it.b << ",\"c1\":" << it.c1 << ",\"c2\":" << it.c2
          << ",\"s\":\"" << s << "\",\"fs\":" << it.fs << ",\"bold\":" << (it.bold ? 1 : 0) << ",\"w\":" << it.w << "}";
    }
    f << "]}\n";
}

int main(int argc, char** argv)
{
    std::string data = argc > 1 ? argv[1] : "../data", out = argc > 2 ? argv[2] : "../out";
    char tmpl[] = "/tmp/sessioninfo170-XXXXXX"; char* dir = mkdtemp(tmpl); std::string profile(dir);
    setenv("USERPROFILE", profile.c_str(), 1);

    std::printf("[1.6.x regressions on the 1.7.0 state]\n");
    CHECK(hm("08:15") == 495 && hm("8:15") == -1 && hm("24:00") == -1 && hm("12:60") == -1 && hm("1x:00") == -1, "strict HH:MM (#39)");
    CHECK(inWindow(15, 1410, 30) && inWindow(0, 1410, 30) && !inWindow(30, 1410, 30), "windows across midnight");
    int v = 0; CHECK(parseInt("2147483647", v) && v == INT_MAX && !parseInt("2147483648", v) && !parseInt("12min", v), "overflow-safe ints (#4)");
    double px = 0; CHECK(sil::parsePrice("7,786.65", px) && px == 7786.65 && !sil::parsePrice("7,7a6", px) && !sil::parsePrice("nan", px) && !sil::parsePrice("", px), "strict prices");
    {
        std::ofstream o(sessionPath(profile, "ES").c_str());
        o << "EXP|24:00\nWIN|ACTIVE|09:60|10:00\nWIN|OTHER|08:00|09:00\n";
        for (int i = 0; i < 65; ++i) o << "WIN|ACTIVE|23:30|00:30|x|" << i << "\n";
        for (int i = 0; i < 65; ++i) o << "CAL|08:00|High|event " << i << "\n";
    }
    SessionInfo x; x.setup();
    { cppExtension* p = CreateExtension(); CHECK(p->version == "1.7.0" && (p->xflags & CALL_CONTINUOUSLY) && (p->flags & FRONT_DRAWING), "1.7.0, FRONT_DRAWING, CALL_CONTINUOUSLY (#36)"); delete p; }
    bool bg = false; for (size_t i = 0; i < mock::params().size(); i++) if (mock::params()[i] == "Background") bg = true;
    CHECK(!bg && mock::params().size() == 5, "the dead Background setting is gone (#41): Market, Show, Font, Clock, Position");
    mock::Chart A; A.root = "ESZ26"; mock::cur() = &A;
    SIState S; x.cfg = SSet(); x.load(S);
    CHECK(S.sourceAvailable && S.D.exp.empty() && S.D.W.size() == MAX_SESSION_WINDOWS && S.D.W[0].fromMin == 1410 && S.D.news.size() == MAX_SESSION_NEWS, "parse: invalid expiry dropped, bounded windows / news");
    long long loads = S.loads; x.load(S); CHECK(S.loads == loads, "unchanged file: no re-open (#31)");
    { std::ofstream o(sessionPath(profile, "NQ").c_str()); o << std::string(70 * 1024, 'x'); }
    mock::Chart Nq; Nq.root = "NQZ26"; mock::cur() = &Nq; SIState SN; x.load(SN);
    CHECK(!SN.sourceAvailable, "oversized (70 KiB) file rejected (#33)");
    std::remove(sessionPath(profile, "NQ").c_str());
    SIState SM; x.load(SM); CHECK(!SM.sourceAvailable && SM.stamp == -1, "missing file cached");
    mock::lists()[x.SP.market] = 5; mock::lists()[x.SP.show] = 0; mock::lists()[x.SP.moveX] = 1; mock::ints()[x.SP.font] = 8; mock::ints()[x.SP.clock] = 0;
    mock::cur() = &A; x.parmsApply();
    for (int i = 0; i < 16; i++) mock::lists()[(size_t)i] = -1;
    { std::ofstream o(sessionPath(profile, "HG").c_str()); o << "EXP|12:00\n"; }
    A.drawn.clear(); x.draw();
    SIState* sa = (SIState*)A.userData;
    CHECK(sa && x.cfg.market == 5 && sa->mkt == "HG", "saved Market selection restored by the native chart market");
    mock::Chart U; U.root = "NQZ26"; mock::cur() = &U; x.draw();
    CHECK(drew(U, "NQ session data unavailable"), "missing source is explicit in the panel");
    mock::widthCalls() = 0; std::string fitted = x.fit(std::string(1024, 'a'), 100, 8, false);
    CHECK(fitted.size() > 3 && fitted.substr(fitted.size() - 3) == "..." && mock::widthCalls() <= 13, "fit: binary search, at most 13 width calls");
    std::remove(dl::placePath("SessionInfoMarket", "ES").c_str()); std::remove(dl::placePath("SessionInfoWide", "HG").c_str()); std::remove(dl::placePath("SessionInfoShow", "HG").c_str());

    mock::cur() = &A; x.destroy(); mock::cur() = &U; x.destroy(); CHECK(A.userData == nullptr && U.userData == nullptr, "destroy frees the regression charts");
    std::printf("[wide layout from today's real ES file]\n");
    std::string esReal = slurp("/mnt/user-data/uploads/lsFlexLevels/LRA-Session-ES.csv");
    sil::Inputs I; I.mkt = "ES"; I.sourceAvailable = sil::parseSession(esReal, I.D); I.now = 14 * 60 + 17; I.dow = 5; I.fs = 8;
    // E-LOD / E-HOD from today's ES bars through the same logic lsHodLod uses
    {
        std::vector<hl::Bar> B; std::ifstream f((data + "/es_chart.csv").c_str()); std::string ln;
        while (std::getline(f, ln)) { int Y, M, D, h, m, s; double o, H, L, c; if (std::sscanf(ln.c_str(), "%d-%d-%d %d:%d:%d,%lf,%lf,%lf,%lf", &Y, &M, &D, &h, &m, &s, &o, &H, &L, &c) == 10) { hl::Bar b; b.absEnd = hl::daysFromCivil(Y, M, D) * 86400 + h * 3600 + m * 60 + s; b.o = o; b.h = H; b.l = L; b.c = c; B.push_back(b); } }
        hl::Cfg c; c.mkt = 0; c.tick = 0.25; c.per = 180;
        hl::Tracker T = hl::runBars(c, B, B.size() - 1, nullptr); hl::View vw = hl::buildView(T, hl::ReadOut());
        I.haveE = true; I.eLod = vw.eLod; I.eHod = vw.eHod; std::printf("    E-LOD %.4f E-HOD %.4f\n", vw.eLod, vw.eHod);
    }
    sil::Slider SL; std::vector<sil::Section> sec = sil::build(I, SL);
    CHECK(sec.size() == 4, "4 sections: NEWS | GAMMA | RTH | EXPECTED MOVE");
    CHECK(sec[0].rows[0].segs[0].s == "NEWS" && sec[1].rows[0].segs[0].s == "GAMMA  /  Exp 3:00 PM (0h43m)", "headers: NEWS, GAMMA / Exp 3:00 PM (0h43m)");
    CHECK(sec[1].rows[0].segs[0].col == sil::C_AMBER, "countdown under 60 min: amber");
    CHECK(sec[0].rows[1].segs[0].s == "3:00 PM  FOMC Member Collins Speaks", "today's coming item first, weekday dropped: 3:00 PM  FOMC ...");
    CHECK(sec[0].rows[2].segs[0].col == sil::C_GREY, "the 9:00 items are past: grey");
    CHECK(sec[1].rows[1].segs[0].s == "NEGATIVE - levels can break" && sec[1].rows[2].segs[0].s == "HVL 7,835.00  \xB7  pin 7,850.00 (29.75 above)", "gamma regime, HVL + pin");
    CHECK(sec[1].rows.size() == 4 && sec[1].rows[3].segs[0].s == "data 211 min old", "stale data line kept");
    CHECK(sec[2].rows[0].segs[0].s == "ES RTH now: normal" && sec[2].rows.size() == 4, "RTH: header + 3 windows");
    CHECK(sec[2].rows[1].segs[0].s == "Active 8:30-10:30 AM (76%)" && sec[2].rows[1].segs[0].col == sil::C_GREEN, "Active window green");
    CHECK(sec[2].rows[2].segs[0].s == "Chop 1:00-2:15 PM (31%)" && sec[2].rows[2].segs[0].col == sil::C_AMBER, "Chop window amber");
    CHECK(sec[3].rows[0].segs[0].s == "EXPECTED MOVE  \xB7  used 12%" && sec[3].rows[1].segs[0].s == "7,786.65 - 7,913.85", "EM header + range");
    CHECK(sec[3].rows[3].segs[0].s == "spot 7,820.25 \xB7 26% up the range", "spot line");
    CHECK(SL.on && SL.pct == 26 && SL.hasE && std::fabs(SL.eLodF - (7826.00 - 7786.65) / 127.2) < 1e-5 && std::fabs(SL.eHodF - (7891.0459 - 7786.65) / 127.2) < 1e-5, "slider: spot 26%, E-LOD 31%, E-HOD 82% of the EM range (the same E values as the table)");
    CHECK(sil::gradient(0) == sil::C_RED && sil::gradient(1) == sil::C_GREEN && sil::gradient(0.5) == sil::C_SLIDER_MID, "gradient red -> grey -> green");
    hl::Box pane = { 0, 0, 1300, 740 };
    int right = (int)pane.r - (int)(pane.r * 0.15);
    hl::Box region = { 0, 18, right, 740 };
    hl::Layout L = sil::layout(sec, SL, region, 1, 8, measure);
    CHECK(L.tableOk && L.note.empty(), "wide panel drawn");
    CHECK(L.table.r <= right && L.table.t == 26 && std::abs((L.table.l + L.table.r) / 2 - right / 2) <= 1, "top centre of the region, ends before the latest bars (15% clear)");
    CHECK(L.table.b - L.table.t <= 4 * 14 + 8 + 4, "4 text rows tall (header + 3)");
    bool clean = true; std::string why;
    for (size_t i = 0; i < L.items.size(); i++) for (size_t j = i + 1; j < L.items.size(); j++) {
        const hl::Item& a = L.items[i]; const hl::Item& b = L.items[j];
        if (a.k != hl::K_TEXT || b.k != hl::K_TEXT) continue;
        if (a.l < b.r && b.l < a.r && a.t < b.b && b.t < a.b) { clean = false; why = a.s + " / " + b.s; }
    }
    for (size_t i = 0; i < L.items.size(); i++) if (L.items[i].k == hl::K_TEXT && (L.items[i].r > L.table.r || L.items[i].l < L.table.l)) { clean = false; why = "outside: " + L.items[i].s; }
    CHECK(clean, "no text overlaps, all inside the panel " + why);
    int ticks = 0, marker = 0; for (size_t i = 0; i < L.items.size(); i++) { if (L.items[i].k == hl::K_FILL && (L.items[i].c1 == sil::C_RED || L.items[i].c1 == sil::C_GREEN) && L.items[i].b - L.items[i].t == 4) ticks++; if (L.items[i].c1 == sil::C_WHITE) marker++; }
    CHECK(ticks == 2 && marker == 1, "slider: one white spot marker + E-LOD red / E-HOD green ticks");
    dumpLayout(L, pane, out + "/sessioninfo_layout.json");
    // outside the range: arrows, not ticks
    sil::Inputs I2 = I; I2.eLod = 7700; I2.eHod = 8000; sil::Slider SL2; std::vector<sil::Section> s2 = sil::build(I2, SL2);
    hl::Layout L2 = sil::layout(s2, SL2, region, 1, 8, measure);
    int t2 = 0, arrows = 0; for (size_t i = 0; i < L2.items.size(); i++) { if (L2.items[i].k == hl::K_FILL && L2.items[i].b - L2.items[i].t == 4 && L2.items[i].c1 != sil::C_WHITE) t2++; if (L2.items[i].k == hl::K_LINE && (L2.items[i].c1 == sil::C_RED || L2.items[i].c1 == sil::C_GREEN)) arrows++; }
    CHECK(t2 == 0 && arrows == 4, "E-LOD / E-HOD outside the expected move: an arrow at each end");
    dumpLayout(L2, pane, out + "/sessioninfo_layout_arrows.json");
    // narrow and short regions: a note, nothing outside
    hl::Layout L3 = sil::layout(sec, SL, hl::Box{ 0, 18, 300, 740 }, 1, 8, measure);
    CHECK(!L3.note.empty() && (L3.items.empty() || L3.items[0].r <= 300), "narrow pane: 'pane too narrow', nothing forced");
    hl::Layout L4 = sil::layout(sec, SL, hl::Box{ 0, 18, 1100, 60 }, 1, 8, measure);
    CHECK(L4.note == "pane too short", "short pane: says so");
    // Show = one section only
    sil::Inputs I5 = I; I5.show = 4; sil::Slider SL5; CHECK(sil::build(I5, SL5).size() == 1, "Show = Expected move: one section");

    std::printf("[two charts on one object, E ticks from the chart's own bars]\n");
    { std::ofstream o(sessionPath(profile, "ES").c_str()); o << esReal; }
    mock::Chart E1; loadBars(E1, data + "/es_chart.csv", "EPZ26", 0.25f); E1.pr = 1300;
    mock::Chart H1; loadBars(H1, data + "/hg_chart.csv", "CPEZ26", 0.0005f); H1.pr = 1300;
    { std::ofstream o(sessionPath(profile, "HG").c_str()); o << slurp("/mnt/user-data/uploads/lsFlexLevels/LRA-Session-HG.csv"); }
    mock::cur() = &E1; x.draw(); mock::cur() = &H1; x.draw(); mock::cur() = &E1; x.draw();
    SIState* se = (SIState*)E1.userData; SIState* sh = (SIState*)H1.userData;
    CHECK(se && sh && se != sh && se->mkt == "ES" && sh->mkt == "HG", "one state per chart");
    CHECK(se->haveE && std::fabs(se->eLod - 7826.00) < 0.01 && sh->haveE, "E-LOD natively from each chart's bars");
    CHECK(se->barCalcs == 1, "bars recomputed once for 2 draws of the same bars (#32)");
    auto drewPrefix = [](const mock::Chart& C, const std::string& p) { for (size_t i = 0; i < C.drawn.size(); i++) if (C.drawn[i].kind == 1 && C.drawn[i].s.compare(0, p.size(), p) == 0) return true; return false; };
    CHECK(drewPrefix(E1, "ES RTH now:") && !drewPrefix(E1, "HG RTH now:") && drewPrefix(H1, "HG RTH now:") && !drewPrefix(H1, "ES RTH now:"), "each chart draws its own market");
    x.destroy(); CHECK(E1.userData == nullptr, "destroy frees chart E1's state");
    mock::cur() = &H1; CHECK((SIState*)H1.userData == sh, "H1 survives"); x.done(); CHECK(H1.userData == nullptr, "done frees H1");
    if (std::system(("rm -rf '" + profile + "'*").c_str()) != 0) std::printf("cleanup failed\n");
    std::printf("\n%d passed, %d failed\n", passes, failures);
    return failures ? 1 : 0;
}
