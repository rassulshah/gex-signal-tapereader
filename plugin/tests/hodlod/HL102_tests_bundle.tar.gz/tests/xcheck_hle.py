"""Cross-check the plugin's hle::State inputs (cpp_hle_states.txt, one line per closed RTH bar) against the studies agent's own
Python (studies.session_table + fit_expected.live_state) on the same bars. usage: xcheck_hle.py <studies dir> <bars.csv> <MKT> <date> <cpp file>"""
import sys, math
sys.path.insert(0, sys.argv[1])
import pandas as pd, numpy as np
import studies as S, fit_expected as F
rows = [l.strip().split(',') for l in open(sys.argv[2])]
b = pd.DataFrame({'t': pd.to_datetime([r[0] for r in rows]), 'o': [float(r[1]) for r in rows], 'h': [float(r[2]) for r in rows],
                  'l': [float(r[3]) for r in rows], 'c': [float(r[4]) for r in rows], 'v': 0.0})
events = {}
try:
    ev = pd.read_csv(sys.argv[1] + '/events_2025_2026.csv')
    for r in ev.itertuples(index=False): events.setdefault(str(r.date)[:10], set()).add(r.event)
except Exception as e:
    print('events', e)
df, arrays = S.session_table(b, sys.argv[3], events)
row = df[df.date == sys.argv[4]].iloc[0]; a = arrays[sys.argv[4]]
cpp = [l.strip() for l in open(sys.argv[5])]
names = ['mso', 'dow', 'atr14', 'open', 'hi', 'lo', 'last'] + ['rngAt%d' % k for k in range(F.KMAX)] + ['onRange', 'prevRange', 'prevClose', 'news', 'firstSide']
bad = 0; diffs = {}
for i, t in enumerate(a['mso']):
    st = F.live_state(sys.argv[3], row, a, int(t))
    py = [st['mso'], st['dow'], st['atr14'], st['open'], st['hi'], st['lo'], st['last']] + st['rngAt'] + [st['onRange'], st['prevRange'], st['prevClose'], st['news'], st['firstSide']]
    c = [float(x) for x in cpp[i].split('|')[0].split(',')]
    for n, x, y in zip(names, py, c):
        if not (abs(float(x) - y) <= 1e-6 * (1 + abs(float(x)))):
            diffs.setdefault(n, []).append((int(t), x, y)); bad += 1
print('%d bars, %d field mismatches' % (len(a['mso']), bad))
for n, v in diffs.items(): print(' ', n, len(v), 'e.g. mso,python,plugin', v[:3])
print('news on', sys.argv[4], ':', int(row.news))
sys.exit(1 if bad else 0)
