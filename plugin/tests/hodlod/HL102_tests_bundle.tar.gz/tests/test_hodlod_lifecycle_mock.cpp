// Mock-host lifecycle test for HodLod.cpp (checklist #1, #9, #30, #31, #32, #35): ONE extension object, several charts with their
// own user-data slots - two ES charts (3-min and 6-min), an HG chart, a symbol change, a new bar, a fault, destroy.
//   g++ -std=c++14 -I mock_sdk -I ../src test_hodlod_lifecycle_mock.cpp
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <sys/stat.h>
#include "HodLod.cpp"

static int passes = 0, failures = 0;
#define CHECK(c, msg) do { if (c) ++passes; else { ++failures; std::printf("  FAIL  %s (line %d)\n", std::string(msg).c_str(), __LINE__); } } while (0)

static void loadInto(mock::Chart& C, const std::string& path, const std::string& root, float tick, double lo, double hi, int agg = 1)
{
    C.root = root; C.tick = tick; C.lo = lo; C.hi = hi; C.t.clear(); C.o.clear(); C.h.clear(); C.l.clear(); C.c.clear(); C.vol.clear();
    std::ifstream f(path.c_str()); std::string ln; int k = 0;
    while (std::getline(f, ln)) {
        int Y, M, D, h, m, s; double o, H, L, c, v = -1;
        int n = std::sscanf(ln.c_str(), "%d-%d-%d %d:%d:%d,%lf,%lf,%lf,%lf,%lf", &Y, &M, &D, &h, &m, &s, &o, &H, &L, &c, &v);
        if (n < 10) continue;
        RTDATE t = (RTDATE)(hl::daysFromCivil(Y, M, D) * 86400 + h * 3600 + m * 60 + s);
        if (agg > 1) {   // 6-min bars from 3-min: END on a multiple of 6 minutes
            bool startNew = k == 0 || ((t / 60) % 6) == 3 || t - C.t.back() > 180;
            if (!startNew) { C.t.back() = t; C.h.back() = std::max(C.h.back(), (float)H); C.l.back() = std::min(C.l.back(), (float)L); C.c.back() = (float)c; k++; continue; }
        }
        if (n == 11 && agg == 1) C.vol.push_back((unsigned long)v);       // barVolume (only when the file has it)
        C.t.push_back(t); C.o.push_back((float)o); C.h.push_back((float)H); C.l.push_back((float)L); C.c.push_back((float)c); k++;
    }
}
static std::string slurp(const std::string& p) { std::ifstream f(p.c_str()); std::stringstream s; s << f.rdbuf(); return s.str(); }
static bool drewText(const mock::Chart& C, const std::string& s) { for (size_t i = 0; i < C.drawn.size(); i++) if (C.drawn[i].kind == 1 && C.drawn[i].s == s) return true; return false; }
static bool inside(const mock::Chart& C) { for (size_t i = 0; i < C.drawn.size(); i++) { const mock::Drawn& d = C.drawn[i]; if (d.kind == 2) continue; if (d.l < C.pl || d.r > C.pr + 8 || d.t < C.pt - 12 || d.b > C.pb + 12) return false; } return true; }

int main(int argc, char** argv)
{
    std::string data = argc > 1 ? argv[1] : "../data", out = argc > 2 ? argv[2] : "../out";
    std::string prof = out + "/mockprofile"; mkdir(prof.c_str(), 0755);
    setenv("USERPROFILE", prof.c_str(), 1);
    if (std::system(("rm -f " + prof + "/HodLod*").c_str()) != 0) std::printf("cleanup failed\n");
    HodLod x; x.setup();
    CHECK(mock::params().size() == 1 && mock::params()[0] == "output:HOD/LOD:NO_UI", "no settings: one output, hidden (OUTPUT_NO_UI)");
    { cppExtension* p = CreateExtension(); CHECK((p->flags & FRONT_DRAWING) && (p->flags & INSTRUMENT_SCALE) && p->version == "1.0.0", "flags FRONT_DRAWING + INSTRUMENT_SCALE, version 1.0.0"); delete p; }

    mock::Chart A, B, H;
    loadInto(A, data + "/es_chart.csv", "EPZ26", 0.25f, 7792, 7892);
    loadInto(B, data + "/es_combined.csv", "EPZ26", 0.25f, 7792, 7892, 2);
    loadInto(H, data + "/hg_chart.csv", "CPEZ26", 0.0005f, 4.50, 4.80);

    {   // (HL101) volume from RTARRAYI(barVolume) feeds hlr::timing; a chart without it is flagged, never guessed
        std::printf("[volume -> hlr::timing]\n");
        mock::Chart V; loadInto(V, data + "/es_vol.csv", "EPZ26", 0.25f, 7700, 7900);
        CHECK(V.vol.size() == V.t.size() && V.vol.size() > 1000, "the volume array is there");
        mock::cur() = &V; x.draw();
        std::string st = slurp(prof + "/HodLod.status-ES-180.txt");
        CHECK(st.find("TIMING,pLater=") != std::string::npos && st.find("no volume") == std::string::npos, "TIMING computed with the chart's volume (no flag)");
        std::string sl = slurp(prof + "/HodLodRead.reads-ES.csv");
        CHECK(!sl.empty() && sl.find(",hlr-1.0.0") != std::string::npos, "the scorer file is written (18 columns, timing filled)");
        V.vol.clear(); V.root = "ESZ26"; x.draw();          // a new symbol, no volume array
        HLState* sv = (HLState*)V.userData;
        CHECK(sv && sv->rd.tWhy.find("no volume on the chart") != std::string::npos, "without volume: equal weights, flagged in TIMING (" + (sv ? sv->rd.tWhy : std::string("no state")) + ")");
        x.destroy(); CHECK(V.userData == nullptr, "volume chart freed");
        if (std::system(("rm -f " + prof + "/HodLod*").c_str()) != 0) std::printf("cleanup failed\n");
    }
    std::printf("[two ES charts + HG on one object]\n");
    mock::cur() = &A; x.draw();
    HLState* sa = (HLState*)A.userData;
    CHECK(sa && sa->mkt == "ES" && sa->per == 180 && sa->have, "chart A: ES, 3-min, view built");
    CHECK(drewText(A, "LOD") && drewText(A, " \xB7 LonLO") && drewText(A, "1:54pm") && drewText(A, "8:51") && drewText(A, "5h03m"), "chart A drew the candle labels");
    CHECK(drewText(A, "8:51 - 9:21  76%") && drewText(A, " LOD") && drewText(A, "  in"), "chart A drew the v15 cells (reclaim window, side word, in tag)");
    CHECK(inside(A), "chart A: everything inside the pane");
    mock::cur() = &B; x.draw();
    HLState* sb = (HLState*)B.userData;
    CHECK(sb && sb != sa && sb->per == 360, "chart B: its own state, 6-min");
    CHECK(sb->view.hodLvl == hl::LV_PF && sa->view.hodLvl == hl::LV_LON, "B (long history) names PFH, A (chart history only) LonHI: no cross-talk");
    CHECK(sb->view.took == 24 && sb->view.lodMod == 8 * 60 + 54, "B on 6-min bars: the LOD bar ends 8:54, took 24m (bar END times)");
    mock::cur() = &H; x.draw();
    HLState* sh = (HLState*)H.userData;
    CHECK(sh && sh->mkt == "HG" && sh != sa && sh != sb, "chart H: HG, own state");
    CHECK(sh->view.has && sh->view.session == "2026-10-09", "HG session built from CPEZ26 bars");
    mock::cur() = &A; x.draw();
    CHECK((HLState*)A.userData == sa && sa->view.hodLvl == hl::LV_LON, "back on A: A's state untouched");
    // status keyed by market AND seconds per bar
    std::string stA = slurp(prof + "/HodLod.status-ES-180.txt"), stB = slurp(prof + "/HodLod.status-ES-360.txt"), stH = slurp(prof + "/HodLod.status-HG-180.txt");
    CHECK(stA.find("PER,180") != std::string::npos && stB.find("PER,360") != std::string::npos && stH.find("MARKET,HG") != std::string::npos, "status files keyed by market + seconds per bar");
    CHECK(stA.find("A_1st Time,8:51 LOD  in") != std::string::npos && stA.find("A_2nd Time,1:54 HOD  in") != std::string::npos && drewText(A, "8:51"), "v15 table: 1st / 2nd with side and in tags");
    CHECK(stA.find("A_Range,43.75p  67%") != std::string::npos, "status carries the drawn table");
    std::string logA = slurp(prof + "/HodLod.reads-ES-180.csv");
    size_t rowsA = 0; for (size_t p = logA.find("\nREAD,"); p != std::string::npos; p = logA.find("\nREAD,", p + 1)) rowsA++;
    CHECK(rowsA == 130 && logA.find(",replay,") != std::string::npos && logA.find("\nOUTCOME,") != std::string::npos, "read log: 130 replayed RTH rows + the OUTCOME line");

    std::printf("[recompute / I/O only on change]\n");
    long long r0 = sa->recomputes, w0 = sa->statusWrites;
    for (int i = 0; i < 50; i++) x.draw();
    CHECK(sa->recomputes == r0, "50 repaints: no recompute (#32)");
    CHECK(sa->statusWrites == w0, "50 repaints within 2 s: no status rewrite (#31)");
    // a new bar arrives (the forming bar closes): one recompute, no duplicated log rows
    A.t.push_back(A.t.back() + 180); A.o.push_back(A.c.back()); A.h.push_back(A.c.back()); A.l.push_back(A.c.back()); A.c.push_back(A.c.back());
    x.draw();
    CHECK(sa->recomputes == r0 + 1, "a new bar: exactly one recompute");
    std::string logA2 = slurp(prof + "/HodLod.reads-ES-180.csv");
    CHECK(logA2 == logA, "post-RTH bar: the log is unchanged (no duplicate rows, OUTCOME once)");

    std::printf("[symbol change, fault quarantine, destroy]\n");
    loadInto(A, data + "/nq_chart.csv", "NQZ26", 0.25f, 24000, 26000);
    x.draw();
    CHECK((HLState*)A.userData == sa && sa->mkt == "NQ" && sa->view.market == "NQ", "symbol change on A: reset to NQ");
    A.throwOnArrays = true; A.t.push_back(A.t.back() + 180); A.o.push_back(1); A.h.push_back(1); A.l.push_back(1); A.c.push_back(1);
    x.draw();
    CHECK(sa->faulted && sa->state.find("fault") != std::string::npos, "a fault quarantines this chart only");
    mock::cur() = &H; x.draw(); CHECK(!sh->faulted && sh->have, "HG chart unaffected by A's fault");
    mock::cur() = &A; A.throwOnArrays = false; loadInto(A, data + "/es_chart.csv", "EPZ26", 0.25f, 7792, 7892); x.draw();
    CHECK(!sa->faulted && sa->mkt == "ES" && sa->have, "symbol change clears the quarantine");
    // pane too short: the table only (or a note), never drawn outside
    A.drawn.clear(); A.pb = 150; x.draw(); CHECK(inside(A), "150 px pane: nothing outside the pane");
    A.pb = 740;
    x.destroy();
    CHECK(A.userData == nullptr, "destroy frees chart A's state");
    mock::cur() = &B; CHECK((HLState*)B.userData == sb && sb->per == 360, "chart B survives A's destroy");
    x.done(); CHECK(B.userData == nullptr, "done frees chart B");
    mock::cur() = &H; x.destroy(); CHECK(H.userData == nullptr, "destroy frees chart H");
    // unknown market: nothing drawn, no files
    mock::Chart Z; loadInto(Z, data + "/es_chart.csv", "ZBZ26", 0.25f, 7792, 7892); mock::cur() = &Z; x.draw();
    CHECK(Z.drawn.empty(), "unknown market: nothing drawn");
    x.destroy();
    std::printf("\n%d passed, %d failed\n", passes, failures);
    return failures ? 1 : 0;
}
