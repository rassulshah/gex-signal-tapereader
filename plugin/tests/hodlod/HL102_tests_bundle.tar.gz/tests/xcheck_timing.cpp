// dumps the hlr::timing features the plugin computes at every closed RTH bar (one bar at a time, as live) - for xcheck_timing.py
#include "HodLodLogic.h"
#include <fstream>
using namespace hl;
int main(int argc, char** argv) {
    if (argc < 4) { fprintf(stderr, "usage: bars.csv MKT tick\n"); return 2; }
    std::ifstream f(argv[1]); std::string line; std::vector<Bar> B;
    while (std::getline(f, line)) { int y,mo,d,h,mi,se; Bar b; double v = NAN;
        int n = sscanf(line.c_str(), "%d-%d-%d %d:%d:%d,%lf,%lf,%lf,%lf,%lf", &y,&mo,&d,&h,&mi,&se,&b.o,&b.h,&b.l,&b.c,&v); if (n < 10) continue; b.v = n >= 11 ? v : NAN;
        b.absEnd = daysFromCivil(y,mo,d)*86400 + h*3600 + mi*60 + se; B.push_back(b); }
    Cfg c; c.mkt = mktIndex(argv[2]); c.per = 180; c.tick = atof(argv[3]); c.readOpen = readOpenFor(c.mkt); c.readN = readNFor(c.mkt);
    Tracker T(c); int nk = readNormKind(c.mkt);
    for (size_t i = 0; i < B.size(); i++) {
        if (!T.push(B[i])) continue;
        if (!(T.cur.any && T.cur.lastSeq == T.seq)) continue;
        ReadIn r = T.readIn(nk, 0);
        if (!r.fOk || r.mso < readNFor(c.mkt)) continue;
        ReadOut o = evalRead(r);
        printf("%s,%d,%d", dateTxt(T.cur.sid).c_str(), r.now, r.side);
        for (int k = 0; k < 14; k++) printf(",%.12g", r.f[k]);
        printf(",%.9f,%.9f,%d,%d\n", o.pLater, o.pClose, o.elseFrom, o.elseTo);
    }
}
