#!/usr/bin/env python3
"""Independent reference for the HOD/LOD definitions (written separately from HodLodLogic.h, straight from the spec).
For every closed-bar prefix of an END-stamped bar file it prints the latest session's state, one line per RTH bar:
  bar_end|open|hod@end|lod@end|first|reclaim_end|second|took|wick|gap|range
Usage: ref_hodlod.py <bars.csv: 'YYYY-MM-DD HH:MM:SS,o,h,l,c'> <open_min> <close_min> <per_sec>"""
import sys, datetime as dt


def main():
    path, op, cl, per = sys.argv[1], int(sys.argv[2]), int(sys.argv[3]), int(sys.argv[4])
    B = []
    for ln in open(path):
        t, o, h, l, c = ln.strip().split(",")
        e = dt.datetime.fromisoformat(t); B.append((e, e - dt.timedelta(seconds=per), float(o), float(h), float(l), float(c)))
    out = []
    for k in range(len(B)):
        e, s = B[k][0], B[k][1]
        day = e.date()
        a = dt.datetime.combine(day, dt.time()) + dt.timedelta(minutes=op)
        z = dt.datetime.combine(day, dt.time()) + dt.timedelta(minutes=cl)
        if not (s >= a and e <= z):
            continue
        R = [b for b in B[:k + 1] if b[0].date() == day and b[1] >= a and b[0] <= z]
        o = R[0][2]; start = R[0][1]
        hi = max(b[3] for b in R); lo = min(b[4] for b in R)
        ih = next(i for i, b in enumerate(R) if b[3] == hi); il = next(i for i, b in enumerate(R) if b[4] == lo)
        mins = lambda x: int((x - start).total_seconds() // 60)
        if ih == il:
            first, rec, second, took, wick, gap = "?", "", "", "", "", ""
        else:
            lodf = il < ih
            fi, si = (il, ih) if lodf else (ih, il)
            first = "L" if lodf else "H"
            ri = next((i for i in range(fi + 1, len(R)) if (R[i][5] >= o if lodf else R[i][5] <= o)), None)
            complete = R[-1][0] >= z
            printed = complete or (ri is not None and ri < si)
            rec = R[ri][0].strftime("%H:%M") if ri is not None else "none"
            second = R[si][0].strftime("%H:%M") if printed else "pending"
            took = str(mins(R[fi][0])); wick = str(mins(R[ri][0])) if ri is not None else ""
            gap = str(int((R[si][0] - R[fi][0]).total_seconds() // 60)) if printed else ""
        out.append("|".join([e.strftime("%H:%M"), "%g" % o, "%g@%s" % (hi, R[ih][0].strftime("%H:%M")), "%g@%s" % (lo, R[il][0].strftime("%H:%M")),
                             first, rec, second, took, wick, gap, "%g" % (hi - lo)]))
    print("\n".join(out))


if __name__ == "__main__":
    main()
