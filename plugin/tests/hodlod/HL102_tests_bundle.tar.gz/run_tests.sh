#!/bin/sh
# builds and runs every HL101 test with ASan + UBSan; exit 0 = all pass
set -e
D=$(cd "$(dirname "$0")" && pwd)
F="-std=c++14 -Wall -Wextra -g -O1 -fsanitize=address,undefined -fno-sanitize-recover=undefined"
cd "$D/tests"
g++ $F -I../src test_hodlod_logic.cpp -o ../out/t_logic
g++ $F -I mock_sdk -I ../src test_hodlod_lifecycle_mock.cpp -o ../out/t_life
g++ $F -I mock_sdk -I ../src test_sessioninfo_170.cpp -o ../out/t_si
cd "$D"
./out/t_logic data out | tail -1
python3 -I tests/ref_hodlod.py data/es_chart.csv 510 900 180 > out/ref_prefix_states.txt
cmp out/ref_prefix_states.txt out/cpp_prefix_states.txt && echo "Python reference == C++ on all $(wc -l < out/ref_prefix_states.txt) RTH prefixes"
./out/t_life data out | tail -1
./out/t_si data out | tail -1
# (HL101) leaks: 50 create/destroy cycles x 3 charts + symbol switches, LeakSanitizer on (and a self-check that it catches a leak)
cd "$D/tests" && g++ $F -I mock_sdk -I ../src test_leaks_hodlod.cpp -o ../out/t_leak_hl && g++ $F -I mock_sdk -I ../src test_leaks_si.cpp -o ../out/t_leak_si && cd "$D"
ASAN_OPTIONS=detect_leaks=1 ./out/t_leak_hl data out 50 | tail -2
ASAN_OPTIONS=detect_leaks=1 ./out/t_leak_si data 50 | tail -3
if ASAN_OPTIONS=detect_leaks=1:exitcode=23 ./out/t_leak_hl data out 1 selfcheck > /dev/null 2>&1; then echo "LeakSanitizer self-check FAILED to catch a leak"; exit 1; else echo "LeakSanitizer self-check: a deliberate 28-byte leak is caught"; fi
# the same logic tests with the read tables NOT built in ("read: building" path)
cd "$D/tests" && g++ $F -DHL_FORCE_NO_READ -I../src test_hodlod_logic.cpp -o ../out/t_logic_noread && cd "$D" && ./out/t_logic_noread data out/noread | tail -1
python3 -I tests/xcheck_read.py /mnt/user-data/outputs/lra/hodlod_read out/cpp_reads_es.csv data/es_chart.csv
# the studies agent's hle self-test (its own vectors) and the hle / hlr input cross-checks against the agents' Python
g++ -std=c++14 -Wall -Wextra -O1 -fsanitize=address,undefined -Isrc tests/hle_selftest.cpp -o out/hle_selftest && ./out/hle_selftest /mnt/user-data/outputs/lra/hodlod_studies/out/model/hle_vectors.txt | tail -1
g++ -std=c++14 -O1 -Isrc tests/xcheck_hle.cpp -o out/xcheck_hle
for m in ES:0.25:es GC:0.1:gc HG:0.0005:hg; do IFS=: read M T l <<EOT
$m
EOT
  for d in 2026-10-09 2026-10-08 2026-10-07 2026-10-06 2026-10-02; do
    ./out/xcheck_hle data/${l}_long.csv $M $T $d > out/x_$M.txt; [ -s out/x_$M.txt ] || continue
    printf "%s %s hle inputs: " $M $d; python3 -I tests/xcheck_hle.py /mnt/user-data/outputs/lra/hodlod_studies data/${l}_long.csv $M $d out/x_$M.txt 2>/dev/null | head -1
    awk -F'|' '{print $3}' out/x_$M.txt | grep -v "^,\|,nan," > out/x_read_$M.txt
    printf "%s %s read: " $M $d; python3 -I tests/xcheck_read.py /mnt/user-data/outputs/lra/hodlod_read out/x_read_$M.txt data/${l}_long.csv $M $d x 2>/dev/null | tail -1
  done
done
# (HL101) the 14 hlr::timing features vs hodlod_read.py tstates() on the IRT store bars WITH volume (sessions from 2026-09-08)
g++ -std=c++14 -O1 -Isrc tests/xcheck_timing.cpp -o out/xcheck_timing
for m in ES:0.25:es GC:0.1:gc HG:0.0005:hg NQ:0.25:nq; do IFS=: read M T l <<EOT
$m
EOT
  ./out/xcheck_timing data/${l}_vol.csv $M $T > out/xt_$M.csv
  HL_EVENTS=/mnt/user-data/outputs/lra/events_2025_2026_ext1009.csv python3 tests/xcheck_timing.py /mnt/user-data/outputs/lra/hodlod_read /mnt/user-data/uploads/level-reversal-analytics $M out/xt_$M.csv 2026-09-08 $T 2>/dev/null | tail -1
done
python3 -I tools/gen_hodlod_events.py /mnt/user-data/outputs/lra/events_2025_2026_ext1009.csv out/HodLodEvents.regen.h > /dev/null && cmp out/HodLodEvents.regen.h src/HodLodEvents.h && echo "HodLodEvents.h regenerates byte-identical"
g++ -std=c++14 -O2 -Isrc tests/bench_hodlod.cpp -o out/bench && ./out/bench
