// HL 1.0.1: Position comes from the per-market place file only; a stale IRT list index (0 = Top left) never moves the table
// (2.0.5, Rassul 2026-10-13 16:24 / 21:04) default Top centre (1); a place file holding the OLD default 7 becomes 1 ONCE per market,
// logged in HodLod.migrate-205.txt; any other value - and a 7 he saves AFTER the migration - is kept
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <unistd.h>
#include <sys/stat.h>
#include "HodLod.cpp"
static int fails = 0, passes = 0;
#define CHECK(c, m) do { if (c) ++passes; else { ++fails; std::printf("FAIL %s (line %d)\n", m, __LINE__); } } while (0)
static std::string slurp(const std::string& p) { std::ifstream f(p.c_str()); std::stringstream s; s << f.rdbuf(); return s.str(); }
int main() {
    char tmpl[] = "/tmp/hlpXXXXXX"; std::string prof = mkdtemp(tmpl); setenv("USERPROFILE", prof.c_str(), 1);
    HodLod x; x.setup();
    mock::lists()[0] = 0;                                   // IRT's stale copy: Top left
    CHECK(hl::POS_DEFAULT == 1, "2.0.5 default = 1 Top centre");
    CHECK(x.position("ES") == 1, "no place file: Top centre even when IRT says Top left");
    std::string f = x.flexPath("HodLod.place-ES.txt"), lg = x.flexPath("HodLod.migrate-205.txt");
    CHECK(slurp(lg).find("ES,") != std::string::npos && slurp(lg).find("no place file") != std::string::npos, "ES checked once and logged (no file)");
    // a fresh object (IRT restart) with an old 7 saved for NQ: migrated to 1, file rewritten, logged
    { std::ofstream o(x.flexPath("HodLod.place-NQ.txt").c_str()); o << "7\n"; }
    HodLod y; y.setup();
    CHECK(y.position("NQ") == 1, "place file 7 (old default): migrated to Top centre");
    CHECK(slurp(x.flexPath("HodLod.place-NQ.txt")) == "1\n", "the NQ place file now holds 1");
    CHECK(slurp(lg).find("NQ,") != std::string::npos && slurp(lg).find("place 7 (old default Bottom centre) -> 1 (Top centre)") != std::string::npos, "migration logged");
    // after the migration he chooses Bottom centre on purpose: kept, also by the next IRT session (a new object)
    sleep(1); { std::ofstream o(x.flexPath("HodLod.place-NQ.txt").c_str()); o << "7\n"; }
    CHECK(y.position("NQ") == 7, "a 7 saved after the migration is his choice: kept");
    HodLod z; z.setup();
    CHECK(z.position("NQ") == 7, "the next session does not migrate NQ again");
    { size_t a = slurp(lg).find("NQ,"); CHECK(a != std::string::npos && slurp(lg).find("NQ,", a + 1) == std::string::npos, "NQ logged exactly once"); }
    // another value is never touched
    { std::ofstream o(x.flexPath("HodLod.place-GC.txt").c_str()); o << "2\n"; }
    CHECK(z.position("GC") == 2 && slurp(x.flexPath("HodLod.place-GC.txt")) == "2\n", "place file 2 (his choice): Top right, file untouched");
    CHECK(slurp(lg).find("GC,") != std::string::npos && slurp(lg).find("place 2 kept") != std::string::npos, "GC logged as kept");
    sleep(1); { std::ofstream o(f.c_str()); o << "x\n"; }
    CHECK(x.position("ES") == 1, "bad place file: Top centre");
    CHECK(x.position("CL") == 1, "another market without a file: Top centre");
    { cppExtension* p = CreateExtension(); CHECK(p->version == "2.0.5", "version 2.0.5"); delete p; }
    std::printf("%d passed, %d failed\n", passes, fails); return fails;
}
