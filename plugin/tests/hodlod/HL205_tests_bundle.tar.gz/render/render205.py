import json, sys
from PIL import Image, ImageDraw, ImageFont
F = "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf"; FB = "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf"
rgb = lambda c: ((c >> 16) & 255, (c >> 8) & 255, c & 255)
def render(path):
    L = json.load(open(path)); _, _, W, H = L["pane"]; lo, hi = L["lo"], L["hi"]
    im = Image.new("RGB", (W + 1, H + 1), (11, 15, 23)); d = ImageDraw.Draw(im)
    # the IRT chart title row (kept clear)
    d.rectangle([0, 0, W, L["title"] - 1], fill=(20, 26, 36)); d.text((8, L["title"] / 2), "ESZ26  3 Minutes   (IRT chart title row - kept clear)", fill=(130, 136, 148), font=ImageFont.truetype(F, 12), anchor="lm")
    # last bar edge + the profile area to its right (never used)
    r = L["right"]; d.rectangle([r + 4, L["title"], W, H], fill=(14, 19, 29)); d.text((r + 12, H - 14), "profiles (right of the last bar)", fill=(80, 86, 98), font=ImageFont.truetype(F, 11), anchor="lm")
    d.rectangle([0, L["title"], 110, H], fill=(13, 18, 27)); d.text((6, H - 14), "Liquidity col.", fill=(80, 86, 98), font=ImageFont.truetype(F, 11), anchor="lm")
    d.rectangle([W - 250, 0, W, 46], outline=(70, 76, 90)); d.text((W - 244, 30), "Dealer Profile header (avoided)", fill=(110, 116, 128), font=ImageFont.truetype(F, 11), anchor="lm")
    y = lambda p: (hi - p) / (hi - lo) * H; bw = L["bw"]
    for x, o, h, l, c in L["bars"]:
        col = (34, 197, 94) if c >= o else (239, 68, 68)
        d.line([(x, y(h)), (x, y(l))], fill=col); d.rectangle([x - bw * 0.33, y(max(o, c)), x + bw * 0.33, y(min(o, c)) + 1], fill=col)
    fonts = {}
    for it in L["items"]:
        k = it["k"]
        if k == 0: d.rectangle([it["l"], it["t"], it["r"], it["b"]], fill=rgb(it["c1"]))
        elif k == 1: d.rectangle([it["l"], it["t"], it["r"], it["b"]], outline=rgb(it["c1"]), fill=None if it["c2"] == 0xFFFFFFFF else rgb(it["c2"]), width=max(1, it["w"]))
        elif k == 2: d.line([(it["l"], it["t"]), (it["r"], it["b"])], fill=rgb(it["c1"]), width=max(1, it["w"]))
        elif k == 3:
            key = (it["fs"], it["bold"]); fonts.setdefault(key, ImageFont.truetype(FB if it["bold"] else F, int(round(it["fs"] * 96 / 72))))
            d.text((it["l"], (it["t"] + it["b"]) / 2), it["s"], fill=rgb(it["c1"]), font=fonts[key], anchor="lm")
    return im, L
main, Lm = render(sys.argv[1])
strips = [render(p) for p in sys.argv[2:-1]]
W = main.width; hdr = 40; sh = sum((s[1]["table"][3] - s[1]["table"][1] + 34) for s in strips)
out = Image.new("RGB", (W, hdr + main.height + 30 + sh), (6, 9, 14)); d = ImageDraw.Draw(out)
d.text((12, hdr / 2), "HOD / LOD v2.0.5: header \"Regime: <Gamma> / <Trend>\" (native VWAP trend, closed bars), Position Top centre under the title row", fill=(235, 238, 242), font=ImageFont.truetype(FB, 15), anchor="lm")
out.paste(main, (0, hdr)); y0 = hdr + main.height + 6
d.text((12, y0 + 10), "Other header states (same table, the trend forced):", fill=(170, 176, 188), font=ImageFont.truetype(FB, 13), anchor="lm"); y0 += 24
for im, L in strips:
    l, t, r, b = L["table"]; crop = im.crop((l - 4, t - 4, r + 5, b + 5)); out.paste(crop, (12, y0))
    d.text((r - l + 30, y0 + (b - t) / 2), L["regime"], fill=(170, 176, 188), font=ImageFont.truetype(F, 13), anchor="lm"); y0 += b - t + 34
out.save(sys.argv[-1]); print("wrote", sys.argv[-1])
