// HOD/LOD 2.0.5 render harness: real ES bars (es_long, to argv[1]) through the 2.0.5 HodLodLogic.h layoutAll, the trend computed with
// vtl::fromChart RTH on the closed bars exactly as HodLod.cpp hlTrend() does. argv: upto from out W pos gam(NEG|POS) [forceLvl]
#include "HodLodLogic.h"
#include "VwapTrendLogic.h"
#include <fstream>
#include <cstdio>
#include "../work/tests/test_font_metrics.h"
using namespace hl;
static int measure(const std::string& s, int fs, bool bold) { double w = 0; for (size_t i = 0; i < s.size(); i++) w += (bold ? ADV_BOLD : ADV_REG)[(unsigned char)s[i]]; return (int)(w * fs * 96.0 / 72.0 / 1000.0 + 0.999); }
static std::string esc(const std::string& in) { std::string s; for (unsigned char ch : in) { if (ch == 0xB7) s += "\\u00b7"; else if (ch >= 0x80) s += "?"; else if (ch == '"' || ch == '\\') { s += '\\'; s += (char)ch; } else s += (char)ch; } return s; }
int main(int argc, char** argv) {
    const char* upto = argv[1]; const char* from = argv[2]; const char* out = argv[3]; int W = atoi(argv[4]); int pos = atoi(argv[5]);
    std::string gam = argv[6]; int force = argc > 7 ? atoi(argv[7]) : 99;
    std::vector<Bar> B; std::vector<std::string> st; std::ifstream f("../work/data/es_long.csv"); std::string ln;
    while (std::getline(f, ln)) { if (ln.compare(0, 16, upto) > 0) break; int Y, M, D, h, m, s; double o, H, L, c;
        if (std::sscanf(ln.c_str(), "%d-%d-%d %d:%d:%d,%lf,%lf,%lf,%lf", &Y, &M, &D, &h, &m, &s, &o, &H, &L, &c) < 10) continue;
        Bar b; b.absEnd = daysFromCivil(Y, M, D) * 86400 + h * 3600 + m * 60 + s; b.o = o; b.h = H; b.l = L; b.c = c; b.v = NAN; B.push_back(b); st.push_back(ln.substr(0, 16)); }
    B.pop_back(); st.pop_back();   // the forming bar is never used
    Cfg c; c.mkt = mktIndex("ES"); c.per = 180; c.tick = 0.25; c.readOpen = readOpenFor(c.mkt); c.readN = readNFor(c.mkt);
    std::vector<ReadRow> rows; Tracker T = runBars(c, B, B.size(), &rows);
    View v = buildView(T, rows.empty() ? ReadOut() : rows.back().out, &rows, nullptr);
    v.sessSegs.push_back(Seg{ gam == "NEG" ? "Regime: Negative" : "Regime: Positive", gam == "NEG" ? C_RED : C_GREEN });
    v.sessSegs.push_back(Seg{ "Expiry 3:00 PM (in 3h 18m)", C_GREY });
    // the trend, as hlTrend(): svl bars, the last RTH bar, vtl::fromChart RTH
    int om = 0, cm = 0; svl::rthOf("ES", om, cm); std::vector<svl::Bar> vb;
    for (size_t i = 0; i < B.size(); i++) { long d = (long)(B[i].absEnd / 86400); svl::Bar x; x.days = d; x.endSec = (int)(B[i].absEnd - (long long)d * 86400); x.h = B[i].h; x.l = B[i].l; x.c = B[i].c; x.v = 1.0; vb.push_back(x); }
    int k = (int)vb.size(); while (k > 0 && svl::classify(vb[k - 1].days, vb[k - 1].endSec, 180, om, cm).kind != svl::RTH) k--;
    vtl::Trend t = vtl::fromChart(vb, k, 180, om, cm, svl::RTH);
    v.trendReady = t.ready; v.trendLvl = t.ready ? vtl::level(t) : 0;
    if (force != 99) { v.trendReady = true; v.trendLvl = force; }
    std::fprintf(stderr, "trend ready %d level %d (%s)\n", (int)t.ready, vtl::level(t), vtl::displayLabel(t));
    size_t first = 0; while (first < st.size() && st[first].compare(0, 16, from) < 0) first++;
    const int PH = 620; size_t n = B.size() - first; Box pane = { 0, 0, W, PH };
    double lo = 1e9, hi = -1e9; for (size_t i = first; i < B.size(); i++) { lo = std::min(lo, B[i].l); hi = std::max(hi, B[i].h); }
    if (v.projOk) { double tp = v.projTo * 0.25; lo = std::min(lo, tp); hi = std::max(hi, tp); }
    double span = hi - lo; hi += span * 0.30; lo -= span * 0.08;
    int right = (int)(W * 0.85); double bw = (double)(right - 120) / n;
    auto xOf = [&](size_t i) { return (int)std::lround(120 + (i - first + 0.5) * bw); };
    auto yOf = [&](long long tk) { double p = tk * 0.25; return (int)std::lround((hi - p) / (hi - lo) * PH); };
    int projX = -1; for (size_t i = first; i < B.size(); i++) if (B[i].absEnd == v.projFromEnd) projX = xOf(i);
    std::vector<Box> avoid; avoid.push_back(Box{ W - 250, 0, W, 46 });                   // the Dealer Profile header (as the host)
    Opts O; Layout L = layoutAll(v, pane, yOf, measure, right, pos, projX, &avoid, &O); applyOpts(L, O);
    std::ofstream o(out);
    o << "{\"pane\":[0,0," << W << "," << PH << "],\"lo\":" << lo << ",\"hi\":" << hi << ",\"right\":" << right << ",\"title\":" << TITLE_ROW_PX << ",\"bars\":[";
    for (size_t i = first; i < B.size(); i++) o << (i > first ? "," : "") << "[" << xOf(i) << "," << B[i].o << "," << B[i].h << "," << B[i].l << "," << B[i].c << "]";
    o << "],\"bw\":" << bw << ",\"regime\":\"" << esc(regimeText(v, L.trendCompact)) << "\",\"table\":[" << L.table.l << "," << L.table.t << "," << L.table.r << "," << L.table.b << "],\"items\":[\n";
    for (size_t i = 0; i < L.items.size(); i++) { const Item& it = L.items[i];
        o << (i ? ",\n" : "") << "{\"k\":" << it.k << ",\"l\":" << it.l << ",\"t\":" << it.t << ",\"r\":" << it.r << ",\"b\":" << it.b << ",\"c1\":" << it.c1 << ",\"c2\":" << it.c2 << ",\"w\":" << it.w << ",\"fs\":" << it.fs << ",\"bold\":" << (it.bold ? "true" : "false") << ",\"s\":\"" << esc(it.s) << "\"}"; }
    o << "]}\n";
    std::fprintf(stderr, "regime '%s' table %d,%d-%d,%d\n", regimeText(v, L.trendCompact).c_str(), L.table.l, L.table.t, L.table.r, L.table.b);
}
