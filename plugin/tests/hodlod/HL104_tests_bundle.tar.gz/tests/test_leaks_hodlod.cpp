// HL101 leak / lifecycle stress for lsHodLod (checklist #1 #30 #35): 50 cycles of create -> setup -> 3 charts (ES 3-min with
// volume, ES 3-min chart-only, HG) -> draws -> symbol switches (ES -> NQ -> ES, HG -> unknown -> HG) -> a new bar -> destroy every
// chart -> delete. Run under ASan with detect_leaks=1: LeakSanitizer fails the process on any leak.
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <sys/stat.h>
#include "HodLod.cpp"
static int passes = 0, failures = 0;
#define CHECK(c, msg) do { if (c) ++passes; else { ++failures; std::printf("  FAIL  %s (line %d)\n", std::string(msg).c_str(), __LINE__); } } while (0)
static void loadInto(mock::Chart& C, const std::string& path, const char* root, float tick, size_t maxBars)
{
    C.root = root; C.tick = tick; C.lo = 7700; C.hi = 7900;
    std::ifstream f(path.c_str()); std::string ln; std::vector<std::string> L;
    while (std::getline(f, ln)) L.push_back(ln);
    size_t a = L.size() > maxBars ? L.size() - maxBars : 0;
    for (size_t i = a; i < L.size(); i++) {
        int Y, M, D, h, m, s; double o, H, Lo, c, v = -1;
        int n = std::sscanf(L[i].c_str(), "%d-%d-%d %d:%d:%d,%lf,%lf,%lf,%lf,%lf", &Y, &M, &D, &h, &m, &s, &o, &H, &Lo, &c, &v);
        if (n < 10) continue;
        C.t.push_back((RTDATE)(hl::daysFromCivil(Y, M, D) * 86400 + h * 3600 + m * 60 + s)); C.o.push_back((float)o); C.h.push_back((float)H); C.l.push_back((float)Lo); C.c.push_back((float)c);
        if (n == 11) C.vol.push_back((unsigned long)v);
    }
}
int main(int argc, char** argv)
{
    std::string data = argc > 1 ? argv[1] : "../data", out = argc > 2 ? argv[2] : "../out";
    std::string prof = out + "/leakprofile"; mkdir(prof.c_str(), 0755); setenv("USERPROFILE", prof.c_str(), 1);
    { std::ofstream o((prof + "/MenthorQLevels.csv").c_str()); o << "SYMBOL,PRICE,LABEL,PENCOLOR,PENWIDTH\nEPZ26,7850,CR 0D / GW 0D,48340,2\nCPEZ26,6.6,PS 0D,48340,2\n"; }   // (HL104) the MQ file present
    mock::Chart V, A, H;
    loadInto(V, data + "/es_vol.csv", "EPZ26", 0.25f, 3000);
    loadInto(A, data + "/es_chart.csv", "ESZ26", 0.25f, 100000);
    loadInto(H, data + "/hg_chart.csv", "CPEZ26", 0.0005f, 100000);
    mock::Chart* charts[3] = { &V, &A, &H };
    int cycles = argc > 3 ? atoi(argv[3]) : 50, freed = 0, drawn = 0;
    if (argc > 4) { int* leak = new int[7]; leak[0] = 1; std::printf("deliberate leak %d (LeakSanitizer self-check)\n", leak[0]); leak = nullptr; }
    for (int k = 0; k < cycles; k++) {
        HodLod* x = new HodLod(); x->setup();
        for (int c = 0; c < 3; c++) { mock::cur() = charts[c]; x->draw(); if (charts[c]->userData && ((HLState*)charts[c]->userData)->view.has) drawn++; }
        if (k == 0) { HLState* sv = (HLState*)V.userData; CHECK(sv && sv->rd.tOk && sv->T && sv->T->prevRanges.size() >= 5, "cycle 0: the volume chart computed the read + timing"); }
        std::string r0 = V.root; V.root = "NQZ26"; mock::cur() = &V; x->draw(); V.root = r0; x->draw();       // symbol switch and back
        std::string h0 = H.root; H.root = "ZBZ26"; mock::cur() = &H; x->draw(); H.root = h0; x->draw();
        {   // a new bar on A (copy of the last one, 3 min later), then remove it again
            mock::cur() = &A; A.t.push_back(A.t.back() + 180); A.o.push_back(A.c.back()); A.h.push_back(A.c.back()); A.l.push_back(A.c.back()); A.c.push_back(A.c.back());
            x->draw(); A.t.pop_back(); A.o.pop_back(); A.h.pop_back(); A.l.pop_back(); A.c.pop_back(); x->draw();
        }
        for (int c = 0; c < 3; c++) { mock::cur() = charts[c]; x->destroy(); if (!charts[c]->userData) freed++; }
        delete x;
        for (int c = 0; c < 3; c++) charts[c]->drawn.clear();
    }
    CHECK(drawn == 3 * cycles, "every chart got its own state on its first draw (" + std::to_string(drawn) + ")");
    CHECK(freed == 3 * cycles, "destroy() freed every chart's state (" + std::to_string(freed) + ")");
    std::printf("%d create/destroy cycles x 3 charts with symbol switches + a new bar\n%d passed, %d failed\n", cycles, passes, failures);
    return failures ? 1 : 0;
}
