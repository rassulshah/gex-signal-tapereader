import json, sys
from PIL import Image, ImageDraw, ImageFont
BG=(11,15,23); F="/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf"; FB=F.replace("Regular","Bold")
def rgb(c): return ((c>>16)&255,(c>>8)&255,c&255)
L=json.load(open(sys.argv[1])); lo,hi=L["lo"],L["hi"]; W,H=1171,641
bars=[x.strip().split(",") for x in open(sys.argv[2])]
bars=[b for b in bars if int(b[0][11:13])*60+int(b[0][14:16])>420]
im=Image.new("RGB",(W,H),BG); d=ImageDraw.Draw(im); n=len(bars); w=(1170-10)/max(n,1)
y=lambda p:(hi-p)/(hi-lo)*640
for i,b in enumerate(bars):
    o,h,l,c=map(float,b[1:5]); col=(34,197,94) if c>=o else (239,68,68); cx=(i+.5)*w
    d.line([(cx,y(h)),(cx,y(l))],fill=col); d.rectangle([cx-w*.33,y(max(o,c)),cx+w*.33,y(min(o,c))+1],fill=col)
fonts={}
for it in L["items"]:
    k=it["k"]
    if k==0: d.rectangle([it["l"],it["t"],it["r"],it["b"]],fill=rgb(it["c1"]))
    elif k==1:
        fill=None if it["c2"]==0xFFFFFFFF else rgb(it["c2"]); d.rectangle([it["l"],it["t"],it["r"],it["b"]],outline=rgb(it["c1"]),fill=fill,width=it["w"])
    elif k==2: d.line([(it["l"],it["t"]),(it["r"],it["b"])],fill=rgb(it["c1"]),width=it["w"])
    elif k==3:
        key=(it["fs"],it["bold"]); fonts.setdefault(key,ImageFont.truetype(FB if it["bold"] else F,int(round(it["fs"]*96/72))))
        d.text((it["l"],(it["t"]+it["b"])/2),it["s"],fill=rgb(it["c1"]),font=fonts[key],anchor="lm")
im.save(sys.argv[3])
