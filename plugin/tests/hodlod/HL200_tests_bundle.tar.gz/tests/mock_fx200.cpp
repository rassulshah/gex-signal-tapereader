// mockup renderer for HL 2.0.0: the real layout (HodLodLogic + HodLodFx) on ES 3-min bars with volume -> layout JSON + bars CSV
// usage: mock_fx200 <bars.csv> <day YYYY-MM-DD> <until HH:MM> <out prefix>
#include <cstdio>
#include <fstream>
#include "test_font_metrics.h"
#include "../src/HodLodFx.h"
using namespace hl;
static int measure(const std::string& s, int fs, bool bold)
{ double w = 0; for (size_t i = 0; i < s.size(); i++) w += (bold ? ADV_BOLD : ADV_REG)[(unsigned char)s[i]]; return (int)(w * fs * 96.0 / 72.0 / 1000.0 + 0.999); }
int main(int argc, char** argv)
{
    if (argc < 5) return 2;
    std::string path = argv[1], day = argv[2], until = argv[3], out = argv[4];
    std::vector<Bar> HB; std::vector<fx2::Bar> FB; std::ifstream f(path.c_str()); std::string ln; std::getline(f, ln);
    std::ofstream bo((out + "_bars.csv").c_str());
    while (std::getline(f, ln)) {
        int Y, M, D, h, m, s; double o, H, L, c, v;
        if (sscanf(ln.c_str(), "%d-%d-%d %d:%d:%d,%lf,%lf,%lf,%lf,%lf", &Y, &M, &D, &h, &m, &s, &o, &H, &L, &c, &v) != 11) continue;
        if (ln.compare(0, 16, day + " " + until) > 0) break;
        long long a = daysFromCivil(Y, M, D) * 86400 + h * 3600 + m * 60 + s;
        Bar b; b.absEnd = a; b.o = (float)o; b.h = (float)H; b.l = (float)L; b.c = (float)c; b.v = v; HB.push_back(b);
        fx2::Bar x; x.tEnd = a; x.o = o; x.h = H; x.l = L; x.c = c; x.v = v; FB.push_back(x);
        if (ln.compare(0, 10, day) == 0) bo << ln.substr(0, 19) << "," << o << "," << H << "," << L << "," << c << "\n";
    }
    HB.pop_back(); FB.pop_back();                               // the last bar is forming
    Cfg cf; cf.mkt = mktIndex("ES"); cf.tick = 0.25; cf.per = 180; cf.readOpen = readOpenFor(cf.mkt); cf.readN = readNFor(cf.mkt);
    std::vector<ReadRow> rows; ProjLock lock; Tracker T = runBars(cf, HB, HB.size(), &rows, &lock);
    View v = buildView(T, rows.empty() ? ReadOut() : rows.back().out, &rows, nullptr, &lock);
    fx2::View fv = fx2::buildView(fx2::mktIndex("ES"), FB, fx2::floorDiv(FB.back().tEnd, 86400));
    v.fxSegs = hlfx::headerLine(fv, true);
    // the day's RTH-and-overnight bars of `day` are drawn left to right across the pane by the renderer: x of bar END e
    double lo = 1e18, hi = -1e18; std::vector<long long> ends;
    for (const auto& b : FB) if (fx2::floorDiv(b.tEnd, 86400) == fx2::floorDiv(FB.back().tEnd, 86400) && (b.tEnd % 86400) / 60 > 7 * 60) { lo = std::min(lo, b.l); hi = std::max(hi, b.h); ends.push_back(b.tEnd); }
    lo -= 8; hi += 8;
    Box pane = { 0, 0, 1170, 640 };
    auto yOf = [&](long long tk) { double p = tk * 0.25; return (int)std::lround((hi - p) / (hi - lo) * 640); };
    std::function<int(double)> yPx = [&](double p) { return (int)std::lround((hi - p) / (hi - lo) * 640); };
    int markerX = -1; const int skip = 0; double w = (1170.0 - skip - 10) / std::max<size_t>(ends.size(), 1);
    for (size_t i = 0; i < ends.size(); i++) if (ends[i] == fv.formedEnd) markerX = (int)(skip + (i + 0.5) * w);
    int projX = -1; for (size_t i = 0; i < ends.size(); i++) if (ends[i] == v.projFromEnd) projX = (int)(skip + (i + 0.5) * w);
    Layout L = layoutAll(v, pane, yOf, measure, 1160, POS_DEFAULT, projX);
    hlfx::marker(L, fv, pane, markerX, yPx, measure);
    std::ofstream j((out + ".json").c_str());
    j << "{\"title\":\"HL 2.0.0\",\"pane\":[0,0,1170,640],\"lo\":" << lo << ",\"hi\":" << hi << ",\"items\":[\n";
    for (size_t i = 0; i < L.items.size(); i++) { const Item& it = L.items[i]; std::string s;
        for (char ch : it.s) { unsigned char u = (unsigned char)ch; if (u == 0xB7) s += "\\u00b7"; else if (u == 0xD7) s += "\\u00d7"; else if (u >= 0x80) s += "?"; else if (ch == '"' || ch == '\\') { s += '\\'; s += ch; } else s += ch; }
        j << (i ? ",\n" : "") << "{\"k\":" << it.k << ",\"l\":" << it.l << ",\"t\":" << it.t << ",\"r\":" << it.r << ",\"b\":" << it.b << ",\"c1\":" << it.c1 << ",\"c2\":" << it.c2 << ",\"s\":\"" << s << "\",\"fs\":" << it.fs << ",\"bold\":" << (it.bold ? 1 : 0) << ",\"w\":" << it.w << "}"; }
    j << "]}\n";
    std::string line; for (auto& g : v.fxSegs) line += g.s;
    printf("%s %s: %s\n", day.c_str(), until.c_str(), line.c_str());
    return 0;
}
