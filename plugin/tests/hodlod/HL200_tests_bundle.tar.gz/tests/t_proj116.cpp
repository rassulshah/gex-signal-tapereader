// HL 1.1.5: the projection log - one line per target change, no duplicates, 3-min only
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <unistd.h>
#include "HodLod.cpp"
static int fails = 0, passes = 0;
#define CHECK(c, m) do { if (c) ++passes; else { ++fails; std::printf("FAIL %s (line %d)\n", std::string(m).c_str(), __LINE__); } } while (0)
static void loadInto(mock::Chart& C, const std::string& path, const std::string& root, float tick, double lo, double hi, const char* upto = nullptr)
{
    C.root = root; C.tick = tick; C.lo = lo; C.hi = hi;
    std::ifstream f(path.c_str()); std::string ln;
    while (std::getline(f, ln)) { if (upto && ln.compare(0, 16, upto) > 0) break; int Y, M, D, h, m, s; double o, H, L, c;
        if (std::sscanf(ln.c_str(), "%d-%d-%d %d:%d:%d,%lf,%lf,%lf,%lf", &Y, &M, &D, &h, &m, &s, &o, &H, &L, &c) < 10) continue;
        C.t.push_back((RTDATE)(hl::daysFromCivil(Y, M, D) * 86400 + h * 3600 + m * 60 + s)); C.o.push_back((float)o); C.h.push_back((float)H); C.l.push_back((float)L); C.c.push_back((float)c); }
}
static std::string slurp(const std::string& p) { std::ifstream f(p.c_str()); std::stringstream s; s << f.rdbuf(); return s.str(); }
int main() {
    char tmpl[] = "/tmp/hlplXXXXXX"; std::string prof = mkdtemp(tmpl); setenv("USERPROFILE", prof.c_str(), 1);
    // every 3-min bar of 2026-10-09 from 09:00 to 15:00, a fresh plugin state each time (= an IRT restart at every bar)
    std::string prevKey, prevTgt; int changes = 0, anchorChanges = 0, bad = 0, n = 0;
    for (int mod = 9 * 60; mod <= 15 * 60; mod += 3) {
        char u[32]; snprintf(u, sizeof u, "2026-10-09 %02d:%02d", mod / 60, mod % 60);
        HodLod x; x.setup(); mock::Chart A; loadInto(A, "../data/es_long.csv", "EPZ26", 0.25f, 7700, 7950, u); mock::cur() = &A; x.draw();
        HLState* S = (HLState*)A.userData;
        if (S && S->view.projOk) {
            n++;
            std::string key = std::string(S->view.projUp ? "L" : "H") + std::to_string(S->view.projFrom), tgt = std::to_string(S->view.projTo);
            if (!prevKey.empty() && key != prevKey) anchorChanges++;
            if (!prevTgt.empty() && tgt != prevTgt) { changes++; if (key == prevKey) { bad++; std::printf("  target moved with the same 1st extreme at %s: %s -> %s\n", u, prevTgt.c_str(), tgt.c_str()); } }
            if (key != prevKey) std::printf("  %s 1st extreme %s -> %s (set %s)\n", u, key.c_str(), S->view.projTxt.c_str(), hl::clkAmPm(S->view.projLockMod).c_str());
            prevKey = key; prevTgt = tgt;
        }
        x.destroy();
    }
    CHECK(n > 50, "projection shown on most bars (" + std::to_string(n) + ")");
    CHECK(bad == 0, "the target never moves while the 1st extreme holds");
    CHECK(changes == anchorChanges, "every target change is a 1st-extreme change (" + std::to_string(changes) + " / " + std::to_string(anchorChanges) + ")");
    {   // live (one state, bar by bar) == restart at the end: no repaint
        // (1.1.8, review: "the tests do not destroy every chart state") ONE chart that grows bar by bar = the live chart, destroyed once
        HodLod x; x.setup(); std::string live; mock::Chart A;
        for (int mod = 9 * 60; mod <= 15 * 60; mod += 3) { char u[32]; snprintf(u, sizeof u, "2026-10-09 %02d:%02d", mod / 60, mod % 60);
            A.t.clear(); A.o.clear(); A.h.clear(); A.l.clear(); A.c.clear();
            loadInto(A, "../data/es_long.csv", "EPZ26", 0.25f, 7700, 7950, u); mock::cur() = &A; x.draw(); HLState* S = (HLState*)A.userData; if (S) live = S->view.projTxt; }
        CHECK(live == "" || live.find("Proj") == 0, "live target text: " + live);
        HodLod y; y.setup(); mock::Chart B; loadInto(B, "../data/es_long.csv", "EPZ26", 0.25f, 7700, 7950, "2026-10-09 15:00"); mock::cur() = &B; y.draw();
        HLState* S2 = (HLState*)B.userData;
        CHECK(S2 && S2->view.projTxt == live, "a restart shows the same target: [" + (S2 ? S2->view.projTxt : std::string()) + "] vs live [" + live + "]");
        std::string st = slurp(y.flexPath("HodLod.proj-ES.csv")); int lines = 0; for (char ch : st) if (ch == '\n') lines++;
        std::printf("%s", st.c_str());
        CHECK(lines - 1 == anchorChanges + 1, "the log has one line per 1st extreme (" + std::to_string(lines - 1) + ")");
        mock::cur() = &A; x.destroy(); mock::cur() = &B; y.destroy();
    }
    std::printf("%d passed, %d failed\n", passes, fails); return fails;
}
