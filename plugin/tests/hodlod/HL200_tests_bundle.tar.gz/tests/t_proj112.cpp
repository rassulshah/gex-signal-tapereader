// HL 1.1.0: the projection line + flag + "Proj HOD" text, the target after Range in the header, PROJ in the status file
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <unistd.h>
#include "HodLod.cpp"
static int fails = 0, passes = 0;
#define CHECK(c, m) do { if (c) ++passes; else { ++fails; std::printf("FAIL %s (line %d)\n", std::string(m).c_str(), __LINE__); } } while (0)
static void loadInto(mock::Chart& C, const std::string& path, const std::string& root, float tick, double lo, double hi, const char* upto = nullptr)
{
    C.root = root; C.tick = tick; C.lo = lo; C.hi = hi;
    std::ifstream f(path.c_str()); std::string ln;
    while (std::getline(f, ln)) { if (upto && ln.compare(0, 16, upto) > 0) break; int Y, M, D, h, m, s; double o, H, L, c;
        if (std::sscanf(ln.c_str(), "%d-%d-%d %d:%d:%d,%lf,%lf,%lf,%lf", &Y, &M, &D, &h, &m, &s, &o, &H, &L, &c) < 10) continue;
        C.t.push_back((RTDATE)(hl::daysFromCivil(Y, M, D) * 86400 + h * 3600 + m * 60 + s)); C.o.push_back((float)o); C.h.push_back((float)H); C.l.push_back((float)L); C.c.push_back((float)c); }
}
static std::string slurp(const std::string& p) { std::ifstream f(p.c_str()); std::stringstream s; s << f.rdbuf(); return s.str(); }
static std::string line(const std::string& st, const std::string& k) { size_t p = st.find("\n" + k + ","); if (p == std::string::npos) return ""; size_t e = st.find('\n', p + 1); return st.substr(p + 1, e - p - 1); }

static int vlineX(const mock::Chart& A, int minLen) { int x = -1; for (const auto& d : A.drawn) if (d.kind == 2 && d.l == d.r && std::abs(d.b - d.t) >= minLen) x = d.l; return x; }
static bool hasText(const mock::Chart& A, const std::string& pre) { for (const auto& d : A.drawn) if (d.kind == 1 && d.s.compare(0, pre.size(), pre) == 0) return true; return false; }
static std::string textOf(const mock::Chart& A, const std::string& pre) { for (const auto& d : A.drawn) if (d.kind == 1 && d.s.compare(0, pre.size(), pre) == 0) return d.s; return ""; }
int main() {
    char tmpl[] = "/tmp/hlpkXXXXXX"; std::string prof = mkdtemp(tmpl); setenv("USERPROFILE", prof.c_str(), 1);
    {   // 1.1.2: the line stands ON the 1st extreme's candle (8:51 LOD), not beside the table
        HodLod x; x.setup();
        mock::Chart A; loadInto(A, "../data/es_long.csv", "EPZ26", 0.25f, 7790, 7890); mock::cur() = &A; x.draw();
        HLState* S = (HLState*)A.userData;
        int lx = vlineX(A, 20);
        PNT p; p.set(S->projIdx, (float)(S->view.projFrom * S->tick), kBarCenter);
        std::printf("  line x %d, bar x %d, table %d..%d\n", lx, (int)p.h, (int)A.drawn.size() ? 0 : 0, 0);
        CHECK(S && S->projIdx >= 0 && lx == (int)p.h, "the line is on the extreme's candle (x " + std::to_string(lx) + " vs bar " + std::to_string((int)p.h) + ")");
        CHECK(hasText(A, "Proj HOD "), "target text drawn");
        x.destroy();
    }
    {   // the target past the top of the pane: the line runs to the edge, the text says (above) - never missing
        HodLod x; x.setup();
        mock::Chart A; loadInto(A, "../data/es_long.csv", "EPZ26", 0.25f, 7815, 7850, "2026-10-09 10:03"); mock::cur() = &A; x.draw();
        HLState* S = (HLState*)A.userData;
        std::string t = textOf(A, "Proj HOD ");
        std::printf("  off-pane text: [%s]\n", t.c_str());
        CHECK(S && S->view.projOk && t.empty() && S->view.headLeftTxt.find("Proj HOD") != std::string::npos, "(1.1.3) off-pane target: line + flag only, the price in the header: [" + t + "]");
        std::string st = slurp(x.flexPath("HodLod.status-ES-180.txt"));
        CHECK(line(st, "PROJ").find(",drawn") != std::string::npos, "status says drawn: " + line(st, "PROJ"));
        x.destroy();
    }
    {   // the label never overlaps the table
        HodLod x; x.setup();
        mock::Chart A; loadInto(A, "../data/es_long.csv", "EPZ26", 0.25f, 7790, 7890); mock::cur() = &A; x.draw();
        HLState* S = (HLState*)A.userData; (void)S;
        std::string st = slurp(x.flexPath("HodLod.status-ES-180.txt"));
        std::string tb = line(st, "TABLE_BOX"); int tl, tt, tr, tbm; std::sscanf(tb.c_str(), "TABLE_BOX,%d,%d,%d,%d", &tl, &tt, &tr, &tbm);
        bool ok = true; for (const auto& d : A.drawn) if (d.kind == 1 && d.s.compare(0, 5, "Proj ") == 0) ok = !(d.l < tr && tl < d.r && d.t < tbm && tt < d.b);
        CHECK(ok, "label clear of the table " + tb);
        x.destroy();
    }
    std::printf("%d passed, %d failed\n", passes, fails); return fails;
}
