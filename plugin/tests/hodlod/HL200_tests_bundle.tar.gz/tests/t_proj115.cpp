// HL 1.1.5: the projection log - one line per target change, no duplicates, 3-min only
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <unistd.h>
#include "HodLod.cpp"
static int fails = 0, passes = 0;
#define CHECK(c, m) do { if (c) ++passes; else { ++fails; std::printf("FAIL %s (line %d)\n", std::string(m).c_str(), __LINE__); } } while (0)
static void loadInto(mock::Chart& C, const std::string& path, const std::string& root, float tick, double lo, double hi, const char* upto = nullptr)
{
    C.root = root; C.tick = tick; C.lo = lo; C.hi = hi;
    std::ifstream f(path.c_str()); std::string ln;
    while (std::getline(f, ln)) { if (upto && ln.compare(0, 16, upto) > 0) break; int Y, M, D, h, m, s; double o, H, L, c;
        if (std::sscanf(ln.c_str(), "%d-%d-%d %d:%d:%d,%lf,%lf,%lf,%lf", &Y, &M, &D, &h, &m, &s, &o, &H, &L, &c) < 10) continue;
        C.t.push_back((RTDATE)(hl::daysFromCivil(Y, M, D) * 86400 + h * 3600 + m * 60 + s)); C.o.push_back((float)o); C.h.push_back((float)H); C.l.push_back((float)L); C.c.push_back((float)c); }
}
static std::string slurp(const std::string& p) { std::ifstream f(p.c_str()); std::stringstream s; s << f.rdbuf(); return s.str(); }
int main() {
    char tmpl[] = "/tmp/hlpjXXXXXX"; std::string prof = mkdtemp(tmpl); setenv("USERPROFILE", prof.c_str(), 1);
    HodLod x; x.setup();
    const char* T[] = { "2026-10-09 08:45", "2026-10-09 09:03", "2026-10-09 09:06", "2026-10-09 09:06", "2026-10-09 10:03", "2026-10-09 11:33", "2026-10-09 13:03", "2026-10-09 14:57" };
    std::string last; int draws = 0;
    for (const char* u : T) {
        mock::Chart A; loadInto(A, "../data/es_long.csv", "EPZ26", 0.25f, 7700, 7950, u); mock::cur() = &A; x.draw(); draws++;
        HLState* S = (HLState*)A.userData;
        if (S) std::printf("  %s projOk=%d %s\n", u, (int)S->view.projOk, S->view.projTxt.c_str());
        x.destroy(); x.setup();   // a fresh chart state each time: the dedupe must still hold within one state, checked below
    }
    std::string p = x.flexPath("HodLod.proj-ES.csv"), st = slurp(p);
    std::printf("%s", st.c_str());
    int n = 0; for (char ch : st) if (ch == '\n') n++;
    CHECK(st.compare(0, 8, "session,") == 0, "header written");
    {   std::istringstream is(st); std::string ln, prev; bool dup = false; std::getline(is, ln);
        while (std::getline(is, ln)) { std::string k = ln.substr(0, 10) + ln.substr(ln.find(',', 11)); size_t c3 = 0; for (int i = 0; i < 5; i++) c3 = ln.find(',', c3 + 1);
            std::string kk = ln.substr(0, 10) + "|" + ln.substr(17, c3 - 17); (void)k; std::string side_t = kk; size_t fpos = side_t.find(',', 15);
            std::string key = ln.substr(0, 10) + ln.substr(16, 4) + ln.substr(ln.find(',', ln.find(',', 21) + 1)); key = key.substr(0, key.find(',', 15));
            (void)fpos; if (ln.substr(16, 3) + ln.substr(ln.find(',', ln.find(',', 20) + 1), 10) == prev) dup = true; prev = ln.substr(16, 3) + ln.substr(ln.find(',', ln.find(',', 20) + 1), 10); }
        CHECK(!dup, "no duplicate lines after restarts"); }
    CHECK(n >= 2, "target changes logged (" + std::to_string(n - 1) + ")");
    CHECK(st.find("08:45") == std::string::npos, "nothing before 30 min after the open");
    CHECK(st.find(",v2,") != std::string::npos || st.find(",v1,") != std::string::npos, "model column");
    {   // same state, same bars drawn twice -> one line only
        mock::Chart A; loadInto(A, "../data/es_long.csv", "EPZ26", 0.25f, 7700, 7950, "2026-10-09 12:03"); mock::cur() = &A;
        std::string before = slurp(p); x.draw(); std::string mid = slurp(p); x.draw(); std::string after = slurp(p);
        CHECK(mid.size() >= before.size() && after == mid, "a redraw with no change writes nothing");
        x.destroy();   // (1.1.8) free this chart's state (clean LeakSanitizer run)
    }
    std::printf("%d passed, %d failed\n", passes, fails); return fails;
}
