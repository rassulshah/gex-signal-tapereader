// HL 1.1.8: the day's FIRST IN call (HodLod.firstcall-<MKT>.csv) - once per session, immutable, restart-safe, 3-min only,
// and its price / formation time match the session's own running extreme at the declaration bar.
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <map>
#include <unistd.h>
#include "HodLod.cpp"
static int fails = 0, passes = 0;
#define CHECK(c, m) do { if (c) ++passes; else { ++fails; std::printf("FAIL %s (line %d)\n", std::string(m).c_str(), __LINE__); } } while (0)
static void loadInto(mock::Chart& C, const std::string& path, const std::string& root, float tick, double lo, double hi, const char* upto = nullptr)
{
    C.root = root; C.tick = tick; C.lo = lo; C.hi = hi;
    C.t.clear(); C.o.clear(); C.h.clear(); C.l.clear(); C.c.clear();
    std::ifstream f(path.c_str()); std::string ln;
    while (std::getline(f, ln)) { if (upto && ln.compare(0, 16, upto) > 0) break; int Y, M, D, h, m, s; double o, H, L, c;
        if (std::sscanf(ln.c_str(), "%d-%d-%d %d:%d:%d,%lf,%lf,%lf,%lf", &Y, &M, &D, &h, &m, &s, &o, &H, &L, &c) < 10) continue;
        C.t.push_back((RTDATE)(hl::daysFromCivil(Y, M, D) * 86400 + h * 3600 + m * 60 + s)); C.o.push_back((float)o); C.h.push_back((float)H); C.l.push_back((float)L); C.c.push_back((float)c); }
}
static std::string slurp(const std::string& p) { std::ifstream f(p.c_str()); std::stringstream s; s << f.rdbuf(); return s.str(); }
static std::vector<std::string> lines(const std::string& s) { std::vector<std::string> v; std::istringstream is(s); std::string l; while (std::getline(is, l)) v.push_back(l); return v; }
static std::vector<std::string> cols(const std::string& l) { std::vector<std::string> c; size_t a = 0, b; while ((b = l.find(',', a)) != std::string::npos) { c.push_back(l.substr(a, b - a)); a = b + 1; } c.push_back(l.substr(a)); return c; }
static int mod(const std::string& hhmm) { return std::atoi(hhmm.substr(0, 2).c_str()) * 60 + std::atoi(hhmm.substr(3, 2).c_str()); }

int main() {
    char tmpl[] = "/tmp/hlfcXXXXXX"; std::string prof = mkdtemp(tmpl); setenv("USERPROFILE", prof.c_str(), 1);
    // 1. synthetic rows: the first IN row wins; FOMC-paused and below-threshold rows are skipped
    {   std::vector<hl::ReadRow> rr(4);
        for (size_t i = 0; i < rr.size(); i++) { rr[i].session = "2026-10-09"; rr[i].barEnd = 540 + 3 * (int)i; rr[i].out.state = 1; rr[i].in.t1Mod = 520; rr[i].readPx = 31000; rr[i].in.side = 0; }
        rr[0].out.pIn = 0.65; rr[0].out.callIn = false;
        rr[1].out.pIn = 0.80; rr[1].out.callIn = false; rr[1].out.fomcPause = true;     // paused: callIn is false by construction
        rr[2].out.pIn = 0.72; rr[2].out.callIn = true;
        rr[3].out.pIn = 0.95; rr[3].out.callIn = true; rr[3].in.side = 1; rr[3].readPx = 31100;
        hl::FirstCall f = hl::firstCall(rr);
        CHECK(f.ok && f.declared == 546 && f.side == 0 && f.px == 31000 && f.formed == 520, "first IN row is the call; a later stronger call does not replace it");
        std::string ln = hl::firstCallLine(f, 0.25, 2);
        CHECK(ln.find("2026-10-09,LOD,7750,08:40,09:06,26,0.720000,") == 0 && ln.find(",0.70,0,") != std::string::npos, "line: " + ln);
        rr.resize(2); CHECK(!hl::firstCall(rr).ok, "no IN row = no call (a no-call day writes nothing)");
    }
    // 2. live: one chart growing bar by bar through 2026-10-09; the file gets ONE line and it never changes afterwards
    std::string p, firstSeen; int writes = 0;
    {   HodLod x; x.setup(); mock::Chart A;
        for (int m = 8 * 60 + 30; m <= 15 * 60; m += 3) { char u[32]; snprintf(u, sizeof u, "2026-10-09 %02d:%02d", m / 60, m % 60);
            loadInto(A, "../data/es_long.csv", "EPZ26", 0.25f, 7700, 7950, u); mock::cur() = &A; x.draw();
            p = x.flexPath("HodLod.firstcall-ES.csv"); std::string st, all = slurp(p);   // (a load before the open logs 10-08's call: the latest session)
            for (const std::string& l : lines(all)) if (l.compare(0, 11, "2026-10-09,") == 0) st += l + "\n";
            if (!st.empty() && firstSeen.empty()) { firstSeen = st; writes++; std::printf("  10-09 call written at %s: %s", u, st.c_str()); }
            if (!firstSeen.empty() && st != firstSeen) { CHECK(false, std::string("the call line changed at ") + u); break; }
        }
        mock::cur() = &A; x.destroy();
    }
    CHECK(!firstSeen.empty(), "2026-10-09 has a first call");
    std::vector<std::string> L = lines(firstSeen); L.insert(L.begin(), lines(slurp(p))[0]);
    CHECK(L.size() == 2 && L[0] == hl::FIRSTCALL_HEADER, "header + one 10-09 line");
    const std::string fileAtClose = slurp(p);
    // 3. a restart at the close (fresh state, whole day replayed) writes nothing new
    {   HodLod y; y.setup(); mock::Chart B; loadInto(B, "../data/es_long.csv", "EPZ26", 0.25f, 7700, 7950, "2026-10-09 15:00"); mock::cur() = &B; y.draw();
        CHECK(slurp(p) == fileAtClose, "restart: same file, no second line");
        HLState* S = (HLState*)B.userData;
        CHECK(S && S->fcSession == "2026-10-09", "restart recognises the session already on file");
        y.destroy();
    }
    // 4. the call matches the bars: price = the running RTH extreme at the declaration bar, formed = the bar it printed on
    {   std::vector<std::string> c = cols(L[1]);
        CHECK(c.size() == 12, "12 columns");
        int formed = mod(c[3]), declared = mod(c[4]); double px = std::atof(c[2].c_str()), pin = std::atof(c[6].c_str());
        CHECK(declared >= formed && std::atoi(c[5].c_str()) == declared - formed, "declared after formed, lag = difference");
        CHECK(pin >= 0.70 - 1e-9, "probability at or above the 70% threshold");
        CHECK(declared >= 8 * 60 + 30 + 30, "declared after the opening range (30 min)");
        double runLo = 1e18, runHi = -1e18; int loEnd = -1, hiEnd = -1;
        std::ifstream f("../data/es_long.csv"); std::string ln;
        while (std::getline(f, ln)) { if (ln.compare(0, 10, "2026-10-09")) continue; int h = std::atoi(ln.substr(11, 2).c_str()), mi = std::atoi(ln.substr(14, 2).c_str()), e = h * 60 + mi;
            if (e <= 8 * 60 + 30 || e > declared) continue;
            std::vector<std::string> b = cols(ln); double H = std::atof(b[2].c_str()), Lo = std::atof(b[3].c_str());
            if (Lo < runLo) { runLo = Lo; loEnd = e; }
            if (H > runHi) { runHi = H; hiEnd = e; } }
        bool lod = c[1] == "LOD";
        CHECK(std::fabs(px - (lod ? runLo : runHi)) < 1e-9, "price = the running " + c[1] + " at the declaration bar");
        CHECK(formed == (lod ? loEnd : hiEnd), "formed = the bar that extreme first printed on");
        CHECK(lod ? loEnd < hiEnd : hiEnd < loEnd, "the called side printed first");
    }
    // 5. many sessions: a restart at each close; one line per session with a call, never two, all immutable
    {   const char* D[] = { "2026-09-22", "2026-09-23", "2026-09-24", "2026-09-25", "2026-09-28", "2026-09-29", "2026-09-30", "2026-10-01", "2026-10-02",
                            "2026-10-05", "2026-10-06", "2026-10-07", "2026-10-08", "2026-10-09" };
        for (const char* d : D) for (int rep = 0; rep < 2; rep++) {   // twice: the second pass must add nothing
            std::string u = std::string(d) + " 15:00"; HodLod z; z.setup(); mock::Chart C; loadInto(C, "../data/es_long.csv", "EPZ26", 0.25f, 7600, 8000, u.c_str());
            mock::cur() = &C; z.draw(); z.destroy(); }
        std::vector<std::string> A = lines(slurp(p)); std::map<std::string, int> per;
        for (size_t i = 1; i < A.size(); i++) per[A[i].substr(0, 10)]++;
        bool once = true; for (auto& kv : per) once = once && kv.second == 1;
        std::printf("  %zu of 14 sessions have a first call\n", per.size());
        CHECK(once, "one line per session");
        CHECK(per.size() >= 1 && per.size() <= 14, "calls recorded only for sessions that had one");
        CHECK(std::find(A.begin(), A.end(), L[1]) != A.end(), "the 10-09 line is unchanged");
    }
    // 6. a 6-min chart writes no call file (3-min only)
    {   char t2[] = "/tmp/hlfc6XXXXXX"; std::string p6 = mkdtemp(t2); setenv("USERPROFILE", p6.c_str(), 1);
        HodLod w; w.setup(); mock::Chart E; loadInto(E, "../data/es_long.csv", "EPZ26", 0.25f, 7700, 7950, "2026-10-09 15:00");
        std::vector<RTDATE> t6; std::vector<float> o6, h6, l6, c6;
        for (size_t i = 0; i + 1 < E.t.size(); i += 2) { t6.push_back(E.t[i + 1]); o6.push_back(E.o[i]); h6.push_back(std::max(E.h[i], E.h[i + 1])); l6.push_back(std::min(E.l[i], E.l[i + 1])); c6.push_back(E.c[i + 1]); }
        E.t = t6; E.o = o6; E.h = h6; E.l = l6; E.c = c6; mock::cur() = &E; w.draw();
        CHECK(slurp(w.flexPath("HodLod.firstcall-ES.csv")).empty(), "6-min chart: no first-call file");
        w.destroy();
    }
    std::printf("%d passed, %d failed\n", passes, fails); return fails;
}
