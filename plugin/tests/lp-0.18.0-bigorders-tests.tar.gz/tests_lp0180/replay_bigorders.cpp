// replay_bigorders.cpp -- feeds a recorded order-by-order file (data\mbo\live\<MKT>\<day>.(mbo|dbo).csv.gz, Chicago time,
// time|action|price|prev_price|size|order_id|aggressor_id|side|bid|ask) through bol::Engine exactly as the plugin does
// (3-min bars built from the fills for the 14-bar ATR; the price = the last fill) and prints the lines per hour, how they
// ended and examples. Usage: zcat FILE | ./replay MKT TICK [floor]
#include "BigOrderLines.h"
#include <iostream>
#include <cstring>
#include <map>
static long long parseT(const char* s) {   // "2026-10-14 06:57:05" -> Central ms (days since 1970 * 86400000 + seconds)
    int y, mo, d, h, mi, se; if (std::sscanf(s, "%d-%d-%d %d:%d:%d", &y, &mo, &d, &h, &mi, &se) != 6) return 0;
    y -= mo <= 2; const long long era = (y >= 0 ? y : y - 399) / 400; const unsigned yoe = (unsigned)(y - era * 400);
    const unsigned doy = (153 * (mo + (mo > 2 ? -3 : 9)) + 2) / 5 + d - 1; const unsigned doe = yoe * 365 + yoe / 4 - yoe / 100 + doy;
    const long long days = era * 146097 + (long long)doe - 719468;
    return (days * 86400LL + h * 3600LL + mi * 60LL + se) * 1000LL;
}
int main(int argc, char** argv) {
    if (argc < 3) return 2;
    const std::string mkt = argv[1]; const double tick = std::atof(argv[2]);
    bol::Engine E; E.tick = tick; E.P.floor = argc > 3 && std::atoll(argv[3]) > 0 ? std::atoll(argv[3]) : bol::floorFor(mkt);
    if (argc > 4) E.P.dwellMs = std::atoll(argv[4]); if (argc > 5) E.P.leaveMs = std::atoll(argv[5]);
    std::vector<double> H, L, C; long long bucket = -1; double h = 0, l = 0, c = 0; bool any = false;
    std::string line; long long n = 0, back = 0, lastT = 0, firstT = 0; std::vector<std::pair<long long, double>> trades;
    std::getline(std::cin, line);
    while (std::getline(std::cin, line)) {
        char* f[10]; int k = 0; char* p = &line[0]; f[k++] = p;
        for (; *p && k < 10; ++p) if (*p == '|') { *p = 0; f[k++] = p + 1; }
        if (k < 8) continue;
        const long long t = parseT(f[0]); if (t <= 0) continue;
        if (lastT && t < lastT - 6LL * 3600000) { ++back; break; }    // another day appended: stop
        if (!firstT) firstT = t;
        lastT = std::max(lastT, t);
        const char* a = f[1]; const int act = !std::strcmp(a, "NEW") ? 0 : !std::strcmp(a, "MOD") ? 1 : !std::strcmp(a, "DEL") ? 2 : !std::strcmp(a, "FILL") ? 3 : 9;
        const double px = std::atof(f[2]); const long long sz = (long long)std::atof(f[4]); const long long id = std::atoll(f[5]);
        const int side = f[7][0] == 'B' ? bol::BID : f[7][0] == 'S' ? bol::ASK : -1;
        const long long b = t / 180000;
        if (act == 3 && px > 0) {
            if (trades.empty() || trades.back().first != t || trades.back().second != px) trades.push_back(std::make_pair(t, px));
            if (b != bucket) {
                if (any) { H.push_back(h); L.push_back(l); C.push_back(c); E.setAtr(bol::atr14(H, L, C)); }
                bucket = b; h = l = c = px; any = true;
            } else { h = std::max(h, px); l = std::min(l, px); c = px; }
        }
        bol::Tick tk = (bol::Tick)std::llround(px / tick);
        E.onEvent(act, side, tk, sz, id, t);
        ++n;
    }
    for (int s = 0; s < 2; ++s) if (E.live[s] >= 0) {}
    // stats
    std::map<int, int> perHour[2]; std::map<int, int> ends; int quick = 0, quickNoTrade = 0; long long restSum = 0; int restN = 0;
    for (size_t i = 0; i < E.lines.size(); ++i) {
        const bol::Line& Ln = E.lines[i];
        const int hr = (int)(Ln.tStart / 1000 % 86400 / 3600);
        perHour[Ln.side][hr]++; ends[Ln.end]++;
        const long long d = (Ln.end == bol::RESTING ? lastT : Ln.tEnd) - Ln.tStart;
        if (d < 3000) { ++quick; if (Ln.traded == 0) ++quickNoTrade; }
        restSum += d; ++restN;
    }
    std::printf("%s floor %lld tick %g: %lld events %s..%s (%s), ATR reach %lld ticks at end (ATR %.2f), min lots at end %lld (hist n %lld p99.9 %lld)\n",
        mkt.c_str(), E.P.floor, tick, n, bol::clock12(firstT).c_str(), bol::clock12(lastT).c_str(), back ? "stopped at a later segment" : "whole file",
        E.reach, E.atrPrice, E.threshold(), E.hist.n, E.hist.pct(0.999));
    std::printf("  lines: %zu (bid %lld, offer %lld); ended:", E.lines.size(), E.lineN[0], E.lineN[1]);
    for (std::map<int, int>::iterator i = ends.begin(); i != ends.end(); ++i) std::printf(" %s %d", bol::endWord(i->first), i->second);
    std::printf("; under 3 s: %d (%d with no trade); median-ish mean rest %s\n", quick, quickNoTrade, bol::dur(restN ? restSum / restN : 0).c_str());
    std::printf("  per hour (CT) bid/offer:");
    for (int hr = 0; hr < 24; ++hr) { const int b = perHour[0].count(hr) ? perHour[0][hr] : 0, s = perHour[1].count(hr) ? perHour[1][hr] : 0; if (b || s) std::printf(" %02d:%d/%d", hr, b, s); }
    std::printf("\n");
    // examples: the biggest few filled / pulled lines
    std::vector<size_t> idx(E.lines.size()); for (size_t i = 0; i < idx.size(); ++i) idx[i] = i;
    std::sort(idx.begin(), idx.end(), [&](size_t a, size_t b) { return E.lines[a].size0 > E.lines[b].size0; });
    int shownF = 0, shownP = 0, shownO = 0;
    for (size_t j = 0; j < idx.size(); ++j) {
        const bol::Line& Ln = E.lines[idx[j]];
        int* cnt = Ln.end == bol::FILLED ? &shownF : (Ln.end == bol::PULLED || Ln.end == bol::MOVED) ? &shownP : &shownO;
        if (*cnt >= 2) continue;
        ++*cnt;
        const long long tEnd = Ln.end == bol::RESTING ? lastT : Ln.tEnd;
        std::printf("  e.g. %s at %s from %s to %s (%s): %s - traded %lld, cancelled %lld%s\n", bol::label(Ln).c_str(), bol::price(Ln.px, tick).c_str(),
            bol::clock12(Ln.tStart).c_str(), bol::clock12(tEnd).c_str(), bol::dur(tEnd - Ln.tStart).c_str(), bol::endWord(Ln.end), Ln.traded, Ln.cancelled,
            Ln.startKnown ? "" : " (start not known)");
    }
    // what price did 5 minutes after each FILLED / PULLED line ended (in the line's favour: up after a bid, down after an offer)
    auto pxAt = [&](long long t) { auto it = std::upper_bound(trades.begin(), trades.end(), std::make_pair(t, 1e300)); return it == trades.begin() ? -1.0 : std::prev(it)->second; };
    for (int kind : { (int)bol::FILLED, (int)bol::PULLED }) {
        int n5 = 0, held = 0, broke = 0; double sum = 0;
        for (const bol::Line& Ln : E.lines) {
            if (Ln.end != kind && !(kind == bol::PULLED && Ln.end == bol::MOVED)) continue;
            if (Ln.tEnd + 300000 > lastT) continue;
            const double a = pxAt(Ln.tEnd + 300000); if (a < 0) continue;
            const double mv = (a - (double)Ln.px * tick) / tick * (Ln.side == bol::BID ? 1 : -1);
            ++n5; sum += mv; if (mv >= 4) ++held; else if (mv <= -4) ++broke;
        }
        std::printf("  5 min after %s: %d lines, price moved %+.1f ticks on average in the order's favour; %d +4 ticks or more, %d -4 or worse\n", kind == bol::FILLED ? "FILLED" : "PULLED / moved", n5, n5 ? sum / n5 : 0.0, held, broke);
    }
    return 0;
}
