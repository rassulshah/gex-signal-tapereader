// render_dump.cpp -- replays a recorded order file through bol::Engine and lays out the lines for a chart window with bol::layout
// (the plugin's own layout), printing the candles and the draw ops for render_bigorders.py.  zcat FILE | ./render_dump MKT TICK FROM_HHMM TO_HHMM PXPERBAR
#include "BigOrderLines.h"
#include <iostream>
#include <cstring>
static long long parseT(const char* s) { int y, mo, d, h, mi, se; if (std::sscanf(s, "%d-%d-%d %d:%d:%d", &y, &mo, &d, &h, &mi, &se) != 6) return 0;
    y -= mo <= 2; const long long era = (y >= 0 ? y : y - 399) / 400; const unsigned yoe = (unsigned)(y - era * 400);
    const unsigned doy = (153 * (mo + (mo > 2 ? -3 : 9)) + 2) / 5 + d - 1; const unsigned doe = yoe * 365 + yoe / 4 - yoe / 100 + doy;
    return ((era * 146097 + (long long)doe - 719468) * 86400LL + h * 3600LL + mi * 60LL + se) * 1000LL; }
int main(int argc, char** argv) {
    const std::string mkt = argv[1]; const double tick = std::atof(argv[2]); const int from = std::atoi(argv[3]), to = std::atoi(argv[4]); const int ppb = std::atoi(argv[5]);
    bol::Engine E; E.tick = tick; E.P.floor = bol::floorFor(mkt);
    struct B { long long end; double o, h, l, c; }; std::vector<B> bars; std::vector<double> H, L, C;
    std::string line; std::getline(std::cin, line); long long day0 = -1, stopT = 0;
    while (std::getline(std::cin, line)) {
        char* f[10]; int k = 0; char* p = &line[0]; f[k++] = p; for (; *p && k < 10; ++p) if (*p == '|') { *p = 0; f[k++] = p + 1; }
        if (k < 8) continue; const long long t = parseT(f[0]); if (t <= 0) continue;
        if (day0 < 0) { day0 = t / 86400000 * 86400000; stopT = day0 + (to / 100 * 3600LL + to % 100 * 60) * 1000; }
        if (t >= stopT) break;
        const char* a = f[1]; const int act = !std::strcmp(a, "NEW") ? 0 : !std::strcmp(a, "MOD") ? 1 : !std::strcmp(a, "DEL") ? 2 : !std::strcmp(a, "FILL") ? 3 : 9;
        const double px = std::atof(f[2]);
        if (act == 3 && px > 0) {
            const long long end = (t / 180000 + 1) * 180000;
            if (bars.empty() || bars.back().end != end) { if (!bars.empty()) { H.push_back(bars.back().h); L.push_back(bars.back().l); C.push_back(bars.back().c); E.setAtr(bol::atr14(H, L, C)); } bars.push_back(B{end, px, px, px, px}); }
            else { B& b = bars.back(); b.h = std::max(b.h, px); b.l = std::min(b.l, px); b.c = px; }
        }
        E.onEvent(act, f[7][0] == 'B' ? bol::BID : f[7][0] == 'S' ? bol::ASK : -1, (bol::Tick)std::llround(px / tick), (long long)std::atof(f[4]), std::atoll(f[5]), t);
        E.evaluate(t);
    }
    const long long fromT = day0 + (from / 100 * 3600LL + from % 100 * 60) * 1000;
    std::vector<long long> ends; int first = -1;
    for (size_t i = 0; i < bars.size(); ++i) { ends.push_back(bars[i].end); if (first < 0 && bars[i].end > fromT) first = (int)i; }
    const int last = (int)bars.size() - 1; double lo = 1e18, hi = -1e18;
    for (int i = first; i <= last; ++i) { lo = std::min(lo, bars[(size_t)i].l); hi = std::max(hi, bars[(size_t)i].h); }
    lo -= 2 * E.atrPrice; hi += 2 * E.atrPrice;
    const int W = 80 + (last - first + 1) * ppb + 140, Ht = 700, colR = 70;   // a 60 px Liquidity column at the left
    auto xOf = [&](int b) { return colR + 10 + (b - first) * ppb + ppb / 2; };
    auto yOf = [&](double p) { return (int)(20 + (hi - p) / (hi - lo) * (Ht - 40)); };
    std::printf("VIEW %d %d %s %d %d %.6f\n", W, Ht, mkt.c_str(), from, to, tick);
    for (int i = first; i <= last; ++i) { const B& b = bars[(size_t)i]; std::printf("BAR %d %d %d %d %d %s\n", xOf(i), yOf(b.o), yOf(b.h), yOf(b.l), yOf(b.c), bol::clock12(b.end - 180000).c_str()); }
    std::vector<bol::Seg> segs; const std::vector<size_t> sh = E.shown();
    for (size_t k = 0; k < sh.size(); ++k) {
        const bol::Line Ln = E.now(sh[k]);
        const int b0 = std::max(0, bol::barOf(ends, Ln.tStart)), b1 = Ln.end == bol::RESTING ? last : std::max(b0, bol::barOf(ends, Ln.tEnd));
        bol::Seg g; g.line = sh[k]; g.side = Ln.side; g.x0 = xOf(b0); g.x1 = Ln.end == bol::RESTING ? xOf(last) + ppb / 2 : xOf(b1); g.y = yOf((double)Ln.px * tick);
        g.live = Ln.end == bol::RESTING; g.end = Ln.end; g.text = bol::label(Ln); g.textW = (int)g.text.size() * 8; segs.push_back(g);
    }
    bol::View V; V.xMin = colR + 6; V.xMax = xOf(last) + ppb / 2 + bol::ARROW_W + 2; V.yTop = 20; V.yBot = Ht - 20; V.rowH = 18;
    for (const bol::Op& o : bol::layout(segs, V)) std::printf("OP %d %d %d %d %d %d %s\n", o.kind, o.side, o.x0, o.y0, o.x1, o.y1, o.text.c_str());
    std::printf("COL %d\n", colR);
    for (size_t k = 0; k < sh.size(); ++k) { const bol::Line Ln = E.now(sh[k]); std::fprintf(stderr, "%s at %s %s-%s %s traded %lld cancelled %lld\n", bol::label(Ln).c_str(), bol::price(Ln.px, tick).c_str(), bol::clock12(Ln.tStart).c_str(), Ln.end ? bol::clock12(Ln.tEnd).c_str() : "now", bol::endWord(Ln.end), Ln.traded, Ln.cancelled); }
    return 0;
}
