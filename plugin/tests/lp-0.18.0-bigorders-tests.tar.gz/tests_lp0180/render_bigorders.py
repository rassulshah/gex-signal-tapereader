# render_bigorders.py -- draws render_dump's output: the candles + the ops of bol::layout (the plugin's own layout), as IRT would
import sys, matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Circle
G='#22c55e'; R='#ef4444'; BG='#0b0f17'; GR='#9ca3af'
L=[l.split(' ',7) for l in open(sys.argv[1]).read().splitlines()]
v=[x for x in L if x[0]=='VIEW'][0]; W,H=int(v[1]),int(v[2])
fig=plt.figure(figsize=(W/100,H/100),dpi=100,facecolor=BG); ax=fig.add_axes([0,0,1,1]); ax.set_xlim(0,W); ax.set_ylim(H,0); ax.axis('off'); ax.set_facecolor(BG)
col=int([x for x in L if x[0]=='COL'][0][1]); ax.add_patch(Rectangle((0,0),col,H,color='#20242c'))
ax.text(4,14,'LIQ',color=GR,fontsize=9,fontweight='bold')
for b in [x for x in L if x[0]=='BAR']:
    x,o,h,l,c=map(int,b[1:6]); up=c<=o; cc=G if up else R
    ax.plot([x,x],[h,l],color=cc,lw=1); ax.add_patch(Rectangle((x-5,min(o,c)),10,max(1,abs(o-c)),color=cc))
for o in [x for x in L if x[0]=='OP']:
    k,s,x0,y0,x1,y1=map(int,o[1:7]); t=o[7] if len(o)>7 else ''; c=G if s==0 else R; y=(y0+y1)/2
    if k==0: ax.plot([x0,x1],[y0,y1],color=c,lw=2)
    elif k==4: ax.plot([x0,x1],[y,y],color=c,lw=2); ax.plot([x1-4,x1,x1-4],[y-4,y,y+4],color=c,lw=2)
    elif k==2: ax.add_patch(Circle(((x0+x1)/2,y),4,color=c))
    elif k==3: ax.plot([x0,x1],[y0,y1],color=c,lw=2); ax.plot([x0,x1],[y1,y0],color=c,lw=2)
    elif k==1: ax.text(x0,y1-4,t,color=c,fontsize=8.3,fontweight='bold')
fig.savefig(sys.argv[2],facecolor=BG)
