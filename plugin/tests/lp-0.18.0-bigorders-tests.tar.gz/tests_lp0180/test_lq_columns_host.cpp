// test_lq_columns_host.cpp -- (CR5200) lsLiquidityProfile 0.16.0 on the mock host: the solid LEFT column (Width 20-200, default 60,
// Solid background), the lots INSIDE each node in white (hidden when it does not fit), the ratio outside as before, the size file
// (5 fields, 70 -> 60 migration, garbage refused), the column on the board, the zone hover stopping at the right-side columns, and
// LRA-LiqLevels-<MKT>.csv for the Dealer Profile's level badges (Rassul 11:00 / 11:02 / 11:39 CT).
//   g++ -std=c++17 -Imock -I. test_lq_columns_host.cpp -o t && ./t
#include "LiquidityProfile.cpp"
#include "DealerColumnsLogic.h"   // the Dealer Profile's reader of LRA-LiqLevels (the two plugins agree on the file)
#include <cstdio>
#include <cstdlib>
#include <unistd.h>

namespace mock { Host* current = nullptr; Feed feed; }
static int fails = 0, passes = 0;
#define CHECK(c, m) do { if (c) ++passes; else { ++fails; std::printf("FAIL %d %s\n", __LINE__, std::string(m).c_str()); } } while (0)

static void setDepth(mock::Host& h, double bestBid, int levels, double extraPx = 0, double extra = 0) {
    h.depth.clear();
    for (int i = 0; i < levels; ++i) {
        DEPTH_LEVEL L; L.bid = (float)(bestBid - i * 0.01); L.ask = (float)(bestBid + 0.01 + i * 0.01);
        L.bidsize = 10; L.asksize = 10;
        if (extra > 0 && std::fabs(L.bid - extraPx) < 0.001) L.bidsize = (unsigned short)(10 + extra);
        h.depth.push_back(L);
    }
}
static std::string readAll(const std::string& p) { std::ifstream f(p.c_str()); std::stringstream s; s << f.rdbuf(); return s.str(); }
static const mock::Draw* bgBox(const mock::Host& h) { for (auto& d : h.draws) if (d.type == "box" && d.color == C_COLBG) return &d; return nullptr; }

int main() {
    char tmpl[] = "/tmp/lqcXXXXXX"; const char* tmp = mkdtemp(tmpl);
    setenv("USERPROFILE", tmp, 1);
    const std::string flex = std::string(tmp) + "\\InvestorRT\\rtx\\lsFlexLevels";
    mock::Host h; mock::current = &h;
    h.tick = 0.01f; h.seconds = 180; h.symbol = "CLEX26"; h.root = "CLEX26"; h.chart = "CL 3m cols";
    const unsigned long day = (unsigned long)(civilDays(2026, 10, 12) * 86400LL);
    unsigned long t0 = day + 9 * 3600;
    for (int i = 0; i < 25; ++i) {
        mock::Bar b; b.time = t0 - (24 - i) * 180; b.open = 80.05f; b.high = 80.12f; b.low = 79.98f; b.close = 80.03f;
        b.rows.push_back(mock::Price(80.03f, 50, 40, 90)); h.bars.push_back(b);
    }
    { mock::Bar f; f.time = t0 + 180; f.open = f.high = f.low = f.close = 80.03f; f.rows.push_back(mock::Price(80.03f, 0, 0, 0)); h.bars.push_back(f); }
    setDepth(h, 80.00, 80, 79.95, 200);
    LiquidityProfile* p = static_cast<LiquidityProfile*>(CreateExtension());
    h.now = t0;
    for (int s = 0; s < 45; ++s) { h.now = t0 + s; p->calc(0); usleep(10000); }
    LQState* S = static_cast<LQState*>(h.data);
    CHECK(S && S->e.haveBook, "a live book");
    CHECK(std::string(LQ_VERSION) == std::string(lqp::VERSION), "one version: LQ_VERSION = lqp::VERSION");
    { const std::string me = __FILE__; std::ifstream src((me.substr(0, me.find_last_of("/\\") + 1) + "LiquidityProfile.cpp").c_str()); std::stringstream ss; ss << src.rdbuf();
      CHECK(ss.str().find(std::string("p->setVersion(\"") + LQ_VERSION + "\")") != std::string::npos, "the setVersion literal gex-build reads = LQ_VERSION (lesson 79: read, never typed)"); }
    // ---- the column: solid background at the left edge, under the header, default 60 px, drawn before the bars
    h.draws.clear(); h.priceBase = 79.88f; h.pxPer = 2000; p->draw();   // 20 px a tick: the zone's rows tall enough for text
    const mock::Draw* bg = bgBox(h);
    CHECK(S->width == 60 && bg && bg->l == h.paneLeft && bg->r == h.paneLeft + 60 && bg->b == h.paneBottom && bg->t > h.paneTop + LQ_TITLE_ROW_PX, "solid column 0-60 px from under the banner / header to the bottom");
    { size_t bgAt = 0, firstBar = 0; for (size_t i = 0; i < h.draws.size(); ++i) { if (&h.draws[i] == bg) bgAt = i; if (!firstBar && h.draws[i].type == "box" && (h.draws[i].color == C_BUY || h.draws[i].color == C_BUY_DIM)) firstBar = i; }
      CHECK(firstBar > bgAt, "the background first: the bars and the header sit on it (candles pass behind it)"); }
    // the bars stay in the column; the lots INSIDE the node in white; the ratio outside on the price side
    int barsOut = 0; for (auto& d : h.draws) if (d.type == "box" && (d.color == C_BUY || d.color == C_SELL) && d.r > h.paneLeft + 1 + 60 - 4) ++barsOut;
    CHECK(barsOut == 0, "every bar inside the 60 px column");
    bool lotsIn = false, ratioOut = false, grayLots = false;
    for (auto& d : h.draws) if (d.type == "text") {
        if (d.color == C_WHITE && d.centred && d.r <= h.paneLeft + 60) lotsIn = true;
        if (!d.text.empty() && d.text.back() == 'x' && std::isdigit((unsigned char)d.text[0]) && d.l >= h.paneLeft + 8) ratioOut = true;
        if (d.color == C_GREY && std::isdigit((unsigned char)d.text[0]) && d.text.back() != 'x') grayLots = true;
    }
    CHECK(lotsIn, "the node's lots INSIDE it, white");
    CHECK(ratioOut, "the ratio stays OUTSIDE on the price side");
    CHECK(!grayLots, "no lots printed beside a node any more");
    // a 20 px column: the node is too short for its lots -> hidden (never spilling out)
    S->width = 20; h.draws.clear(); p->draw();
    int spill = 0; for (auto& d : h.draws) if (d.type == "text" && d.color == C_WHITE && d.r > h.paneLeft + 20) ++spill;
    const mock::Draw* bg20 = bgBox(h);
    CHECK(spill == 0 && bg20 && bg20->r == h.paneLeft + 20, "20 px: the lots hidden when the node is too short, the column 20 px");
    // Solid background off
    S->width = 60; S->bg = false; h.draws.clear(); p->draw();
    CHECK(!bgBox(h), "'Solid background' off: no column fill");
    S->bg = true;
    // ---- the size file: 5 fields; the old default 70 read as 60 once; garbage refused (last good kept)
    const std::string sf = flex + "\\LiquidityProfile.size-CL.txt";
    auto load = [&](const std::string& body) { { std::ofstream f(sf.c_str(), std::ios::trunc); f << body; } S->sizeStamp = -2; S->sizeCheckMs = -1; S->sizeMkt.clear(); h.draws.clear(); p->draw(); };
    load("70,11,0,0\n");       CHECK(S->width == 60 && S->sizeWhy.find("70 read as 60") != std::string::npos, "an old file with the old default 70: read as 60 (reason on the status)");
    load("70,11,0,0,1\n");     CHECK(S->width == 70 && S->bg, "a 0.16.0 file with 70: kept (his choice)");
    load("120,12,0,0,0\n");    CHECK(S->width == 120 && !S->bg && S->font == 12, "120 px, background off: applied");
    load("250,12,0,0,1\n");    CHECK(S->width == 200, "250: clamped to the 200 maximum");
    load("15,12,0,0,1\n");     CHECK(S->width == 200 && S->sizeWhy.find("garbled") != std::string::npos, "15 px: refused, the last good kept");
    load("90,11,0,0,7\n");     CHECK(S->width == 200 && S->sizeWhy.find("garbled") != std::string::npos, "a bad background flag: refused");
    load("nan,11\n");          CHECK(S->width == 200, "garbage: refused");
    load("60,11,0,0,1\n");     CHECK(S->width == 60, "back to 60");
    // the settings window: filled from the file (Width, Font, offsets, background), Apply writes 5 fields
    h.period = ""; h.parms[0] = 5; h.checks[4] = false; p->parmsLoad();
    CHECK(h.parms[0] == 60 && h.checks[4], "the window opens filled from the file (60, background on)");
    h.checks[4] = false; p->parmsApply();
    CHECK(readAll(sf) == "60,11,0,0,0\n", "Apply: 'Solid background' off saved: " + readAll(sf));
    h.parms[0] = 999; p->parmsApply();
    CHECK(readAll(sf).rfind("200,", 0) == 0 || readAll(sf).rfind("60,", 0) == 0, "a garbage width from the window never saved raw: " + readAll(sf));
    h.period = "3 min"; load("60,11,0,0,1\n");
    // ---- the board: this column's width; the right-side columns limit the hover
    { int w = 0; long long ms = 0; CHECK(cb::peek(cb::LIQ, h.symbol, h.seconds, h.chart, w, ms) && w == 60, "the column's width on the board"); }
    CHECK(S->colPriceRight == -1, "no right-side columns on the chart: the hover may go to the axis");
    cb::publish(cb::DEALER, h.symbol, h.seconds, h.chart, 1, 80); cb::publish(cb::LEVELS, h.symbol, h.seconds, h.chart, 1, 78); cb::publish(cb::DELTA, h.symbol, h.seconds, h.chart, 1, 80);
    h.draws.clear(); p->draw();
    CHECK(S->colPriceRight == 1978 - 258, "Dealer + Levels + Delta on the chart: the hover stops 20 px before the Levels column (1720)");
    cb::clear(cb::DEALER, h.symbol, h.seconds, h.chart); cb::clear(cb::LEVELS, h.symbol, h.seconds, h.chart); cb::clear(cb::DELTA, h.symbol, h.seconds, h.chart);
    // ---- LRA-LiqLevels-CL.csv: every price within reach with size, its band and prominence, the market's LQ lines
    usleep(1100000); h.now = t0 + 50; p->calc(0);
    const std::string lf = readAll(flex + "\\LRA-LiqLevels-CL.csv");
    CHECK(lf.rfind("LIQL,1,", 0) == 0, "the file starts with its LIQL header");
    {   std::istringstream in(lf); std::string ln; std::getline(in, ln);
        std::vector<std::string> hd = split(ln, ',');
        CHECK(hd.size() == 7 && hd[3] == "0.01" && hd[4] == "2.5" && hd[5] == "2.1", "header: tick 0.01, the LQ lines 2.5x / 2.1x");
        int rows = 0, wrongSide = 0, zero = 0; bool wall = false; const long long last = S->e.lastPx;
        while (std::getline(in, ln)) { std::vector<std::string> c = split(ln, ','); if (c.size() != 5 || c[0] != "L") continue; ++rows;
            const long long tk = std::atoll(c[1].c_str()); const long long n = std::atoll(c[3].c_str()); const double bx = std::atof(c[4].c_str());
            if ((c[2] == "S" && tk >= last) || (c[2] == "R" && tk <= last)) ++wrongSide;
            if (n < 1) ++zero;
            if (tk == 7995 && c[2] == "S" && n >= 200 && bx >= 2.5) wall = true; }
        CHECK(rows > 20 && wrongSide == 0 && zero == 0, "rows: bids below price (S), offers above (R), never 0 (" + std::to_string(rows) + " rows)");
        CHECK(wall, "the 200-lot bid at 79.95: its band and 2.5x+ (an HL level for the badge)");
        double lots = 0, bx = 0; int side = 0;
        CHECK(S->e.levelLiq(7995, lots, bx, side) && side == lqp::BID && lots >= 200 && !S->e.levelLiq(S->e.lastPx, lots, bx, side), "levelLiq: the band at a level; none at the last price");
    }
    // the Dealer Profile's parser reads it as written: the 79.95 bid wall -> an HL green block on that badge
    {   dcol::LiqLevels L; std::string why;
        const bool ok = dcol::parseLiqLevels(lf, (long long)time(nullptr), L, why);
        const dcol::LiqRow* r = ok ? dcol::liqRowAt(L, 79.95) : nullptr;
        dcol::HLState hs; const bool hl = r && dcol::hlStep(hs, true, r->bid, r->bx, L.onX, L.offX, 0);
        CHECK(ok && r && r->bid && r->n >= 200 && hl && dcol::liqBlockText(r->n, hl).rfind("HL? ", 0) == 0, "the Dealer Profile reads the file: 79.95 = 'HL? " + (r ? dcol::lotsK(r->n) : std::string("?")) + "' on green (" + why + ")"); }
    p->destroy();
    { int w = 0; long long ms = 0; CHECK(!cb::peek(cb::LIQ, h.symbol, h.seconds, h.chart, w, ms), "removed: the column leaves the board"); }
    std::string rm = std::string("rm -rf ") + tmp; if (std::system(rm.c_str()) != 0) {}
    std::printf("%d passed, %d failed\n", passes, fails);
    return fails ? 1 : 0;
}
