// test_bigorders_host.cpp -- lsLiquidityProfile 0.18.0 on the mock host: the biggest resting order lines through the WHOLE plugin
// (LiquidityProfile.cpp) with the order-by-order feed, plus the two-line warning (Rassul 22:48 CT).
//   g++ -std=c++17 -Imock -I. test_bigorders_host.cpp -o tbh && ./tbh
// [1] lines drawn: green bid / red offer, label at the left end in its colour (11 pt), arrow while resting, inside the band (right of
//     the Liquidity column, never past the last bar + arrow, never into the right-side columns)  [2] hover box  [3] FILLED dot / PULLED X
// [4] record + restart: ended lines drawn identically, the resting one ends at the last heartbeat, "since restart"  [5] settings:
//     on / off, font, kept lines, min lots, reach - each real, saved per market, the dialog filled from the file, untouched rows kept
// [6] the right-side columns (ColumnBoard) limit  [7] the warning detail on two lines, never truncated, the header below it.
#include "LiquidityProfile.cpp"
#include <cstdio>
#include <cstdlib>
#include <unistd.h>

namespace mock { Host* current = nullptr; Feed feed; }
static int fails = 0, passes = 0;
#define CHECK(c, m) do { if (c) ++passes; else { ++fails; std::printf("FAIL %d %s\n", __LINE__, m); } } while (0)
static std::string readAll(const std::string& p) { std::ifstream f(p.c_str()); std::stringstream s; s << f.rdbuf(); return s.str(); }
static void setDepth(mock::Host& h, double bestBid, int levels, std::map<int, int> extra) {
    h.depth.clear();
    for (int i = 0; i < levels; ++i) {
        DEPTH_LEVEL L; L.bid = (float)(bestBid - i * 0.01); L.ask = (float)(bestBid + 0.01 + i * 0.01); L.bidsize = 10; L.asksize = 10;
        const int bk = (int)std::lround(L.bid * 100), ak = (int)std::lround(L.ask * 100);
        if (extra.count(bk)) L.bidsize = (unsigned short)(10 + extra[bk]);
        if (extra.count(ak)) L.asksize = (unsigned short)(10 + extra[ak]);
        h.depth.push_back(L);
    }
}
static void order(unsigned char action, float px, unsigned long size, RTDATE t, int id, int side) { mock::feed.push(action, (unsigned char)side, px, size, t, id); }
static void mouseAt(LiquidityProfile* p, float price, long bar) { RTX_EVENT e; std::memset(&e, 0, sizeof(e)); e.type = E_MOUSE_MOVE; e.v.mouse.price = price; e.v.mouse.bar = bar; p->mouse(&e); }
static const COLOR GREEN = 0x0022C55E, RED = 0x00EF4444;
struct Look { std::vector<mock::Draw> lines, labels, dots; int xs = 0; };
// the big-order draws: 2-px lines in green / red, the "Bid N" / "Ask N" labels, filled dots (rings with a solid brush)
static Look look(mock::Host& h) {
    Look L;
    for (auto& d : h.draws) {
        if (d.type == "line" && d.penW == 2 && (d.pen == GREEN || d.pen == RED)) L.lines.push_back(d);
        if (d.type == "text" && (d.text.compare(0, 4, "Bid ") == 0 || d.text.compare(0, 4, "Ask ") == 0)) L.labels.push_back(d);
        if (d.type == "ring" && (d.color == GREEN || d.color == RED)) L.dots.push_back(d);
    }
    return L;
}
static bool hasLine(const Look& L, int y, COLOR c, int* x0 = nullptr, int* x1 = nullptr) {
    int best = -1; for (size_t i = 0; i < L.lines.size(); ++i) { const mock::Draw& d = L.lines[i]; if (d.t == y && d.y == y && d.pen == c && (best < 0 || d.x - d.l > L.lines[(size_t)best].x - L.lines[(size_t)best].l)) best = (int)i; }
    if (best < 0) return false; if (x0) *x0 = L.lines[(size_t)best].l; if (x1) *x1 = L.lines[(size_t)best].x; return true;
}
struct Box { bool found = false; int l = 0, t = 0, r = 0, b = 0; std::vector<std::string> rows; int minFont = 99; };
static Box hoverBox(mock::Host& h) {
    Box x;
    size_t at = 0;   // only the text drawn AFTER the box is its content (the box is a transient overlay over the chart)
    for (size_t i = 0; i < h.draws.size(); ++i) { const auto& d = h.draws[i]; if (d.type == "box" && d.color == 0x0011151C) { x.found = true; x.l = d.x; x.t = d.y; x.r = d.r; x.b = d.b; at = i; } }
    if (!x.found) return x;
    for (size_t i = at; i < h.draws.size(); ++i) { const auto& d = h.draws[i]; if (d.type == "text" && d.x > x.l && d.x < x.r && d.y >= x.t && d.y < x.b) { x.rows.push_back(d.text); x.minFont = std::min(x.minFont, d.fsize); } }
    return x;
}
static void run(LiquidityProfile* p, mock::Host& h, unsigned long from, int secs) { for (int s = 0; s < secs; ++s) { h.now = from + s; p->calc(0); usleep(3000); } }

int main() {
    setvbuf(stdout, nullptr, _IONBF, 0);
    char tmpl[] = "/tmp/lqbXXXXXX"; const char* tmp = mkdtemp(tmpl); setenv("USERPROFILE", tmp, 1);
    const std::string flex = std::string(tmp) + "\\InvestorRT\\rtx\\lsFlexLevels";
    { std::ofstream nf((flex + "\\LRA-LiqNorms-CL.csv").c_str()); nf << "VERSION,test\r\nMARKET,CL\r\nZONE,0.25,4,8\r\n"; }
    mock::Host h; mock::current = &h;
    h.tick = 0.01f; h.seconds = 180; h.symbol = "CLEX26"; h.root = "CLEX26"; h.chart = "CL 3m";
    h.priceBase = 79.5f; h.pxPer = 1000.0f; h.barW = 10; h.barX0 = 50; h.paneBottom = 1000; h.paneRight = 2000; h.scaleLeft = 1980;
    const unsigned long day = (unsigned long)(civilDays(2026, 10, 12) * 86400LL), t0 = day + 9 * 3600;
    for (int i = 0; i < 25; ++i) { mock::Bar b; b.time = t0 - (24 - i) * 180; b.open = 80.05f; b.high = 80.12f; b.low = 79.98f; b.close = 80.03f; b.rows.push_back(mock::Price(80.03f, 50, 40, 90)); h.bars.push_back(b); }
    { mock::Bar f; f.time = t0 + 180; f.open = f.high = f.low = f.close = 80.03f; f.rows.push_back(mock::Price(80.03f, 0, 0, 0)); h.bars.push_back(f); }
    setDepth(h, 80.00, 60, std::map<int, int>{ { 7995, 300 }, { 8010, 60 } });
    // the order feed: the 300-lot bid at 79.95 (8 ticks under 80.03), a 60-lot offer at 80.10, small orders, a 12-lot bid (under CL's 15)
    for (int k = 0; k < 6; ++k) order(0, 79.97f - 0.01f * (float)k, 5, (RTDATE)t0, 10 + k, 1);
    order(0, 79.96f, 12, (RTDATE)t0, 20, 1);
    order(0, 79.95f, 300, (RTDATE)t0, 21, 1);
    order(0, 80.10f, 60, (RTDATE)t0, 22, 0);
    order(0, 80.60f, 900, (RTDATE)t0, 23, 0);                    // 57 ticks above: outside the 2 ATR (0.28 = 28 ticks) reach
    LiquidityProfile* p = static_cast<LiquidityProfile*>(CreateExtension());
    run(p, h, t0, 3);
    LQState* S = static_cast<LQState*>(h.data);
    if (!S) { std::printf("no state\n"); return 1; }
    CHECK(S->e.haveBook && S->bo.events >= 9, "fixture: the depth + the order feed reach the big-order engine");
    CHECK(std::fabs(S->bo.atrPrice - 0.14) < 1e-6 && S->bo.reach == 28, "ATR14 of the chart's closed bars (0.14) -> 2 ATR = 28 ticks");
    CHECK(S->bo.P.floor == 15 && S->boWhy.find("defaults") != std::string::npos, "CL floor 15 (no settings file: the market default)");
    CHECK(S->bo.live[0] < 0 && S->bo.live[1] < 0, "nothing drawn inside the 10 s dwell");
    run(p, h, t0 + 3, 15);
    CHECK(S->bo.live[0] >= 0 && S->bo.lines[(size_t)S->bo.live[0]].oid == 21 && S->bo.lines[(size_t)S->bo.live[0]].size0 == 300, "the bid line: the 300-lot ORDER");
    CHECK(S->bo.live[1] >= 0 && S->bo.lines[(size_t)S->bo.live[1]].oid == 22, "the offer line: the 60-lot order (the 900 is out of reach)");
    // ---- [1] the drawing: the lines started in the forming bar; three more bars come (the line extends bar by bar)
    h.draws.clear(); p->draw();
    const int startX = 50 + ((int)h.bars.size() - 1) * 10;
    CHECK(look(h).lines.size() >= 2 && look(h).lines[0].l == startX, "a line starts at the bar the order appeared in");
    for (int k = 1; k <= 3; ++k) { h.bars.back().close = 80.03f; mock::Bar f; f.time = t0 + 180 * (k + 1); f.open = f.high = f.low = f.close = 80.03f; f.rows.push_back(mock::Price(80.03f, 0, 0, 0)); h.bars.back().high = 80.12f; h.bars.back().low = 79.98f; h.bars.push_back(f); }
    run(p, h, t0 + 18, 2);
    h.draws.clear(); p->draw();
    const int lastBar = (int)h.bars.size() - 1, lastX = 50 + lastBar * 10;
    auto yOf = [](float px) { return (int)static_cast<short>(1000 - (px - 79.5f) * 1000.0f); };
    const int yBid = yOf(79.95f), yAsk = yOf(80.10f);
    Look L = look(h); int bx0 = 0, bx1 = 0, ax0 = 0, ax1 = 0;
    CHECK(hasLine(L, yBid, GREEN, &bx0, &bx1) && hasLine(L, yAsk, RED, &ax0, &ax1), "a green line at the bid's price, a red one at the offer's");
    const int xMin = 1 + std::max(S->width, S->colRight) + 6;
    CHECK(bx0 >= xMin && ax0 >= xMin, "never inside the Liquidity column (its bars and labels)");
    CHECK(bx1 == lastX && ax1 == lastX && bx0 == startX && ax0 == startX, "a resting line extends from its start bar to the last bar (3 bars later)");
    int arrowR = 0; for (auto& d : L.lines) arrowR = std::max(arrowR, std::max((int)d.x, d.l));
    CHECK(arrowR == lastX + bol::ARROW_W, "the arrow past the last bar - nothing further right");
    bool lb = false, la = false; for (auto& d : L.labels) { if (d.text == "Bid 300" && d.color == GREEN && d.fsize == 11 && d.r <= bx0 && d.t <= yBid && d.b >= yBid) lb = true; if (d.text == "Ask 60" && d.color == RED && d.fsize == 11) la = true; }
    CHECK(lb && la, "labels 'Bid 300' / 'Ask 60' at the left end, 11 pt, in the line's colour");
    CHECK(S->boState == "ready", "status: ready");
    {   // the status file
        p->calc(0); usleep(1100000); h.now = t0 + 19; p->calc(0);
        const std::string st = readAll(flex + "\\LiquidityProfile.status-CL-180.txt");
        CHECK(st.find("VERSION,0.18.0") != std::string::npos && st.find("BIG_ORDERS,1.0.0,on,ready") != std::string::npos && st.find("floor 15") != std::string::npos && st.find("live bid/offer") != std::string::npos, "status: BIG_ORDERS line");
    }
    // ---- [2] the hover
    mouseAt(p, 79.95f, lastBar - 3); h.draws.clear(); p->draw();
    Box b = hoverBox(h);
    CHECK(b.found && b.rows.size() >= 8 && b.rows[0] == "Bid 300 at 79.95 - still resting", "hover on the bid line: its box");
    CHECK(b.found && b.rows[1].find("Appeared 9:00 AM - rested") == 0 && b.minFont >= 10, "appeared on the 12-hour clock; fonts 10 pt+");
    CHECK(b.found && b.l >= xMin && b.r <= h.scaleLeft, "the box stays right of the column and left of the axis");
    mouseAt(p, 79.70f, lastBar - 3); h.draws.clear(); p->draw();
    CHECK(!hoverBox(h).found && S->boHovKey == 0, "mouse away: no box");
    // ---- [3] FILLED dot (the feed's way: fills carry the aggressor's side) and PULLED X
    order(3, 79.95f, 100, (RTDATE)(t0 + 30), 21, 0); order(1, 79.95f, 200, (RTDATE)(t0 + 30), 21, 0);
    order(3, 79.95f, 200, (RTDATE)(t0 + 31), 21, 0); order(2, 79.95f, 200, (RTDATE)(t0 + 31), 21, 0);
    order(2, 80.10f, 60, (RTDATE)(t0 + 32), 22, 0);
    run(p, h, t0 + 30, 4);
    CHECK(S->bo.lines.size() >= 2 && S->bo.lines[0].end == bol::FILLED && S->bo.lines[0].traded == 300 && S->bo.lines[1].end == bol::PULLED && S->bo.lines[1].cancelled == 60, "the bid FILLED (300 traded), the offer PULLED (60 cancelled)");
    h.draws.clear(); p->draw(); L = look(h);
    bool dot = false; for (auto& d : L.dots) if (d.color == GREEN && std::abs(d.y - yBid) <= 1) dot = true;
    CHECK(dot, "a filled green dot at the filled bid's end");
    int xr = 0; for (auto& d : L.lines) if (d.pen == RED && d.l != d.x && d.t != d.y) ++xr;
    CHECK(xr == 2, "an X (two diagonal strokes) at the pulled offer's end");
    // a new bid line resting, then a restart
    order(0, 79.94f, 80, (RTDATE)(t0 + 40), 30, 1);
    run(p, h, t0 + 40, 14);
    CHECK(S->bo.live[0] >= 0 && S->bo.lines[(size_t)S->bo.live[0]].oid == 30, "a new bid line (80 at 79.94)");
    usleep(1100000); h.now = t0 + 70; p->calc(0); usleep(1100000); h.now = t0 + 75; p->calc(0);
    const std::string rec = flex + "\\LiquidityProfile\\CL-CLEX26-180-bigorders-" + std::to_string(S->session) + ".csv";
    const std::string recText = readAll(rec);
    CHECK(recText.find("BOL1") == 0 && recText.find("|FILL|") != std::string::npos && recText.find("|PULL|") != std::string::npos && recText.find("\nH|") != std::string::npos, "the session record: S / E rows + a heartbeat");
    h.draws.clear(); p->draw(); Look before = look(h);
    // ---- [4] restart: a new plugin instance on the same chart (IRT reopened)
    const size_t nBefore = S->bo.lines.size();
    std::vector<bol::Line> was = S->bo.lines;
    p->destroy(); delete p; h.data = nullptr;
    mock::Host h2 = h; h2.data = nullptr; h2.draws.clear(); mock::current = &h2;
    LiquidityProfile* q = static_cast<LiquidityProfile*>(CreateExtension());
    run(q, h2, t0 + 300, 2);
    LQState* S2 = static_cast<LQState*>(h2.data);
    CHECK(S2 && S2->boRestored == (long long)nBefore && S2->boBad == 0, "the restart reads every line back");
    bool same = S2 != nullptr;
    for (size_t i = 0; same && i < was.size(); ++i) {
        const bol::Line& a = was[i]; const bol::Line& r = S2->bo.lines[i];
        if (a.end != bol::RESTING) same = a.key == r.key && a.tStart == r.tStart && a.tEnd == r.tEnd && a.end == r.end && a.size0 == r.size0 && a.px == r.px && a.traded == r.traded;
        else same = r.end == bol::RESTART && r.tStart == a.tStart && r.tEnd >= a.tStart;
    }
    CHECK(same, "ended lines identical after the restart; the resting one ends at the last heartbeat (IRT closed)");
    h2.draws.clear(); q->draw(); Look after = look(h2);
    int matched = 0;
    for (auto& d : before.lines) for (auto& e : after.lines) if (d.pen == e.pen && d.l == e.l && d.t == e.t && d.x == e.x && d.y == e.y) { ++matched; break; }
    int beforeEnded = 0; for (auto& d : before.lines) if (d.y != yOf(79.94f) && d.t != yOf(79.94f)) ++beforeEnded;
    CHECK(matched >= beforeEnded && beforeEnded >= 4, "the ended lines' strokes are drawn exactly as before the restart (no repaint)");
    {   // an order first seen after the restart (a MOD): no known start - "since restart"
        order(1, 79.93f, 400, (RTDATE)(t0 + 302), 40, 1);
        run(q, h2, t0 + 302, 14);
        CHECK(S2->bo.live[0] >= 0 && S2->bo.lines[(size_t)S2->bo.live[0]].sinceRestart && !S2->bo.lines[(size_t)S2->bo.live[0]].startKnown, "first seen after the restart: since restart");
        h2.draws.clear(); q->draw(); mouseAt(q, 79.93f, lastBar - 1); h2.draws.clear(); q->draw();
        Box hb = hoverBox(h2);
        CHECK(hb.found && hb.rows.size() > 1 && hb.rows[1].find("Seen since restart 9:05 AM - start not known") == 0, "hover: since restart, no invented age");
        mouseAt(q, 79.70f, 0);
    }
    // ---- [5] settings: OK / Apply from the dialog's copy -> the per-market file -> every chart of the market
    {
        mock::Host dlg = h2; dlg.data = nullptr; dlg.period = ""; mock::current = &dlg;   // the settings window: no bar size
        LiquidityProfile* d = static_cast<LiquidityProfile*>(CreateExtension());
        d->parmsLoad();
        CHECK(dlg.checks[BO_ON_INDEX] && std::fabs(dlg.floats[BO_REACH_INDEX] - 2.0f) < 1e-6 && dlg.parms[BO_MIN_INDEX] == 15 && dlg.parms[BO_KEEP_INDEX] == 10 && dlg.parms[BO_FONT_INDEX] == 11,
              "the dialog opens with on, 2.0 ATR, the market's floor 15, 10 kept, 11 pt");
        dlg.checks[BO_ON_INDEX] = false; d->parmsApply();
        const std::string bf = flex + "\\LiquidityProfile.bigorders-CL.txt";
        CHECK(readAll(bf) == "BOL1,0,20,0,10,11\n", "unticked: saved per market (min lots = the market default -> 0)");
        mock::current = &h2; usleep(1100000); h2.now = t0 + 330; q->calc(0); h2.draws.clear(); q->draw();
        CHECK(look(h2).lines.empty() && look(h2).labels.empty() && S2->boState == "off (setting)", "off: nothing of it drawn on the chart");
        mock::current = &dlg; dlg.checks[BO_ON_INDEX] = true; dlg.parms[BO_FONT_INDEX] = 14; dlg.parms[BO_KEEP_INDEX] = 1; d->parmsApply();
        CHECK(readAll(bf) == "BOL1,1,20,0,1,14\n", "on, font 14, 1 kept line per side");
        mock::current = &h2; usleep(1100000); h2.now = t0 + 332; q->calc(0); h2.draws.clear(); q->draw();
        Look k = look(h2); bool f14 = !k.labels.empty(); for (auto& x : k.labels) if (x.fsize != 14) f14 = false;
        int greens = 0; for (auto& x : k.labels) if (x.color == GREEN) ++greens;
        CHECK(f14, "the font reaches the chart's labels");
        CHECK(S2->bo.shown().size() <= 3 && greens <= 2, "kept 1: the live line + the last ended line per side");
        // a garbage dialog value never reaches the file; an untouched row keeps the file's value (IRT may hand a copy with boxes unchecked)
        mock::current = &dlg; d->parmsLoad(); dlg.floats[BO_REACH_INDEX] = 99.0f; d->parmsApply();
        CHECK(readAll(bf) == "BOL1,1,20,0,1,14\n", "reach 99 refused: the file keeps 2.0");
        d->parmsLoad(); dlg.parms[BO_MIN_INDEX] = 500; dlg.floats[BO_REACH_INDEX] = 1.5f; d->parmsApply();
        CHECK(readAll(bf) == "BOL1,1,15,500,1,14\n", "min lots 500, reach 1.5 saved");
        d->parmsLoad(); CHECK(dlg.parms[BO_MIN_INDEX] == 500 && std::fabs(dlg.floats[BO_REACH_INDEX] - 1.5f) < 1e-6, "the dialog is filled from the file");
        mock::current = &h2; usleep(1100000); h2.now = t0 + 334; q->calc(0);
        CHECK(S2->bo.P.floor == 500 && S2->bo.reach == 21 && S2->bo.threshold() == 500, "min lots + reach reach the engine (1.5 x 0.14 = 21 ticks)");
        order(0, 79.92f, 450, (RTDATE)(t0 + 335), 50, 1); run(q, h2, t0 + 335, 14);
        bool no450 = true; for (auto& l : S2->bo.lines) if (l.oid == 50) no450 = false;
        CHECK(no450, "a 450 under the 500 minimum never draws");
        mock::current = &dlg; d->parmsLoad(); dlg.parms[BO_MIN_INDEX] = 15; dlg.floats[BO_REACH_INDEX] = 2.0f; dlg.parms[BO_KEEP_INDEX] = 10; dlg.parms[BO_FONT_INDEX] = 11; d->parmsApply();
        CHECK(readAll(bf) == "BOL1,1,20,0,10,11\n", "back to the defaults (15 = CL's floor -> 0)");
        d->destroy(); delete d;
        mock::current = &h2; usleep(1100000); h2.now = t0 + 350; q->calc(0);
        { std::ofstream g(bf.c_str(), std::ios::trunc); g << "BOL1,1,20,0,10,99\n"; }
        mock::current = &h2; usleep(1100000); h2.now = t0 + 360; q->calc(0);
        CHECK(S2->boWhy.find("garbled") != std::string::npos && S2->boSet.font == 11, "a garbled file: the last good settings kept, the reason in the status");
        { std::ofstream g(bf.c_str(), std::ios::trunc); g << "BOL1,1,20,0,10,11\n"; }
        usleep(1100000); h2.now = t0 + 362; q->calc(0);
    }
    // ---- [6] the right-side columns: a Levels column on this chart moves the limit left of the last bar
    {
        mock::current = &h2;
        int over = 0, n = 0;
        for (int k = 0; k < 4; ++k) {
            cb::publish(cb::LEVELS, h2.symbol, h2.seconds, h2.chart, steadyMs(), 78);
            h2.draws.clear(); q->draw(); usleep(20000);
            if (S2->colPriceRight > 0) for (auto& d : look(h2).lines) { ++n; if (std::max((int)d.x, d.l) > S2->colPriceRight - 4) ++over; }
        }
        CHECK(S2->colPriceRight > 0, "fixture: the Levels column is on the board");
        CHECK(over == 0, "no stroke of a line / arrow into the right-side columns");
        h2.paneRight = 300; h2.scaleLeft = 290; h2.draws.clear(); q->draw();
        int bad = 0; for (auto& d : look(h2).lines) if (std::max((int)d.x, d.l) > 286) ++bad;
        CHECK(bad == 0, "a narrow chart: still nothing past the axis");
        h2.paneRight = 2000; h2.scaleLeft = 1980; cb::clear(cb::LEVELS, h2.symbol, h2.seconds, h2.chart);
    }
    // ---- [7] the warning detail on TWO lines (Rassul 22:48 CT): "sellers slowed (0.2x); buyers now lifting offers 2.0x normal"
    {
        mock::current = &h2; const int keepBw = h2.barW; h2.barW = 40;      // a wide chart: the room runs to the last bar
        const double oldCounter = S2->e.L.counter; S2->e.L.counter = 1.5;
        lqp::Attempt fa; fa.side = lqp::BID; fa.done = true; fa.barS = 1; fa.tS = S2->e.bookT; fa.sX = 2.0; fa.exE = 0.2;
        S2->e.finished.push_back(fa);
        h2.draws.clear(); q->draw();
        int badgeY = -1, badgeB = -1; std::vector<mock::Draw> grey;
        for (auto& d : h2.draws) if (d.type == "text") { if (d.text == "BUYERS STEPPING IN") { badgeY = d.t; badgeB = d.b; } if (d.color == C_GREY && d.fsize == 12) grey.push_back(d); }
        CHECK(badgeY >= 0, "fixture: the BUYERS STEPPING IN warning is drawn");
        CHECK(grey.size() == 2 && grey[0].text == "sellers slowed (0.2x)" && grey[1].text == "buyers now lifting offers 2.0x normal", "the detail on two lines, one per side, the connector dropped");
        CHECK(grey.size() == 2 && grey[0].l == grey[1].l && grey[1].t >= grey[0].b - 2 && grey[0].t == badgeY, "line 1 next to the badge, line 2 directly under it (same x)");
        bool dots = false; for (auto& d : h2.draws) if (d.type == "text" && d.text.find("...") != std::string::npos) dots = true;
        CHECK(!dots, "never truncated");
        int hdrT = -1; for (auto& d : h2.draws) if (d.type == "text" && d.text.find("LIQ") == 0) hdrT = d.t;
        CHECK(grey.size() == 2 && hdrT >= grey[1].b, "the column header sits below the second line (its height reserved)");
        // a narrow chart: the side that does not fit wraps at a space - every word is still drawn
        const int keepR = h2.paneRight, keepS = h2.scaleLeft; h2.paneRight = 420; h2.scaleLeft = 410; h2.bars.resize(25); h2.draws.clear(); q->draw();
        std::string all; for (auto& d : h2.draws) if (d.type == "text" && d.color == C_GREY && d.fsize == 12) all += d.text + " ";
        CHECK(all.find("sellers slowed (0.2x)") != std::string::npos && all.find("lifting") != std::string::npos && all.find("normal") != std::string::npos && all.find("...") == std::string::npos, "narrow: wrapped, no word lost");
        h2.paneRight = keepR; h2.scaleLeft = keepS; h2.barW = keepBw;
        S2->e.finished.pop_back(); S2->e.L.counter = oldCounter;
        // the split rule itself
        std::vector<std::string> w = lqp::warnLines("sellers slowed (0.1x), but buyers are pulling their bids (133%)");
        CHECK(w.size() == 2 && w[0] == "sellers slowed (0.1x)" && w[1] == "buyers are pulling their bids (133%)", "mockup v5 sentence: two lines, 'but' dropped");
        w = lqp::warnLines("buyers pulling their bids (80%) while sellers keep hitting");
        CHECK(w.size() == 2 && w[1] == "sellers keep hitting", "'while' splits too");
        w = lqp::warnLines("sellers have eaten 45% of everything at 79.95 (line 30%)");
        CHECK(w.size() == 1 && w[0] == "sellers have eaten 45% of everything at 79.95 (line 30%)", "one side only: one line, unchanged");
        CHECK(lqp::warnLines("").empty(), "no detail: no line");
        std::vector<std::string> ww = lqp::wrapWords("alpha beta gamma delta", [](const std::string& s) { return s.size() <= 11; });
        CHECK(ww.size() == 2 && ww[0] == "alpha beta" && ww[1] == "gamma delta", "wrap at spaces");
        ww = lqp::wrapWords("supercalifragilistic x", [](const std::string& s) { return s.size() <= 5; });
        CHECK(ww.size() == 2 && ww[0] == "supercalifragilistic", "a word wider than the room stays whole (never cut)");
    }
    q->destroy(); delete q;
    std::printf("big orders host (lsLiquidityProfile %s): %d passed, %d failed\n", LQ_VERSION, passes, fails);
    std::string cmd = std::string("rm -rf ") + tmp; if (std::system(cmd.c_str()) != 0) {}
    return fails ? 1 : 0;
}
