// test_bigorders_logic.cpp -- BigOrderLines.h 1.0.0 (lsLiquidityProfile 0.18.0): the biggest resting order lines, SDK-free.
//   g++ -std=c++17 -Wall -Wextra -Werror -fsanitize=address,undefined -I. test_bigorders_logic.cpp && ./a.out
// Covers: order lineage -> the biggest single order per side within reach (never a level total); the floor / past-only top 0.1%;
// dwell (flashed orders never draw); takeover; filled / pulled / partial / moved; leaving the reach; the depth-book check (LOST);
// the session record + restore (no repaint, bar-by-bar restart fuzz); "since restart"; hover rows; settings round trip; the
// layout limits (never left of the column, never past the last bar + arrow, labels never overlap); ATR14; bar of a time.
#include "BigOrderLines.h"
#include <cstdio>
#include <random>
using namespace bol;
static int fails = 0, passes = 0;
#define CHECK(c, m) do { if (c) ++passes; else { ++fails; std::printf("FAIL %d %s\n", __LINE__, m); } } while (0)

static const long long T0 = (20740LL * 86400 + 7 * 3600) * 1000;   // 7:00 AM CT
static Engine mk(long long floor = 30, Tick price = 31000, Tick reachTicks = 40) {
    Engine e; e.tick = 0.25; e.P.floor = floor; e.P.pctMinN = 1000000;   // percentile off unless a test turns it on
    e.setPrice(price, true); e.atrPrice = 0; e.reach = reachTicks; return e;
}
static int liveSide(const Engine& e, int s) { return e.live[s]; }
static const Line* liveLine(const Engine& e, int s) { return e.live[s] >= 0 ? &e.lines[(size_t)e.live[s]] : nullptr; }

static void test_biggest_single_order() {
    Engine e = mk();
    long long t = T0;
    e.onEvent(NEW, BID, 30990, 40, 1, t);           // 10 ticks below: a candidate
    e.onEvent(NEW, BID, 30980, 25, 2, t);           // under the floor
    e.onEvent(NEW, BID, 30980, 25, 3, t);           // 25 + 25 = 50 at one price: a LEVEL total - never counts
    e.onEvent(NEW, BID, 30900, 90, 4, t);           // 100 ticks below: outside the reach (40)
    e.onEvent(NEW, BID, 31010, 99, 5, t);           // a "bid" above price (wrong side beyond the 1-tick spread)
    e.onEvent(NEW, ASK, 31004, 35, 6, t);           // offer 4 ticks above
    e.onEvent(NEW, ASK, 30990, 80, 7, t);           // an "offer" below price: not on its side
    CHECK(liveSide(e, BID) < 0 && liveSide(e, ASK) < 0, "nothing drawn before the 10 s dwell");
    e.evaluate(t + 9999);
    CHECK(liveSide(e, BID) < 0, "still nothing at 9.999 s");
    e.evaluate(t + 10000);
    const Line* b = liveLine(e, BID); const Line* a = liveLine(e, ASK);
    CHECK(b && b->oid == 1 && b->size0 == 40 && b->px == 30990, "bid: the single biggest ORDER within reach (40), not the 50-lot level of two orders");
    CHECK(a && a->oid == 6 && a->size0 == 35, "offer: the biggest offer above price within reach");
    CHECK(b && b->tStart == t, "the line starts when it became the biggest (back-dated to the dwell start, never drawn before)");
    CHECK(b && b->tNew == t && b->startKnown, "appeared time known (NEW seen)");
    CHECK(e.rows.size() == 2 && e.rows[0].compare(0, 2, "S|") == 0, "two S rows recorded");
    // equal ages: the older id / earlier appearance wins on a tie
    Engine f = mk(); f.onEvent(NEW, BID, 30990, 40, 11, t); f.onEvent(NEW, BID, 30995, 40, 12, t + 1000); f.evaluate(t + 20000);
    CHECK(liveLine(f, BID) && liveLine(f, BID)->oid == 11, "tie on size: the order that appeared first");
}
static void test_floor_and_percentile() {
    Hist h; for (int i = 0; i < 999; ++i) h.add(1); h.add(500);
    CHECK(h.pct(0.999) == 500, "p99.9 of 999 x 1 + one 500 = 500 (the top 0.1%)");
    Hist g; for (int i = 0; i < 10000; ++i) g.add(i % 100 == 0 ? 20 : 2);
    CHECK(g.pct(0.999) == 20, "top 0.1% of a 1%-20-lot book = 20");
    Engine e = mk(10); e.P.pctMinN = 1000;
    long long t = T0; long long id = 100;
    for (int i = 0; i < 999; ++i) e.onEvent(NEW, BID, 30000 - i % 50, 2, id++, t);   // far: the distribution only
    CHECK(e.threshold() == 10, "under 1,000 orders: the floor alone");
    e.onEvent(NEW, BID, 30000, 60, id++, t);                                         // n = 1000 after it
    CHECK(e.threshold() == 60, "past-only distribution: the 60 itself now sets the top 0.1%");
    // past-only: the order is judged BEFORE its own size joins
    Engine p = mk(10); p.P.pctMinN = 1000;
    for (int i = 0; i < 1000; ++i) p.onEvent(NEW, BID, 30000, 2, 1000 + i, t);
    CHECK(p.threshold() == 10, "1,000 orders of 2: floor 10 (p99.9 = 2)");
    p.onEvent(NEW, BID, 30995, 15, 5000, t); p.evaluate(t + 10000);
    CHECK(liveLine(p, BID) && liveLine(p, BID)->oid == 5000 && liveLine(p, BID)->thr == 10, "a 15 qualifies against the past (min 10)");
    Engine q = mk(10); q.P.pctMinN = 1000;
    for (int i = 0; i < 1000; ++i) q.onEvent(NEW, BID, 29000, i < 5 ? 80 : 2, 2000 + i, t);   // 0.5% at 80 -> p99.9 = 80
    q.onEvent(NEW, BID, 30995, 50, 9000, t); q.evaluate(t + 10000);
    CHECK(liveSide(q, BID) < 0, "a 50 under today's top 0.1% (80) does not draw");
    CHECK(floorFor("ES") == 30 && floorFor("NQ") == 10 && floorFor("GC") == 15 && floorFor("HG") == 12 && floorFor("CL") == 15 && floorFor("NG") == 10 && floorFor("EU") == 50 && floorFor("ZZ") == 20, "per-market floors");
    Engine r = mk(10); r.onEvent(NEW, BID, 30995, 12, 1, t); r.setFloor(15); r.evaluate(t + 20000);
    CHECK(liveSide(r, BID) < 0, "floor raised to 15: a 12 is no longer a candidate");
    r.setFloor(5); r.evaluate(t + 21000); r.evaluate(t + 31000);
    CHECK(liveLine(r, BID) && liveLine(r, BID)->oid == 1, "floor lowered: the book is re-scanned (no event needed)");
}
static void test_dwell_flash() {
    Engine e = mk(); long long t = T0;
    e.onEvent(NEW, BID, 30990, 200, 1, t); e.onEvent(DEL, BID, 30990, 200, 1, t + 3000); e.evaluate(t + 20000);
    CHECK(e.lines.empty(), "a 200 flashed for 3 s and pulled: never drawn");
    Engine f = mk(); f.onEvent(NEW, BID, 30990, 200, 1, t); f.onEvent(FILL, ASK, 30990, 5, 1, t + 2000);
    CHECK(liveLine(f, BID) && liveLine(f, BID)->size0 == 200 && liveLine(f, BID)->tStart == t, "hit inside the dwell: drawn at once, label = the size when it became the biggest");
}
static void test_takeover() {
    Engine e = mk(); long long t = T0;
    e.onEvent(NEW, BID, 30990, 40, 1, t); e.evaluate(t + 10000);
    CHECK(liveLine(e, BID) && liveLine(e, BID)->oid == 1, "line 1");
    e.onEvent(NEW, BID, 30985, 40, 2, t + 11000); e.evaluate(t + 30000);
    CHECK(liveLine(e, BID)->oid == 1, "an EQUAL order never takes over");
    e.onEvent(NEW, BID, 30980, 120, 3, t + 31000);
    e.evaluate(t + 35000);
    CHECK(liveLine(e, BID)->oid == 1, "a bigger one must stay the biggest 10 s first");
    e.evaluate(t + 41000);
    CHECK(liveLine(e, BID) && liveLine(e, BID)->oid == 3 && liveLine(e, BID)->tStart == t + 31000, "Bid 120 took over after its dwell, starting where it became the biggest");
    const Line& old = e.lines[0];
    CHECK(old.end == OVER && old.tEnd == t + 41000 && old.overBy == 120 && old.left == 40, "the old line ENDS where it is (a plain end, never shortened), with what took over");
    CHECK(e.lines.size() == 2, "exactly one new line");
    std::vector<Row> rows = hoverRows(old, HoverCtx());
    CHECK(rows[0].text.find("a bigger bid took over") != std::string::npos && rows[2].text.find("(bigger: 120)") != std::string::npos, "the hover says what took over");
}
static void test_filled_pulled_partial() {
    long long t = T0;
    {   // full fill, the feed's way: FILL (the AGGRESSOR's side on the row) + MOD sync + FILL rest + DEL
        Engine e = mk(); e.onEvent(NEW, BID, 30990, 120, 1, t); e.evaluate(t + 10000);
        e.onEvent(FILL, ASK, 30990, 30, 1, t + 60000); e.onEvent(MOD, ASK, 30990, 90, 1, t + 60000);
        CHECK(liveLine(e, BID) && e.book[1].cancelled == 0 && e.book[1].traded == 30, "fill + MOD sync: 30 traded, nothing cancelled; the order keeps its BID side");
        e.onEvent(FILL, ASK, 30990, 90, 1, t + 61000);
        const Line& L = e.lines[0];
        CHECK(L.end == FILLED && L.traded == 120 && L.cancelled == 0 && L.size0 == 120 && L.tEnd == t + 61000, "FILLED (dot) when it traded away; label keeps 120");
        e.onEvent(DEL, ASK, 30990, 90, 1, t + 61000);
        CHECK(e.lines.size() == 1 && e.lines[0].end == FILLED, "the DEL after the full fill changes nothing");
    }
    {   // pulled
        Engine e = mk(); e.onEvent(NEW, ASK, 31010, 95, 1, t); e.evaluate(t + 10000);
        e.onEvent(DEL, ASK, 31010, 95, 1, t + 120000);
        const Line& L = e.lines[0];
        CHECK(L.end == PULLED && L.cancelled == 95 && L.traded == 0 && L.tEnd == t + 120000, "PULLED (X): 95 cancelled");
        std::vector<Row> r = hoverRows(L, HoverCtx());
        CHECK(r[0].text == "Ask 95 at 7,752.50 - PULLED (cancelled)" && r[0].ink == INK_RED, "hover header red for an offer");
    }
    {   // partial fill, then cancelled; a MOD down (not after a fill) = cancelled lots
        Engine e = mk(); e.onEvent(NEW, BID, 30990, 120, 1, t); e.evaluate(t + 10000);
        e.onEvent(FILL, ASK, 30990, 40, 1, t + 20000); e.onEvent(MOD, BID, 30990, 80, 1, t + 20000);
        e.onEvent(MOD, BID, 30990, 60, 1, t + 30000);
        CHECK(e.book[1].cancelled == 20 && e.book[1].traded == 40, "a MOD down not after a fill: 20 cancelled");
        e.onEvent(DEL, BID, 30990, 60, 1, t + 40000);
        const Line& L = e.lines[0];
        CHECK(L.end == PULLED && L.traded == 40 && L.cancelled == 80 && L.size0 == 120, "partial: label 120, traded 40, cancelled 80, PULLED");
        std::vector<Row> r = hoverRows(L, HoverCtx());
        CHECK(r[2].text == "Traded 40 lots - cancelled 80 lots", "hover: what traded vs cancelled");
    }
    {   // moved: X at the old price; the moved order is a fresh candidate at the new one
        Engine e = mk(); e.onEvent(NEW, BID, 30990, 120, 1, t); e.evaluate(t + 10000);
        e.onEvent(MOD, BID, 30992, 120, 1, t + 15000);
        CHECK(e.lines[0].end == MOVED && e.lines[0].movedTo == 30992 && liveSide(e, BID) < 0, "moved: the line ends with an X");
        e.evaluate(t + 25000);
        CHECK(liveLine(e, BID) && liveLine(e, BID)->px == 30992 && liveLine(e, BID)->tStart == t + 15000, "a new line at the new price after its dwell");
        CHECK(hoverRows(e.lines[0], HoverCtx()).at(0).text.find("moved to 7,748.00") != std::string::npos, "hover: moved to");
    }
}
static void test_leaving_reach() {
    Engine e = mk(30, 31000, 40); long long t = T0;
    e.onEvent(NEW, BID, 30970, 60, 1, t); e.evaluate(t + 10000);
    CHECK(liveLine(e, BID) != nullptr, "line at 30 ticks below");
    e.setPrice(31045, true); e.evaluate(t + 20000);   // 75 ticks: past 1.25 x 40 = 50
    CHECK(liveLine(e, BID) != nullptr, "out of reach for 0 s: kept");
    e.setPrice(31010, true); e.evaluate(t + 50000);
    e.setPrice(31045, true); e.evaluate(t + 60000); e.evaluate(t + 119000);
    CHECK(liveLine(e, BID) != nullptr, "came back inside within 60 s: the timer restarted, still one line");
    e.evaluate(t + 120000);
    CHECK(liveSide(e, BID) < 0 && e.lines[0].end == LEFT && e.lines[0].tEnd == t + 120000, "out of reach 60 s: LEFT (plain end, now)");
    e.setPrice(31045 - 1000, true); e.evaluate(t + 121000);   // price 1000 ticks lower: the bid is ABOVE price (wrong side)
    CHECK(e.lines.size() == 1, "nothing new on the wrong side");
    // the 1-tick spread tolerance: a bid 1 tick above the last trade still counts
    Engine f = mk(30, 31000, 40); f.onEvent(NEW, BID, 31001, 60, 1, t); f.evaluate(t + 10000);
    CHECK(liveSide(f, BID) >= 0, "1 tick of spread tolerance");
}
static void test_lost_and_session() {
    Engine e = mk(); long long t = T0;
    e.onEvent(NEW, BID, 30990, 120, 1, t); e.evaluate(t + 10000);
    e.checkBook(BID, 30990, 200, true, 1000, t + 11000);
    e.checkBook(BID, 30990, 10, false, 2000, t + 12000);
    e.checkBook(BID, 30990, 10, true, 3000, t + 13000);
    e.checkBook(BID, 30990, 10, true, 7999, t + 17000);
    CHECK(liveSide(e, BID) >= 0, "the depth book short for < 5 s: kept");
    e.checkBook(BID, 30990, 10, true, 8000, t + 18000);
    CHECK(liveSide(e, BID) < 0 && e.lines[0].end == LOST && e.lostEnds == 1 && !e.book.count(1), "the book shows 10 < 120 for 5 s: the feed missed its exit (plain end)");
    Engine s = mk(); s.onEvent(NEW, ASK, 31010, 50, 1, t); s.evaluate(t + 10000);
    s.endSession(t + 99000); CHECK(s.lines[0].end == SESSION && s.rows.back().find("|SESSION|") != std::string::npos, "session end: a plain end, recorded in the old file");
    s.clearSession(); CHECK(s.lines.empty() && s.rows.empty() && s.hist.n == 0 && s.book.count(1), "a new session: lines + distribution start over, the book stays");
    s.evaluate(t + 200000); s.evaluate(t + 210000);
    CHECK(liveLine(s, ASK) && liveLine(s, ASK)->tNew == t && liveLine(s, ASK)->startKnown, "the still-resting order starts a line in the new session with its real age");
}
// ---- no repaint: the record + restore ----
static std::vector<std::string> feedScenario(Engine& e, long long t, int upto, std::vector<std::string>& file) {
    // a scripted day: events every second, bars of 60 s; the record rows flushed each step
    std::mt19937 rng(7); std::vector<std::string> all;
    long long id = 1; std::vector<long long> alive;
    for (int k = 0; k < upto; ++k) {
        const long long tk = t + k * 1000LL;
        const int r = (int)(rng() % 100);
        if (r < 30) { const Tick p = 31000 + (Tick)(rng() % 60) - 30; e.setPrice(p, true); e.onEvent(FILL, BID, p, 1, 999999, tk); }
        else if (r < 55) { const int side = rng() % 2; const Tick p = side == BID ? 31000 - (Tick)(rng() % 45) : 31000 + (Tick)(rng() % 45); e.onEvent(NEW, side, p, 20 + (long long)(rng() % 150), id, tk); alive.push_back(id++); }
        else if (r < 70 && !alive.empty()) { const size_t j = rng() % alive.size(); const long long o = alive[j]; std::unordered_map<long long, Ord>::const_iterator it = e.book.find(o); if (it != e.book.end()) e.onEvent(DEL, it->second.side, it->second.px, it->second.size, o, tk); alive.erase(alive.begin() + (long)j); }
        else if (r < 80 && !alive.empty()) { const long long o = alive[rng() % alive.size()]; std::unordered_map<long long, Ord>::const_iterator it = e.book.find(o); if (it != e.book.end()) { const int sd = it->second.side; const Tick p = it->second.px; const long long sz = it->second.size; e.onEvent(FILL, 1 - sd, p, std::min<long long>(sz, 10), o, tk); e.onEvent(MOD, 1 - sd, p, std::max<long long>(0, sz - 10), o, tk); } }
        else e.evaluate(tk);
        if (k % 30 == 0 && (e.live[0] >= 0 || e.live[1] >= 0)) e.rows.push_back(Engine::hRow(tk));
        for (size_t i = 0; i < e.rows.size(); ++i) file.push_back(e.rows[i]);
        e.rows.clear();
    }
    return all;
}
static bool sameEnded(const Line& a, const Line& b) {
    return a.key == b.key && a.oid == b.oid && a.side == b.side && a.px == b.px && a.size0 == b.size0 && a.tStart == b.tStart && a.end == b.end && a.tEnd == b.tEnd
        && a.traded == b.traded && a.cancelled == b.cancelled && a.startKnown == b.startKnown;
}
static void test_no_repaint() {
    const long long t = T0;
    Engine full = mk(); std::vector<std::string> fileFull; feedScenario(full, t, 3000, fileFull);
    CHECK(full.lines.size() >= 10, "the scripted day draws lines");
    // every line, once ended, never changes again: snapshot after each step of a second run
    {
        Engine e = mk(); std::vector<std::string> f; std::map<long long, Line> seen; bool changed = false;
        for (int upto = 100; upto <= 3000; upto += 100) {
            Engine x = mk(); std::vector<std::string> fx; feedScenario(x, t, upto, fx);
            for (size_t i = 0; i < x.lines.size(); ++i) { const Line& L = x.lines[i]; if (L.end == RESTING) continue;
                std::map<long long, Line>::iterator s = seen.find(L.key); if (s == seen.end()) seen[L.key] = L; else if (!sameEnded(s->second, L)) changed = true; }
        }
        CHECK(!changed && seen.size() >= 10, "an ended line is identical in every later state (it only ever extends, then ends once)");
    }
    // a restart after N steps: the file read back = the same lines; open ones end at the last heartbeat; later state never rewrites them
    int bad = 0, restored = 0;
    for (int cut = 200; cut <= 2800; cut += 300) {
        Engine a = mk(); std::vector<std::string> f; feedScenario(a, t, cut, f);
        Engine b = mk(); long long nb = 0; b.restore(f, &nb); restored++;
        if (nb != 0) bad++;
        long long lastH = 0; for (size_t i = 0; i < f.size(); ++i) if (f[i].compare(0, 2, "H|") == 0) lastH = std::atoll(f[i].c_str() + 2);
        for (size_t i = 0; i < a.lines.size(); ++i) {
            const Line& L = a.lines[i]; const Line* R = nullptr;
            for (size_t j = 0; j < b.lines.size(); ++j) if (b.lines[j].key == L.key) R = &b.lines[j];
            if (!R) { bad++; continue; }
            if (L.end != RESTING) { if (!sameEnded(L, *R)) bad++; }
            else if (!(R->end == RESTART && R->tEnd == std::max(L.tStart, lastH) && R->tStart == L.tStart && R->size0 == L.size0)) bad++;
        }
        CHECK(b.rows.size() == (size_t)((a.live[0] >= 0) + (a.live[1] >= 0)), "the restore writes one RESTART end per line that was resting");
        // reading the file again (with those E rows appended) gives the same picture: idempotent
        std::vector<std::string> f2 = f; for (size_t i = 0; i < b.rows.size(); ++i) f2.push_back(b.rows[i]);
        Engine c = mk(); c.restore(f2);
        bool same = c.lines.size() == b.lines.size(); for (size_t i = 0; same && i < c.lines.size(); ++i) same = sameEnded(c.lines[i], b.lines[i]);
        CHECK(same && c.rows.empty(), "read back twice = the same lines, nothing more to write");
        // after the restart, new lines take NEW keys (never reuse a drawn one)
        c.onEvent(NEW, BID, 30995, 500, 777777, t + cut * 1000LL + 5000); c.evaluate(t + cut * 1000LL + 20000);
        if (c.live[BID] >= 0) { long long mx = 0; for (size_t i = 0; i + 1 < c.lines.size(); ++i) mx = std::max(mx, c.lines[i].key); if (c.lines.back().key <= mx) bad++; }
    }
    CHECK(bad == 0 && restored == 9, "restart after every 300 s: ended lines byte-identical, resting ones end at the last heartbeat");
    // malformed rows are skipped and counted; never crash
    Engine g = mk(); long long nb = 0;
    std::vector<std::string> junk = { Engine::header(), "S|x|1|0|1|1|1|1|1|0|1", "E|1|5|NOPE|0|0|0|0|0", "H|abc", "S|1|5|0|30990|40|10|10|1|0|30", "E|1|50|FILL|40|0|0|0|0", "E|1|60|PULL|0|40|0|0|0", "Q|1", std::string(5000, 'x'), "" };
    g.restore(junk, &nb);
    CHECK(g.lines.size() == 1 && g.lines[0].end == FILLED && g.lines[0].tEnd == 50 && nb == 6, "garbage skipped (6 rows), the FIRST end wins");
}
static void test_since_restart() {
    const long long t = T0;
    Engine e = mk(); std::vector<std::string> prior = { "S|1|5|0|30990|40|" + std::to_string(t) + "|" + std::to_string(t) + "|1|0|30", "H|" + std::to_string(t + 60000) };
    e.restore(prior);
    CHECK(e.restarted && e.lines[0].end == RESTART && e.lines[0].tEnd == t + 60000, "IRT closed while it rested: ends at the last heartbeat");
    std::vector<Row> r0 = hoverRows(e.lines[0], HoverCtx());
    CHECK(r0[0].text.find("IRT closed - after 7:01 AM not known") != std::string::npos, "hover: what happened after is not known");
    // after the restart an order first seen by a MOD rested before: no known start, "since restart"
    e.onEvent(MOD, BID, 30992, 150, 42, t + 600000); e.evaluate(t + 610000);
    const Line* L = liveLine(e, BID);
    CHECK(L && !L->startKnown && L->sinceRestart && L->tNew == t + 600000, "first seen after the restart: start NOT known, since restart");
    HoverCtx c; c.nowMs = t + 900000;
    std::vector<Row> r = hoverRows(e.now((size_t)e.live[BID]), c);
    CHECK(r[1].text == "Seen since restart 7:10 AM - start not known, rested 5 min 0 s+", "hover: since restart, never an invented age");
    Engine f = mk(); f.onEvent(MOD, BID, 30992, 150, 42, t); f.evaluate(t + 10000);
    CHECK(liveLine(f, BID) && !liveLine(f, BID)->sinceRestart && hoverRows(*liveLine(f, BID), c)[1].text.find("Seen since the chart opened") == 0, "no earlier file: since the chart opened");
    // a FILL / DEL of an order never seen: nothing invented
    Engine g = mk(); g.onEvent(FILL, ASK, 30990, 50, 77, t); g.onEvent(DEL, BID, 30990, 50, 78, t);
    CHECK(g.book.empty() && g.lines.empty() && g.unknown == 2, "fills / deletes of unknown orders are only counted");
}
static void test_hover_rows() {
    Line L; L.side = BID; L.px = 119620; L.size0 = 120; L.tNew = T0 - 3 * 60000; L.tStart = L.tNew; L.end = FILLED; L.tEnd = T0 + 11 * 60000 + 20000; L.traded = 120;
    HoverCtx c; c.tick = 0.25; c.reachAtr = 2.0; c.atrPrice = 6.25; c.minLots = 30; c.floor = 30; c.pctLots = 15;
    std::vector<Row> r = hoverRows(L, c);
    CHECK(r.size() <= 12 && r.size() >= 8, "8-12 rows");
    bool len = true; for (size_t i = 0; i < r.size(); ++i) if (r[i].text.size() > 125) { len = false; std::printf("  long row %zu: %zu\n", i, r[i].text.size()); }
    CHECK(len, "every row <= 125 characters (lesson 83)");
    CHECK(r[0].text == "Bid 120 at 29,905.00 - FILLED (traded away)" && r[0].ink == INK_GREEN, "size, price, filled - green bid");
    CHECK(r[1].text == "Appeared 6:57 AM - rested 14 min 20 s", "appeared (12-hour CT) and how long it rested");
    CHECK(r[2].text == "Traded 120 lots - cancelled 0 lots", "traded vs cancelled");
    CHECK(r[3].text.find("within 2.0 ATR (12.50) below price; min 30 lots (floor 30, top 0.1% today 15)") != std::string::npos && r[3].ink == INK_GREY, "the rule and its numbers");
    bool q = false, how = false, use = false, ex = false, lim = false;
    for (size_t i = 0; i < r.size(); ++i) { q |= r[i].text.find("Answers:") == 0; how |= r[i].text.find("How:") == 0; use |= r[i].text.find("Use:") == 0; ex |= r[i].text.find("e.g.") == 0; lim |= r[i].text.find("hidden / iceberg size cannot be seen") != std::string::npos; }
    CHECK(q && how && use && ex && lim, "what it answers / how / use / example / the honest limit");
    L.end = RESTING; L.left = 70; L.traded = 50; c.nowMs = T0 + 60000;
    r = hoverRows(L, c);
    CHECK(r[0].text.find("still resting") != std::string::npos && r[2].text == "Traded 50 lots - cancelled 0 lots - 70 still showing", "resting: what still shows");
    Line A = L; A.side = ASK; A.end = LEFT; A.tEnd = T0;
    r = hoverRows(A, c); CHECK(r[0].ink == INK_RED && r[0].text.find("left the reach") != std::string::npos && r[3].text.find("above price") != std::string::npos, "offer: red, above");
    CHECK(clock12((20740LL * 86400 + 13 * 3600 + 5 * 60) * 1000) == "1:05 PM" && clock12((20740LL * 86400) * 1000) == "12:00 AM" && clock12((20740LL * 86400 + 12 * 3600) * 1000) == "12:00 PM", "12-hour clock");
    CHECK(price(119620, 0.25) == "29,905.00" && price(13540, 0.0005) == "6.7700" && price(22361, 0.00005) == "1.11805", "prices with the tick's decimals");
}
static void test_settings() {
    Settings s; s.on = false; s.reach10 = 25; s.minLots = 45; s.keep = 7; s.font = 13;
    Settings r; CHECK(parseSettings(settingsLine(s), r) && !r.on && r.reach10 == 25 && r.minLots == 45 && r.keep == 7 && r.font == 13, "round trip");
    CHECK(settingsLine(Settings()) == "BOL1,1,20,0,10,11", "defaults: on, 2.0 ATR, market floor, 10 kept, 11 pt");
    const char* bad[] = { "", "BOL1,1,20,0,10", "BOL2,1,20,0,10,11", "BOL1,2,20,0,10,11", "BOL1,1,4,0,10,11", "BOL1,1,51,0,10,11", "BOL1,1,20,-1,10,11",
                          "BOL1,1,20,0,51,11", "BOL1,1,20,0,10,9", "BOL1,1,20,0,10,17", "BOL1,1,2.0,0,10,11", "BOL1,1,20,0,10,11,x", "BOL1, 1,20,0,10,11" };
    int ok = 0; for (size_t i = 0; i < sizeof(bad) / sizeof(bad[0]); ++i) { Settings z; if (!parseSettings(bad[i], z) && !z.ok && !z.why.empty()) ++ok; }
    CHECK(ok == (int)(sizeof(bad) / sizeof(bad[0])), "every garbled / out-of-range file refused with a reason");
    Settings z; CHECK(parseSettings("BOL1,1,20,0,10,11\r\n", z) && z.ok, "CRLF accepted");
    Settings fileV; fileV.reach10 = 30; fileV.keep = 5; fileV.font = 12;
    const Settings c1 = cleanSettings(true, 99.0, -5, 999, 3, fileV);
    CHECK(c1.reach10 == 30 && c1.minLots == 0 && c1.keep == 5 && c1.font == 12, "garbage dialog values keep the file's (never reach the file)");
    const Settings c2 = cleanSettings(false, 1.5, 40, 0, 16, fileV);
    CHECK(!c2.on && c2.reach10 == 15 && c2.minLots == 40 && c2.keep == 0 && c2.font == 16, "good values taken");
    const Settings c3 = cleanSettings(true, std::nan(""), 40, 3, 11, fileV); CHECK(c3.reach10 == 30, "NaN reach refused");
}
static void test_layout() {
    View V; V.xMin = 100; V.xMax = 900; V.yTop = 50; V.yBot = 950; V.rowH = 18;
    std::mt19937 rng(11); int out = 0, overlap = 0, lbl = 0, total = 0;
    for (int it = 0; it < 3000; ++it) {
        std::vector<Seg> segs; const int n = 1 + (int)(rng() % 12);
        for (int i = 0; i < n; ++i) {
            Seg s; s.line = (size_t)i; s.side = (int)(rng() % 2); s.x0 = (int)(rng() % 1200) - 200; s.x1 = s.x0 + (int)(rng() % 900); s.y = (int)(rng() % 1100) - 50;
            s.live = i < 2 && rng() % 2; if (s.live) s.x1 = 891; s.end = s.live ? RESTING : 1 + (int)(rng() % 8); s.text = s.side == BID ? "Bid 120" : "Ask 95"; s.textW = 50; segs.push_back(s);
        }
        const std::vector<Op> ops = layout(segs, V);
        std::vector<const Op*> labs;
        for (size_t i = 0; i < ops.size(); ++i) {
            const Op& o = ops[i]; ++total;
            if (o.x0 < V.xMin || o.x1 > V.xMax || std::min(o.y0, o.y1) < V.yTop - MARK_R - V.rowH || std::max(o.y0, o.y1) > V.yBot + MARK_R + V.rowH){ ++out; if (out < 4) std::printf("  out: kind %d x %d..%d y %d..%d\n", o.kind, o.x0, o.x1, o.y0, o.y1); }
            if (o.kind == OP_LINE && (o.y0 < V.yTop || o.y0 > V.yBot)) ++out;
            if (o.kind == OP_LABEL) { ++lbl; if (o.y0 < V.yTop || o.y1 > V.yBot) ++out; for (size_t j = 0; j < labs.size(); ++j) { const Op& p = *labs[j]; if (o.x0 < p.x1 && p.x0 < o.x1 && o.y0 < p.y1 && p.y0 < o.y1) ++overlap; } labs.push_back(&o); }
        }
    }
    std::printf("  layout fuzz: %d ops, %d labels, %d out, %d overlaps\n", total, lbl, out, overlap);
    CHECK(out == 0 && overlap == 0 && lbl > 1000, "3,000 random layouts: nothing left of the column / right of the last bar + arrow / off the pane, no two labels overlap");
    // the label sits at the LEFT end, left of the start when there is room
    Seg s; s.line = 0; s.side = BID; s.x0 = 400; s.x1 = 700; s.y = 500; s.end = FILLED; s.text = "Bid 120"; s.textW = 50;
    std::vector<Op> ops = layout(std::vector<Seg>(1, s), V);
    const Op* lb = nullptr; const Op* dot = nullptr; for (size_t i = 0; i < ops.size(); ++i) { if (ops[i].kind == OP_LABEL) lb = &ops[i]; if (ops[i].kind == OP_DOT) dot = &ops[i]; }
    CHECK(lb && lb->x1 == 400 - LABEL_GAP && lb->text == "Bid 120", "label just left of the line's start");
    CHECK(dot && dot->x0 == 700 - MARK_R && dot->x1 == 700 + MARK_R, "a filled dot at the end");
    s.x0 = 20; ops = layout(std::vector<Seg>(1, s), V);
    for (size_t i = 0; i < ops.size(); ++i) { if (ops[i].kind == OP_LINE) CHECK(ops[i].x0 == V.xMin, "a line starting under the column is clipped at its edge"); if (ops[i].kind == OP_LABEL) CHECK(ops[i].x0 >= V.xMin && ops[i].y1 <= s.y, "its label goes above the line, right of the column"); }
    Seg l = s; l.live = true; l.end = RESTING; l.x0 = 300; l.x1 = 900; ops = layout(std::vector<Seg>(1, l), V);
    const Op* ar = nullptr; for (size_t i = 0; i < ops.size(); ++i) if (ops[i].kind == OP_ARROW) ar = &ops[i];
    CHECK(ar && ar->x1 <= V.xMax && ar->x1 - ar->x0 == ARROW_W, "the live arrow ends inside xMax (before the right-side columns)");
    Seg p = s; p.end = PULLED; ops = layout(std::vector<Seg>(1, p), V); bool x = false; for (size_t i = 0; i < ops.size(); ++i) x |= ops[i].kind == OP_X; CHECK(x, "pulled: an X");
    Seg o = s; o.end = OVER; ops = layout(std::vector<Seg>(1, o), V); bool mark = false; for (size_t i = 0; i < ops.size(); ++i) mark |= ops[i].kind == OP_X || ops[i].kind == OP_DOT || ops[i].kind == OP_ARROW; CHECK(!mark, "taken over / left / lost / restart: a plain end");
    Seg off = s; off.x0 = -500; off.x1 = 50; CHECK(layout(std::vector<Seg>(1, off), V).empty(), "a line entirely under the column / scrolled off: nothing");
    // lesson 49: labels decided in TIME order - appending a newer line never moves or removes an older line's label
    int moved = 0, runs = 0;
    for (int it = 0; it < 3000; ++it) {
        std::vector<Seg> segs; const int n = 1 + (int)(rng() % 10);
        for (int i = 0; i < n; ++i) { Seg q; q.line = (size_t)i; q.side = (int)(rng() % 2); q.x0 = 100 + (int)(rng() % 700); q.x1 = q.x0 + (int)(rng() % 200); q.y = 60 + (int)(rng() % 120); q.end = FILLED; q.text = "Bid " + std::to_string(30 + i); q.textW = 50; segs.push_back(q); }
        std::vector<Op> a1 = layout(segs, V);
        Seg nw; nw.line = (size_t)n; nw.side = BID; nw.x0 = 100 + (int)(rng() % 700); nw.x1 = 880; nw.y = 60 + (int)(rng() % 120); nw.live = true; nw.end = RESTING; nw.text = "Bid 999"; nw.textW = 50;
        std::vector<Seg> more = segs; more.insert(more.begin(), nw);                  // handed in any order
        std::vector<Op> a2 = layout(more, V); ++runs;
        for (size_t i = 0; i < a1.size(); ++i) if (a1[i].kind == OP_LABEL) { bool same = false; for (size_t j = 0; j < a2.size(); ++j) if (a2[j].kind == OP_LABEL && a2[j].line == a1[i].line && a2[j].x0 == a1[i].x0 && a2[j].y0 == a1[i].y0) same = true; if (!same) ++moved; }
    }
    CHECK(moved == 0 && runs == 3000, "3,000 layouts: a newer line never moves / removes an older label (time order, lesson 49)");
    Seg r1 = s; r1.line = 0; r1.x0 = 300; r1.x1 = 400; r1.end = LEFT; Seg r2 = r1; r2.line = 1; r2.x0 = 500; r2.x1 = 600; r2.end = OVER; Seg r3 = r1; r3.line = 2; r3.x0 = 650; r3.x1 = 880; r3.live = true; r3.end = RESTING;
    std::vector<Seg> rep; rep.push_back(r3); rep.push_back(r1); rep.push_back(r2);
    ops = layout(rep, V); int nl = 0, nlines = 0; for (size_t i = 0; i < ops.size(); ++i) { if (ops[i].kind == OP_LABEL) { ++nl; CHECK(ops[i].line == 0, "the first line keeps the label"); } if (ops[i].kind == OP_LINE) ++nlines; }
    CHECK(nl == 1 && nlines == 3, "the same order back on the same price: 3 lines, its label once");
}
static void test_bounded_book() {
    Engine e = mk(); e.P.bookCap = 50; long long t = T0;
    e.onEvent(NEW, BID, 30990, 120, 1, t); e.evaluate(t + 10000);
    for (int i = 0; i < 500; ++i) e.onEvent(NEW, i % 2 ? BID : ASK, i % 2 ? 20000 - i : 40000 + i, 2, 1000 + i, t + 11000);
    CHECK(e.book.size() <= 50 && e.book.count(1) && e.live[BID] >= 0 && e.drops > 0, "bounded book: far orders dropped, the live line's order kept");
    e.onEvent(DEL, BID, 30990, 120, 1, t + 20000);
    CHECK(e.lines[0].end == PULLED, "and its exit still seen");
}
static void test_atr_barof() {
    std::vector<double> H, L, C;
    for (int i = 0; i < 15; ++i) { H.push_back(102); L.push_back(100); C.push_back(101); }
    CHECK(std::fabs(atr14(H, L, C) - 2.0) < 1e-12, "ATR14 of 2-point bars = 2");
    H.back() = 110; CHECK(std::fabs(atr14(H, L, C) - (13 * 2.0 + 10) / 14.0) < 1e-12, "true range uses the bar's own high / low");
    std::vector<double> h2 = H, l2 = L, c2 = C; c2[13] = 90; h2[14] = 95; l2[14] = 94; CHECK(std::fabs(atr14(h2, l2, c2) - ((12 * 2.0 + 2.0 + 5.0) / 14.0)) < 1e-12, "a gap counts from the prior close");
    H.pop_back(); L.pop_back(); C.pop_back(); CHECK(atr14(H, L, C) == 0, "fewer than 15 closed bars: no ATR (nothing drawn)");
    std::vector<double> n(15, 100), lo(15, 99), cl(15, 99.5); n[5] = std::nan(""); CHECK(atr14(n, lo, cl) == 0, "NaN: no ATR");
    std::vector<long long> ends = { 180000, 360000, 540000, 720000 };
    CHECK(barOf(ends, 1000) == 0 && barOf(ends, 179999) == 0 && barOf(ends, 180000) == 1 && barOf(ends, 719999) == 3 && barOf(ends, 900000) == 3, "bars stamp their END: [end-1, end)");
    CHECK(barOf(ends, 0) == -1 && barOf(std::vector<long long>(), 5) == -1, "unknown time / no bars");
}
int main() {
    test_biggest_single_order(); test_floor_and_percentile(); test_dwell_flash(); test_takeover(); test_filled_pulled_partial(); test_leaving_reach();
    test_lost_and_session(); test_no_repaint(); test_since_restart(); test_hover_rows(); test_settings(); test_layout(); test_bounded_book(); test_atr_barof();
    std::printf("big orders logic (BigOrderLines %s): %d passed, %d failed\n", VERSION, passes, fails);
    return fails ? 1 : 0;
}
