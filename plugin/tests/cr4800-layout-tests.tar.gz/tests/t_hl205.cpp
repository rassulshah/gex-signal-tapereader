// HL 2.0.5 (2026-10-13 night) tests: the header "Regime: <Gamma> / <Trend>" (Rassul 21:01, "Range" in white 21:20, "Downtrend" spelled
// out), the trend computed natively from CLOSED bars (vtl::fromChart RTH - the Tape Reader TREND vote's rule; no repaint), Top centre
// under the 22 px IRT title row, and the overlap boxes (Dealer Profile header / banner, Tape Reader box; the projection label too).
//   g++ -std=c++14 -fsanitize=address,undefined -I mock_sdk -I../src t_hl205.cpp -o ../out/t_hl205 && ../out/t_hl205 ../data ../out
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <unistd.h>
#include <utime.h>
#include <sys/stat.h>
#include "HodLod.cpp"
static int fails = 0, passes = 0;
#define CHECK(c, m) do { if (c) ++passes; else { ++fails; std::printf("  FAIL %s (line %d)\n", std::string(m).c_str(), __LINE__); } } while (0)
static std::string slurp(const std::string& p) { std::ifstream f(p.c_str()); std::stringstream s; s << f.rdbuf(); return s.str(); }
static void put(const std::string& p, const std::string& s) { std::ofstream o(p.c_str(), std::ios::binary); o << s; }
static std::string kvLine(const std::string& st0, const std::string& k) { const std::string st = "\n" + st0; size_t a = st.find("\n" + k + ","); if (a == std::string::npos) return ""; a += k.size() + 2; return st.substr(a, st.find('\n', a) - a); }
struct Row { RTDATE t; float o, h, l, c; unsigned long v; };
static std::vector<Row> load(const std::string& path) {
    std::vector<Row> R; std::ifstream f(path.c_str()); std::string ln;
    while (std::getline(f, ln)) { int Y, M, D, h, m, s; double o, H, L, c, v = 1;
        int n = std::sscanf(ln.c_str(), "%d-%d-%d %d:%d:%d,%lf,%lf,%lf,%lf,%lf", &Y, &M, &D, &h, &m, &s, &o, &H, &L, &c, &v); if (n < 10) continue;
        R.push_back(Row{ (RTDATE)(hl::daysFromCivil(Y, M, D) * 86400 + h * 3600 + m * 60 + s), (float)o, (float)H, (float)L, (float)c, (unsigned long)v }); }
    return R;
}
static void fill(mock::Chart& C, const std::vector<Row>& R, size_t n, bool vol) {
    C.t.clear(); C.o.clear(); C.h.clear(); C.l.clear(); C.c.clear(); C.vol.clear(); C.drawn.clear();
    for (size_t i = 0; i < n && i < R.size(); i++) { C.t.push_back(R[i].t); C.o.push_back(R[i].o); C.h.push_back(R[i].h); C.l.push_back(R[i].l); C.c.push_back(R[i].c); if (vol) C.vol.push_back(R[i].v); }
}
static const mock::Drawn* findText(const mock::Chart& C, const std::string& s) { for (size_t i = 0; i < C.drawn.size(); i++) if (C.drawn[i].kind == 1 && C.drawn[i].s == s) return &C.drawn[i]; return nullptr; }
static int measure(const std::string& s, int fs, bool bold) { double w = 0; for (size_t i = 0; i < s.size(); i++) w += (bold ? ADV_BOLD : ADV_REG)[(unsigned char)s[i]]; return (int)(w * fs * 96.0 / 72.0 / 1000.0 + 0.999); }

int main(int argc, char** argv)
{
    std::string data = argc > 1 ? argv[1] : "../data";
    char tmpl[] = "/tmp/hl205XXXXXX"; std::string prof = mkdtemp(tmpl); setenv("USERPROFILE", prof.c_str(), 1);

    std::printf("[1] header words and colours\n");
    {
        // the words are vtl::displayLabel's (the agreed Session Info strings) for every trend level, "Range" for none
        const char* want[5] = { "Strong Dntrend", "Dntrend", "Range", "Uptrend", "Strong Uptrend" };
        for (int l = -2; l <= 2; l++) CHECK(hl::trendWord(l) == want[l + 2], std::string("trend word ") + want[l + 2]);
        for (int st = -1; st <= 1; st++) for (int sg = 0; sg < 2; sg++) {
            if (st == 0 && sg) continue;
            vtl::Trend t; t.ready = true; t.state = st; t.strength = sg ? vtl::STR_STRONG : vtl::STR_NONE;
            const std::string dl = vtl::displayLabel(t);
            CHECK(hl::trendWord(vtl::level(t)) == (dl.empty() ? std::string("Range") : dl), "trendWord == vtl::displayLabel for state " + std::to_string(st) + (sg ? " strong" : ""));
        }
        CHECK(hl::trendCol(2) == hl::C_GREEN && hl::trendCol(1) == hl::C_GREEN, "up = green");
        CHECK(hl::trendCol(-1) == hl::C_RED && hl::trendCol(-2) == hl::C_RED, "down = red");
        CHECK(hl::trendCol(0) == hl::C_SLATE, "Range = the table's white text (no extra colour)");
        // every combination: gamma Pos / Neg / no file x trend Strong Up / Up / Range / Dn / Strong Dn / not ready
        const char* gIn[3] = { "Regime: Positive", "Regime: Negative", nullptr };
        const char* gOut[3] = { "Regime: Pos", "Regime: Neg", "Regime: --" };
        const unsigned gCol[3] = { hl::C_GREEN, hl::C_RED, hl::C_GREY };
        int combos = 0;
        for (int g = 0; g < 3; g++) for (int l = -2; l <= 3; l++) {   // l == 3: trend not ready
            hl::View v; if (gIn[g]) v.sessSegs.push_back(hl::Seg{ gIn[g], gCol[g] });
            v.sessSegs.push_back(hl::Seg{ "Expiry 3:00 PM", hl::C_GREY });
            v.trendReady = l != 3; v.trendLvl = l == 3 ? 0 : l;
            std::vector<hl::Seg> p = hl::regimeParts(v);
            std::string tag = std::string(gOut[g]) + " x " + (l == 3 ? "not ready" : hl::trendWord(l));
            if (l == 3) {
                if (gIn[g]) CHECK(p.size() == 1 && p[0].s == gOut[g] && p[0].col == gCol[g], tag + ": gamma only, never a guessed 'Range'");
                else CHECK(p.empty(), tag + ": no Regime cell");
            } else {
                CHECK(p.size() == 2 && p[0].s == gOut[g] && p[0].col == gCol[g] && p[1].s == " / " + hl::trendWord(l) && p[1].col == hl::trendCol(l), tag);
                CHECK(hl::regimeText(v) == std::string(gOut[g]) + " / " + hl::trendWord(l), tag + " text");
            }
            combos++;
        }
        CHECK(combos == 18, "18 combinations");
        { hl::View v; v.sessSegs.push_back(hl::Seg{ "Regime: Negative", hl::C_RED }); v.trendReady = true;
          v.trendLvl = 1; CHECK(hl::regimeText(v) == "Regime: Neg / Uptrend", "the 21:01 example 'Regime: Neg / Uptrend'");
          v.trendLvl = 0; CHECK(hl::regimeText(v) == "Regime: Neg / Range", "no trend: 'Regime: Neg / Range' (21:20)");
          v.sessSegs[0] = hl::Seg{ "Regime: Positive", hl::C_GREEN }; v.trendLvl = -1; CHECK(hl::regimeText(v) == "Regime: Pos / Dntrend", "'Regime: Pos / Dntrend'");
          v.trendLvl = -2; CHECK(hl::regimeText(v, true) == "Regime: Pos / Strong Dn", "compact form only on request"); }
    }

    std::printf("[2] placeAvoid\n");
    {
        hl::Box area = { 110, 22, 1000, 740 };
        std::vector<hl::Box> none;
        bool mv = true, cl = false;
        hl::Box b = hl::placeAvoid(area, 400, 100, 1, none, &mv, &cl);
        CHECK(!mv && cl && b.t == 22 && b.l == (110 + 1000) / 2 - 200, "nothing in the way: the Position spot");
        std::vector<hl::Box> av; av.push_back(hl::Box{ 300, 0, 900, 140 });   // a Tape Reader box moved to Top centre
        b = hl::placeAvoid(area, 400, 100, 1, av, &mv, &cl);
        CHECK(mv && cl && !hl::overlap(b, av[0]) && b.t == 144 && b.l == (110 + 1000) / 2 - 200, "Tape Reader at the top: the table drops just under it, same column");
        av.clear(); av.push_back(hl::Box{ 760, 0, 1010, 46 });                  // the Dealer Profile header reaching left of the last bar
        b = hl::placeAvoid(area, 400, 100, 2, av, &mv, &cl);
        CHECK(mv && !hl::overlap(b, av[0]) && b.r <= 1000 && b.t >= 22, "Top right under the Dealer Profile header: moved clear, inside the area");
        av.clear(); av.push_back(hl::Box{ 0, 0, 2000, 2000 });
        b = hl::placeAvoid(area, 400, 100, 1, av, &mv, &cl);
        CHECK(!cl && !mv && b.t == 22, "no clear spot at all: the Position spot, reported not clear");
    }

    std::printf("[3] layout on real ES bars: header parts, version, title row, overlaps\n");
    {
        std::vector<Row> R = load(data + "/es_long.csv");
        std::vector<hl::Bar> B; size_t cut = 0;
        for (size_t i = 0; i < R.size(); i++) { hl::Bar b; b.absEnd = R[i].t; b.o = R[i].o; b.h = R[i].h; b.l = R[i].l; b.c = R[i].c; b.v = NAN; B.push_back(b); }
        // up to 2026-10-09 11:42 (the mockup's frame)
        long long stop = hl::daysFromCivil(2026, 10, 9) * 86400 + 11 * 3600 + 42 * 60; while (cut < B.size() && B[cut].absEnd <= stop) cut++;
        B.resize(cut);
        hl::Cfg c; c.mkt = hl::mktIndex("ES"); c.per = 180; c.tick = 0.25; c.readOpen = hl::readOpenFor(c.mkt); c.readN = hl::readNFor(c.mkt);
        std::vector<hl::ReadRow> rows; hl::Tracker T = hl::runBars(c, B, B.size(), &rows);
        hl::View v = hl::buildView(T, rows.empty() ? hl::ReadOut() : rows.back().out, &rows, nullptr);
        v.sessSegs.push_back(hl::Seg{ "Regime: Negative", hl::C_RED }); v.sessSegs.push_back(hl::Seg{ "Expiry 3:00 PM (in 3h 18m)", hl::C_GREY });
        v.trendReady = true; v.trendLvl = 1;
        auto yOf = [&](long long tk) { return (int)std::lround((7900.0 - tk * 0.25) / 120.0 * 620); };
        int nBad = 0, nTitle = 0, nAvoid = 0, nRuns = 0, nCompact = 0, nProjHit = 0, nOnTable = 0;
        for (int W : { 900, 1170, 1600 }) for (int pos = 0; pos < 9; pos++) for (int withAvoid = 0; withAvoid < 2; withAvoid++) {
            hl::Box pane = { 0, 0, W, 620 }; std::vector<hl::Box> av;
            if (withAvoid) { av.push_back(hl::Box{ W - 250, 0, W, 46 }); av.push_back(hl::Box{ 0, 0, 440, 32 });
                             av.push_back(hl::placeIn(hl::Box{ 110, 2, (int)(W * 0.85), 618 }, 600, 150, pos == 7 ? 1 : 7)); }   // the Tape Reader opposite
            hl::Layout L = hl::layoutAll(v, pane, yOf, measure, (int)(W * 0.85), pos, 300, &av);
            nRuns++;
            if (!L.tableOk) { nBad++; continue; }
            if (L.table.t < pane.t + hl::TITLE_ROW_PX) nTitle++;
            if (L.table.r > (int)(W * 0.85) + 1) nBad++;
            if (L.trendCompact) nCompact++;
            for (size_t k = 0; k < av.size(); k++) if (hl::overlap(L.table, av[k]) && L.tableClear) nAvoid++;
            for (size_t i = 0; i < L.items.size(); i++) { const hl::Item& it = L.items[i]; if (it.k != hl::K_TEXT || it.role == hl::R_TABLE) continue;
                hl::Box b = { it.l, it.t, it.r, it.b }; for (size_t k = 0; k < av.size(); k++) if (hl::overlap(b, av[k])) nProjHit++;
                if (hl::overlap(b, L.table)) nOnTable++; }
            if (W == 1170 && pos == 1 && !withAvoid) {
                const hl::Item* a = nullptr; const hl::Item* b = nullptr; const hl::Item* ver = nullptr; const hl::Item* ttl = nullptr;
                for (size_t i = 0; i < L.items.size(); i++) { const hl::Item& it = L.items[i]; if (it.k != hl::K_TEXT) continue;
                    if (it.s == "Regime: Neg") a = &it; if (it.s == " / Uptrend") b = &it; if (it.s == "  v2.0.6") ver = &it; if (it.s == "ES RTH 8:30-3:00") ttl = &it; }
                CHECK(a && a->c1 == hl::C_RED && b && b->c1 == hl::C_GREEN && b->l == a->r && a->t == b->t, "drawn: 'Regime: Neg' red, ' / Uptrend' green right after it on one line");
                CHECK(ver && ttl && ver->l == ttl->r && ver->t == ttl->t && ver->c1 == hl::C_GREY, "the version next to the RTH title (his rule)");
                CHECK(L.table.t == hl::TITLE_ROW_PX && !L.tableMoved, "Top centre starts right under the 22 px title row");
                CHECK(!L.trendCompact, "the full trend word fits at 1170 px");
                char b2[96]; snprintf(b2, sizeof b2, "table %d,%d-%d,%d", L.table.l, L.table.t, L.table.r, L.table.b); std::printf("    1170 px Top centre: %s\n", b2);
            }
        }
        CHECK(nBad == 0, "every pane width x 9 positions x avoid: a table inside the area, left of the last bar (" + std::to_string(nBad) + " bad)");
        CHECK(nTitle == 0, "no table in the IRT title row (" + std::to_string(nTitle) + ")");
        CHECK(nAvoid == 0, "no table over a Dealer Profile / Tape Reader box when a clear spot exists (" + std::to_string(nAvoid) + ")");
        CHECK(nOnTable == 0, "no projection label on the table at any of the 9 positions (" + std::to_string(nOnTable) + ")");
        CHECK(nProjHit == 0, "no projection / candle label over an avoid box (" + std::to_string(nProjHit) + ")");
        std::printf("    %d layouts, compact trend used in %d\n", nRuns, nCompact);
        // narrow: the full word does not fit -> compact (never cut mid-word); wide enough -> full
        v.trendLvl = -2; int seenCompact = 0, seenFull = 0;
        for (int W = 420; W <= 1000; W += 10) { hl::Box pane = { 0, 0, W, 620 }; hl::Layout L = hl::layoutAll(v, pane, yOf, measure, W - 10, 1, -1, nullptr);
            if (!L.tableOk) continue; bool f = false, s = false;
            for (size_t i = 0; i < L.items.size(); i++) { if (L.items[i].s == " / Strong Dntrend") f = true; if (L.items[i].s == " / Strong Dn") s = true; }
            if (f) seenFull++; if (s) seenCompact++; CHECK(f != s, "exactly one trend form drawn at W " + std::to_string(W)); if (s) CHECK(L.trendCompact, "compact flagged"); }
        CHECK(seenFull > 0, "full 'Strong Dntrend' at normal widths");
        std::printf("    widths 420-1000: full %d, compact %d\n", seenFull, seenCompact);
    }

    std::printf("[4] host: trend from closed bars only (no repaint), same as vtl::fromChart (the Tape Reader rule), header drawn\n");
    {
        std::vector<Row> R = load(data + "/es_vol.csv");
        // the last full RTH session in the file and its bars
        long lastDay = -1; for (size_t i = 0; i < R.size(); i++) { long d = (long)(R[i].t / 86400); int s = (int)(R[i].t % 86400); if (s == 15 * 3600) lastDay = d; }
        size_t a = 0; while (a < R.size() && !((long)(R[a].t / 86400) == lastDay && R[a].t % 86400 > 8 * 3600 + 30 * 60)) a++;
        size_t z = a; while (z < R.size() && R[z].t % 86400 <= 15 * 3600 && (long)(R[z].t / 86400) == lastDay) z++;
        // keep the chart to the last 21 days like the plugin (it caps the history itself)
        HodLod x; x.setup(); mock::Chart C; C.root = "EPZ26"; C.tick = 0.25f; C.lo = 7700; C.hi = 7950; mock::cur() = &C;
        put(x.flexPath("LRA-Session-ES.csv"), "GAM|NEG\nEXP|15:00\n");
        int checked = 0, mism = 0, rep = 0, readyAt = -1, lvSeen[5] = { 0, 0, 0, 0, 0 };
        std::vector<int> straight;
        for (size_t k = a; k <= z && k + 1 < R.size(); k += 1) {
            fill(C, R, k + 2, true);                                // bars [0..k] closed, k+1 forming
            x.draw(); HLState* S = (HLState*)C.userData; if (!S) { mism++; continue; }
            // independent: vtl::fromChart on the same closed bars, RTH, the way TapeReader.cpp builds svl bars
            std::vector<svl::Bar> vb; for (size_t i = 0; i <= k; i++) { svl::Bar q; q.days = (long)(R[i].t / 86400); q.endSec = (int)(R[i].t % 86400); q.h = R[i].h; q.l = R[i].l; q.c = R[i].c; q.v = (double)R[i].v; vb.push_back(q); }
            int om, cm; svl::rthOf("ES", om, cm);
            vtl::Trend T = vtl::fromChart(vb, (int)vb.size(), 180, om, cm, svl::RTH);
            int want = T.ready ? vtl::level(T) : 0;
            if (S->view.trendReady != T.ready || S->view.trendLvl != want) mism++;
            if (T.ready && readyAt < 0) readyAt = (int)(k - a + 1);
            if (T.ready) lvSeen[want + 2]++;
            straight.push_back(S->view.trendLvl * 10 + (S->view.trendReady ? 1 : 0));
            // the forming bar spikes far above: the label must not change (it reflects closed bars only)
            C.h.back() = C.h.back() + 200; C.c.back() = C.c.back() + 150; x.draw();
            if (S->view.trendLvl * 10 + (S->view.trendReady ? 1 : 0) != straight.back()) rep++;
            checked++;
        }
        CHECK(checked > 100 && mism == 0, "every RTH prefix of " + std::to_string(lastDay) + ": HodLod's trend == vtl::fromChart RTH (" + std::to_string(mism) + " of " + std::to_string(checked) + " differ)");
        CHECK(rep == 0, "a spiking forming bar never changes the label (" + std::to_string(rep) + ")");
        CHECK(readyAt == 20, "the trend appears at the 20th RTH bar (" + std::to_string(readyAt) + ")");
        std::printf("    levels seen -2..+2: %d %d %d %d %d\n", lvSeen[0], lvSeen[1], lvSeen[2], lvSeen[3], lvSeen[4]);
        // header drawn on the host + status lines
        HLState* S = (HLState*)C.userData;
        // (the mock's last-bar x is 100 + n % 800, so this pane can be narrow: the compact word is allowed only when flagged)
        const bool cpt = findText(C, " / " + hl::trendWord(S->view.trendLvl, true)) && !findText(C, " / " + hl::trendWord(S->view.trendLvl));
        const std::string tw = " / " + hl::trendWord(S->view.trendLvl, cpt);
        CHECK(findText(C, "Regime: Neg") && findText(C, tw), "host draws 'Regime: Neg' + '" + tw + "'");
        std::string st = slurp(x.flexPath("HodLod.status-ES-180.txt"));
        CHECK(kvLine(st, "VERSION") == "2.0.6", "status VERSION 2.0.6");
        CHECK(kvLine(st, "REGIME_TEXT") == "Regime: Neg" + tw, "status REGIME_TEXT = the drawn text (" + kvLine(st, "REGIME_TEXT") + ")");
        CHECK(kvLine(st, "TREND").compare(0, hl::trendWord(S->view.trendLvl).size(), hl::trendWord(S->view.trendLvl)) == 0, "status TREND line");
        // overnight (bars after the close, the table shows the prior RTH): its final trend stays
        int fin = S->view.trendLvl; size_t on = z; while (on < R.size() && R[on].t % 86400 < 18 * 3600) on++;
        if (on + 5 < R.size()) { fill(C, R, on + 5, true); x.draw(); CHECK(S->view.trendReady && S->view.trendLvl == fin, "overnight: the prior RTH's final trend"); }
        // a chart without volume: equal weights, still a trend (never blank because the array is missing)
        fill(C, R, z, false); x.draw(); CHECK(S->view.trendReady, "no volume array: trend still computed (equal weights)");
        x.destroy();
    }

    std::printf("[5] host: the Tape Reader box and the Dealer Profile banner are avoided\n");
    {
        std::vector<Row> R = load(data + "/es_chart.csv");
        HodLod x; x.setup(); mock::Chart C; C.root = "EPZ26"; C.tick = 0.25f; C.lo = 7792; C.hi = 7892; mock::cur() = &C; fill(C, R, R.size(), false);
        std::string trp = x.flexPath("TapeReader.status-ES.txt"), stp = x.flexPath("HodLod.status-ES-180.txt");
        x.draw(); std::string st = slurp(stp); int l0, t0, r0, b0; std::sscanf(kvLine(st, "TABLE_BOX").c_str(), "%d,%d,%d,%d", &l0, &t0, &r0, &b0);
        CHECK(b0 == C.pb - 1, "(2.0.6) no Tape Reader file: Bottom centre (" + kvLine(st, "TABLE_BOX") + ")");
        CHECK(kvLine(st, "TABLE_PLACE").compare(0, 13, "position spot") == 0, "status: position spot");
        // the Tape Reader moved to Top centre and published its box over the table's spot
        put(trp, "VERSION,1.1.3\nMARKET,ES\nPOSITION,7\nLAYOUT,drawn,banner,box " + std::to_string(l0 - 20) + " " + std::to_string(t0 - 30) + " " + std::to_string(r0 + 20) + " " + std::to_string(C.pb) + ",region 110 900,lines 5\n");
        sleep(4); x.draw(); st = slurp(stp); int l1, t1, r1, b1; std::sscanf(kvLine(st, "TABLE_BOX").c_str(), "%d,%d,%d,%d", &l1, &t1, &r1, &b1);
        hl::Box tb = { l1, t1, r1, b1 }, trb = { l0 - 20, t0 - 30, r0 + 20, C.pb };
        CHECK(!hl::overlap(tb, trb) && b1 <= t0 - 30, "the table moved clear of the Tape Reader box (" + kvLine(st, "TABLE_BOX") + ")");
        CHECK(kvLine(st, "TABLE_PLACE").compare(0, 11, "moved clear") == 0, "status: moved clear");
        // a stale Tape Reader file (3 min old): its box is not trusted; its Position (bottom centre = 7) is reserved instead
        put(trp, "VERSION,1.1.3\nMARKET,ES\nPOSITION,0\nLAYOUT,drawn,banner,box " + std::to_string(l0 - 20) + " " + std::to_string(t0 - 30) + " " + std::to_string(r0 + 20) + " " + std::to_string(C.pb) + ",region 110 900,lines 5\n");
        { struct utimbuf u; u.actime = u.modtime = time(nullptr) - 180; utime(trp.c_str(), &u); }
        sleep(4); for (int k = 0; k < bp::Hyst::HOLD + 3; ++k) x.draw(); sleep(3); x.draw(); st = slurp(stp); std::sscanf(kvLine(st, "TABLE_BOX").c_str(), "%d,%d,%d,%d", &l1, &t1, &r1, &b1);
        CHECK(b1 == C.pb - 1, "stale box ignored: back at Bottom centre (after the hysteresis hold)");
        bool topReserved = st.find("\nAVOID,") != std::string::npos && st.find("\nAVOID," + std::to_string(C.pl + 110) + "," + std::to_string(C.pt + 2) + ",") != std::string::npos;
        CHECK(topReserved, "stale: its Position (1.1.3 banner, Top left) region is reserved");
        // a table placed Bottom centre by him: it keeps clear of that reserved Tape Reader region
        put(x.flexPath("HodLod.place-ES.txt"), "7\n");
        sleep(4); x.draw(); st = slurp(stp); std::sscanf(kvLine(st, "TABLE_BOX").c_str(), "%d,%d,%d,%d", &l1, &t1, &r1, &b1);
        int al, at, ar, ab; size_t ap = st.find("\nAVOID,"); bool clear = true;
        while (ap != std::string::npos) { std::sscanf(st.c_str() + ap + 7, "%d,%d,%d,%d", &al, &at, &ar, &ab); if (hl::overlap(hl::Box{ l1, t1, r1, b1 }, hl::Box{ al, at, ar, ab })) clear = false; ap = st.find("\nAVOID,", ap + 1); }
        CHECK(clear, "Bottom centre (his choice, migrated already): the table sits clear of every AVOID box (" + kvLine(st, "TABLE_BOX") + ")");
        put(x.flexPath("HodLod.place-ES.txt"), "1\n");
        // the Dealer Profile banner on for ES: an AVOID box at the top left; off for HG: none
        put(x.flexPath("DealerProfile.settings.txt"), "EPZ26~3 Minutes*~|0|50|9|0|1|1|1|1|cob_bull\nCPEZ26~3 Minutes*~|0|50|9|0|0|0|0|0|cob_bull\n");
        sleep(4); x.draw(); st = slurp(stp);
        CHECK(st.find("\nAVOID," + std::to_string(C.pl) + "," + std::to_string(C.pt) + ",") != std::string::npos, "banner on (ES): its top-left box is avoided");
        put(x.flexPath("DealerProfile.settings.txt"), "EPZ26~3 Minutes*~|0|50|9|0|1|1|1|0|cob_bull\n");
        sleep(4); x.draw(); st = slurp(stp);
        CHECK(st.find("\nAVOID," + std::to_string(C.pl) + "," + std::to_string(C.pt) + ",") == std::string::npos, "banner off: no top-left box");
        CHECK(st.find("\nAVOID," + std::to_string(C.pr - 250) + "," + std::to_string(C.pt) + ",") != std::string::npos, "the Dealer Profile header (top right) is always avoided");
        // garbage files never break the draw
        put(trp, std::string(70 * 1024, 'x')); put(x.flexPath("DealerProfile.settings.txt"), "\x01\x02|||\n|\n");
        sleep(4); x.draw(); st = slurp(stp); CHECK(!kvLine(st, "TABLE_BOX").empty(), "garbled Tape Reader / Dealer Profile files: still drawn");
        x.destroy();
    }
    std::printf("[6] settings are real: every drawn element has a checkbox and a colour, each one changes the drawing\n");
    {
        mock::params().clear();
        HodLod x; x.setup();
        // (2.0.6) Position, Offset X, Offset Y, then a checkbox + colour(s) per element
        const char* wantP[11] = { "Position", "Offset X", "Offset Y", "bool:Show table", "color:Table background", "bool:Show projection", "color:Up (to the HOD)",
                                 "color:Down (to the LOD)", "bool:Show 1st-extreme mark", "color:LOD call", "color:HOD call" };
        bool order = mock::params().size() >= 11; for (int i = 0; order && i < 11; i++) order = mock::params()[(size_t)i] == wantP[i];
        CHECK(order, "the settings window: Position, Offset X / Y, then a checkbox + colour(s) per element, in that order");
        CHECK(x.posParam == 0 && x.pOffX == 1 && x.pOffY == 2 && x.pShowTable == 3 && x.pTableBg == 4 && x.pShowProj == 5 && x.pProjUp == 6 && x.pProjDn == 7 && x.pShowMark == 8 && x.pMarkLod == 9 && x.pMarkHod == 10, "indices match the order");
        { int ui = 0; for (size_t i = 0; i < mock::params().size(); i++) if (mock::params()[i].compare(0, 7, "output:") == 0 && mock::params()[i].find(":NO_UI") == std::string::npos) ui++;
          CHECK(ui == 0, "the value array stays out of the settings window"); }
        for (int i = 0; i < 16; i++) { mock::bools()[(size_t)i] = 0; mock::lists()[(size_t)i] = 0; mock::ints()[(size_t)i] = 0; }   // (2.0.6) what IRT really hands the chart copy
        hl::Opts d = x.opts(x.readPlace("ES"));
        CHECK(d.table && d.proj && d.mark && d.tableBg == hl::C_PANEL && d.projUp == hl::C_GREEN && d.projDn == hl::C_RED && d.markLod == hl::C_GREEN && d.markHod == hl::C_RED, "defaults (no file, the chart copy's boxes all unchecked): everything on, the standard colours");
        auto setPlace = [&](const std::string& line) { sleep(1); put(x.flexPath("HodLod.place-ES.txt"), line + "\n"); };
        setPlace("7,0,0,1,1,1,0,16777216,-1,-1,-1"); CHECK(!x.opts(x.readPlace("ES")).table || x.readPlace("ES").why.find("malformed") != std::string::npos, "an out-of-range colour in the file: options default, reason kept");
        std::vector<Row> R = load(data + "/es_long.csv");
        const RTDATE stop = (RTDATE)(hl::daysFromCivil(2026, 10, 9) * 86400 + 11 * 3600 + 42 * 60);
        size_t n1142 = 0; while (n1142 < R.size() && R[n1142].t <= stop) n1142++;   // live at 11:42 (the mockup's frame): a projection exists
        mock::Chart C; C.root = "EPZ26"; C.tick = 0.25f; C.lo = 7792; C.hi = 7892; mock::cur() = &C; fill(C, R, n1142 + 1, false);
        put(x.flexPath("LRA-Session-ES.csv"), "GAM|NEG\nEXP|15:00\n"); put(x.flexPath("HodLod.place-ES.txt"), "1,0,0,1,1,1,-1,-1,-1,-1,-1\n");
        auto count = [&](int kind, COLOR c) { int n = 0; for (size_t i = 0; i < C.drawn.size(); i++) if (C.drawn[i].kind == kind && C.drawn[i].c == c) n++; return n; };
        auto redraw = [&]() { fill(C, R, n1142 + 1, false); x.draw(); };
        C.drawn.clear(); x.draw(); HLState* S = (HLState*)C.userData;
        const bool proj = S && S->view.projOk; const COLOR pc = S && S->view.projUp ? hl::C_GREEN : hl::C_RED;
        const int base = count(2, pc), tbl = count(0, hl::C_PANEL);
        CHECK(findText(C, "Regime: Neg") != nullptr && tbl > 0, "default: the table drawn on its background");
        CHECK(proj && base > 0, "default: the projection drawn (" + std::to_string(base) + " lines)");
        std::printf("    11:42 frame: projection %s, %d lines, table fills %d\n", proj ? (S->view.projUp ? "up" : "down") : "none", base, tbl);
        setPlace("1,0,0,0,1,1,-1,-1,-1,-1,-1"); C.drawn.clear(); x.draw();
        CHECK(!findText(C, "Regime: Neg") && count(0, hl::C_PANEL) < tbl, "Show table off: no table text, no table background");
        CHECK(count(2, pc) >= base, "Show table off: the projection still drawn, never cut by a hidden table");
        setPlace("1,0,0,1,1,1," + std::to_string(0x00302010) + ",-1,-1,-1,-1"); C.drawn.clear(); x.draw();
        CHECK(count(0, 0x00302010) > 0 && count(0, hl::C_PANEL) < tbl, "Table background colour applied");
        setPlace("1,0,0,1,0,1,-1,-1,-1,-1,-1"); C.drawn.clear(); x.draw();
        CHECK(count(2, pc) == 0 && findText(C, "Regime: Neg"), "Show projection off: no projection line, the table stays");
        setPlace(S && S->view.projUp ? "1,0,0,1,1,1,-1," + std::to_string(0x00ABCDEF) + ",-1,-1,-1" : "1,0,0,1,1,1,-1,-1," + std::to_string(0x00ABCDEF) + ",-1,-1"); C.drawn.clear(); x.draw();
        CHECK(count(2, 0x00ABCDEF) == base && count(2, pc) == 0, "projection colour applied to every projection line");
        CHECK(count(1, 0x00ABCDEF) > 0, "projection colour applied to its label");
        CHECK(findText(C, "Regime: Neg") && findText(C, "Regime: Neg")->c == hl::C_RED, "the table's own colours never change with the projection colour");
        setPlace("1,0,0,1,1,1,-1,-1,-1,-1,-1");
        // the 1st-extreme mark: logic level (E_MARK items)
        hl::Layout L; hl::addLine(L, 0, 0, 10, 0, hl::C_GREEN, 2, hl::R_LABEL); hl::addText(L, 0, 0, 10, "LOD?", hl::C_GREEN, 9, true, 30, hl::R_LABEL, -1);
        hl::addLine(L, 0, 5, 10, 5, hl::C_GREY, 1, hl::R_LABEL); hl::tagElem(L, 0, hl::E_MARK);
        hl::Opts O; O.markLod = 0x00112233; hl::Layout L2 = L; hl::applyOpts(L2, O);
        CHECK(L2.items.size() == 3 && L2.items[0].c1 == 0x00112233 && L2.items[1].c1 == 0x00112233 && L2.items[2].c1 == hl::C_GREY, "mark LOD colour applied (grey sub-parts kept)");
        O.mark = false; L2 = L; hl::applyOpts(L2, O); CHECK(L2.items.empty(), "Show 1st-extreme mark off: no mark");
        // (2.0.6) two charts of one market share the per-market file (the place file rule): both follow it
        setPlace("1,0,0,1,0,1,-1,-1,-1,-1,-1"); C.drawn.clear(); x.draw(); CHECK(count(2, pc) == 0, "chart A: projection off (file)");
        mock::Chart C2 = C; C2.userData = nullptr; C2.drawn.clear(); mock::cur() = &C2; x.draw();
        { int n = 0; for (size_t i = 0; i < C2.drawn.size(); i++) if (C2.drawn[i].kind == 2 && C2.drawn[i].c == pc) n++; CHECK(n == 0, "chart B of the same market: the same file, projection off too"); }
        mock::cur() = &C2; x.destroy(); mock::cur() = &C; x.destroy();
        for (int i = 0; i < 16; i++) { mock::bools()[(size_t)i] = 1; mock::ints()[(size_t)i] = -1; }
    }
    std::printf("%d passed, %d failed\n", passes, fails);
    return fails;
}
