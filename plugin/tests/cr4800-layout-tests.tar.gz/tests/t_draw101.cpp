#include <cstdlib>
#include <fstream>
#include <sstream>
#include <unistd.h>
#include <sys/stat.h>
#include "HodLod.cpp"
static void loadInto(mock::Chart& C, const std::string& path, const std::string& root, float tick, double lo, double hi)
{
    C.root = root; C.tick = tick; C.lo = lo; C.hi = hi;
    std::ifstream f(path.c_str()); std::string ln;
    while (std::getline(f, ln)) { int Y, M, D, h, m, s; double o, H, L, c, v = -1;
        int n = std::sscanf(ln.c_str(), "%d-%d-%d %d:%d:%d,%lf,%lf,%lf,%lf,%lf", &Y, &M, &D, &h, &m, &s, &o, &H, &L, &c, &v); if (n < 10) continue;
        C.t.push_back((RTDATE)(hl::daysFromCivil(Y, M, D) * 86400 + h * 3600 + m * 60 + s)); C.o.push_back((float)o); C.h.push_back((float)H); C.l.push_back((float)L); C.c.push_back((float)c); }
}
static std::string slurp(const std::string& p) { std::ifstream f(p.c_str()); std::stringstream s; s << f.rdbuf(); return s.str(); }
int main() {
    char tmpl[] = "/tmp/hldXXXXXX"; std::string prof = mkdtemp(tmpl); setenv("USERPROFILE", prof.c_str(), 1);
    HodLod x; x.setup(); mock::lists()[0] = 0;                 // IRT's stale copy says Top left
    mock::Chart A; loadInto(A, "../data/es_chart.csv", "EPZ26", 0.25f, 7792, 7892); mock::cur() = &A; x.draw();
    std::string st = slurp(x.flexPath("HodLod.status-ES-180.txt"));
    size_t p = st.find("TABLE_BOX,"); if (p == std::string::npos) { std::printf("FAIL no TABLE_BOX\n%s", st.c_str()); return 1; }
    int l, t, r, b; std::sscanf(st.c_str() + p, "TABLE_BOX,%d,%d,%d,%d", &l, &t, &r, &b);
    // (2.0.6) Bottom centre (Rassul 07:13 "move it DOWN"), the chart copy's stale list (Top left) ignored
    int cx = (l + r) / 2; bool ok = b >= A.pb - 4 && b <= A.pb && t > A.pb / 2 && cx > 150;
    std::printf("TABLE_BOX %d,%d,%d,%d (pane %d..%d x %d..%d): %s\n", l, t, r, b, A.pl, A.pr, A.pt, A.pb, ok ? "bottom centre - PASS" : "FAIL");
    x.destroy(); return ok ? 0 : 1;
}
