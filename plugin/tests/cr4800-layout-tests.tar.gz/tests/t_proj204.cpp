// HL 2.0.4 (2026-10-13, Rassul screenshot): the projection callout "HOD after 10:45 . 94.34" sat on the left-edge key-level label
// ("/PDH" - the Liquidity column's level names). The callout (2-line or 1-line) must never start inside the left level-label band
// (max(110 px, 15% of the pane)), wherever the 1st extreme's bar is - the line + flag stay on the bar. And the callout's price ("94.00")
// sat on the G1 badge: no callout text on a level badge's row (the key levels + MenthorQ levels, +/- PROJ_LVL_ROW_HALF px).
//   g++ -std=c++14 -I../src t_proj204.cpp -o ../out/t_proj204 && ../out/t_proj204   (run from tests/)
#include "HodLodLogic.h"
#include "test_font_metrics.h"
#include <fstream>
#include <cstdlib>
using namespace hl;
static int fails = 0, passes = 0;
#define CHECK(c, m) do { if (c) ++passes; else { ++fails; std::printf("FAIL %s (line %d)\n", std::string(m).c_str(), __LINE__); } } while (0)
static int measure(const std::string& s, int fs, bool bold)
{ double w = 0; for (size_t i = 0; i < s.size(); i++) w += (bold ? ADV_BOLD : ADV_REG)[(unsigned char)s[i]]; return (int)(w * fs * 96.0 / 72.0 / 1000.0 + 0.999); }
static View viewAt(const char* upto)
{
    std::vector<Bar> B; std::ifstream f("../data/es_long.csv"); std::string ln;
    while (std::getline(f, ln)) { if (ln.compare(0, 16, upto) > 0) break; int Y, M, D, h, m, s; double o, H, L, c;
        if (std::sscanf(ln.c_str(), "%d-%d-%d %d:%d:%d,%lf,%lf,%lf,%lf", &Y, &M, &D, &h, &m, &s, &o, &H, &L, &c) == 10) { Bar b; b.absEnd = daysFromCivil(Y, M, D) * 86400 + h * 3600 + m * 60 + s; b.o = o; b.h = H; b.l = L; b.c = c; b.v = NAN; B.push_back(b); } }
    Cfg c; c.mkt = 0; c.tick = 0.25; c.per = 180; c.readOpen = readOpenFor(0); c.readN = readNFor(0);
    std::vector<ReadRow> rows; ProjLock lock; Tracker T = runBars(c, B, B.size(), &rows, &lock);
    return buildView(T, rows.empty() ? ReadOut() : rows.back().out, &rows, nullptr, &lock);
}
static bool isProjText(const Item& it, const View& v)
{
    if (it.k != K_TEXT || it.role != R_LABEL) return false;
    if (it.s == "HOD" || it.s == "LOD" || it.s.compare(0, 6, "after ") == 0 || it.s == v.projTxt) return true;
    const size_t sp = v.projTxt.rfind(' ');
    return sp != std::string::npos && it.s == v.projTxt.substr(sp + 1);
}
int main()
{
    int views = 0, layouts = 0, drawn = 0, inBand = 0, onRow = 0, rowLayouts = 0, rowDrawn = 0, keyLv = 0;
    const char* times[] = { "2026-10-09 09:30", "2026-10-09 10:45", "2026-10-09 12:00", "2026-10-09 14:30" };
    const Box panes[] = { { 0, 0, 1170, 740 }, { 0, 0, 1600, 640 }, { 0, 0, 700, 500 } };
    for (const char* t : times) {
        View v = viewAt(t); if (!v.projOk) continue; views++; keyLv += (int)v.levelTicks.size();
        View vl = v;   // + MenthorQ-like levels ON the target and around it (the G1 badge case), every 30 ticks (7.5 pt) across +/- 60 ticks
        vl.levelTicks.push_back(v.projTo); for (int d = -60; d <= 60; d += 30) vl.levelTicks.push_back(v.projTo + d);
        for (const Box& pane : panes) {
            const int band = projLevelBandR(pane);
            CHECK(band >= pane.l + 110 && band >= pane.l + (pane.r - pane.l) * 15 / 100, "band = max(110 px, 15%)");
            // the target near the middle of the pane and the 1st extreme lower / higher: price scale fitted around both
            const double a = v.projFrom * 0.25, b = v.projTo * 0.25, lo = std::min(a, b) - 20, hi = std::max(a, b) + 20;
            auto yOf = [&](long long tk) { return (int)std::lround((hi - tk * 0.25) / (hi - lo) * (pane.b - pane.t)) + pane.t; };
            for (int x = pane.l + 6; x < pane.r - 120; x += 24) {
                Layout L = layoutAll(v, pane, yOf, measure, pane.r - 10, POS_DEFAULT, x); layouts++;
                bool any = false;
                for (const Item& it : L.items) if (isProjText(it, v)) { any = true; if (it.l < band) { inBand++; std::printf("  in band: %s x=%d text '%s' at l=%d (band %d)\n", t, x, it.s.c_str(), it.l, band); } }
                if (any) drawn++;
                Layout L2 = layoutAll(vl, pane, yOf, measure, pane.r - 10, POS_DEFAULT, x); rowLayouts++;
                bool any2 = false;
                for (const Item& it : L2.items) if (isProjText(it, vl)) {
                    any2 = true;
                    for (long long tk : vl.levelTicks) { const int ly = yOf(tk);
                        if (ly + PROJ_LVL_ROW_HALF > it.t && ly - PROJ_LVL_ROW_HALF < it.b) { onRow++; if (onRow <= 5) std::printf("  on a level row: %s x=%d '%s' t=%d b=%d level y=%d\n", t, x, it.s.c_str(), it.t, it.b, ly); break; } }
                    if (it.l < band) inBand++;
                }
                if (any2) rowDrawn++;
            }
        }
    }
    std::printf("  %d views, %d layouts, %d with the callout drawn, %d callout texts inside the level band\n", views, layouts, drawn, inBand);
    CHECK(views >= 2, "fixture: projections on the ES 2026-10-09 views");
    CHECK(drawn > layouts / 2, "the callout is still drawn in most layouts (" + std::to_string(drawn) + " / " + std::to_string(layouts) + ")");
    std::printf("  with levels: %d layouts, %d with the callout drawn, %d callout texts on a level row; %d key levels seen\n", rowLayouts, rowDrawn, onRow, keyLv);
    CHECK(inBand == 0, "2.0.4: no callout text inside the left level-label band");
    CHECK(keyLv > 0, "2.0.4: buildView collects the key levels (PF / PD / ON / Lon) for the level rows");
    CHECK(onRow == 0, "2.0.4: no callout text on a level badge's row (e.g. '94.00' over the G1 badge)");
    CHECK(rowDrawn > rowLayouts / 2, "the callout is still drawn in most layouts with levels (" + std::to_string(rowDrawn) + " / " + std::to_string(rowLayouts) + ")");
    CHECK(std::string(HL_VERSION) == "2.0.4" || std::string(HL_VERSION) == "2.0.5" || std::string(HL_VERSION) == "2.0.6", "version 2.0.4+ (2.0.5 keeps the callout rules)");
    std::printf("%d passed, %d failed\n", passes, fails); return fails;
}
