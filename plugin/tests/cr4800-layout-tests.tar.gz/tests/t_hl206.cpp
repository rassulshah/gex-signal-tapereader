// HL 2.0.6 (2026-10-14, CR4800) tests:
//  [1] the regression: IRT hands the CHART copy every box unchecked / every list 0 - the table must still draw (2.0.5 hid it on ES / CL)
//  [2] Bottom centre default; the ONE-TIME migration 1 -> 7 (HodLod.migrate-206.txt), other choices kept, a later 1 not migrated again
//  [3] the settings round trip: dialog (no bar size) -> Apply -> per-market file -> a fresh object (restart) -> draw at Position + Offset;
//      the dialog filled from the file; a control he did not touch keeps the file value (also when the dialog ignores the fill)
//  [4] fuzz: 2,000 random dialog values -> the file only ever holds valid values; no crash
//  [5] offsets: 9 positions x offsets always inside the area up to the last bar
//  [6] hysteresis: a Tape Reader box appearing / disappearing every draw never makes the table ping-pong; jitter-free over 1,000 draws
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <random>
#include <unistd.h>
#include <sys/stat.h>
#include "HodLod.cpp"
static int fails = 0, passes = 0;
#define CHECK(c, m) do { if (c) ++passes; else { ++fails; std::printf("FAIL %s (line %d)\n", std::string(m).c_str(), __LINE__); } } while (0)
static std::string slurp(const std::string& p) { std::ifstream f(p.c_str()); std::stringstream s; s << f.rdbuf(); return s.str(); }
static void put(const std::string& p, const std::string& s) { std::ofstream o(p.c_str(), std::ios::binary); o << s; }
static std::string kv(const std::string& st0, const std::string& k) { const std::string st = "\n" + st0; size_t a = st.find("\n" + k + ","); if (a == std::string::npos) return ""; a += k.size() + 2; return st.substr(a, st.find('\n', a) - a); }
static void loadInto(mock::Chart& C, const char* path, const char* root, float tick, double lo, double hi) {
    std::ifstream f(path); std::string ln; C.root = root; C.tick = tick; C.lo = lo; C.hi = hi;
    while (std::getline(f, ln)) { int Y, M, D, h, m, s; double o, H, L, c; if (std::sscanf(ln.c_str(), "%d-%d-%d %d:%d:%d,%lf,%lf,%lf,%lf", &Y, &M, &D, &h, &m, &s, &o, &H, &L, &c) < 10) continue;
        C.t.push_back((RTDATE)(hl::daysFromCivil(Y, M, D) * 86400 + h * 3600 + m * 60 + s)); C.o.push_back((float)o); C.h.push_back((float)H); C.l.push_back((float)L); C.c.push_back((float)c); }
}
static bool tableBox(const std::string& st, int& l, int& t, int& r, int& b) { const std::string v = kv(st, "TABLE_BOX"); return !v.empty() && std::sscanf(v.c_str(), "%d,%d,%d,%d", &l, &t, &r, &b) == 4; }
static void chartCopy() { for (int i = 0; i < 16; i++) { mock::bools()[(size_t)i] = 0; mock::lists()[(size_t)i] = 0; mock::ints()[(size_t)i] = 0; } mock::period() = "3 min"; }
static void dialog(bool on) { mock::period() = on ? "" : "3 min"; }

int main() {
    char tmpl[] = "/tmp/hl6XXXXXX"; std::string prof = mkdtemp(tmpl); setenv("USERPROFILE", prof.c_str(), 1);
    std::printf("[1] the chart copy: every box unchecked, every list 0 - the table still draws\n");
    {   HodLod x; x.setup(); chartCopy();
        mock::Chart A; loadInto(A, "../data/es_chart.csv", "EPZ26", 0.25f, 7792, 7892); mock::cur() = &A; x.draw();
        const std::string st = slurp(x.flexPath("HodLod.status-ES-180.txt")); int l, t, r, b;
        CHECK(tableBox(st, l, t, r, b), "TABLE_BOX written (2.0.5 wrote none: Show table read unchecked)");
        CHECK(kv(st, "OPTS").find("table on") == 0 && kv(st, "PLACE").find("pos 7") == 0, "status: PLACE pos 7, OPTS table on");
        CHECK(b >= A.pb - 4 && t > A.pb / 2, "Bottom centre by default (no place file)");
        CHECK(kv(st, "VERSION") == "2.0.6", "version 2.0.6");
        x.destroy(); }
    std::printf("[2] the one-time migration 1 -> 7\n");
    {   HodLod x; x.setup(); chartCopy();
        const std::string lg = x.flexPath("HodLod.migrate-206.txt");
        put(x.flexPath("HodLod.place-NQ.txt"), "1\n"); put(x.flexPath("HodLod.place-GC.txt"), "2\n"); put(x.flexPath("HodLod.place-CL.txt"), "1,30,-10,1,0,1,-1,-1,-1,-1,-1\n");
        CHECK(x.position("NQ").pos == 7 && slurp(x.flexPath("HodLod.place-NQ.txt")).compare(0, 6, "7,0,0,") == 0, "NQ place 1 (the 2.0.5 default) -> 7, rewritten in the 2.0.6 form");
        CHECK(x.position("CL").pos == 7 && x.position("CL").o.dx == 30 && !x.position("CL").o.proj, "CL 1 with offsets / options: -> 7, the rest kept");
        CHECK(x.position("GC").pos == 2 && slurp(x.flexPath("HodLod.place-GC.txt")) == "2\n", "GC 2 (his choice): kept, file untouched");
        CHECK(x.position("ES").pos == 7 && slurp(lg).find("ES,") != std::string::npos && slurp(lg).find("no place file") != std::string::npos, "ES no file: default 7, logged");
        CHECK(slurp(lg).find("NQ,") != std::string::npos && slurp(lg).find("place 1 (2.0.5 default Top centre) -> 7 (Bottom centre)") != std::string::npos, "migration logged");
        sleep(1); put(x.flexPath("HodLod.place-NQ.txt"), "1,0,0,1,1,1,-1,-1,-1,-1,-1\n");
        HodLod y; y.setup();
        CHECK(y.position("NQ").pos == 1, "a Top centre he saves AFTER the migration: kept by the next session");
        { const std::string L = slurp(lg); size_t a = L.find("NQ,"); CHECK(a != std::string::npos && L.find("NQ,", a + 1) == std::string::npos, "NQ logged exactly once"); }
        put(x.flexPath("HodLod.place-HG.txt"), "x\n"); CHECK(y.position("HG").pos == 7 && y.position("HG").why.find("ignored") != std::string::npos, "garbage place file: Bottom centre, reason kept"); }
    std::printf("[3] the settings round trip\n");
    {   HodLod x; x.setup(); chartCopy(); std::remove(x.flexPath("HodLod.place-ES.txt").c_str());
        mock::Chart A; loadInto(A, "../data/es_chart.csv", "EPZ26", 0.25f, 7792, 7892); mock::cur() = &A;
        // Apply from the chart copy never writes
        mock::lists()[0] = 2; mock::ints()[1] = 40; x.parmsApply();
        CHECK(slurp(x.flexPath("HodLod.place-ES.txt")).empty(), "Apply from the chart copy (it has a bar size): nothing written");
        dialog(true); x.parmsLoad();
        CHECK(mock::lists()[0] == 7 && mock::ints()[1] == 0 && mock::ints()[2] == 0 && mock::bools()[3] == 1 && mock::bools()[5] == 1 && mock::bools()[8] == 1 && mock::ints()[4] == (int)hl::C_PANEL, "the dialog opens filled with the defaults (Bottom centre, 0, 0, all on, the standard colours)");
        mock::lists()[0] = 1; mock::ints()[1] = -60; mock::ints()[2] = 25; mock::bools()[5] = 0; x.parmsApply(); dialog(false);
        const std::string f1 = slurp(x.flexPath("HodLod.place-ES.txt"));
        CHECK(f1 == "1,-60,25,1,0,1,-1,-1,-1,-1,-1\n", "Apply: Top centre, -60, 25, projection off; untouched colours stay default (-1)");
        chartCopy(); x.draw(); int l, t, r, b; std::string st = slurp(x.flexPath("HodLod.status-ES-180.txt"));
        CHECK(tableBox(st, l, t, r, b) && kv(st, "PLACE").find("pos 1,dx -60,dy 25") == 0 && kv(st, "OPTS").find("projection off") != std::string::npos, "the chart draws from the file (its own copy all unchecked)");
        const std::string want = kv(st, "TABLE_PLACE");
        int wl = 0, wt = 0, wr = 0, wb = 0; std::sscanf(want.c_str() + want.find("want ") + 5, "%d %d %d %d", &wl, &wt, &wr, &wb);
        CHECK(wt >= A.pt + 22 + 25 - 1 && wt <= A.pt + 22 + 25 + 1, "Offset Y 25 below the Top centre spot (under the title row)");
        x.destroy();
        HodLod y; y.setup(); chartCopy(); mock::cur() = &A; A.userData = nullptr; y.draw(); int l2, t2, r2, b2;
        CHECK(tableBox(slurp(y.flexPath("HodLod.status-ES-180.txt")), l2, t2, r2, b2) && l2 == l && t2 == t, "restart (a new object): the same place");
        // the dialog showing stale values (the fill ignored), OK pressed: nothing he did not touch changes
        dialog(true); mock::ignoreSets() = true; for (int i = 0; i < 16; i++) { mock::bools()[(size_t)i] = 0; mock::lists()[(size_t)i] = 0; mock::ints()[(size_t)i] = 0; }
        y.parmsLoad(); y.parmsApply(); mock::ignoreSets() = false; dialog(false);
        CHECK(slurp(y.flexPath("HodLod.place-ES.txt")) == f1, "stale dialog (Top left, 0, 0, every box off) + OK: the file is unchanged");
        dialog(true); y.parmsLoad(); mock::ints()[7] = 0x00123456; y.parmsApply(); dialog(false);
        CHECK(slurp(y.flexPath("HodLod.place-ES.txt")) == "1,-60,25,1,0,1,-1,-1," + std::to_string(0x00123456) + ",-1,-1\n", "a colour changed in the dialog: only that colour saved");
        y.destroy(); }
    std::printf("[4] fuzz the dialog\n");
    {   HodLod x; x.setup(); std::mt19937 rng(11); int bad = 0;
        mock::Chart A0; loadInto(A0, "../data/es_chart.csv", "EPZ26", 0.25f, 7792, 7892); mock::cur() = &A0;
        for (int i = 0; i < 2000; ++i) {
            dialog(true); x.parmsLoad();
            const int k = (int)(rng() % 11); const int vals[] = { (int)rng(), -1, 0, 601, -601, 9, 0x01000000, INT_MIN, INT_MAX, 5, 300 };
            const int v = vals[rng() % 11];
            if (k == 0) mock::lists()[0] = v; else if (k <= 2) mock::ints()[(size_t)k] = v; else if (k <= 5) mock::bools()[(size_t)(k == 3 ? 3 : k == 4 ? 5 : 8)] = v & 1; else mock::ints()[(size_t)(k == 6 ? 4 : k == 7 ? 6 : k == 8 ? 7 : k == 9 ? 9 : 10)] = v;
            x.parmsApply(); dialog(false);
            HodLod::Place P; const std::string ln = slurp(x.flexPath("HodLod.place-ES.txt"));
            const std::string l1 = ln.substr(0, ln.find('\n'));
            if (!hlParsePlace(l1, P) || !bp::posOk(P.pos) || !bp::offOk(P.o.dx) || !bp::offOk(P.o.dy)) { ++bad; if (bad < 3) std::printf("    bad line [%s]\n", l1.c_str()); }
            for (int c = 0; c < 5; ++c) if (P.col[c] != -1 && (P.col[c] <= 0 || P.col[c] > 0xFFFFFF)) ++bad;
        }
        CHECK(bad == 0, "2,000 random / garbage dialog values: the file only ever holds valid values");
        mock::Chart A; loadInto(A, "../data/es_chart.csv", "EPZ26", 0.25f, 7792, 7892); mock::cur() = &A; chartCopy(); x.draw();
        CHECK(!slurp(x.flexPath("HodLod.status-ES-180.txt")).empty(), "still draws after the fuzz");
        x.destroy(); std::remove(x.flexPath("HodLod.place-ES.txt").c_str()); }
    std::printf("[5] 9 positions x offsets: always inside the area\n");
    {   HodLod x; x.setup(); chartCopy(); mock::Chart A; loadInto(A, "../data/es_chart.csv", "EPZ26", 0.25f, 7792, 7892); mock::cur() = &A;
        int out = 0, n = 0;
        for (int p = 0; p < 9; ++p) for (int dx : { -600, -80, 0, 80, 600 }) for (int dy : { -600, 0, 600 }) {
            sleep(0); put(x.flexPath("HodLod.place-ES.txt"), std::to_string(p) + "," + std::to_string(dx) + "," + std::to_string(dy) + ",1,1,1,-1,-1,-1,-1,-1\n");
            x.posCache.clear(); A.userData = nullptr; x.draw(); int l, t, r, b; ++n;
            if (!tableBox(slurp(x.flexPath("HodLod.status-ES-180.txt")), l, t, r, b) || l < A.pl || r > A.pr || t < A.pt + 22 || b > A.pb) ++out;
            HLState* S = (HLState*)A.userData; delete S; A.userData = nullptr;
        }
        CHECK(n == 135 && out == 0, "135 placements: every table fully inside the pane, under the title row");
        std::remove(x.flexPath("HodLod.place-ES.txt").c_str()); }
    std::printf("[6] hysteresis: no ping-pong, no jitter\n");
    {   HodLod x; x.setup(); chartCopy(); mock::Chart A; loadInto(A, "../data/es_chart.csv", "EPZ26", 0.25f, 7792, 7892); mock::cur() = &A;
        x.draw(); int l0, t0, r0, b0; tableBox(slurp(x.flexPath("HodLod.status-ES-180.txt")), l0, t0, r0, b0);
        const std::string trp = x.flexPath("TapeReader.status-ES.txt");
        int moves = 0, lastT = t0, lastL = l0; HLState* S = (HLState*)A.userData;
        for (int i = 0; i < 1000; ++i) {
            if (i % 2) put(trp, "POSITION,7\nLAYOUT,drawn,banner,box " + std::to_string(l0 + 10) + " " + std::to_string(t0 + 5) + " " + std::to_string(r0 - 10) + " " + std::to_string(b0) + ",region 0 0\n");
            else std::remove(trp.c_str());
            S->avoidChecked = 0;                                            // re-read the Tape Reader file on every draw (worst case)
            x.draw(); int l, t, r, b; tableBox(slurp(x.flexPath("HodLod.status-ES-180.txt")), l, t, r, b);
            if (l != lastL || t != lastT) ++moves;
            lastL = l; lastT = t;
        }
        CHECK(moves <= 1, "a Tape Reader box there / gone on alternate draws (1,000): the table moves at most once, never back and forth (" + std::to_string(moves) + ")");
        std::remove(trp.c_str()); int still = 0;
        for (int i = 0; i < 1000; ++i) { A.c.back() = (float)(7850 + (i % 9) * 0.25); A.h.back() = std::max(A.h.back(), A.c.back()); x.draw(); int l, t, r, b; tableBox(slurp(x.flexPath("HodLod.status-ES-180.txt")), l, t, r, b); if (l != lastL || t != lastT) ++still; lastL = l; lastT = t; }
        CHECK(still <= 1, "1,000 draws with the forming bar moving: the table stays put (" + std::to_string(still) + ")");
        x.destroy(); }
    std::printf("%d passed, %d failed\n", passes, fails);
    return fails;
}
