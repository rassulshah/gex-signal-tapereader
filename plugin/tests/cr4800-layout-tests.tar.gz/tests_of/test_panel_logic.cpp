// test_panel_logic.cpp -- BoxPlace.h 1.0.0 + OrderFlowFeed.h 1.3.0 panel geometry (CR4800, 2026-10-14). Pure logic, no SDK.
// Rassul 07:18 "test them thoroughly to ensure they work and dont shake or act erratic, and dont have garbage values":
//   clamping (9 positions x offsets x pane sizes: always fully inside, never right of the last bar), parse / format round trips,
//   a fuzz of garbage setting values (never accepted, never a crash), the overlap hysteresis (no ping-pong), the stable width,
//   the dialog snapshot (an untouched control keeps the file value), the read box size independent of the text (1,000 draws with
//   alternating text lengths), the wrap keeping the verdict, one spike label per candle, the text reserve per mode, rare L.
#include "OrderFlowFeed.h"
#include <cstdio>
#include <random>
using namespace off;
static int fails = 0, passes = 0;
#define CHECK(c, m) do { if (c) ++passes; else { ++fails; std::printf("FAIL %d %s\n", __LINE__, m); } } while (0)
static int W6(const std::string& s, int pt, bool bold) { return (int)s.size() * (pt >= 10 ? 7 : 6) + (bold ? (int)s.size() / 4 : 0); }

int main() {
    const TextW M = W6;
    CHECK(std::string(bp::VERSION) == "1.0.0" && std::string(off::VERSION) == "1.3.0", "versions");
    // ---------------- clamping: 9 positions x offsets x areas ----------------
    {
        long long n = 0, bad = 0;
        const int offs[] = { -600, -599, -300, -45, -1, 0, 1, 45, 300, 599, 600 };
        const int sizes[][2] = { { 360, 81 }, { 50, 20 }, { 900, 400 }, { 1, 1 } };
        const bp::Box areas[] = { bp::mk(3, 3, 720, 84), bp::mk(110, 37, 666, 531), bp::mk(0, 0, 40, 30), bp::mk(-50, -20, 300, 200) };
        for (const bp::Box& A : areas) for (auto& sz : sizes) for (int pos = 0; pos < 9; ++pos) for (int dx : offs) for (int dy : offs) {
            bp::Place p; p.pos = pos; p.dx = dx; p.dy = dy;
            const bp::Box b = bp::placeBox(A, sz[0], sz[1], p);
            ++n;
            if (b.l < A.l || b.t < A.t || b.r > A.r || b.b > A.b || b.w() < 0 || b.h() < 0) ++bad;
            if (sz[0] <= A.w() && sz[1] <= A.h() && (b.w() != sz[0] || b.h() != sz[1])) ++bad;   // fits: never resized
        }
        CHECK(n == 4 * 4 * 9 * 11 * 11 && bad == 0, "9 positions x 121 offsets x 4 areas x 4 sizes: always fully inside the area (never right of the last bar), never resized when it fits");
        bp::Place p; p.pos = 0; p.dx = 45; p.dy = 10;
        const bp::Box b = bp::placeBox(bp::mk(3, 3, 720, 84), 360, 50, p);
        CHECK(b.l == 48 && b.t == 13 && b.r == 408 && b.b == 63, "Top left + (45, 10): moved right / down by exactly the offset");
        p.dx = -45; const bp::Box c = bp::placeBox(bp::mk(3, 3, 720, 84), 360, 50, p);
        CHECK(c.l == 3, "an offset past the left edge stops at the edge");
        p.pos = 8; p.dx = 600; p.dy = 600; const bp::Box d = bp::placeBox(bp::mk(3, 3, 720, 84), 360, 50, p);
        CHECK(d.r == 720 && d.b == 84, "Bottom right + (600, 600): stays at the last bar / pane bottom");
        p.pos = 7; p.dx = 0; p.dy = 0; const bp::Box e = bp::placeBox(bp::mk(0, 0, 1000, 500), 400, 100, p);
        CHECK(e.l == 300 && e.b == 500, "Bottom centre: centred, on the bottom");
        p.pos = 99; p.dx = 9999; p.dy = -9999; const bp::Box f = bp::placeBox(bp::mk(0, 0, 1000, 500), 400, 100, p);
        CHECK(f.l == 0 && f.t == 0, "garbage position / offsets in a Place: Top left, no offset");
    }
    // ---------------- parse / format ----------------
    {
        bp::Place p; std::string why; std::vector<std::string> rest;
        CHECK(bp::parse("7", 1, p, &why) && p.pos == 7 && p.dx == 0 && p.dy == 0, "an old one-digit place file: its position, no offset");
        CHECK(bp::parse("4,-45,12", 1, p, &why) && p.pos == 4 && p.dx == -45 && p.dy == 12, "pos,dx,dy");
        CHECK(bp::parse("4,-45,12,1,0\r\n", 1, p, &why, &rest) && rest.size() == 2 && rest[0] == "1", "extra fields handed back; CR LF tolerated");
        CHECK(bp::format(p) == "4,-45,12", "format");
        const char* badLines[] = { "", "9", "-1", "a", "4,", "4,1", "4,1,x", "4,601,0", "4,0,-601", "4,1.5,0", "4, 1,0", "4,+1,0", "44", "4,99999,0", "4,-,0" };
        bool allBad = true; for (const char* l : badLines) { bp::Place q; if (bp::parse(l, 1, q)) allBad = false; if (!bp::posOk(q.pos) || !bp::offOk(q.dx) || !bp::offOk(q.dy)) allBad = false; }
        CHECK(allBad, "15 malformed lines rejected, each leaving valid defaults");
        bp::Place q; bp::parse("4,601,0", 1, q, &why); CHECK(q.pos == 4 && q.dx == 0 && why.find("bad offset") == 0, "a bad offset keeps the valid position and says why");
        // fuzz: random bytes / numbers never accepted out of range, never crash
        std::mt19937 rng(42); long long acc = 0, rej = 0, badAcc = 0;
        for (int i = 0; i < 20000; ++i) {
            std::string s; const int len = (int)(rng() % 16);
            const char alpha[] = "0123456789,-+. x\r\n\x85\xff";
            for (int k = 0; k < len; ++k) s += alpha[rng() % (sizeof(alpha) - 1)];
            bp::Place r; if (bp::parse(s, 7, r)) { ++acc; if (!bp::posOk(r.pos) || !bp::offOk(r.dx) || !bp::offOk(r.dy)) ++badAcc; } else ++rej;
            if (!bp::posOk(r.pos) || !bp::offOk(r.dx) || !bp::offOk(r.dy)) ++badAcc;
        }
        CHECK(badAcc == 0 && acc > 0 && rej > 0, "fuzz 20,000 random lines: nothing out of range ever accepted or left behind");
        CHECK(bp::cleanOff(601LL) == 0 && bp::cleanOff(-600LL) == -600 && bp::cleanOff(std::nan("")) == 0 && bp::cleanOff(1e30) == 0 && bp::cleanOff(12.4) == 12 && bp::cleanPos(9, 7) == 7 && bp::cleanPos(-1, 7) == 7, "clean: NaN / huge / out of range -> the default");
    }
    // ---------------- the dialog snapshot ----------------
    {
        bp::DlgSnap s; CHECK(s.pick(0, 3, 7) == 3, "no snapshot: the dialog's value");
        s.take({ 0, 5 }); CHECK(s.pick(0, 0, 7) == 7 && s.pick(1, 6, 9) == 6 && s.pick(5, 4, 1) == 4, "untouched since it opened: the FILE's value (a stale 0 never saved); changed: the new value");
    }
    // ---------------- hysteresis: no ping-pong ----------------
    {
        bp::Hyst h; const bp::Box A = bp::mk(0, 0, 10, 10), B = bp::mk(20, 0, 30, 10), C = bp::mk(40, 0, 50, 10);
        CHECK(bp::same(h.step(A), A), "first draw: the wanted spot");
        CHECK(bp::same(h.step(B), A) && bp::same(h.step(B), B), "a new spot only after it won 2 draws in a row");
        int switches = 0; bp::Box last = h.cur;
        for (int i = 0; i < 1000; ++i) { const bp::Box got = h.step(i % 2 ? A : B); if (!bp::same(got, last)) ++switches; last = got; }
        CHECK(switches == 0, "A / B alternating every draw for 1,000 draws: the box never moves");
        bp::Hyst g; g.step(A); g.step(B); g.step(B);                         // moved A -> B
        bp::Box x = g.step(A); x = g.step(A); x = g.step(A);
        CHECK(bp::same(x, B), "never straight back to the spot just left (HOLD draws)");
        for (int i = 0; i < bp::Hyst::HOLD; ++i) x = g.step(A);
        CHECK(bp::same(x, A), "a lasting change is followed after the hold");
        bp::Hyst k; k.step(A); CHECK(bp::same(k.step(C, true), C), "the current spot is blocked now: the move is immediate");
    }
    // ---------------- stable width ----------------
    {
        bp::StableW w; long long t = 0; int changes = 0, last = 0;
        for (int i = 0; i < 1000; ++i) { t += 250; const int got = w.step(i % 2 ? 300 : 420, t); if (got != last) ++changes; last = got; }
        CHECK(changes == 1 && last == 420, "text widths alternating 300 / 420 px for 1,000 draws: the width grows once and never shakes");
        for (int i = 0; i < 300; ++i) { t += 250; w.step(300, t); }
        CHECK(w.step(300, t) == 300, "a narrower width that held for 60 s: shrinks once");
    }
    // ---------------- the panel: read mode is a FIXED box ----------------
    {
        Info I; I.colHead[0] = "Sellers"; I.colHead[1] = "Buyers";
        const char* labels[] = { "Lots", "Pace", "Sweep", "Large", "StopRun", "Crowd", "Burst" };
        for (const char* l : labels) { InfoRow r; r.label = l; r.v[0] = "1"; r.v[1] = "2"; I.rows.push_back(r); }
        I.head = "Live"; I.tmpl = CROWD_TMPL;
        const bp::Box area = bp::mk(3, 3, 720, 84); bp::Place pl;
        const std::string a = "7:18 Sellers hit the bid with a 276-lot (2.1x) into MQ+CR0 - bids held.", b = "7:18 Normal activity - no spike";
        bp::Box first; int changes = 0;
        for (int i = 0; i < 1000; ++i) {
            I.rows[0].v[0] = std::to_string(i * 37 % 9999) + " (" + std::to_string(i % 99) + ".0x)";   // live values change every draw
            const PanelPlan P = planPanel(area, 0, MODE_READ, pl, I, i % 2 ? a : b, i % 3 ? "oHit: 7900 calls 5.6x \xB7 IV flat ? \xB7 dealers sell 587 ES ($231M) ?" : "", textReserve(87, MODE_READ), M);
            if (i == 0) first = P.box; else if (!bp::same(P.box, first)) ++changes;
            if (P.read.size() > (size_t)READ_MAX || P.opt.size() > (size_t)OPT_MAX) ++changes;
        }
        CHECK(changes == 0 && first.w() == READ_W && first.l == 3 && first.t == 3, "1,000 draws, live values + read / options text alternating: the read box never moves or resizes (360 px, top left)");
        const PanelPlan P = planPanel(area, 0, MODE_READ, pl, I, a, "", textReserve(87, MODE_READ), M);
        std::string j; for (auto& s : P.read) { j += (j.empty() ? "" : " ") + s; CHECK(W6(s, READ_PT, true) <= READ_W - 12, "every read line fits the box"); }
        CHECK(j == a && P.read.size() >= 2, "the read wraps (not cut) inside the box");
        CHECK(P.grid.g.size() >= 2 && P.gridBox.l == P.box.l && P.gridBox.t == P.box.t && P.gridBox.r <= area.r, "hover grid: every row in column groups, anchored at the box, inside the pane");
        size_t rows = 0; for (auto& g : P.grid.g) rows += g.n; CHECK(rows == I.rows.size(), "hover grid: all 7 rows (Lots ... Burst), nothing lost");
        const std::string longer = std::string(a) + " " + a + " " + a + " " + a;
        const PanelPlan Q = planPanel(area, 0, MODE_READ, pl, I, longer, "", 4, M);
        CHECK(Q.read.size() == 3 && Q.read.back().find("...") != std::string::npos, "a read longer than 3 lines: the 3rd line ends in '...'");
        // numbers mode: the box width from the templates of the rows that fit, not from the live values
        int nchg = 0; bp::Box nb;
        for (int i = 0; i < 1000; ++i) {
            I.rows[0].v[0] = std::to_string(i * 7919 % 100000);
            const PanelPlan N = planPanel(area, 0, MODE_NUMBERS, pl, I, i % 2 ? a : b, "", textReserve(87, MODE_NUMBERS), M);
            if (i == 0) nb = N.box; else if (!bp::same(N.box, nb)) ++nchg;
            for (auto& r : N.textRects) if (bp::overlap(r, N.box)) ++nchg;
        }
        CHECK(nchg == 0, "numbers mode, 1,000 draws with changing values: the box never resizes and the read never overlaps it");
        const PanelPlan N = planPanel(area, 0, MODE_NUMBERS, pl, I, a, "", textReserve(87, MODE_NUMBERS), M);
        CHECK(N.num.rows == 3 && N.box.w() < 260, "numbers mode in an 87 px pane: the 3 rows that fit, compact (< 260 px; 1.5.1 was ~375)");
        // the verdict is kept when the read is shortened
        std::vector<std::string> L = wrapRead("2:30 Sellers hit the bid with a 50-lot (5.0x) fast (p 3.7x ?), swept 3 levels with one 25-lot order - price held: buyers absorbing.", 420, 2, M);
        std::string jj; for (auto& s : L) jj += (jj.empty() ? "" : " ") + s;
        CHECK(jj.find("price held: buyers absorbing.") != std::string::npos && jj.find("...") == std::string::npos, "2 lines: the large-order clause / pace words go first, the verdict stays");
        CHECK(textReserve(87, MODE_READ) == 4 && textReserve(87, MODE_NUMBERS) == 30 && textReserve(100, MODE_NUMBERS) == 47 && textReserve(30, MODE_NUMBERS) == 0, "text reserve per mode (a 75 px pane keeps its read line: was 0 under 80 px)");
        CHECK(textReserve(75, MODE_NUMBERS) == 30, "the 75 px PullStats pane: room for one read line + the options line");
    }
    // ---------------- one spike label per candle ----------------
    {
        bool s[2] = { true, true }, ok[2] = { true, true }; double r[2] = { 3.2, 3.5 }; long long v[2] = { 6301, 100 };
        CHECK(spikeSideOf(s, ok, r, v) == 1, "both sides spike: the bigger ratio (3.5x)");
        r[1] = 3.2; CHECK(spikeSideOf(s, ok, r, v) == 0, "same ratio: the bigger value");
        s[0] = false; CHECK(spikeSideOf(s, ok, r, v) == 1, "one side: that side");
        s[1] = false; CHECK(spikeSideOf(s, ok, r, v) == -1, "no spike: none");
    }
    // ---------------- rare L ----------------
    {
        Params P; SizeDist orders, bars;
        for (int i = 0; i < 5000; ++i) orders.add(1 + i % 25);              // per-order p99 = 25
        CHECK(rareThreshold(orders, bars, 0, P) == 0, "no candle history (a restart / the session start): no L at all");
        for (int i = 0; i < 19; ++i) bars.add(30 + i);
        CHECK(rareThreshold(orders, bars, 0, P) == 0, "19 candles: still no L");
        bars.add(49);
        const long long t = rareThreshold(orders, bars, 0, P);
        CHECK(t == bars.pct(90) + 1 && t > 25, "20 candles: above the 90th pct of the candles' biggest orders (not the per-order 20-lot floor)");
        int lCount = 0; for (int i = 0; i < 100; ++i) { const long long biggest = 30 + i % 20; if (biggest >= t) ++lCount; }
        CHECK(lCount <= 10, "on candles like the prior ones, L fires on at most ~10% (was ~100%)");
        CHECK(rareThreshold(orders, bars, 75, P) == 75, "a fixed lot size from the params file still wins");
        Params Q; Q.largeBarMin = 0; CHECK(rareThreshold(orders, SizeDist(), 0, Q) == 25, "largeBarMin 0: the per-order rule alone");
    }
    std::printf("panel logic (BoxPlace 1.0.0 + OrderFlowFeed 1.3.0): %d passed, %d failed\n", passes, fails);
    return fails ? 1 : 0;
}
