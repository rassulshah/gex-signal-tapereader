#!/bin/sh
# runs every HodLod harness suite, writes FAIL lines (line numbers stripped) per suite to $1/
O=$1; mkdir -p $O; cd /home/claude/aud/layout/b/hlw/tests; rm -f ../out/t_*
F="-std=c++14 -Wall -Wextra -g -O1 -fsanitize=address,undefined -fno-sanitize-recover=undefined"
g++ $F -I../src test_hodlod_logic.cpp -o ../out/t_logic 2>$O/cc_logic.txt || echo "COMPILE FAIL logic"
g++ $F -I mock_sdk -I ../src test_hodlod_lifecycle_mock.cpp -o ../out/t_life 2>$O/cc_life.txt || echo "COMPILE FAIL life"
g++ $F -DHL_FORCE_NO_READ -I../src test_hodlod_logic.cpp -o ../out/t_logic_noread 2>$O/cc_nr.txt || echo "COMPILE FAIL noread"
g++ $F -I mock_sdk -I ../src test_leaks_hodlod.cpp -o ../out/t_leak_hl 2>/dev/null || echo "COMPILE FAIL leak"
cd ..
./out/t_logic data out > $O/logic.txt 2>&1; ./out/t_life data out > $O/life.txt 2>&1; mkdir -p out/noread; ./out/t_logic_noread data out/noread > $O/noread.txt 2>&1
ASAN_OPTIONS=detect_leaks=1 ./out/t_leak_hl data out 50 > $O/leak.txt 2>&1
python3 -I tests/ref_hodlod.py data/es_chart.csv 510 900 180 > out/ref_prefix_states.txt; cmp -s out/ref_prefix_states.txt out/cpp_prefix_states.txt && echo "pyref == C++ $(wc -l < out/ref_prefix_states.txt) prefixes" > $O/pyref.txt || echo "PYREF DIFF" > $O/pyref.txt
cd tests
for t in t_hl206 t_draw101 t_proj110 t_proj112 t_proj115 t_proj116 t_fx200 t_fc118 t_proj204 $EXTRA; do g++ $F -I mock_sdk -I../src $t.cpp -o ../out/$t 2>$O/cc_$t.txt || echo "COMPILE FAIL $t"; ../out/$t ../data ../out > $O/$t.txt 2>&1; done
cd $O; for f in *.txt; do case $f in cc_*) continue;; esac; grep -h "FAIL" $f | sed 's/(line [0-9]*)//' > ${f%.txt}.fails; printf "%-12s %s | %s\n" ${f%.txt} "$(grep -c FAIL $f)" "$(tail -1 $f | cut -c1-90)"; done
