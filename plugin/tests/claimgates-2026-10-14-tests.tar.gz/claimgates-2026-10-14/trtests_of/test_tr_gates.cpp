// test_tr_gates.cpp -- lsTapeReader 1.1.4 claim gates (Rassul 2026-10-14 15:07 CT approval, peer review E): built with the DEFAULT
// gates (hidden). The Delta Profile A is not a FLOW vote and not a BUYERS / SELLERS message; the LEVELS gamma node has no "(dlrs ...)"
// cause text; everything else in the read is unchanged. test_tr_logic.cpp is built with the gates RESTORED
// (-DLRA_SHOW_ABSORPTION_REASON=1 -DLRA_SHOW_HVL_CUSHION=1) and must still pass in full - the restore path.
#include "tr_scenario.h"
#include "../DealerLogic.h"
#include <cstdio>
#include <string>
static int g_pass = 0, g_fail = 0;
#define CHECK(c, m) do { if (c) ++g_pass; else { ++g_fail; std::printf("FAIL %s:%d  %s\n", __FILE__, __LINE__, std::string(m).c_str()); } } while (0)
static bool has(const std::string& s, const std::string& k) { return s.find(k) != std::string::npos; }
int main()
{
    CHECK(!cgate::kShowAbsorptionReason && !cgate::kShowHvlCushion && !cgate::kShowStrength && !cgate::kShowOptionsCauses, "every gate hidden by default");
    CHECK(std::string(tr::VERSION) == "1.1.4", "version 1.1.4");
    {   // the A alone: no FLOW vote (it was BULL with the gate open - test_tr_logic 'a support A alone is bullish')
        scen::World w; w.in.of[0] = w.in.of[1] = w.in.of[2] = nullptr; tr::DeltaSnap d = w.dp; d.ae.clear(); w.in.dp = &d;
        const tr::Read R = tr::compute(w.in);
        CHECK(R.votes[tr::V_FLOW] == tr::NEUTRAL && R.why[tr::V_FLOW] == "none", "A alone: FLOW neutral, why 'none' (" + R.why[tr::V_FLOW] + ")");
        CHECK(!has(R.buyers, "bsorbing") && !has(R.sellers, "bsorbing"), "A alone: no 'Absorbing at' message: " + R.buyers + " | " + R.sellers);
        d.a[0].support = false; d.a[0].lo = 92.94; d.a[0].hi = 92.98;
        CHECK(tr::compute(w.in).votes[tr::V_FLOW] == tr::NEUTRAL, "a resistance A alone: FLOW neutral");
    }
    {   // the full mockup world: the other three FLOW sources still vote, the bias still forms; no A words, no dealer cause words
        scen::World w; const tr::Read R = tr::compute(w.in);
        CHECK(R.votes[tr::V_FLOW] == tr::BULL, "mockup: FLOW still bullish from the order-flow panes");
        CHECK(!has(R.why[tr::V_FLOW], "A+") && !has(R.why[tr::V_FLOW], "A-"), "mockup: A not in the FLOW why (" + R.why[tr::V_FLOW] + ")");
        CHECK(!has(R.buyers, "absorbing at LonLO") && has(R.buyers, "Defending LonLO"), "mockup BUYERS: no A message, the stack message kept: " + R.buyers);
        CHECK(has(R.levels, "+GEX PS 92.90") && !has(R.levels, "dlrs"), "mockup LEVELS: the gamma node, no '(dlrs buy dips)': " + R.levels);
    }
    {   // the A circle's own record is untouched: the parser still reads the A (the chart draws it; only its use as a reason is gated)
        tr::DeltaSnap d; tr::parseDelta(tr::lines(scen::deltaRecord("QCL"), true), "QCL", d);
        CHECK(d.a.size() == 1, "the Delta Profile A record still parses (the circle stays)");
    }
    std::printf("tr gates: %d passed, %d failed\n", g_pass, g_fail);
    return g_fail ? 1 : 0;
}
