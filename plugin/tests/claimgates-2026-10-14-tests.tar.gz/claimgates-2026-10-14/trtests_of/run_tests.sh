#!/bin/sh
# lsTapeReader 1.1.0 (of140; 6:40 PM: a compile error or a failed check now FAILS the run - it used to slip through "&&"): logic + host tests under ASan / UBSan (-Werror), the order-flow record compatibility test against the real
# OrderFlowFeed.h (if its build is present), the real-SDK syntax check (MinGW, windows.h before irtsdk.h), the render check PNG.
set -e
D=$(cd "$(dirname "$0")" && pwd); B=${BUILD:-/tmp/tr-build}; mkdir -p "$B"; SAN="-fsanitize=address,undefined -fno-sanitize-recover=undefined"
# (1.1.4) claim gates: the full logic suite runs with the gates RESTORED (the restore path); test_tr_gates runs the DEFAULT (hidden) build
g++ -std=c++17 -Wall -Wextra -Werror -g $SAN -DLRA_SHOW_ABSORPTION_REASON=1 -DLRA_SHOW_HVL_CUSHION=1 -I"$D" "$D/test_tr_logic.cpp" -o "$B/tl" || { echo "FAILED: tr logic compile"; exit 1; }; "$B/tl" | tee "$B/tl.out"; grep -q " 0 failed" "$B/tl.out" || exit 1
g++ -std=c++17 -Wall -Wextra -Werror -g $SAN -I"$D" "$D/test_tr_gates.cpp" -o "$B/tg" || { echo "FAILED: tr gates compile"; exit 1; }; "$B/tg" | tee "$B/tg.out"; grep -q " 0 failed" "$B/tg.out" || exit 1
g++ -std=c++17 -Wall -Wextra -Werror -g $SAN -DTR_TEST_CLOCK -DTR_TEST_DATA="\"$D/data/\"" -I"$D/mock" -I"$D" -I"$D/.." "$D/test_tr_host.cpp" -o "$B/th" || { echo "FAILED: tr host compile"; exit 1; }; "$B/th" | tee "$B/th.out"; grep -q " 0 failed" "$B/th.out" || exit 1
g++ -std=c++17 -Wall -Wextra -Werror -g $SAN -DTR_TEST_CLOCK -DTR_TEST_DATA="\"$D/data/\"" -I"$D/mock" -I"$D" -I"$D/.." "$D/test_tr_banner.cpp" -o "$B/tb" || { echo "FAILED: tr banner compile"; exit 1; }; "$B/tb" | tee "$B/tb.out"; grep -q " 0 failed" "$B/tb.out" || exit 1
OF=${OF:-$D/..}
if [ -f "$OF/OrderFlowFeed.h" ]; then g++ -std=c++17 -Wall -Wextra -g $SAN -I"$OF" -I"$D" "$D/test_tr_ofcompat.cpp" -o "$B/toc" || { echo "FAILED: of-compat compile"; exit 1; }; "$B/toc" | tee "$B/toc.out"; grep -q " 0 failed" "$B/toc.out" || exit 1; else echo "of-compat: skipped (no $OF/OrderFlowFeed.h)"; fi
SDK=${SDK:-/mnt/user-data/uploads/sdk/c++/include}
x86_64-w64-mingw32-g++ -std=c++17 -fsyntax-only -Wall -Wextra -I"$SDK" -I"$D/.." "$D/wrap_real_sdk.cpp" 2>"$B/syntax.log" || true
echo "MinGW syntax (real SDK): $(grep -c ' error' "$B/syntax.log" || true) errors, $(grep warning "$B/syntax.log" | grep -vc "$SDK" || true) warnings outside the SDK"
g++ -std=c++17 -DTR_TEST_CLOCK -I"$D/mock" -I"$D" -I"$D/.." "$D/render_check.cpp" -o "$B/rc" && "$B/rc" > "$B/rc.txt" 2>"$B/rc.read" && python3 "$D/render_check.py" "$B/rc.txt" "$B/render-check-tr.png"
