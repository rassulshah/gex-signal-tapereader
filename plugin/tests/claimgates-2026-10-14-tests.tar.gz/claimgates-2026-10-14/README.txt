Claim gates 2026-10-14 (lsTapeReader 1.1.4, lsDealerRead 4.6.0) - tests run on Linux (g++ ASan/UBSan -Werror):
  sh trtests_of/run_tests.sh       Tape Reader: logic suite built RESTORED (-DLRA_SHOW_ABSORPTION_REASON=1 -DLRA_SHOW_HVL_CUSHION=1),
                                   test_tr_gates built DEFAULT (hidden), host + banner suites default, MinGW real-SDK syntax, render check
  g++ -std=c++17 -I.. test_dealerread_460.cpp                        Dealer Read gates, default (hidden)
  g++ -std=c++17 -DLRA_SHOW_STRENGTH=1 -DLRA_SHOW_OPTIONS_CAUSES=1 -DLRA_SHOW_ABSORPTION_REASON=1 -I.. test_dealerread_460.cpp   restored
Results 2026-10-14: tr logic 240/0, tr gates 10/0, tr host 91/0 (and 91/0 restored), tr banner 42/0, MinGW 0 errors / 0 warnings
outside the SDK (TapeReader and DealerRead), dealerread gates 9/0 hidden, 4/0 restored.
