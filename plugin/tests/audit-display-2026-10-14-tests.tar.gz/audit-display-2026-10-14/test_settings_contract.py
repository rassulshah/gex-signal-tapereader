"""Settings-audit contract (2026-10-13): static checks on the plugins changed tonight - versions agree, dead rows are gone,
types are right (check box / colour / list), and no how-to text sits in a settings window.   python3 -I test_settings_contract.py <plugin dir>"""
import re, sys
from pathlib import Path
D = Path(sys.argv[1] if len(sys.argv) > 1 else ".")
def src(n): return (D / n).read_text(encoding="latin-1")
checks = {}
def lit(s, pat):
    m = re.search(pat, s); return m.group(1) if m else None
sv = src("SessionVWAP.cpp")
checks["SessionVWAP: SV_VERSION = setVersion = 1.5.0"] = lit(sv, r'SV_VERSION = "([\d.]+)"') == lit(sv, r'setVersion\("([\d.]+)"\)') == "1.5.0"
checks["SessionVWAP: a show box per line"] = len(re.findall(r'setBoolParameter\("', sv)) == 7
checks["SessionVWAP: a colour per line"] = len(re.findall(r'setColorParameter\("', sv)) == 6
checks["SessionVWAP: widths are lists"] = len(re.findall(r'setListParameter\("(VWAP|Band) width"', sv)) == 2
checks["SessionVWAP: parameter version bumped (6)"] = "setParameterVersion(6)" in sv
checks["SessionVWAP: no fixed band colours left in the draw"] = not re.search(r"C_SD1|C_SD2|C_PRTH", sv)
checks["SessionVWAP: description no longer promises badges"] = "badge" not in (lit(sv, r'setDescription\("([^"]*)"') or "badge")
checks["SessionVWAP: settings saved only from the window callbacks"] = "int SessionVWAP::parmsApply(void) { saveStyle();" in sv and "int SessionVWAP::parmsLoad(void)" in sv and "saveStyle" not in sv.split("int SessionVWAP::parmsLoad(void)")[1].split("\n}\n")[0]
ds = src("DealerSig.cpp")
checks["DealerSig: DS_VERSION = setVersion = 1.7.0"] = lit(ds, r'DS_VERSION = "([\d.]+)"') == lit(ds, r'setVersion\("([\d.]+)"\)') == "1.7.0"
checks["DealerSig: ledger is a check box"] = 'setBoolParameter("Dealer ledger marks", false)' in ds and "isBoxChecked(SX.ledger)" in ds and '"Off;On"' not in ds
checks["DealerSig: parameter version bumped (3)"] = "setParameterVersion(3)" in ds
lq, lql = src("LiquidityProfile.cpp"), src("LiquidityProfileLogic.h")
checks["Liquidity: LQ_VERSION = setVersion = lqp::VERSION = 0.15.1"] = lit(lq, r'LQ_VERSION "([\d.]+)"') == lit(lq, r'setVersion\("([\d.]+)"\)') == lit(lql, r'VERSION = "([\d.]+)"') == "0.15.1"
flow = lq.split("int cppExtension::setup(void) {")[1].split("#else")[0]
checks["LiquidityFlow: Font row only, parameter version 2"] = "Width px" not in flow and 'setIntegerParameter("Font pt"' in flow and "setParameterVersion(2)" in flow
checks["Liquidity: Apply saves per market; draw reads it"] = "void LiquidityProfile::saveSize()" in lq and "loadSize(*S)" in lq
dr = src("DealerRead.cpp")
checks["DealerRead: setVersion = status VERSION = 4.7.0"] = lit(dr, r'setVersion\("([\d.]+)"\)') == lit(dr, r'"VERSION,([\d.]+)') == "4.7.0"
drs = re.sub(r"//[^\n]*", "", dr.split("int cppExtension::setup(void)")[1].split("\n}\n")[0])
checks["DealerRead: Clock offset + Background rows gone, version 14 (4.5.9 Offset X / Y)"] = "Clock offset" not in drs and '"Background"' not in drs and "setParameterVersion(14)" in drs
checks["DealerRead: Font size saved from the window and read by the draw"] = 'placePath("DealerReadFont", m)' in dr and "cfg.font = drLoadFont(mkt, cfg.font)" in dr
checks["DealerRead: no stale 'drag' text in the description"] = "Drag" not in (lit(dr, r'setDescription\("([^"]*)"') or "Drag")
for n, s in (("DealerRead", dr), ("SessionVWAP", sv), ("DealerSig", ds), ("LiquidityProfile", lq)):
    checks[f"{n}: no how-to text rows (setLabelParameter)"] = "setLabelParameter(" not in s
bad = [k for k, v in checks.items() if not v]
for k, v in checks.items(): print(("ok   " if v else "FAIL ") + k)
print(f"\nsettings contract: {len(checks) - len(bad)} passed, {len(bad)} failed")
sys.exit(1 if bad else 0)
