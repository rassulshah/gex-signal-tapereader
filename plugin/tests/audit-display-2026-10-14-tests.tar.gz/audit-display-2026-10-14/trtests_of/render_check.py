# render_check.py -- rasterises render_check's dump (lsTapeReader's own draw calls on the mock host) with Liberation Sans, the font whose
# advances the mock measures with (metric-compatible with Arial / Helvetica). The candles / level line are chart context only.
import sys
from PIL import Image, ImageDraw, ImageFont
S = 2
D = '/usr/share/fonts/truetype/liberation/'
def font(pt, bold): return ImageFont.truetype(D + ('LiberationSans-Bold.ttf' if bold else 'LiberationSans-Regular.ttf'), round(pt * 4 / 3) * S)
def rgb(h): v = int(h, 16); return ((v >> 16) & 255, (v >> 8) & 255, v & 255)
rows = [l.rstrip('\n').split('|') for l in open(sys.argv[1], encoding='cp1252')]
pane = next(r for r in rows if r[0] == 'pane'); W, H = int(pane[3]), int(pane[4])
img = Image.new('RGB', ((W + 70) * S, (H + 40) * S), (12, 14, 18)); d = ImageDraw.Draw(img)
oy = 30
d.text((10 * S, 6 * S), 'lsTapeReader 1.1.0 render check - the plugin\'s own draw() on the mock host (CL 3-min, 10:30 AM, approved mockup scenario)', font=font(9, True), fill=(210, 214, 220))
d.rectangle([0, oy * S, W * S, (oy + H) * S], outline=(45, 50, 58), width=S)
Y = lambda v: (oy + v) * S
for r in rows:
    if r[0] == 'level':
        y = int(r[1]); col = (245, 158, 11) if 'LonLO' in r[2] else (59, 130, 246)
        d.line([(0, Y(y)), (W * S, Y(y))], fill=col, width=S); d.text((150 * S, Y(y) - 14 * S), r[2], font=font(8, False), fill=col)
for r in rows:
    if r[0] == 'bar':
        x, o, h, l, c = map(int, r[1:6]); col = (34, 197, 94) if c <= o else (239, 68, 68)
        d.line([(x * S, Y(h)), (x * S, Y(l))], fill=col, width=S)
        d.rectangle([(x - 5) * S, Y(min(o, c)), (x + 5) * S, Y(max(o, c)) + S], fill=col)
    if r[0] == 'circle':
        x, y = int(r[1]), int(r[2]); d.ellipse([(x - 14) * S, Y(y - 10), (x + 14) * S, Y(y + 10)], outline=(34, 197, 94), width=2 * S)
        d.text(((x - 9) * S, Y(y + 12)), r[3], font=font(8, True), fill=(34, 197, 94))
for r in rows:
    if r[0] == 'box':
        l, t, rr, b = map(int, r[1:5]); d.rectangle([l * S, Y(t), rr * S, Y(b)], fill=rgb(r[5]), outline=rgb(r[6]), width=int(r[7]) * S)
    elif r[0] == 'text':
        l, t, rr, b = map(int, r[1:5]); fs = int(r[7]); bold = r[8] == '1'; txt = '|'.join(r[9:])
        yc = (t + b) / 2 + fs * 0.45          # the plugin puts the text's centre fs*0.45 below its rect centre (execute())
        d.text((l * S, Y(yc)), txt, font=font(fs, bold), fill=rgb(r[5]), anchor='lm')
img.save(sys.argv[2]); print('saved', sys.argv[2], img.size)
