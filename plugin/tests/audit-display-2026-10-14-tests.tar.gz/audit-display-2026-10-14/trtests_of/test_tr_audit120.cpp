// test_tr_audit120.cpp -- lsTapeReader 1.2.0 (2026-10-14, Rassul approved the external-audit display list at 18:25 CT, section 3).
// Built with the DEFAULT gates: every before -> after of the approved list, on the banner (line 1) and the hover (BUYERS / SELLERS /
// OPTIONS), plus the logged LEVELS. test_tr_logic.cpp runs the restore path (-DLRA_SHOW_TAPE_BIAS=1 -DLRA_SHOW_TURN_ODDS=1 ...).
#include "tr_scenario.h"
#include "../DealerLogic.h"
#include <cstdio>
#include <string>
static int g_pass = 0, g_fail = 0;
#define CHECK(c, m) do { if (c) ++g_pass; else { ++g_fail; std::printf("FAIL %s:%d  %s\n", __FILE__, __LINE__, std::string(m).c_str()); } } while (0)
static bool has(const std::string& s, const std::string& k) { return s.find(k) != std::string::npos; }
static int measure(const std::string& s, int fs, bool bold) { return (int)s.size() * (fs * (bold ? 6 : 5)) / 10; }
static std::string line1(const tr::Read& R) { std::string o; for (const tr::Seg& g : tr::line1Segs(R, "Tape Reader v1.2.0  \xB7  CL  \xB7  10:03 AM")) o += g.s; return o; }
static std::string allText(const tr::Layout& L) { std::string o; for (const tr::Item& it : L.items) if (it.k == tr::K_TEXT) o += it.s + "|"; return o; }
int main()
{
    CHECK(!cgate::kShowTapeBias && !cgate::kShowTurnOdds && !cgate::kShowControlWord && !cgate::kShowAnalyst && !cgate::kShowReadExit, "the 1.1.0 gates are hidden by default");
    CHECK(std::string(tr::VERSION) == "1.2.0", "version 1.2.0");
    scen::World w; const tr::Read R = tr::compute(w.in);
    // BIAS: still computed + logged, not shown
    CHECK(R.bias == tr::BULL && R.biasText == "BULLISH 3 of 4", "bias still computed (logged): " + R.biasText);
    const std::string l1 = line1(R);
    CHECK(!has(l1, "BULLISH") && !has(l1, "BEARISH") && !has(l1, "MIXED") && !has(l1, " of 4"), "line 1: BULLISH 3 of 4 HIDDEN: " + l1);
    // TURN / SWING odds: "Turn up at LonLO 62%?   Swing 20+ ticks 41%?   Next: 93.20 PWH" -> "Turn odds learning . Next: 93.20 PWH"
    CHECK(R.turn == "Turn up at LonLO 62%?   Swing 20+ ticks 41%?   Next: 93.20 PWH", "the full centre is still logged: " + R.turn);
    CHECK(tr::shownCentre(R.turn) == "Turn odds learning   Next: 93.20 PWH", "shown centre: Turn odds learning + Next, no Swing: " + tr::shownCentre(R.turn));
    CHECK(!has(l1, "%") && has(l1, "Turn odds learning") && has(l1, "Next: 93.20 PWH") && !has(l1, "Swing"), "line 1 has no percentage: " + l1);
    CHECK(l1.find("   Turn odds learning") != std::string::npos, "no leading dot when the bias is not shown: " + l1);
    { bool ok = false; for (const tr::Seg& g : tr::line1Segs(R, "h")) if (g.s.find("Turn odds learning") != std::string::npos) ok = g.col == tr::C_QUIET && g.s.find("Next") == std::string::npos;
      CHECK(ok, "'Turn odds learning' neutral (not green / red), Next in its own colour"); }
    CHECK(tr::shownCentre("Next: 92.80 PWL") == "Next: 92.80 PWL" && tr::shownCentre("") == "", "a centre with only Next is unchanged");
    {   // the read reloaded from the log (restart) shows the same
        tr::Read B; CHECK(tr::parseLogLine(tr::logLine(R, w.in.P), B) && line1(B) == l1, "a read reloaded from the log shows the same line 1 (no repaint)"); }
    // Tgt without %
    CHECK(has(R.levels, "Tgt 93.20 PWH") && !has(R.levels, "Tgt 93.20 PWH ("), "logged Tgt without %: " + R.levels);
    // GEX node: "+GEX PS 92.90" -> "+GEX PS 92.90 (model) ?" / "(model, 7m old) ?"
    CHECK(has(R.levels, "+GEX PS 92.90 (model) ?"), "GEX node marked model + ? (age unknown): " + R.levels);
    { scen::World w2; w2.in.gammaAgeS = 7 * 60 + 10; CHECK(has(tr::compute(w2.in).levels, "+GEX PS 92.90 (model, 7m old) ?"), "GEX node with its age: (model, 7m old) ?"); }
    // LQ: "Bid LQ 2.6x on LonLO" -> "Bids 2.6x normal at LonLO ?"
    CHECK(has(R.levels, "Bids 2.6x normal at LonLO ?") && !has(R.levels, "LQ"), "LQ reworded: " + R.levels);
    // Stack: "Defending LonLO: ... added fast, 90% rebuilt, reloading (I 5.2x)" -> "Added at LonLO: ... fast, 90% re-added after hits, reloading? (I 5.2x)"
    CHECK(R.buyers.rfind("Added at LonLO: 42 bids, 150 lots (4.4x) fast, 90% re-added after hits, reloading? (I 5.2x)", 0) == 0, "stack line reworded: " + R.buyers);
    CHECK(!has(R.buyers, "Defending") && !has(R.buyers, "rebuilt") && !has(R.buyers, "added fast"), "no 'Defending' / 'rebuilt' / second 'added'");
    // Pull: no tail
    CHECK(has(R.sellers, "pulled 92 offers, 356 lots (4.4x) fast at LonLO.") && !has(R.sellers, "leaving"), "pull line ends at the numbers: " + R.sellers);
    // Needs ... (KEEP), AE? (KEEP in the text the Delta record gives)
    CHECK(has(R.buyers, "Needs a higher low / lift the offer (S)."), "KEEP: Needs a higher low / lift the offer (S)");
    // Ex?: "(Ex?) - exhausted" -> "(Ex?)"; a record that says "Ex" still shows "Ex?"
    {   scen::World w3; tr::DeltaSnap d = w3.dp; d.a.clear(); d.ae.clear(); tr::DeltaEx e; e.decT = w3.B[48].t; e.top = false; e.extreme = 92.87; e.mark = "Ex"; d.ex.push_back(e); w3.in.dp = &d;
        const tr::Read Rx = tr::compute(w3.in);
        CHECK(has(Rx.sellers, "ast push to 92.87 on thin selling (Ex?)") && !has(Rx.sellers, "exhausted") && !has(Rx.sellers, "(Ex)"), "Ex always Ex?, no 'exhausted': " + Rx.sellers); }
    // OPTIONS: ON gates keep "?" (ODEX too), the first line says the age
    {   scen::World w4;
        const ofo::Snap s = ofo::parse({ "VERSION,1", "MARKET,GC", "ASOF,1791900000", "OWALL,PS,2650,2.4,+,40,building,12", "ODEX,1200,487000000,2.1,1", "OHVL,2640,above" }, "GC");
        w4.in.mkt = "GC"; w4.in.opt = &s; for (int g = 0; g < ofo::NGATE; ++g) w4.in.optGates[g] = ofo::GATE_ON; w4.in.optAgeS = 7 * 60;
        const tr::Read Ro = tr::compute(w4.in);
        CHECK(has(Ro.opt[0], "wall 2.4x (+) building ?") && has(Ro.opt[0], "above HVL ?") && has(Ro.opt[0], " (model, 7m old)"), "OPTIONS line 1 marked ? + age: " + Ro.opt[0]);
        CHECK(has(Ro.opt[1], "Dealers buy") && has(Ro.opt[1], "2.1x ?"), "GC ODEX gets its ? back: " + Ro.opt[1]);
        w4.in.optGates[ofo::G_ODEX] = ofo::GATE_OFF; CHECK(!has(tr::compute(w4.in).opt[1], "Dealers"), "an OFF gate stays off"); }
    // the hover draws the reworded lines; line 1 never draws the bias
    {   tr::Box area; area.l = 4; area.t = tr::TITLE_ROW; area.r = 1100; area.b = 600;
        const tr::Banner Bn = tr::layoutBanner(R, "Tape Reader v1.2.0", bb::Warn(), area, bp::Place(), 0, true, true, measure);
        const std::string t = allText(Bn.L);
        CHECK(!has(t, "BULLISH") && !has(t, "Swing") && !has(t, "62%") && !has(t, "leaving") && !has(t, "Defending") && !has(t, "exhausted"), "the drawn banner + hover: no hidden / old words: " + t);
        CHECK(has(t, "Turn odds learning") && has(t, "Added at LonLO"), "the drawn banner + hover carry the new words"); }
    std::printf("tr audit 1.2.0: %d passed, %d failed\n", g_pass, g_fail);
    return g_fail ? 1 : 0;
}
