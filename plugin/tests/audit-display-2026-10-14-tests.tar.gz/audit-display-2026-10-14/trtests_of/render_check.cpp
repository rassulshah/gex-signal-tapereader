// render_check.cpp -- runs lsTapeReader's own draw() (TapeReader.cpp + TapeReaderLogic.h layout) on the mock host with the approved
// mockup scenario (CL 3-min, 10:30 AM) and dumps every draw call + the candles for render_check.py -> out/render-check.png.
#include "irtsdk.h"
#include "../TapeReader.cpp"
#include "tr_scenario.h"
#include <cstdio>
#include <sys/stat.h>
#include <utime.h>
namespace mock { Host* current = nullptr; }
long long tr_test_now_ms = 1000000, tr_test_unix = 0; void* tr_test_cursor_wnd = nullptr; int tr_test_fail_rename = 0;
static std::string DIR;
static void put(const std::string& rel, const std::string& text) { const std::string p = DIR + "/" + rel; mkdir(p.substr(0, p.rfind('/')).c_str(), 0755); std::ofstream f(p.c_str(), std::ios::binary); f << text; }
int main(int argc, char** argv) {
    char tmpl[] = "/tmp/trrenderXXXXXX"; DIR = mkdtemp(tmpl); setenv("USERPROFILE", DIR.c_str(), 1); tr_test_unix = (long long)std::time(nullptr);
    put("LRA-KeyLevels-CL.csv", scen::keyLevels(tr_test_unix)); put("LRA-Levels-CL.csv", scen::mqLevels()); put("LRA-Touch-CL.csv", scen::touch());
    put("LRA-Dealer-CL.csv", scen::dealer("CLX6", tr_test_unix)); put("LRA-LiqZones-CL.csv", scen::liqZones(tr_test_unix)); put("LiquidityProfile.status-CL-180.txt", scen::liqStatus("CLX6"));
    put("HodLod.status-CL-180.txt", scen::hodlod()); put("LRA-Turns-CL.csv", scen::turns());
    put("DeltaProfile/CL-CLX6-180-signals-20739.csv", scen::deltaRecord("QCL"));
    put("BidAskStats/CL-CLX6-180-20261013.csv", scen::basFile()); put("PullStats/CL-CLX6-180-20261013.csv", scen::pullFile()); put("StackStats/CL-CLX6-180-20261013.csv", scen::stackFile());
    put("DealerProfile.status.txt", "REACH,150\n"); put("DeltaProfile.status.txt", "WIDTH,50\nPLACE,Right\n");
    if (argc > 1) put("TapeReader.place-CL.txt", std::string(argv[1]) + "\n");
    // (1.1.0) the options grid of 10:28, written at 10:29 (arrived on the 10:30 candle); gates not proven yet
    put("LRA-Options-CL.csv", "VERSION,1\nMARKET,CL\nASOF," + std::to_string(scen::ct(10, 28)) + "\nOHIT,92.5,P,2.4,2.0,dn,put sellers,1200\nOSTACK,PS,92.9,40,+,3,2.4,building\nOWALL,PS,92.9,2.4,+,40,building,-\nODEX,1200,111000000,2.1,0\nOHVL,92.6,above\n");
    { struct utimbuf u; u.actime = u.modtime = (time_t)scen::ct(10, 29); utime((DIR + "/LRA-Options-CL.csv").c_str(), &u); }
    put("LRA-OrderFlow-CL.csv", "VERSION,1\nMARKET,CL\n");
    mock::Host H; mock::current = &H; H.paneRight = 1240; H.paneBottom = 640; H.priceBase = 92.20f; H.pxPerPoint = 420.0f; H.x0 = 130; H.ppb = 16;
    const std::vector<tr::Bar> B = scen::bars(1, 92.97);
    for (const tr::Bar& b : B) { mock::Bar m; m.time = (unsigned long)b.raw; m.open = (float)b.o; m.high = (float)b.h; m.low = (float)b.l; m.close = (float)b.c; H.bars.push_back(m); }
    TapeReader* x = static_cast<TapeReader*>(CreateExtension()); x->setup(); x->calc(0); x->draw();
    std::printf("pane|%d|%d|%d|%d\n", H.paneLeft, H.paneTop, H.paneRight, H.paneBottom);
    for (size_t i = 0; i < H.bars.size(); ++i) { cppExtension::PNT p; p.set((int)i, 0, cppExtension::kBarCenter); auto y = [&](float v) { return (int)(H.paneBottom - (v - H.priceBase) * H.pxPerPoint); };
        std::printf("bar|%d|%d|%d|%d|%d\n", p.h, y(H.bars[i].open), y(H.bars[i].high), y(H.bars[i].low), y(H.bars[i].close)); }
    std::printf("level|%d|LonLO 92.90  41%%  /  58%%\n", (int)(H.paneBottom - (92.90f - H.priceBase) * H.pxPerPoint));
    std::printf("level|%d|PWH 93.20\n", (int)(H.paneBottom - (93.20f - H.priceBase) * H.pxPerPoint));
    { cppExtension::PNT p; p.set(47, 0, cppExtension::kBarCenter); std::printf("circle|%d|%d|AE?\n", p.h, (int)(H.paneBottom - (92.90f - H.priceBase) * H.pxPerPoint)); }
    for (const mock::Draw& d : H.draws) std::printf("%s|%d|%d|%d|%d|%06lx|%06lx|%d|%d|%s\n", d.type.c_str(), d.l, d.t, d.r, d.b, d.color, d.border, d.fs, d.bold ? 1 : 0, d.text.c_str());
    TRState* S = x->testState(); std::fprintf(stderr, "read: %s | %s\nB: %s\nS: %s\nL: %s\n", S->live.biasText.c_str(), S->live.turn.c_str(), S->live.buyers.c_str(), S->live.sellers.c_str(), S->live.levels.c_str());
    x->destroy(); delete x; return 0;
}
