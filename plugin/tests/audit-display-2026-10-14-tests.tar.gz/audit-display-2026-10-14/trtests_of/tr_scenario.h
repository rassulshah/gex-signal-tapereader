// tr_scenario.h -- test scenarios for lsTapeReader 1.0.1: the approved mockup (CL 3-min, LonLO 92.90 swept to 92.87, 10:30 AM)
// as bars + the other plugins' files, written in their real formats (Delta Profile 2.7.0 record lines, OrderFlowFeed.h session rows,
// LRA-LiqZones / LiquidityProfile status, KeyLevels / Levels / Touch / Dealer, HodLod status, the new LRA-Turns / LRA-TapeReader).
#ifndef TR_SCENARIO_H
#define TR_SCENARIO_H
#include "../TapeReaderLogic.h"
#include <cstdio>
#include <fstream>
#include <string>
#include <vector>

namespace scen {

static const long long DAY = 20739;                        // 2026-10-13 (days since 1970)
inline long long ct(int h, int m) { return DAY * 86400LL + h * 3600LL + m * 60LL; }
static const double TICK = 0.01;

// 50 closed CL bars 8:03 .. 10:30 (bar END times): a decline from 93.62, the 10:24 bar sweeps LonLO 92.90 to 92.87 and closes back
// at 92.93, then 10:27 / 10:30 climb. extra = forming bars after 10:30.
inline std::vector<tr::Bar> bars(int extra = 0, double formingClose = 92.97) {
    std::vector<tr::Bar> B; double px = 93.62;
    for (int i = 0; i < 50 + extra; ++i) {
        tr::Bar b; b.t = ct(8, 3) + 180LL * i; b.raw = (unsigned long long)b.t; b.v = 1000 + 37 * (i % 7);
        b.o = px;
        if (i < 47) b.c = px - 0.0145 + ((i % 3) - 1) * 0.004;
        else if (i == 47) b.c = 92.93;
        else if (i == 48) b.c = 92.95;
        else if (i == 49) b.c = 92.96;
        else b.c = formingClose;
        b.h = std::max(b.o, b.c) + 0.03; b.l = std::min(b.o, b.c) - 0.03;
        if (i == 47) { b.l = 92.87; b.h = b.o + 0.01; }
        b.o = std::floor(b.o * 100 + 0.5) / 100; b.c = std::floor(b.c * 100 + 0.5) / 100; b.h = std::floor(b.h * 100 + 0.5) / 100; b.l = std::floor(b.l * 100 + 0.5) / 100;
        B.push_back(b); px = b.c;
    }
    return B;
}

// ---- file texts (the real formats) ----
inline std::string keyLevels(long long unix) { return "KEYLV,1," + std::to_string(unix) + "\nL|LonLO|92.90|1\nL|PWH|93.20|0\nL|PDL|92.40|0\nL|ONH|94.10|0\n"; }
inline std::string mqLevels() {
    return "# LRA level touch - level_touch 1.2.0\nMARKET|CL\nAT|2026-10-13 10:29\nPX|92.96\n"
           "LEVEL|PS|PS|92.90|gamma|30|40|45|50|55|60|0|50%/60%?|60\n"
           "LEVEL|PWH|PWH|93.20|prior_week|10|20|25|34|40|50|0|34%/50%|50\n"
           "LEVEL|CR|CR/CR0/GW0|94.00|gamma|1|2|3|4|5|10|0|4%/10%?|10\n";
}
inline std::string touch() { return "# LRA touch probability\nMARKET|CL\nTOUCH|PWH|93.20|34|40|50|1|Exp/CL 50%\n"; }
// (1.0.1) ASOF|<sec of day>|<yyyy-mm-dd> for a CT clock value given as unix seconds (the test clock IS Central)
inline std::string asof(long long unix) {
    if (unix < 0) return std::string();
    time_t v = (time_t)unix; struct tm t; gmtime_r(&v, &t); char b[64];
    std::snprintf(b, sizeof(b), "ASOF|%d|%04d-%02d-%02d\n", t.tm_hour * 3600 + t.tm_min * 60 + t.tm_sec, t.tm_year + 1900, t.tm_mon + 1, t.tm_mday); return b;
}
// mode 0 = futures book (g filled), 1 = index book (g = 0 on every row, MenthorQ net GEX $ only, as dealer_irt writes SPX / QQQ),
// 2 = index book with GEX $ also 0 (nothing usable). asofUnix < 0 = no ASOF row.
inline std::string dealer(const std::string& sym, long long asofUnix = -1, int mode = 0, const std::string& srcAt = std::string()) {
    std::string s = "VERSION|1.7\n" + asof(asofUnix) + "MARKET|CL\n" + (sym.empty() ? std::string() : "SYMBOL|" + sym + "\n") + "PRICE|92.96|2.91\n";
    if (mode == 0) return s + (srcAt.empty() ? std::string() : "SRC|CL|1|futures|" + srcAt + "\n") +
           "NODE|92.90|12.6|12.6|12.6|11.8|-393|0|0.3|10.3|0|3713768|0\n"
           "NODE|93.50|-3.6|-3.6|-3.6|-3.6|207|0|0.1|5.4|0|-1125267|0\n"
           "NODE|94.00|9.1|9.1|9.1|9.0|-100|0|0.1|5.4|0|900000|0\n";
    const bool z = mode == 2;
    return s + "SRC|SPX|1.00615|T1 09:00 CT|" + srcAt + "\n"
           "NODE|92.90|0|0|0|0|0|0|||0|" + (z ? "0" : "3713768") + "|" + (z ? "0" : "-822082") + "\n"
           "NODE|93.50|0|0|0|0|0|0|||0|" + (z ? "0" : "-1125267") + "|0\n"
           "NODE|94.00|0|0|0|0|0|0|||0|" + (z ? "0" : "900000") + "|0\n";
}
inline std::string liqZones(long long unix) { return "LIQZ,1," + std::to_string(unix) + ",0.01,96\nZ,S,92.86,92.92,2.6,1840\nZ,R,93.18,93.22,1.8,900\n"; }
inline std::string liqStatus(const std::string& sym) {
    return "VERSION,0.14.0\nMARKET,CL\nSYMBOL," + sym + "\nSPB,180\nLQ,shown,1\nCONFIRM,LonLO,92.9,support,bx 2.6,shown\n"
           "ZONE,bx 2.6,rank 1,behind 8,shown,support,92.86,92.92,1840,x 2.1,age_s 400,old 0.8,near\n"
           "ZONE,bx 1.8,rank 1,behind 8,shown,resistance,93.18,93.22,900,x 1.1,age_s 400,old 0.8,far\n";
}
inline std::string hodlod() {
    return "VERSION,2.0.3\nMARKET,CL\nPER,180\nSTATE,RTH live\nFIRST,LOD\nRANGE,1.07,$1,070,64%\nREAD,CL RTH 8:00-1:30   Range used 64%   Proj HOD 93.95   LOD IN 87%\n"
           "READ_VALUES,0.870000,645,0.680000,795,0.806400,hlr-1.0.0,pInShow=0.87\nEVENTS,none,news=0,fomc=0\nPROJ,HOD,93.95,from,92.87,drawn\n";
}
// LRA-Turns-<MKT>.csv, file VERSION 2 (lra.turns): the mockup's LonLO up bucket at 10:30 (to11) = 62% turn, 41% swing >= X (20 ticks)
static const char* const TURNS_COLS = "COLS,kind,level,context,side,n,p_turn,p_swing,p_swing_x,q25,q50,q75,q90,r_net,lift,status,q25_t,q50_t,q75_t,q90_t\n";
inline std::string turnsHead(const std::string& mkt = "CL") {
    return "# LRA turns - turns 1.1.0 (test)\nVERSION,2\nMARKET," + mkt + "\nASOF,2026-10-12 18:05\nSWING,threshold,0.25,0.1\nUNIT,xER\nER_TICKS,80.0,2026-10-12\nX,0.25,20.0\n" + TURNS_COLS;
}
inline std::string turns(const std::string& status = "?", long long n = 75) {
    return turnsHead() +
           "ROW,level_tod,LonLO,to11,long," + std::to_string(n) + ",0.620,0.300,0.410,0.100,0.225,0.400,0.700,0.050,0.020," + status + ",8.0,18.0,32.0,56.0\n"
           "ROW,base,all,all,long,820,0.480,0.300,0.300,0.090,0.150,0.275,0.500,-0.200,0.000,proven,7.2,12.0,22.0,40.0\n"
           "ROW,base,all,all,short,790,0.450,0.280,0.280,0.090,0.150,0.262,0.480,-0.210,0.000,proven,7.2,12.0,21.0,38.4\n";
}
// Delta Profile 2.7.0 record: the A (support, LonLO node 92.88-92.92, 4.4x) decided at 10:24, AE? decided at 10:27
inline std::string deltaRecord(const std::string& root, long long aDecided = ct(10, 24), long long aeDecided = ct(10, 27)) {
    const std::string head = "t_first|t_decided|code|side|bias|zone_lo|zone_hi|tick|net_delta|multiple|decided_by_t|version|event|root|id|peak_t|peak_raw|price|lo_ticks|hi_ticks|node_side|source|formed_t|formed_raw\n";
    const std::string F = std::to_string(ct(10, 21)) + "|0|A?|support|bullish|92.88|92.92|0.01|-3010|4.4|0|2.7.0|F|" + root + "|7|" + std::to_string(ct(10, 21)) + "|" + std::to_string(ct(10, 21)) + "|92.9|9288|9292|sell|node|" + std::to_string(ct(10, 21)) + "|" + std::to_string(ct(10, 21)) + "\n";
    const std::string D = std::to_string(ct(10, 21)) + "|" + std::to_string(aDecided) + "|A|support|bullish|92.88|92.92|0.01|-3010|4.4|" + std::to_string(aDecided) + "|2.7.0|D|" + root + "|7|" + std::to_string(ct(10, 21)) + "|" + std::to_string(ct(10, 21)) + "|92.9|9288|9292|sell|node|" + std::to_string(ct(10, 21)) + "|" + std::to_string(ct(10, 21)) + "\n";
    const std::string AE = "AE|Y|2.7.0|" + root + "|7|" + std::to_string(aeDecided) + "|" + std::to_string(aeDecided) + "|" + std::to_string(ct(10, 21)) + "|92.88|92.92|sellers|4|3010|20|0.007|0.5|AE?|aeFadeX=0.5;src=file\n";
    return head + F + D + AE;
}
// OrderFlowFeed.h 1.2.0 session record rows (53 numbers between dbo and the letters - 1.0's 38 + 15 at the end; BidAskStats adds
// bid|ask|bbid|bask in front). (of140) the scenario writes the 1.2.0 record so the Tape Reader 1.1 reads lots / pace / rebuilt.
static const char* const OF_COLS = "partial|events|pull_n_b|pull_n_a|pull_cts_b|pull_cts_a|pull_max_b|pull_max_a|pull_close_b|pull_close_a|"
    "add_n_b|add_n_a|add_cts_b|add_cts_a|add_top_b|add_top_a|add_max_b|add_max_a|refill_n_b|refill_n_a|refill_cts_b|refill_cts_a|iceberg_b|iceberg_a|"
    "sweep_lv_b|sweep_lv_a|sweep_size_b|sweep_size_a|aggr_max_b|aggr_max_a|sweep_is_max_b|sweep_is_max_a|ice_shown_b|ice_shown_a|ice_traded_b|ice_traded_a|thr_aggr|thr_rest|"
    "pull_traded_b|pull_traded_a|hit_cts_b|hit_cts_a|rebuilt_cts_b|rebuilt_cts_a|aggr_n_b|aggr_n_a|aggr_cts_b|aggr_cts_a|pace_x100_b|pace_x100_a|pace_note_b|pace_note_a|pace_gate";
static const int OF_NUMS = 53;
inline bool isBas(const char* name) { return std::string(name) == "BidAskStats"; }
inline std::string ofHeader(const char* name) { return std::string("# ") + name + " 1.2.0 CL CLX6 180\nbar_time|ct_time|dbo|" + (isBas(name) ? "bid|ask|bbid|bask|" : "") + OF_COLS + "|letters_left|letters_right|spike_left|spike_right|dash_left|dash_right|implication|level|message|numbers\n"; }
inline std::string ofRow(long long t, const std::string& ctTxt, std::vector<long long> nums, const std::string& lL, const std::string& lR, int sL, int sR,
                         const std::string& impl, const std::string& level, const std::string& msg, const std::string& numbers) {
    if (nums.size() < (size_t)OF_NUMS) nums.resize(OF_NUMS, 0);
    std::string o = std::to_string(t) + "|" + ctTxt + "|1";
    for (long long v : nums) o += "|" + std::to_string(v);
    o += "|" + lL + "|" + lR + "|" + std::to_string(sL) + "|" + std::to_string(sR) + "|-|-|" + impl + "|" + level + "|" + tr::clean(msg, 300) + "|" + tr::clean(numbers, 300) + "\n";   // as OrderFlowFeed rowLine: '|' -> ' '
    return o;
}
inline std::vector<long long> nums(std::initializer_list<std::pair<int, long long> > kv) { std::vector<long long> v(OF_NUMS, 0); for (auto& p : kv) v[(size_t)p.first] = p.second; return v; }
// BidAskStats: bid / ask (the bars, lots) in front of the 53
inline std::vector<long long> basNums(long long bid, long long ask, std::initializer_list<std::pair<int, long long> > kv) { std::vector<long long> v = nums(kv); v.insert(v.begin(), { bid, ask, 1, 1 }); return v; }
// column indexes inside the 53 numbers
enum { N_PULL_N_B = 2, N_PULL_N_A = 3, N_PULL_CTS_B = 4, N_PULL_CTS_A = 5, N_PULL_MAX_A = 7, N_ADD_N_B = 10, N_ADD_N_A = 11, N_ADD_CTS_B = 12, N_ADD_CTS_A = 13,
       N_ADD_MAX_B = 16, N_REFILL_N_B = 18, N_ICE_B = 22, N_SWEEP_LV_B = 24, N_SWEEP_LV_A = 25, N_AGGR_MAX_B = 28, N_AGGR_MAX_A = 29, N_ICE_SHOWN_B = 32, N_ICE_TRADED_B = 34,
       N_HIT_B = 40, N_HIT_A = 41, N_REB_B = 42, N_REB_A = 43, N_PACE_B = 48, N_PACE_A = 49, N_NOTE_B = 50, N_NOTE_A = 51, N_GATE = 52 };
inline std::string basFile() {
    return ofHeader("BidAskStats") +
        ofRow(ct(10, 24), "10:24", basNums(240, 78, { {N_SWEEP_LV_B, 4}, {N_AGGR_MAX_B, 120}, {N_PACE_B, 230}, {N_NOTE_B, 1}, {N_GATE, 2} }), "SL", "", 1, 0, "bull", "LonLO",
              "Sellers hit the bid with a 240-lot (4.1x) fast (p 2.3x), swept 4 levels with one 120-lot order into LonLO - price held: buyers absorbing.", "BBid 240  BidRatio 4.1x  Jump 2.3x  Sweep 4 lvls  Large 120   |   BAsk 78  AskRatio 1.0x") +
        ofRow(ct(10, 27), "10:27", basNums(60, 70, {}), "", "", 0, 0, "neutral", "", "Normal activity - no spike", "BBid 60  BidRatio 1.0x   |   BAsk 70  AskRatio 1.1x") +
        ofRow(ct(10, 30), "10:30", basNums(50, 80, {}), "", "", 0, 0, "neutral", "", "Normal activity - no spike", "BBid 50  BidRatio 0.9x   |   BAsk 80  AskRatio 1.2x");
}
inline std::string pullFile() {
    return ofHeader("PullStats") +
        ofRow(ct(10, 27), "10:27", nums({}), "", "", 0, 0, "neutral", "", "Normal activity - no spike", "BidPull 50 (0.6x)  12 orders   |   AskPull 60 (0.7x)  15 orders") +
        ofRow(ct(10, 30), "10:30", nums({ {N_PULL_MAX_A, 80}, {N_PULL_N_A, 92}, {N_PULL_CTS_A, 356}, {N_PACE_A, 280}, {N_NOTE_A, 1}, {N_GATE, 2} }), "", "L", 0, 1, "bull", "LonLO",
              "Sellers pulled 92 offers totaling 356 lots (4.4x) fast (p 2.8x) - resistance leaving at LonLO.", "AskPull 356 (4.4x)  AskPace 2.8x  92 orders  Large 80   |   BidPull 41 (0.5x)  10 orders");
}
inline std::string stackFile() {
    return ofHeader("StackStats") +
        ofRow(ct(10, 21), "10:21", nums({ {N_REFILL_N_B, 44}, {N_ADD_MAX_B, 60}, {N_ADD_N_B, 42}, {N_ADD_CTS_B, 150}, {N_HIT_B, 100}, {N_REB_B, 90}, {N_PACE_B, 340}, {N_NOTE_B, 1}, {N_GATE, 2} }), "IL", "", 1, 0, "bull", "LonLO",
              "Buyers added 42 bids totaling 150 lots (4.4x) fast (p 3.4x) - rebuilt 90% after hits - defending LonLO.", "BidStack 150 (4.4x)  BidPace 3.4x  42 orders  BidRefill 44 (5.2x)  1 order = 12%  avg 3.6 cts  Rebuilt 90%   |   AskStack 12 (0.5x)") +
        ofRow(ct(10, 30), "10:30", nums({}), "", "", 0, 0, "neutral", "", "Normal activity - no spike", "BidStack 20 (0.8x)  BidRefill 3 (0.9x)   |   AskStack 15 (0.6x)");
}
inline std::vector<std::string> L(const std::string& t) { return tr::lines(t, false); }

// the logic inputs for the mockup read (all inputs present)
struct World {
    std::vector<tr::Bar> B; tr::DeltaSnap dp; tr::OfSnap of[3]; tr::LiqSnap liq; tr::HodLodSnap hl; tr::TurnsSnap tu; std::vector<tr::Level> key, mq; std::vector<tr::Touch> tp;
    tr::Inputs in;
    World() {
        B = bars();
        tr::parseDelta(tr::lines(deltaRecord("QCL"), true), "QCL", dp);
        tr::parseOf(L(basFile()), of[0]); tr::parseOf(L(pullFile()), of[1]); tr::parseOf(L(stackFile()), of[2]);
        tr::parseLiqZones(L(liqZones(1791900000)), liq); tr::parseLiqStatus(L(liqStatus("CLX6")), liq);
        tr::parseHodLod(L(hodlod()), hl); tu = tr::parseTurns(true, L(turns()), "CL");
        long long at; tr::parseKeyLevels(L(keyLevels(1791900000)), at, key); bool st; std::string sym; tr::parseMqLevels(L(mqLevels()), mq, st, sym); tr::parseTouch(L(touch()), tp);
        in.mkt = "CL"; in.root = "QCL"; in.tick = TICK; in.spb = 180; in.B = &B; in.k = 49;
        in.dp = &dp; in.of[0] = &of[0]; in.of[1] = &of[1]; in.of[2] = &of[2]; in.liq = &liq; in.hl = &hl; in.turns = &tu;
        in.levels = tr::mergeLevels(key, mq, tp, TICK); in.mqRaw = mq;
        in.gnodes = { {92.90, 12.6}, {93.50, -3.6}, {94.00, 9.1} };
        in.trend = -1; in.trendReady = true; in.rthOpen = 8 * 60; in.rthClose = 13 * 60 + 30;
    }
};

} // namespace scen
#endif
