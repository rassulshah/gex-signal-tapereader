// test_tr_ofcompat.cpp -- lsTapeReader 1.0.0 reads the order-flow session records exactly as OrderFlowFeed.h 1.0.0 writes them
// (BidAskStats 1.3.0 with its bid|ask|bbid|bask columns, PullStats / StackStats 1.0.0): rows made by the REAL off::rowLine and parsed
// back with off::parseRow (their own reader) and tr::parseOf (ours). Built against -I<of131/out> (1.0.1: refill / iceberg letter I).
#include "OrderFlowFeed.h"
#include "../TapeReaderLogic.h"
#include "StackStatsLogic.h"
#include <cstdio>
#include <string>

static int g_pass = 0, g_fail = 0;
#define CHECK(c, m) do { if (c) ++g_pass; else { ++g_fail; std::printf("FAIL %s:%d  %s\n", __FILE__, __LINE__, std::string(m).c_str()); } } while (0)

int main() {
    CHECK(std::string(st::ONE_ORDER_TAIL) == tr::STACK_ONE_ORDER, "(6:40 PM) the Tape Reader keys on the same one-order words StackStats writes");
    for (int kind = 0; kind < 2; ++kind) {
        const bool bas = kind == 0; const size_t nNums = (bas ? 4 : 0) + (size_t)off::REC_NUMS;
        const std::string head = std::string("# x 1.3.0 CL CLX6 180\nbar_time|ct_time|dbo|") + (bas ? "bid|ask|bbid|bask|" : "") + off::REC_COLS +
                                 "|letters_left|letters_right|spike_left|spike_right|dash_left|dash_right|implication|level|message|numbers\n";
        off::Row r; r.t = 1791887040; r.ct = "10:24"; r.dbo = 1;
        off::Rec rec; rec.sweepLv[0] = 4; rec.aggrMax[0] = 120; rec.pullMax[1] = 80; rec.refN[0] = 44; rec.ice[0] = 2;
        if (bas) { r.nums.push_back(240); r.nums.push_back(78); r.nums.push_back(23); r.nums.push_back(4); }
        off::recNums(rec, r.nums);
        r.let[0] = "SL"; r.let[1] = "I"; r.spike[0] = 1; r.dash[0] = 12; r.impl = off::BULL; r.level = "LonLO";
        r.line1 = "Sellers swept 4 levels with one 120-lot into LonLO - price held: buyers absorbing"; r.line2 = "BBid 240  BidRatio 4.1x   |   BAsk 78  AskRatio 1.0x";
        const std::string ln = off::rowLine(r);
        off::Row back; CHECK(off::parseRow(ln, nNums, back), "their own reader accepts the row");
        tr::OfSnap S; tr::parseOf(tr::lines(head + ln + "\n", false), S);
        CHECK(S.header && S.rows.size() == 1 && S.rejected == 0, std::string(bas ? "BidAskStats" : "Pull/Stack") + ": tr::parseOf reads the real row");
        if (S.rows.size() != 1) continue;
        const tr::OfRow& o = S.rows.begin()->second;
        CHECK(o.t == 1791887040ULL && o.let[0] == "SL" && o.let[1] == "I" && o.spike[0] == 1 && o.spike[1] == 0 && o.impl == tr::BULL && o.level == "LonLO", "letters / spikes / implication / level");
        CHECK(tr::num(o, "sweep_lv_b") == 4 && tr::num(o, "aggr_max_b") == 120 && tr::num(o, "pull_max_a") == 80 && tr::num(o, "refill_n_b") == 44 && tr::num(o, "iceberg_b") == 2, "named numbers by the header");
        CHECK(!bas || tr::num(o, "bbid") == 23, "BidAskStats extra columns by name");
        CHECK(o.msg == r.line1 && tr::ratioAfter(o.nums, "BidRatio ") == 4.1, "message + numbers line ('|' cleaned by rowLine)");
    }
    std::printf("tr of-compat: %d passed, %d failed\n", g_pass, g_fail);
    return g_fail ? 1 : 0;
}
