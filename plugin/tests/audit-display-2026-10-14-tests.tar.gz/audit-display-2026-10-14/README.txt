Audit display list (Rassul approved 18:25 CT 2026-10-14) - the test changes that live outside plugin\ (the plugin-level tests were committed
next to the sources: test_dealerread_460/470, test_dealersig_regression (+ test_dealersig_mock\irtsdk.h records drawn text), test_cobimpulse_031 /
_host / _gamma_host, test_dealerprofile_2110 / _290 / _2120, test_columnboard_logic, test_trademanager_130, test_exhaustion_host, tests_cvd\test_cvd_host).
  trtests_of\                Tape Reader 1.2.0 suite (logic = restore path with -DLRA_SHOW_TAPE_BIAS=1 -DLRA_SHOW_TURN_ODDS=1; test_tr_gates + the new
                             test_tr_audit120 = the default build): sh trtests_of/run_tests.sh   (SDK=<real irtsdk.h dir>)
  test_audit_display_contract.py   every plugin's version + every changed label / hidden element, from the sources: python -I <it> <plugin dir>
  test_settings_contract.py  the 10-14 settings contract with the DealerSig 1.7.0 / DealerRead 4.7.0 versions and parameter version 14
  hodlod_tests\              HodLod 2.2.0 changes to the harness tests (t_hl210 version, t_proj110 / t_proj112 "Proj HOD? ", lifecycle "%, in test)")
  tools\mingw.sh             real-SDK syntax check (windows.h first; NOWIN=1 for HodLod, which declares GetCursorPos itself)
Results 2026-10-14 night: see the session report (all suites pass; pre-existing failures listed there are unchanged from the base).
