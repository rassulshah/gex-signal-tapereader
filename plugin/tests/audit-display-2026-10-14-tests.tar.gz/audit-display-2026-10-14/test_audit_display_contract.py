"""test_audit_display_contract.py -- the external-audit display list Rassul approved 2026-10-14 18:25 CT (APPROVAL-LIST-2026-10-14.md),
checked against the plugin SOURCES: every version bumped consistently (constant = setVersion literal = header), every changed label in
its new form and the old form gone, every hidden element behind its switch. Run from plugin\\:  python -I tests_settings/test_audit_display_contract.py ."""
import re, sys, os
D = sys.argv[1] if len(sys.argv) > 1 else "."
src = lambda f: open(os.path.join(D, f), encoding="latin-1").read()
def code(s):   # the source without // comments (the old wording is quoted in the version notes)
    return "\n".join(re.sub(r'\s*//(?!/).*$', '', l) if '"' not in l.split('//')[0][-1:] else l.split(' //')[0] for l in s.split("\n"))
def lit(s, pat):
    m = re.search(pat, s); return m.group(1) if m else None
checks = {}
dr, ds, tr, trl, trt, ci, cil = src("DealerRead.cpp"), src("DealerSig.cpp"), src("TapeReader.cpp"), src("TapeReaderLogic.h"), src("TapeReaderText.h"), src("CobImpulse.cpp"), src("CobImpulseLogic.h")
dp, dcl, hl, hll, tm, tgl = src("DealerProfile.cpp"), src("DealerColumnsLogic.h"), src("HodLod.cpp"), src("HodLodLogic.h"), src("TradeManager.cpp"), src("TradeGuardLayout.h")
ex, exl, ex2, cvd, tfm, kt, cg, drg = src("Exhaustion.cpp"), src("ExhaustionLogic.h"), src("ExhaustionV2.cpp"), src("CVD.cpp"), src("TapeFlowMarks.cpp"), src("KingTracker.cpp"), src("ClaimGates.h"), src("DealerReadGates.h")
# versions
checks["DealerRead 4.7.0 (setVersion = status)"] = lit(dr, r'setVersion\("([\d.]+)"\)') == lit(dr, r'"VERSION,([\d.]+)') == "4.7.0"
checks["DealerSig 1.7.0"] = lit(ds, r'DS_VERSION = "([\d.]+)"') == lit(ds, r'setVersion\("([\d.]+)"\)') == "1.7.0"
checks["TapeReader 1.2.0"] = lit(tr, r'#define TR_VERSION "([\d.]+)"') == lit(tr, r'setVersion\("([\d.]+)"\)') == lit(trl, r'VERSION = "([\d.]+)"') == "1.2.0"
checks["CobImpulse 0.3.1"] = lit(ci, r'#define CI_VERSION "([\d.]+)"') == lit(ci, r'setVersion\("([\d.]+)"\)') == lit(cil, r'VERSION = "([\d.]+)"') == "0.3.1"
checks["DealerProfile 2.12.0"] = lit(dp, r'DP_VERSION = "([\d.]+)"') == lit(dp, r'setVersion\("([\d.]+)"\)') == "2.12.0"
checks["HodLod 2.2.0"] = lit(hl, r'setVersion\("([\d.]+)"\)') == lit(hll, r'HL_VERSION = "([\d.]+)"') == "2.2.0"
checks["TradeManager 1.3.0"] = lit(tm, r'TM_VERSION = "([\d.]+)"') == lit(tm, r'setVersion\("([\d.]+)"\)') == "1.3.0"
checks["Exhaustion 0.2.3"] = lit(ex, r'#define EX_VERSION "([\d.]+)"') == lit(ex, r'setVersion\("([\d.]+)"\)') == lit(exl, r'VERSION = "([\d.]+)"') == "0.2.3"
checks["ExhaustionV2 2.0.2"] = lit(ex2, r'#define EX2_VERSION "([\d.]+)"') == lit(ex2, r'setVersion\("([\d.]+)"\)') == "2.0.2"
checks["CVD 1.2.0"] = lit(cvd, r'#define CVD_VERSION "([\d.]+)"') == lit(cvd, r'setVersion\("([\d.]+)"\)') == "1.2.0"
checks["TapeFlowMarks 1.2.0"] = lit(tfm, r'TFM_VERSION = "([\d.]+)"') == "1.2.0" and "setVersion(TFM_VERSION)" in tfm
checks["KingTracker 0.17"] = lit(kt, r'setVersion\("([\d.]+)"\)') == "0.17"
# the gates (0 = hidden by default)
for g in ("CONTROL_WORD", "ANALYST", "TAPE_BIAS", "TURN_ODDS", "READ_EXIT"):
    checks[f"ClaimGates LRA_SHOW_{g} defaults to 0"] = f"#define LRA_SHOW_{g} 0" in cg
# labels: before -> after
checks["Dealer Read: control word stripped, Analyst cleared, FUTURES chips ?"] = "stripControl(D.turnHead)" in drg and "D.aMag.clear()" in drg and "markQ(D.trows[i].tag)" in drg
checks["Dealer Sig: footprint code + '?'"] = 't += "?"' in ds and "dsVisible" in ds
checks["Tape Reader: no 'support leaving' / 'Defending' / 'exhausted' / 'LQ'"] = all(k not in code(trt) for k in ('" - support leaving"', '"Defending {lvl}: "', ') - exhausted"', '"{side} LQ {bx}x{on}"'))
checks["Tape Reader: 'Added at', 're-added after hits', 'reloading?', 'iceberg?', 'x normal'"] = all(k in trt for k in ('"Added at {lvl}: "', 're-added after hits', 'reloading? (I {rx})', ', iceberg?', '{bx}x normal{on} ?'))
checks["CobImpulse: no 'gamma driver' / 'is a gamma level behind'"] = "gamma driver" not in code(cil) and "is a gamma level behind" not in code(cil) and "MenthorQ level near the CoB start" in cil
checks["Dealer Profile: HL? / reach only / locked trigger / model not forecast"] = all(k in dcl for k in ('"HL? " + k', "A chance to REACH only", "wait for your trigger - a sweep through the exact level, then RB or CoB, before 11:00 AM CT", "Not a prediction it holds."))
checks["Dealer Profile: no 'defending it as support' / 'is the turn'"] = "defending it as support" not in dcl and "at the level is the turn" not in dcl
checks["HOD/LOD: Regime ?, IN?, in test, Proj HOD?"] = all(k in hll for k in ("Regime ?: below HVL (model)", '" IN?"', ", in test)", '"Proj HOD? "', '"HOD?" : "LOD?"'))
checks["Trade Manager: READY from the checklist, no HOLD / EXIT? by default"] = "tgl::readyFromChecklist(ri)" in tm and "if (cgate::kShowReadExit)" in tm and "CUTOFF_MIN = 11 * 60" in tgl
checks["Exhaustion: 'E?'"] = '"E?"' in ex and '"E", m->second' not in ex
checks["Exhaustion V2: marks hidden"] = "kDrawMarks = false" in ex2
checks["CVD: Div? / Exh? / BR?"] = 'label += "?"' in cvd
checks["TapeFlowMarks: always A?"] = 'const char* label = "A?";' in tfm and '? "A?" : "A"' not in tfm
checks["KingTracker: title King ? (vendor)"] = 'setDescription("King ? (vendor):' in kt
fail = [k for k, v in checks.items() if not v]
for k, v in checks.items(): print(("ok   " if v else "FAIL ") + k)
print(f"audit display contract: {len(checks) - len(fail)} passed, {len(fail)} failed")
sys.exit(1 if fail else 0)
