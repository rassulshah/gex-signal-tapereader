#!/bin/sh
# usage: mingw.sh <plugin dir> <Name.cpp>  - syntax check against the REAL irtsdk.h (windows.h first)
D=$1; F=$2; SDK=/home/claude/aud26/sdk; W=/tmp/claude-0/-home-claude/62b1afce-8372-5fe7-a188-ef315fa0ebcd/scratchpad/mw/w_$$_$(basename $F .cpp).cpp
WINH='#include <windows.h>\n'; [ -n "$NOWIN" ] && WINH='#include <cstddef>\n#include <cstdio>\n#include <cstdlib>\n#include <cstring>\n#include <cmath>\n#include <ctime>\n#include <string>\n#include <vector>\n#include <map>\n#include <sys/stat.h>\n'
printf "#ifndef NOMINMAX\n#define NOMINMAX\n#endif\n$WINH"'#pragma push_macro("__GNUC__")\n#undef __GNUC__\n#include "irtsdk.h"\n#pragma pop_macro("__GNUC__")\n#include "%s"\n' "$F" > $W
x86_64-w64-mingw32-g++ -std=c++17 -fsyntax-only -Wall -Wextra -I"$SDK" -I"$D" $W 2>/tmp/claude-0/mingw_$$.log
E=$(grep -c ' error' /tmp/claude-0/mingw_$$.log); Wn=$(grep 'warning' /tmp/claude-0/mingw_$$.log | grep -vc "$SDK")
echo "$F: MinGW real-SDK syntax: $E errors, $Wn warnings outside the SDK"; [ "$E" = 0 ] || grep ' error' /tmp/claude-0/mingw_$$.log | head -10
[ "$Wn" = 0 ] || grep warning /tmp/claude-0/mingw_$$.log | grep -v "$SDK" | head -10
rm -f $W /tmp/claude-0/mingw_$$.log
