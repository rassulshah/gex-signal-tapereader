#!/bin/sh
# usage: hlsuite.sh <plugin tree> <out dir>   (the HodLod harness, from /home/claude/aud/layout/b/hlw, on a given plugin tree)
P=$1; O=$2; H=/home/claude/aud26/hlw; mkdir -p $O; rm -rf $H/src/*; 
for f in BoxPlace.h DealerLogic.h DealerRead_test_linux_sdk_compat.h FirstExtremeLogic.h FirstExtremeView.h HodLod.cpp HodLodEvents.h HodLodExpected.h HodLodExpectedV2.h HodLodFx.h HodLodGex.h HodLodLogic.h HodLodMedians.h HodLodReadTables.h HostSlot.h OnTouchLogic.h OnTouchParams.h SessionInfo.cpp SessionInfoLayout.h SessionVWAPLogic.h TapeReaderLogic.h TapeReaderText.h VwapTrendLogic.h first_extreme_inference.cpp first_extreme_state.hpp ClaimGates.h OptionsFlow.h NearLevels.h HoverBoard.h BannerBoard.h; do [ -f $P/$f ] && cp $P/$f $H/src/; done
cd $H/tests; rm -f ../out/t_*
F="-pipe -std=c++14 -Wall -Wextra -g -O1 -fsanitize=address,undefined -fno-sanitize-recover=undefined"
g++ $F -I../src test_hodlod_logic.cpp -o ../out/t_logic 2>$O/cc_logic.txt || echo "COMPILE FAIL logic"
g++ $F -I mock_sdk -I ../src test_hodlod_lifecycle_mock.cpp -o ../out/t_life 2>$O/cc_life.txt || echo "COMPILE FAIL life"
cd ..
./out/t_logic data out > $O/logic.txt 2>&1; ./out/t_life data out > $O/life.txt 2>&1
cd tests
for t in t_hl206 t_hl210 t_draw101 t_proj110 t_proj112 t_proj115 t_proj116 t_fx200 t_fc118 t_proj204 $EXTRA; do [ -f $t.cpp ] || continue; g++ $F -I mock_sdk -I../src $t.cpp -o ../out/$t 2>$O/cc_$t.txt || echo "COMPILE FAIL $t"; ../out/$t ../data ../out > $O/$t.txt 2>&1; rm -f ../out/$t; done
rm -f ../out/t_logic ../out/t_life
cd $O; for f in *.txt; do case $f in cc_*) continue;; esac; grep -h "FAIL" $f | sed 's/(line [0-9]*)//' > ${f%.txt}.fails; printf "%-12s %s | %s\n" ${f%.txt} "$(grep -c FAIL $f)" "$(tail -1 $f | cut -c1-90)"; done
