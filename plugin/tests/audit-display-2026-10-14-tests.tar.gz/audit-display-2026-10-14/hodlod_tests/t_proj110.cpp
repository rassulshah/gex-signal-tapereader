// HL 1.1.0: the projection line + flag + "Proj HOD" text, the target after Range in the header, PROJ in the status file
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <unistd.h>
#include "HodLod.cpp"
static int fails = 0, passes = 0;
#define CHECK(c, m) do { if (c) ++passes; else { ++fails; std::printf("FAIL %s (line %d)\n", std::string(m).c_str(), __LINE__); } } while (0)
static void loadInto(mock::Chart& C, const std::string& path, const std::string& root, float tick, double lo, double hi, const char* upto = nullptr)
{
    C.root = root; C.tick = tick; C.lo = lo; C.hi = hi;
    std::ifstream f(path.c_str()); std::string ln;
    while (std::getline(f, ln)) { if (upto && ln.compare(0, 16, upto) > 0) break; int Y, M, D, h, m, s; double o, H, L, c;
        if (std::sscanf(ln.c_str(), "%d-%d-%d %d:%d:%d,%lf,%lf,%lf,%lf", &Y, &M, &D, &h, &m, &s, &o, &H, &L, &c) < 10) continue;
        C.t.push_back((RTDATE)(hl::daysFromCivil(Y, M, D) * 86400 + h * 3600 + m * 60 + s)); C.o.push_back((float)o); C.h.push_back((float)H); C.l.push_back((float)L); C.c.push_back((float)c); }
}
static std::string slurp(const std::string& p) { std::ifstream f(p.c_str()); std::stringstream s; s << f.rdbuf(); return s.str(); }
static std::string line(const std::string& st, const std::string& k) { size_t p = st.find("\n" + k + ","); if (p == std::string::npos) return ""; size_t e = st.find('\n', p + 1); return st.substr(p + 1, e - p - 1); }
int main() {
    char tmpl[] = "/tmp/hlpjXXXXXX"; std::string prof = mkdtemp(tmpl); setenv("USERPROFILE", prof.c_str(), 1);
    {   // the whole Friday: LOD first (8:51 7,826.75) -> Proj HOD at or above the HOD, green line + flag + text
        HodLod x; x.setup();
        mock::Chart A; loadInto(A, "../data/es_long.csv", "EPZ26", 0.25f, 7790, 7890); mock::cur() = &A; x.draw();
        std::string st = slurp(x.flexPath("HodLod.status-ES-180.txt"));
        std::string pj = line(st, "PROJ");
        std::printf("  %s\n  %s\n", pj.c_str(), line(st, "READ").c_str());
        CHECK(pj.compare(0, 9, "PROJ,HOD,") == 0 && pj.find(",from,7,826.75") != std::string::npos && pj.find(",drawn") != std::string::npos, "PROJ HOD from the LOD, drawn: " + pj);
        double tgt = std::atof(pj.substr(9).c_str()) * 1000 + std::atof(pj.substr(pj.find(',', 9) - 6).c_str());
        (void)tgt;
        HLState* S = (HLState*)A.userData;
        CHECK(S && S->view.projUp && S->view.projTo == 31466, "(1.1.6) the target stays where it was set at 9:51 (7,866.50) even after price passed it: " + std::to_string(S ? S->view.projTo : 0));
        CHECK(S && S->view.headLeftTxt.find("Range ") != std::string::npos && S->view.headLeftTxt.find("Proj HOD? ") > S->view.headLeftTxt.find("Range "), "header: the target after Range: " + (S ? S->view.headLeftTxt : std::string()));
        bool flagText = false, vline = false, green = true;
        for (size_t i = 0; i < A.drawn.size(); i++) { const mock::Drawn& d = A.drawn[i];
            if (d.kind == 1 && d.s.compare(0, 10, "Proj HOD? ") == 0) flagText = true; }
        CHECK(flagText, "the flag text is drawn");
        (void)vline; (void)green;
        CHECK(S && S->projIdx >= 0 && S->projIdx < (long)A.t.size(), "the 1st extreme's bar is found on the chart");
        if (S && S->projIdx >= 0) { struct tm t; RTDATE e = A.t[(size_t)S->projIdx]; long long d = e / 86400; (void)t;
            int mod = (int)((e - d * 86400) / 60); CHECK(mod == 8 * 60 + 51, "the line sits on the 8:51 bar (got " + std::to_string(mod) + ")"); }
        x.destroy();
    }
    {   // mid-morning (10:00): the target moves with the expected range but stays above the running high
        HodLod x; x.setup();
        mock::Chart A; loadInto(A, "../data/es_long.csv", "EPZ26", 0.25f, 7790, 7890, "2026-10-09 10:03"); mock::cur() = &A; x.draw();
        HLState* S = (HLState*)A.userData;
        std::printf("  10:00 view: %s | %s\n", S ? S->view.headLeftTxt.c_str() : "?", S ? S->view.projTxt.c_str() : "?");
        CHECK(S && S->view.projOk && S->view.projTo > S->view.hod, "10:00: projected HOD above the running high");
        x.destroy();
    }
    for (const char* t : { "2026-10-09 08:57", "2026-10-09 09:00", "2026-10-09 09:03" }) {   // the projection waits 30 minutes after the open
        HodLod x; x.setup();
        mock::Chart A; loadInto(A, "../data/es_long.csv", "EPZ26", 0.25f, 7790, 7890, t); mock::cur() = &A; x.draw();
        HLState* S = (HLState*)A.userData;
        // the last CLOSED bar is the one before the forming bar: 08:57 loaded -> 08:54 closed (24 min), 09:03 -> 09:00 (30 min)
        bool want = std::string(t) == "2026-10-09 09:03";
        CHECK(S && S->view.projOk == want && (S->view.headLeftTxt.find("Proj") != std::string::npos) == want,
              std::string(t) + ": projection " + (want ? "shown" : "not yet") + " | " + (S ? S->view.headLeftTxt : std::string()));
        x.destroy();
    }
    std::printf("%d passed, %d failed\n", passes, fails); return fails;
}
