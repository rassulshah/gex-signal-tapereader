// HL 2.1.0 (2026-10-14, the GEX line; Rassul 16:01-16:04 CT) tests:
//  [1] parse: a good file; strict - wrong market / version / torn / oversized / garbled rows; every NODE field
//  [2] pick: flagged only, one strike per zone (the bigger wins), nearest first, at most 3; WAIT / MISMATCH / NaN price = none
//  [3] stale: > 20 min inside MenthorQ hours = "STALE 25m" / "STALE 3h"; paused hours / fresh = ""; the update-hours table
//  [4] layout: the GEX row inside the table under the header, every row still there, nothing overlaps; the table grows to fit;
//      9 positions: inside the pane, under the title row, left of the last bar; Show table off = no row
//  [5] the hover: inside the pane, left of the last bar, never over the table; wraps on a narrow pane; too narrow = none
//  [6] host: the file read natively (stamp, 5 s), the row drawn, GEX / GEX_BOX status lines; mouse over the row -> the detail,
//      the cursor leaving -> closed; file gone -> no row; garbled -> the last good copy; another market's file -> ignored;
//      two charts (ES / NQ) on one DLL never share a line
//  [7] fuzz: 3,000 random / mutated files never crash and never yield a row that breaks the rules
//  [8] parity with the bridge: the real 12:57 PM 10-14 file -> 7750 G8, 7775 G7 (up), 7700 PS (lra.gex_nodes.pick_line)
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <random>
#include <unistd.h>
#include <sys/stat.h>
#define HL_TEST_CURSOR 1
#include "HodLod.cpp"
static int fails = 0, passes = 0;
#define CHECK(c, m) do { if (c) ++passes; else { ++fails; std::printf("FAIL %s (line %d)\n", std::string(m).c_str(), __LINE__); } } while (0)
static std::string slurp(const std::string& p) { std::ifstream f(p.c_str()); std::stringstream s; s << f.rdbuf(); return s.str(); }
static void put(const std::string& p, const std::string& s) { std::ofstream o(p.c_str(), std::ios::binary); o << s; }
static std::string kv(const std::string& st0, const std::string& k) { const std::string st = "\n" + st0; size_t a = st.find("\n" + k + ","); if (a == std::string::npos) return ""; a += k.size() + 2; return st.substr(a, st.find('\n', a) - a); }
static void loadInto(mock::Chart& C, const char* path, const char* root, float tick, double lo, double hi) {
    std::ifstream f(path); std::string ln; C.root = root; C.tick = tick; C.lo = lo; C.hi = hi;
    while (std::getline(f, ln)) { int Y, M, D, h, m, s; double o, H, L, c; if (std::sscanf(ln.c_str(), "%d-%d-%d %d:%d:%d,%lf,%lf,%lf,%lf", &Y, &M, &D, &h, &m, &s, &o, &H, &L, &c) < 10) continue;
        C.t.push_back((RTDATE)(hl::daysFromCivil(Y, M, D) * 86400 + h * 3600 + m * 60 + s)); C.o.push_back((float)o); C.h.push_back((float)H); C.l.push_back((float)L); C.c.push_back((float)c); }
}
static void chartCopy() { for (int i = 0; i < 16; i++) { mock::bools()[(size_t)i] = 0; mock::lists()[(size_t)i] = 0; mock::ints()[(size_t)i] = 0; } mock::period() = "3 min"; }
static int measure(const std::string& s, int fs, bool bold) { double w = 0; for (size_t i = 0; i < s.size(); i++) w += (bold ? ADV_BOLD : ADV_REG)[(unsigned char)s[i]]; return (int)(w * fs * 96.0 / 72.0 / 1000.0 + 0.999); }
static bool box4(const std::string& v, hl::Box& b) { return std::sscanf(v.c_str(), "%d,%d,%d,%d", &b.l, &b.t, &b.r, &b.b) == 4; }
static bool inside(const hl::Box& a, const hl::Box& o) { return a.l >= o.l && a.r <= o.r && a.t >= o.t && a.b <= o.b; }

// a v2 file like the bridge writes (asof = unix s)
static std::string gexFile(const std::string& mkt, long long asof, const std::string& state, const std::vector<std::string>& rows,
                           const std::string& basis = "BASIS|VERIFIED|0|0|5|2026-10-14 12:38|same contract", const std::string& side = "down") {
    char b[160]; std::string s = "# LRA GEX nodes - test\nVERSION|2\nMARKET|" + mkt + "\nSESSION|2026-10-14\n";
    snprintf(b, sizeof b, "ASOF|%lld|9:14 AM|09:10\nSTATE|%s|\nPX|7803.75\nVWAP|7820.29|%s\n", asof, state.c_str(), side.c_str()); s += b;
    s += basis + "\nWIDTH|10|20|2.2677|75.59|20d|5\n";
    for (const std::string& r : rows) s += r + "\n";
    return s;
}
// the real 9:14 AM 10-14 line: 7780-7800 F (up) . 7750 F . 7700 F | 7825 M
static std::vector<std::string> esRows() {
    return { "LOC|1|T|7780|7800|F|1|3", "STR|1|7800|7800|14.0|66.81|F|1.76|40|G1|1", "STR|1|7790|7790|8.4|40.08|F|3.68|192|PS/PS0|2", "STR|1|7780|7780|7.3|35.04|F|3.35|166|G6|4",
             "LOC|2|T|7750|7750|F|0|1", "STR|2|7750|7750|5.8|27.64|F|1.56|24|G9|6", "LOC|3|T|7700|7700|F|0|1", "STR|3|7700|7700|7.9|37.90|F|1.42|12|-|3",
             "LOC|4|O|7825|7825|M|0|1", "STR|4|7825|7825|3.2|15.50|M|1.25|-1|-|8" };
}

int main() {
    char tmpl[] = "/tmp/hl21XXXXXX"; std::string prof = mkdtemp(tmpl); setenv("USERPROFILE", prof.c_str(), 1);
    { std::string d = prof + "/InvestorRT"; mkdir(d.c_str(), 0755); d += "/rtx"; mkdir(d.c_str(), 0755); d += "/lsFlexLevels"; mkdir(d.c_str(), 0755); }
    const long long T0 = 1791987245;   // 2026-10-14 9:14 AM CT
    std::printf("[1] parse v2\n");
    {   hlg::File F = hlg::parse(gexFile("ES", T0, "LIVE", esRows()), "ES");
        CHECK(F.ok && F.locs.size() == 4 && F.asof == T0 && F.asofTxt == "9:14 AM" && F.state == "LIVE" && F.side == "down" && std::fabs(F.vwap - 7820.29) < 1e-9 && F.basis == "VERIFIED", "a good file parses (4 locations, ASOF, STATE, VWAP side, BASIS)");
        const hlg::Loc& L = F.locs[0];
        CHECK(L.side == 'T' && L.loTxt == "7780" && L.hiTxt == "7800" && L.sign == 'F' && L.grow && L.mem.size() == 3 && L.mem[1].name == "PS/PS0" && L.mem[1].gOpen == 192 && L.mem[1].rank == 2, "location + its 3 strikes, each separate");
        CHECK(F.locs[3].side == 'O' && F.locs[3].mem[0].gOpen == -1, "the other side's location");
        CHECK(!hlg::parse(gexFile("NQ", T0, "LIVE", esRows()), "ES").ok, "another market's file: refused");
        std::string v1 = gexFile("ES", T0, "LIVE", esRows()); v1.replace(v1.find("VERSION|2"), 9, "VERSION|1");
        CHECK(!hlg::parse(v1, "ES").ok, "a v1 file (the old rule): refused");
        CHECK(!hlg::parse(gexFile("ES", T0, "LIVE", esRows()).substr(0, 40), "ES").ok, "a torn file: refused");
        CHECK(!hlg::parse(std::string(70000, 'x'), "ES").ok, "over 64 KiB: refused");
        std::vector<std::string> bad = esRows(); bad.push_back("LOC|5|X|7600|7600|F|0|1"); bad.push_back("LOC|6|T|abc|7600|F|0|1"); bad.push_back("STR|9|7600|7600|1|1|F|-|-|-|9");
        bad.push_back("STR|1|7810|7810|nan|1|F|-|-|-|9"); bad.push_back("LOC|7|T|7600|7600|F|0|1");   // a location with no strike
        hlg::File B = hlg::parse(gexFile("ES", T0, "LIVE", bad), "ES");
        CHECK(B.ok && B.locs.size() == 4 && B.why.find("5 bad LOC / STR rows") == 0, "garbled rows skipped and counted, a location without strikes dropped: " + B.why);
        std::string crlf = gexFile("ES", T0, "LIVE", esRows()); std::string w; for (char c : crlf) { if (c == '\n') w += '\r'; w += c; }
        CHECK(hlg::parse(w, "ES").ok && hlg::parse(w, "ES").locs.size() == 4, "CRLF line ends");
    }
    std::printf("[2] gates\n");
    {   for (const char* st : { "WAIT", "MISMATCH", "BASIS_UNKNOWN" }) CHECK(!hlg::showable(hlg::parse(gexFile("ES", T0, st, esRows()), "ES")), std::string(st) + ": no row");
        CHECK(!hlg::showable(hlg::parse(gexFile("ES", T0, "LIVE", esRows(), "BASIS|UNKNOWN|-|-|1|-|1 offset measurements"), "ES")), "basis UNKNOWN: no row (unknown is not zero)");
        CHECK(!hlg::showable(hlg::parse(gexFile("ES", T0, "LIVE", esRows(), "# no basis"), "ES")), "no BASIS row: no row");
        CHECK(!hlg::showable(hlg::parse(gexFile("ES", T0, "LIVE", {}), "ES")), "no location: no row");
        for (const char* st : { "LIVE", "STALE", "PAUSED" }) CHECK(hlg::showable(hlg::parse(gexFile("ES", T0, st, esRows()), "ES")), std::string(st) + ": shown");
    }
    std::printf("[3] stale + update hours\n");
    {   hlg::File F = hlg::parse(gexFile("ES", T0, "LIVE", esRows()), "ES");
        CHECK(hlg::staleText(F, T0 + 3 * 60, true).empty(), "3 min old: fresh");
        CHECK(hlg::staleText(F, T0 + 25 * 60, true) == "STALE 25m", "25 min old in MenthorQ hours: STALE 25m");
        CHECK(hlg::staleText(F, T0 + 200 * 60, true) == "STALE 3h", "200 min: STALE 3h");
        CHECK(hlg::staleText(F, T0 + 200 * 60, false).empty(), "MenthorQ paused: never STALE");
        CHECK(hlg::updateHours(3, 12 * 60) && !hlg::updateHours(3, 17 * 60) && hlg::updateHours(3, 21 * 60 + 40) && !hlg::updateHours(6, 12 * 60) && hlg::updateHours(0, 21 * 60 + 41) && !hlg::updateHours(5, 16 * 60 + 1), "update-hours table");
    }
    std::printf("[4] layout\n");
    {   hl::View v; v.has = true; v.headLeftSegs.push_back(hl::Seg{ "ES RTH 8:30-3:00", hl::C_SLATE });
        v.sessSegs.push_back(hl::Seg{ "Regime: Negative", hl::C_RED }); v.sessSegs.push_back(hl::Seg{ "Expiry 3:00 PM (in 5h 46m)", hl::C_GREY });
        hl::View v0 = v;
        hlg::toView(v, hlg::parse(gexFile("ES", T0, "LIVE", esRows()), "ES"), 7803.75, T0 + 120, 3, 555);
        CHECK(v.gexItems.size() == 4 && v.gexItems[0].strike == std::string("7780\x96") + "7800" && v.gexItems[0].grow && v.gexItems[0].name == "F" && v.gexItems[3].other && !v.gexItems[2].other && v.gexStale.empty(), "toView: 4 locations, the range, W/F, the arrow, the other side");
        hl::Box pane = { 0, 0, 1150, 620 }; auto yOf = [](long long) { return 300; };
        int bad = 0, overl = 0;
        for (int pos = 0; pos < 9; pos++) {
            hl::Layout L = hl::layoutAll(v, pane, yOf, measure, 924, pos, -1, nullptr, nullptr);
            hl::Layout L0 = hl::layoutAll(v0, pane, yOf, measure, 924, pos, -1, nullptr, nullptr);
            if (!L.tableOk || !L.gexOk || !inside(L.gexRow, L.table) || L.table.r > 924 || L.table.t < 22 || L.table.b > 620) ++bad;
            if (L.table.b - L.table.t != L0.table.b - L0.table.t + hl::lineH(10) + 1 + 1) ++bad;
            std::vector<hl::Item> tx; for (const hl::Item& it : L.items) if (it.k == hl::K_TEXT && !it.s.empty()) tx.push_back(it);
            for (size_t i = 0; i < tx.size(); i++) for (size_t j = i + 1; j < tx.size(); j++) { const hl::Item& a = tx[i]; const hl::Item& b = tx[j];
                const int ah = (a.t + a.b) / 2, bh = (b.t + b.b) / 2; if (std::abs(ah - bh) < 6 && a.l < b.r - 1 && b.l < a.r - 1) ++overl; }
        }
        CHECK(bad == 0, "9 positions: the GEX row inside the table, one row taller, inside the pane, under the title row, left of the last bar");
        CHECK(overl == 0, "no two texts overlap (" + std::to_string(overl) + ")");
        hl::Opts O; O.table = false; hl::Layout L = hl::layoutAll(v, pane, yOf, measure, 924, 7, -1, nullptr, &O); hl::applyOpts(L, O);
        int gexTxt = 0; for (const hl::Item& it : L.items) if (it.s == "GEX ?") ++gexTxt;
        CHECK(gexTxt == 0 && !L.tableOk, "Show table off: no GEX row");
        L = hl::layoutAll(v, pane, yOf, measure, 924, 7, -1, nullptr, nullptr);
        int q = 0, bar = 0, arrows = 0; for (const hl::Item& it : L.items) { if (it.s == "GEX ?") ++q; if (it.s.find('|') != std::string::npos) ++bar;
            if (it.k == hl::K_LINE && it.t >= L.gexRow.t && it.b <= L.gexRow.b && it.l > L.gexRow.l + 40) ++arrows; }
        CHECK(q == 1 && bar == 1 && arrows == 3, "label 'GEX ?', one '|' before the other side, one arrow (3 lines) for the growing location");
        hl::View vs = v; hlg::toView(vs, hlg::parse(gexFile("ES", T0, "LIVE", esRows()), "ES"), 0, T0 + 25 * 60, 3, 580);
        L = hl::layoutAll(vs, pane, yOf, measure, 924, 7, -1, nullptr, nullptr);
        int dim = 0, stale = 0; for (const hl::Item& it : L.items) { if (it.s == "7750" && it.c1 == hl::C_DIM) ++dim; if (it.s.find("STALE 25m") != std::string::npos) ++stale; }
        CHECK(dim == 1 && stale == 1, "stale: dimmed + STALE 25m");
        bool cp = true; for (const hl::Item& it : L.items) for (unsigned char c : it.s) if (c >= 0x80 && c != 0xB7 && c != 0x96) cp = false;
        CHECK(cp, "only the chart's code page (middle dot, en dash)");
    }
    std::printf("[5] the hover\n");
    {   hl::View v; v.has = true; v.headLeftSegs.push_back(hl::Seg{ "ES RTH 8:30-3:00", hl::C_SLATE });
        hlg::toView(v, hlg::parse(gexFile("ES", T0, "LIVE", esRows()), "ES"), 0, T0 + 120, 3, 555);
        auto yOf = [](long long) { return 300; }; int bad = 0;
        for (int W : { 1150, 800, 520 }) for (int H : { 620, 420 }) for (int pos = 0; pos < 9; pos++) {
            hl::Box pane = { 0, 0, W, H }; const int pe = (int)(W * 0.8);
            hl::Layout L = hl::layoutAll(v, pane, yOf, measure, pe, pos, -1, nullptr, nullptr);
            if (!L.gexOk) continue;
            const size_t h0 = L.items.size();
            hl::layoutGexHover(L, v, pane, pe, measure);
            if (!L.gexHoverOk) continue;
            if (L.gexHover.l < 0 || L.gexHover.r > (pe > 200 ? pe : W) || L.gexHover.t < 0 || L.gexHover.b > H) ++bad;
            {   const int hh = L.gexHover.b - L.gexHover.t, ww = L.gexHover.r - L.gexHover.l, top = 22, fr = pe > 200 ? pe : W;
                const bool room = L.table.t - 4 - hh >= top || L.table.b + 4 + hh <= H - 1 || (hh <= H - 1 - top && (L.table.r + 4 + ww <= fr || L.table.l - 4 - ww >= 2));
                if (hl::overlap(L.gexHover, L.table) && room) ++bad; }
            for (size_t i = h0; i < L.items.size(); i++) { const hl::Item& it = L.items[i]; if (it.k == hl::K_TEXT && (it.r > L.gexHover.r - 4 || it.l < L.gexHover.l || it.t < L.gexHover.t || it.b > L.gexHover.b)) ++bad; }
        }
        CHECK(bad == 0, "hover: inside the pane, left of the last bar, off the table when there is room, wrapped to its box");
        std::string all; for (const hl::Seg& g : v.gexHover) all += g.s + "\n";
        CHECK(all.find("7790 PS/PS0  -  8.4% of the model GEX (rank 2)  \xB7  FUEL ?  \xB7  share +192% since open (growing)  \xB7  abs 3.7x") != std::string::npos,
              "hover: every strike on its own - share, rank, name, W/F, growth as ratios");
        CHECK(all.find("(toward, 3 strikes)") != std::string::npos && all.find("(other side, nearest, 1 strike)") != std::string::npos && all.find("supports below") != std::string::npos, "hover: each location and its side, the direction");
        CHECK(all.find("FUEL ?  net short gamma (model): dealers forced to sell drops") != std::string::npos && all.find("MIXED ?") != std::string::npos && all.find("WALL ?") == std::string::npos, "hover: his dealers-forced wording for the signs present, '?' kept");
        CHECK(all.find("What it answers") != std::string::npos && all.find("How to use it") != std::string::npos && all.find("Example:") != std::string::npos && all.find("ZONE") != std::string::npos, "hover: question / how / example");
        CHECK(all.find("MAP ?") == 0 && all.find("received 9:14 AM CT, 2m old") != std::string::npos, "hover: MAP ?, received time + age");
        std::string lw = all; for (char& c : lw) c = (char)std::tolower((unsigned char)c);
        for (const char* banned : { "defend", "will hold", "proven", "confirm" }) CHECK(lw.find(banned) == std::string::npos, std::string("hover never says '") + banned + "'");
        hl::View v11; hlg::toView(v11, hlg::parse(gexFile("ES", T0, "LIVE", esRows()), "ES"), 0, T0 + 120, 3, 12 * 60);
        std::string w11; for (const hl::Seg& g : v11.gexHover) w11 += g.s; CHECK(w11.find("OBSERVATION ONLY, no new entry after 11:00 CT") != std::string::npos, "after 11:00 CT: OBSERVATION ONLY");
        hl::View vf; hlg::toView(vf, hlg::parse(gexFile("ES", T0 + 3600, "LIVE", esRows()), "ES"), 0, T0, 3, 555);
        CHECK(vf.gexItems.empty(), "a grid 'received' after now: never shown");
    }
    std::printf("[6] host\n");
    {   cppExtension* ce = CreateExtension(); HodLod* hx = static_cast<HodLod*>(ce);
        CHECK(hx->flags & TRACK_MOUSE, "TRACK_MOUSE set"); CHECK(hx->version == "2.2.0" && std::string(hl::HL_VERSION).compare(0, 5, "2.2.0") == 0, "setVersion 2.2.0 == HL_VERSION"); delete ce; }
    {   HodLod x; x.setup(); chartCopy();
        mock::Chart A; loadInto(A, "../data/es_chart.csv", "EPZ26", 0.25f, 7792, 7892); mock::cur() = &A;
        const long long now = (long long)time(nullptr);
        const std::string gp = x.flexPath("LRA-GexNodes-ES.csv");
        put(gp, gexFile("ES", now - 120, "LIVE", esRows()));
        x.draw(); std::string st = slurp(x.flexPath("HodLod.status-ES-180.txt")); hl::Box row, tb;
        CHECK(kv(st, "GEX").find("LIVE,asof 9:14 AM,shown 7780-7800 F up ; 7750 F ; 7700 F ; 7825 M (other),basis VERIFIED,side down") == 0, "status GEX: the line in the bridge's order: " + kv(st, "GEX"));
        CHECK(box4(kv(st, "GEX_BOX"), row) && box4(kv(st, "TABLE_BOX"), tb) && inside(row, tb), "GEX_BOX inside TABLE_BOX");
        CHECK(kv(st, "VERSION").compare(0, 5, "2.2.0") == 0, "status VERSION 2.2.0");
        HLState* S = (HLState*)A.userData;
        RTX_EVENT e; memset(&e, 0, sizeof e); e.type = E_MOUSE_MOVE; e.v.mouse.h = (short)((row.l + row.r) / 2); e.v.mouse.v = (short)((row.t + row.b) / 2);
        hl_test_cx = 500; hl_test_cy = 500; const long long inv0 = x.invalidations;
        CHECK(x.mouse(&e) == RTX_FAIL && S->inGex && x.invalidations == inv0 + 1, "mouse over the row: the detail opens (event not swallowed, chart redrawn)");
        S->lastStatusWrite = 0; x.draw(); st = slurp(x.flexPath("HodLod.status-ES-180.txt"));
        hl::Box hv; const std::string gb = kv(st, "GEX_BOX"); const size_t hp = gb.find("hover ");
        CHECK(hp != std::string::npos && box4(gb.substr(hp + 6), hv) && hv.r <= A.pr && hv.l >= A.pl && hv.t >= A.pt && hv.b <= A.pb && (!hl::overlap(hv, tb) || (hv.b - hv.t) > tb.t - A.pt - 26), "the detail drawn inside the pane: " + gb);
        e.v.mouse.v = (short)(row.t - 2); x.mouse(&e); CHECK(S->inGex, "2 px above the row: still open (dead band)");
        e.v.mouse.h = (short)((hv.l + hv.r) / 2); e.v.mouse.v = (short)((hv.t + hv.b) / 2); x.mouse(&e); CHECK(S->inGex, "on the detail itself: still open");
        hl_test_cx = 900; S->lastStatusWrite = 0; x.draw(); CHECK(!S->inGex, "the cursor left the pane: closed on the next draw");
        e.v.mouse.h = (short)(row.l + 5); e.v.mouse.v = (short)(row.b + 40); x.mouse(&e); CHECK(!S->inGex, "mouse elsewhere: no detail");
        sleep(1); put(gp, "VERSION|2\nMARKET|ES\nASOF|garbage\n"); S->gexChecked = 0; S->lastStatusWrite = 0; x.draw(); st = slurp(x.flexPath("HodLod.status-ES-180.txt"));
        CHECK(kv(st, "GEX").find("shown 7780-7800 F up") != std::string::npos && kv(st, "GEX").find("kept the last good") != std::string::npos, "a garbled write: the last good line kept, reason in the status");
        sleep(1); put(gp, gexFile("NQ", now, "LIVE", esRows())); S->gexChecked = 0; S->lastStatusWrite = 0; x.draw(); st = slurp(x.flexPath("HodLod.status-ES-180.txt"));
        CHECK(kv(st, "GEX").find("kept the last good") != std::string::npos, "an NQ file in the ES name: refused");
        std::remove(gp.c_str()); S->gexChecked = 0; S->lastStatusWrite = 0; x.draw(); st = slurp(x.flexPath("HodLod.status-ES-180.txt"));
        CHECK(kv(st, "GEX").find("none,asof -,shown none") == 0 && kv(st, "GEX_BOX").find("none") == 0, "no file: no row");
        mock::Chart Bq; loadInto(Bq, "../data/nq_chart.csv", "ENQZ26", 0.25f, 31000, 31400); mock::cur() = &Bq;
        x.draw(); std::string sq = slurp(x.flexPath("HodLod.status-NQ-180.txt"));
        CHECK(kv(sq, "GEX").find("none") == 0, "NQ chart, no NQ file: no line (never ES's)");
        put(x.flexPath("LRA-GexNodes-NQ.csv"), gexFile("NQ", now, "LIVE", { "LOC|1|T|31200|31200|F|0|1", "STR|1|31200|31200|20|50|F|1.5|7|G1|1" }));
        put(gp, gexFile("ES", now - 60, "LIVE", esRows()));
        ((HLState*)Bq.userData)->gexChecked = 0; ((HLState*)Bq.userData)->lastStatusWrite = 0; x.draw(); sq = slurp(x.flexPath("HodLod.status-NQ-180.txt"));
        mock::cur() = &A; S->gexChecked = 0; S->lastStatusWrite = 0; x.draw(); st = slurp(x.flexPath("HodLod.status-ES-180.txt"));
        CHECK(kv(sq, "GEX").find("shown 31200 F") != std::string::npos && kv(st, "GEX").find("31200") == std::string::npos && kv(st, "GEX").find("7750") != std::string::npos, "ES and NQ charts keep their own lines");
        x.destroy(); mock::cur() = &Bq; x.destroy(); }
    std::printf("[7] fuzz\n");
    {   std::mt19937 rng(7); int bad = 0; const std::string good = gexFile("ES", T0, "LIVE", esRows());
        for (int i = 0; i < 3000; i++) {
            std::string s = good; const int muts = 1 + (int)(rng() % 6);
            for (int k = 0; k < muts; k++) { size_t at = rng() % s.size(); switch (rng() % 4) { case 0: s[at] = (char)(rng() % 256); break; case 1: s.erase(at, 1 + rng() % 8); break; case 2: s.insert(at, std::string(1 + rng() % 5, "|-.9x\nLOCSTR"[rng() % 13])); break; default: s = s.substr(0, at); } if (s.empty()) s = "x"; }
            hlg::File F = hlg::parse(s, "ES");
            if (!F.ok) continue;
            if (F.locs.size() > (size_t)hlg::MAX_LOCS) ++bad;
            for (const hlg::Loc& L : F.locs) { if (L.mem.empty() || L.mem.size() > (size_t)hlg::MAX_MEMBERS) ++bad; for (const hlg::Mem& m : L.mem) if (m.rank < 1 || !(m.share >= 0 && m.share <= 100) || (m.sign != 'W' && m.sign != 'F' && m.sign != 'M')) ++bad; }
            hl::View v; hlg::toView(v, F, 0, T0, 3, 555); if (v.gexItems.size() > (size_t)hlg::MAX_LOCS) ++bad;
        }
        CHECK(bad == 0, "3,000 mutated files: no crash, no rule-breaking row");
    }
    std::printf("[8] parity with lra.gex_nodes 2.0.0 on the real 10-14 files\n");
    {   const struct { const char* f; const char* want; } C[] = { { "../data/gexv2_0914.csv", "7780-7800 F up ; 7750 F ; 7700 F ; 7825 M (other)" },
                                                                  { "../data/gexv2_1257.csv", "7750 F up ; 7700 F up ; 7775-7780 F up (other)" } };
        for (const auto& c : C) {
            hlg::File F = hlg::parse(slurp(c.f), "ES"); hl::View v; hlg::toView(v, F, 0, F.asof + 120, 3, 600);
            const std::string st = hlg::statusLine(F, v, "");
            CHECK(F.ok && st.find(std::string("shown ") + c.want + ",") != std::string::npos, std::string("the bridge's line == the plugin's: ") + st);
        }
    }
    std::printf("%d passed, %d failed\n", passes, fails);
    return fails;
}
