#!/bin/sh
# (2026-10-14 night) one bar per candle: lsBidAskStats 1.7.0, lsStackStats 1.4.0, lsPullStats 1.6.0, OrderFlowFeed.h 1.6.0 (+ test_onebar).
# Earlier: lsPullStats 1.5.0 (+ test_pullstats_zone_host). Earlier: lsBidAskStats 1.5.3 + lsPullStats 1.2.2 + lsStackStats 1.1.3 (shared OrderFlowFeed.h 1.3.1; CR5300 label persistence; was 1.5.0 / 1.1.0 / 1.1.0 + 1.2.0, OptionsFlow.h 1.0.0, StopRun.h 1.0.0):
# logic + host tests under ASan/UBSan (-Werror), the real-SDK syntax check of all three plugins (MinGW, windows.h before irtsdk.h),
# the Win32 link-library check and the render dumps. (of140) every step FAILS the run (a compile error used to slip through '&&').
D=$(cd "$(dirname "$0")" && pwd); B=${BUILD:-/tmp/of140-build}; mkdir -p "$B"
SAN="-fsanitize=address,undefined -fno-sanitize-recover=undefined"; CXX="g++ -std=c++17 -Wall -Wextra -Werror -g $SAN"
step() { echo "== $1" >&2; shift; "$@" || { echo "FAILED: $*"; [ -n "$KEEPGOING" ] || exit 1; }; }
step "off logic" $CXX -I"$D/.." "$D/test_off_logic.cpp" -o "$B/tol"; step "run" "$B/tol"
step "of140 logic" $CXX -I"$D/.." "$D/test_of140_logic.cpp" -o "$B/t14"; step "run" "$B/t14"
step "fix1 logic" $CXX -I"$D/.." "$D/test_fix1_logic.cpp" -o "$B/tf1"; step "run" "$B/tf1"
step "bas logic" $CXX -I"$D/.." "$D/test_bas_logic.cpp" -o "$B/tbl"; step "run" "$B/tbl"
step "bas host" $CXX -DBAS_TEST_CLOCK -DBAS_DEFAULT_MODE=1 -I"$D/mock" -I"$D/.." "$D/test_bas_host.cpp" -o "$B/tbh"; step "run" "$B/tbh"
step "bas 1.3+ host" $CXX -DBAS_TEST_CLOCK -DBAS_DEFAULT_MODE=1 -DOFF_LARGE_BAR_MIN_DEFAULT=0 -I"$D/mock" -I"$D/.." "$D/test_bas130_host.cpp" -o "$B/t13"; step "run" "$B/t13"
step "panel logic (1.3.0)" $CXX -I"$D/.." "$D/test_panel_logic.cpp" -o "$B/tpl"; step "run" "$B/tpl"
step "panel host PullStats" $CXX -DOFF_TEST_CLOCK -DZREAD_TEST_HOOK -I"$D/mock" -I"$D/.." "$D/test_panel_host.cpp" -o "$B/tphp"; step "run" "$B/tphp"
step "panel host StackStats" $CXX -DOFF_TEST_CLOCK -DSTACK -DZREAD_TEST_HOOK -I"$D/mock" -I"$D/.." "$D/test_panel_host.cpp" -o "$B/tphs"; step "run" "$B/tphs"
step "panel host BidAskStats" $CXX -DBAS_TEST_CLOCK -DBAS -DZREAD_TEST_HOOK -I"$D/mock" -I"$D/.." "$D/test_panel_host.cpp" -o "$B/tphb"; step "run" "$B/tphb"
# (CR5300, OrderFlowFeed 1.3.1) spike labels never lose rows to another spike: logic + fuzz + drawBars, then each pane on the mock host
step "label persist logic" $CXX -I"$D/mock" -I"$D/.." "$D/test_label_persist.cpp" -o "$B/tlpl"; step "run" "$B/tlpl"
step "label persist BidAskStats" $CXX -DBAS -DBAS_TEST_CLOCK -I"$D/mock" -I"$D/.." "$D/test_label_persist.cpp" -o "$B/tlpb"; step "run" "$B/tlpb"
step "label persist PullStats" $CXX -DPULL -DOFF_TEST_CLOCK -I"$D/mock" -I"$D/.." "$D/test_label_persist.cpp" -o "$B/tlpp"; step "run" "$B/tlpp"
step "label persist StackStats" $CXX -DSTACK -DOFF_TEST_CLOCK -I"$D/mock" -I"$D/.." "$D/test_label_persist.cpp" -o "$B/tlps"; step "run" "$B/tlps"
# (OrderFlowFeed 1.6.0 / BidAskStats 1.7.0 / StackStats 1.4.0 / PullStats 1.6.0, Rassul 22:37 CT + 23:00 CT) ONE BAR PER CANDLE: winner / ties,
# colour, bright / dim, the white tick only when both spiked, letters on the single bar (none on StackStats), labels, no overlap, titles
step "one bar logic" $CXX -I"$D/mock" -I"$D/.." "$D/test_onebar.cpp" -o "$B/tob"; step "run" "$B/tob"
step "one bar BidAskStats" $CXX -DBAS -DBAS_TEST_CLOCK -DBAS_DEFAULT_MODE=1 -DSRC_DIR="\"$D/..\"" -I"$D/mock" -I"$D/.." "$D/test_onebar.cpp" -o "$B/tobb"; step "run" "$B/tobb"
step "one bar PullStats" $CXX -DPULL -DOFF_TEST_CLOCK -DSRC_DIR="\"$D/..\"" -I"$D/mock" -I"$D/.." "$D/test_onebar.cpp" -o "$B/tobp"; step "run" "$B/tobp"
step "one bar StackStats" $CXX -DSTACK -DOFF_TEST_CLOCK -DSRC_DIR="\"$D/..\"" -I"$D/mock" -I"$D/.." "$D/test_onebar.cpp" -o "$B/tobs"; step "run" "$B/tobs"
step "pull host" $CXX -DOFF_TEST_CLOCK -I"$D/mock" -I"$D/.." "$D/test_pane_host.cpp" -o "$B/tps"; step "run" "$B/tps"
step "stack host" $CXX -DOFF_TEST_CLOCK -DSTACK -I"$D/mock" -I"$D/.." "$D/test_pane_host.cpp" -o "$B/tss"; step "run" "$B/tss"
# (PullStats 1.5.0, ZoneRead 1.1.0; lsPulling retired 2026-10-14 night) the zone read line end to end through lsPullStats: ported from
# tests_pulling/test_pulling_zone_host.cpp - nothing while approaching / measuring, the locked arrival read, hover, record, restart
# after the lock, restart INSIDE the window
step "pullstats zone host" $CXX -DOFF_TEST_CLOCK -I"$D/mock" -I"$D/.." "$D/test_pullstats_zone_host.cpp" -o "$B/tpz"; step "run" "$B/tpz"; rm -f "$B/tpz"
# (CR5450, OrderFlowFeed 1.4.0 / PullStats 1.3.0 / MboRecord 1.1.0) the 250 ms order-feed clock: loss reproduced on a ring-buffer mock, then none
step "feed clock host" $CXX -DOFF_TEST_CLOCK -I"$D/mock" -I"$D/.." "$D/test_feedclock_host.cpp" -o "$B/tfc"; step "run" "$B/tfc"; rm -f "$B/tfc"
# (PullStats 1.2.0) Record order feed: the recorder alone, then lra.mbo_live's own parser on what it wrote
step "mborecord" $CXX -I"$D/.." "$D/test_mborecord.cpp" -o "$B/tmr"; step "run" "$B/tmr" "$B/mborec"
LRA=${LRA:-/mnt/user-data/uploads/level-reversal-analytics/analytics}
if [ -f "$LRA/lra/mbo_live.py" ]; then rm -rf "$B/pyl"; mkdir -p "$B/pyl/lra"; cp "$LRA/lra/mbo_live.py" "$B/pyl/lra/"; touch "$B/pyl/lra/__init__.py"; step "mbo_live parse" python3 -I "$D/check_mbolive.py" "$B/pyl" "$B/mborec"; else echo "mbo_live parse: SKIPPED (no $LRA/lra/mbo_live.py)"; fi
SDK=${SDK:-/mnt/user-data/uploads/sdk/c++/include}
for N in BidAskStats PullStats StackStats; do
  x86_64-w64-mingw32-g++ -std=c++17 -fsyntax-only -Wall -Wextra -Wno-unknown-pragmas -I"$SDK" -I"$D/.." "$D/wrap_$N.cpp" 2>"$B/syntax-$N.log"
  E=$(grep -c ' error' "$B/syntax-$N.log"); W=$(grep 'warning' "$B/syntax-$N.log" | grep -vc "$SDK")
  echo "syntax $N: $E errors, $W warnings outside the SDK"; [ "$E" = 0 ] && [ "$W" = 0 ] || { cat "$B/syntax-$N.log" | head -30; exit 1; }
done
sh "$D/check_win32_libs.sh" || exit 1
for W in 1 2 3; do C=-DOFF_TEST_CLOCK; [ $W = 1 ] && C=-DBAS_TEST_CLOCK; step "render $W" g++ -std=c++17 -O1 -DWHICH=$W -DZREAD_TEST_HOOK $C -I"$D/mock" -I"$D/.." "$D/render_dump.cpp" -o "$B/rd$W"; done
"$B/rd1" 24 > "$B/d1.tsv" && "$B/rd2" 26 > "$B/d2.tsv" && "$B/rd3" 22 > "$B/d3.tsv" || exit 1
echo "render dumps: $B/d1.tsv $B/d2.tsv $B/d3.tsv"
# (of140 6:18 PM) the panes in Rassul's order BidAskStats, StackStats, PullStats; + the Tape Reader render (trtests) -> render-check-final.png
python3 "$D/render_check.py" "$B/d1.tsv" "$B/d3.tsv" "$B/d2.tsv" "$B/panes.png" || exit 1
TRPNG=${TRPNG:-/tmp/tr-build/render-check-tr.png}
if [ -f "$TRPNG" ]; then python3 "$D/render_final.py" "$TRPNG" "$B/panes.png" "$D/../render-check-final.png" || exit 1; else echo "final render: run trtests/run_tests.sh first (no $TRPNG)"; fi
