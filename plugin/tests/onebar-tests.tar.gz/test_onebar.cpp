// test_onebar.cpp -- ONE BAR PER CANDLE (OrderFlowFeed.h 1.6.0, lsBidAskStats 1.7.0, lsStackStats 1.4.0, lsPullStats 1.6.0;
// Rassul approved 22:37 CT 2026-10-14, mockup-one-bar.png v2; StackStats-only "no letters / no dashes" correction 23:00 CT).
//   -DLOGIC (default)  oneBarOf (winner, ties, colour, bright / dim, the white tick only when BOTH sides spiked), drawBars in one-bar
//                      mode on the mock SDK (one box per candle, colours, the tick, letters on the single bar for the winner, the loser's
//                      only on a both-spiked candle, marks off = no letters / dash, spike label on the winner only), no overlap (fuzz),
//                      a later candle never changes an earlier label (fuzz), the two-bar default unchanged for other users
//   -DBAS / -DPULL / -DSTACK   the plugin on the mock host: the pane title (parmsTitle, version next to it), the close direction
//                      read from the chart for ties, the hover (Numbers box) still shows BOTH sides, BidAskStats "pressing" wording
#if defined(BAS)
#include "BidAskStats.cpp"
typedef BidAskStats Ind;
long long bas_test_now_ms = 1000000; void* bas_test_cursor_wnd = nullptr;
#define NOW bas_test_now_ms
#elif defined(PULL) || defined(STACK)
#if defined(STACK)
#include "StackStats.cpp"
typedef StackStats Ind;
#else
#include "PullStats.cpp"
typedef PullStats Ind;
#endif
namespace off { long long off_test_now_ms = 1000000; void* off_test_cursor_wnd = nullptr; }
#define NOW off::off_test_now_ms
#else
#define LOGIC 1
#include "irtsdk.h"
#define OFF_SDK 1
#include "OrderFlowFeed.h"
#include "BidAskStatsLogic.h"
int cppExtension::init() { return 0; } int cppExtension::setup() { return 0; } int cppExtension::calc(int) { return 0; } int cppExtension::done() { return 0; } int cppExtension::destroy() { return 0; }
#endif
#include <cstdio>
#include <map>
#include <set>
#include <sys/stat.h>
namespace mock { Host* current = nullptr; Feed feed; }
static int fails = 0, passes = 0;
#define CHECK(c, m) do { if (c) ++passes; else { ++fails; std::printf("FAIL %d %s\n", __LINE__, m); } } while (0)

#ifdef LOGIC
struct Pane : cppExtension {};
static const COLOR NRM[2] = { 0x962D2D, 0x1F9D55 }, SPK[2] = { 0xFF3B3B, 0x00FF00 };   // BidAskStats order: 0 = sellers red, 1 = buyers green
static const COLOR WHITE = 0x00FFFFFF;
static bool barCol(COLOR c) { return c == NRM[0] || c == NRM[1] || c == SPK[0] || c == SPK[1]; }
struct Cand { long long v[2] = {0, 0}; bool spk[2] = {false, false}; int dir = 0; std::string let[2]; std::string mark[2]; long long dash[2] = {-1, -1}; };
// draw candles with drawBars; returns the draws
static std::vector<mock::Draw> drawC(mock::Host& h, const std::vector<Cand>& C, int oneBull, bool marks = true, long long top = 0, int v0 = 0, int v1 = -1) {
    Pane pane; const off::PaneGeo g = off::paneGeo(&pane, off::MODE_READ);
    auto xOf = [&](int i) { cppExtension::PNT p; p.set(i, 0.0f); return (int)p.h; };
    auto look = [&](int i) { off::BarLook k; if (i < 0 || i >= (int)C.size()) return k; const Cand& c = C[(size_t)i]; k.ok = true;
        for (int s = 0; s < 2; ++s) { k.v[s] = c.v[s]; k.spike[s] = c.spk[s]; k.let[s] = c.let[s]; k.mark[s] = c.mark[s]; k.markCol[s] = s == 0 ? 0x168A42 : 0xE0242A; k.dash[s] = c.dash[s];
            if (c.spk[s]) { k.ratioOk[s] = true; k.ratio[s] = 2.5 + s; k.p100[s] = 150; } }
        k.dir = c.dir; return k; };
    if (top <= 0) for (auto& c : C) top = std::max(top, std::max(c.v[0], c.v[1]));
    h.draws.clear();
    off::drawBars(&pane, g, v0, v1 < 0 ? (int)C.size() - 1 : v1, h.barW, top, -1, NRM, SPK, xOf, look, std::vector<off::LBox>(), oneBull, marks);
    return h.draws;
}
static std::vector<const mock::Draw*> boxesNear(const std::vector<mock::Draw>& D, int xc, int half, bool (*pred)(COLOR)) {
    std::vector<const mock::Draw*> v; for (auto& d : D) if (d.type == "box" && pred(d.color) && d.x >= xc - half && d.r <= xc + half) v.push_back(&d); return v; }
static bool isWhite(COLOR c) { return c == WHITE; }
static int cx(mock::Host& h, int i) { return 50 + i * h.barW; }
static std::vector<std::string> textsNear(const std::vector<mock::Draw>& D, int xc, int half, COLOR c) {
    std::vector<std::string> v; for (auto& d : D) if (d.type == "text" && d.color == c && std::abs((d.x + d.r) / 2 - xc) <= half) v.push_back(d.text); return v; }
static bool rectHit(int l1, int t1, int r1, int b1, int l2, int t2, int r2, int b2) { return !(r1 < l2 || r2 < l1 || b1 < t2 || b2 < t1); }

int main() {
    // 1) winner selection and ties (BidAskStats buyers = side 1; Stack / Pull buyers = side 0)
    {
        long long a[2] = { 50, 70 }, b[2] = { 70, 50 }, t[2] = { 40, 40 }, z[2] = { 0, 0 }, one[2] = { 0, 5 };
        CHECK(off::oneBarWinner(a, 0, 1) == 1 && off::oneBarWinner(b, 0, 1) == 0 && off::oneBarWinner(a, -1, 0) == 1 && off::oneBarWinner(b, 1, 0) == 0, "the bigger side wins whatever the close direction");
        CHECK(off::oneBarWinner(t, 1, 1) == 1 && off::oneBarWinner(t, -1, 1) == 0 && off::oneBarWinner(t, 0, 1) == 0, "BidAskStats tie: up close = buyers (1), down close = sellers (0), flat = red (0)");
        CHECK(off::oneBarWinner(t, 1, 0) == 0 && off::oneBarWinner(t, -1, 0) == 1 && off::oneBarWinner(t, 0, 0) == 1, "Stack / Pull tie: up close = bids (0, green), down = offers (1, red), flat = red (1)");
        CHECK(off::oneBarWinner(z, 1, 1) == -1 && off::oneBarWinner(one, -1, 0) == 1, "no lots on either side = no bar; one side only = that side");
        bool sp[2] = { true, false };
        off::OneBar o = off::oneBarOf(a, sp, 0, 1);
        CHECK(o.side == 1 && o.v == 70 && o.other == 50 && !o.bright && !o.tick, "loser spiked, winner normal: dim, no tick (not a two-sided fight)");
        bool sp2[2] = { false, true }; o = off::oneBarOf(a, sp2, 0, 1);
        CHECK(o.bright && !o.tick, "winner spiked alone: bright, no tick");
        bool sp3[2] = { true, true }; o = off::oneBarOf(a, sp3, 0, 1);
        CHECK(o.bright && o.tick && o.other == 50, "both spiked: bright + tick at the smaller side's 50 lots");
        bool sp0[2] = { false, false }; o = off::oneBarOf(a, sp0, 0, 1);
        CHECK(!o.bright && !o.tick, "normal candle: dim, no tick");
    }
    mock::Host h; mock::current = &h; h.paneTop = 0; h.paneBottom = 200; h.paneLeft = 0; h.paneRight = 1300; h.scaleLeft = 1300; h.barW = 22; h.ppb = 22;
    for (int i = 0; i < 60; ++i) { mock::Bar b; b.time = 1791900000UL + 180UL * i; h.bars.push_back(b); }
    // 2) colour, bright vs dim, one box per candle, height = the winner's lots
    {
        std::vector<Cand> C(6);
        C[0].v[0] = 30; C[0].v[1] = 20;                                   // sellers win, normal
        C[1].v[0] = 20; C[1].v[1] = 30;                                   // buyers win, normal
        C[2].v[0] = 100; C[2].v[1] = 20; C[2].spk[0] = true;              // seller spike
        C[3].v[0] = 20; C[3].v[1] = 100; C[3].spk[1] = true;              // buyer spike
        C[4].v[0] = 25; C[4].v[1] = 25; C[4].dir = 1;                     // tie, up close
        C[5].v[0] = 25; C[5].v[1] = 25; C[5].dir = 0;                     // tie, flat
        const auto D = drawC(h, C, 1);
        int perCandle[6] = {0}; COLOR col[6] = {0}; int ht[6] = {0};
        for (int i = 0; i < 6; ++i) for (auto* d : boxesNear(D, cx(h, i), 11, barCol)) { ++perCandle[i]; col[i] = d->color; ht[i] = d->b - d->y; }
        bool one = true; for (int i = 0; i < 6; ++i) if (perCandle[i] != 1) one = false;
        CHECK(one, "exactly one bar per candle");
        CHECK(col[0] == NRM[0] && col[1] == NRM[1] && col[2] == SPK[0] && col[3] == SPK[1], "colour = the bigger side (red sellers / green buyers); bright only for a spike, dim otherwise");
        CHECK(col[4] == NRM[1] && col[5] == NRM[0], "ties: up close -> buyers' green, flat -> red");
        Pane pane; const off::PaneGeo g = off::paneGeo(&pane, off::MODE_READ);
        CHECK(ht[2] == off::barHeight(100, 100, g.px) && ht[0] == off::barHeight(30, 100, g.px) && ht[1] == off::barHeight(30, 100, g.px), "height = the winner's lots on the pane's scale");
        const auto* b2 = boxesNear(D, cx(h, 2), 11, barCol)[0];
        int l = 0, r = 0; off::oneBarSpan(cx(h, 2), h.barW, l, r);
        CHECK(b2->x == l && b2->r == r && r - l + 1 >= (h.barW * 8) / 10 - 1, "the single bar spans the slot's inner 80% (both old bars' room)");
        CHECK(boxesNear(D, cx(h, 0), 11, isWhite).empty() && boxesNear(D, cx(h, 2), 11, isWhite).empty() && boxesNear(D, cx(h, 3), 11, isWhite).empty(), "no white tick on normal or one-sided spike candles");
        bool flat = true; for (auto& d : D) if (d.type == "box" && (d.width != 0 || d.border != d.color || d.pen != d.color)) flat = false;
        CHECK(flat, "bars and ticks drawn flat (no outline, no white pen on a coloured bar)");
    }
    // 3) the white tick: ONLY when both sides spiked, at the smaller side's height, 2 px, across the bar (inside the slot)
    {
        std::vector<Cand> C(3);
        C[0].v[0] = 410; C[0].v[1] = 380; C[0].spk[0] = C[0].spk[1] = true;   // the mockup's two-sided fight
        C[1].v[0] = 360; C[1].v[1] = 50; C[1].spk[0] = true;                   // sellers won clearly
        C[2].v[0] = 230; C[2].v[1] = 210; C[2].spk[0] = true;                  // both big, only one met its rule: no tick
        const auto D = drawC(h, C, 1, true, 410);
        Pane pane; const off::PaneGeo g = off::paneGeo(&pane, off::MODE_READ);
        auto t0 = boxesNear(D, cx(h, 0), 11, isWhite);
        CHECK(t0.size() == 1, "two-sided fight: one white tick");
        if (t0.size() == 1) {
            const int want = g.yBase - off::barHeight(380, 410, g.px);
            int l = 0, r = 0; off::oneBarSpan(cx(h, 0), h.barW, l, r);
            CHECK(t0[0]->y == want && t0[0]->b - t0[0]->y == 2, "the tick sits at the smaller side's 380 lots, 2 px tall");
            CHECK(t0[0]->x == l - 1 && t0[0]->r == r + 1 && t0[0]->x >= cx(h, 0) - h.barW / 2 && t0[0]->r <= cx(h, 0) - h.barW / 2 + h.barW - 1, "the tick crosses the bar (1 px each side), inside the candle's slot");
        }
        CHECK(boxesNear(D, cx(h, 1), 11, isWhite).empty() && boxesNear(D, cx(h, 2), 11, isWhite).empty(), "no tick when only one side spiked");
        // the tick draws after the bar (on top of it)
        size_t ib = 0, it = 0; for (size_t k = 0; k < D.size(); ++k) { if (D[k].type == "box" && barCol(D[k].color) && D[k].x >= cx(h, 0) - 11 && D[k].r <= cx(h, 0) + 11) ib = k; if (D[k].type == "box" && D[k].color == WHITE && D[k].x >= cx(h, 0) - 11 && D[k].r <= cx(h, 0) + 11) it = k; }
        CHECK(it > ib, "the tick is drawn over its bar");
        // equal sides both spiked: the tick at the bar top, still inside the bar
        std::vector<Cand> E(1); E[0].v[0] = E[0].v[1] = 200; E[0].spk[0] = E[0].spk[1] = true; E[0].dir = -1;
        const auto D2 = drawC(h, E, 1, true, 200); auto te = boxesNear(D2, cx(h, 0), 11, isWhite); auto be = boxesNear(D2, cx(h, 0), 11, barCol);
        CHECK(te.size() == 1 && be.size() == 1 && be[0]->color == SPK[0] && te[0]->y == be[0]->y, "200 / 200 both spiked, down close: red bar, tick at its top");
    }
    // 4) letters on the single bar for the winner; the loser's only on a both-spiked candle; marks off = none; the dash
    {
        std::vector<Cand> C(5);
        C[0].v[0] = 120; C[0].v[1] = 40; C[0].spk[0] = true; C[0].let[0] = "SL"; C[0].let[1] = "L";      // loser's L dropped
        C[1].v[0] = 120; C[1].v[1] = 100; C[1].spk[0] = C[1].spk[1] = true; C[1].let[0] = "S"; C[1].let[1] = "L";   // both: S then L above
        C[2].v[0] = 30; C[2].v[1] = 90; C[2].let[0] = "S";                                                // winner has none: nothing
        C[3].v[0] = 20; C[3].v[1] = 90; C[3].spk[1] = true; C[3].let[1] = "S"; C[3].mark[1] = "R?";      // the R? mark on the winner
        C[4].v[0] = 20; C[4].v[1] = 90; C[4].dash[1] = 30; C[4].dash[0] = 10;                             // the winner's refill dash
        h.barW = 26; h.ppb = 26;
        const auto D = drawC(h, C, 1, true, 120);
        auto L0 = textsNear(D, cx(h, 0), 13, WHITE), L1 = textsNear(D, cx(h, 1), 13, WHITE), L2 = textsNear(D, cx(h, 2), 13, WHITE);
        CHECK(L0.size() == 2 && std::count(L0.begin(), L0.end(), "L") == 1 && std::count(L0.begin(), L0.end(), "S") == 1, "one-sided: the winner's S + L only (the loser's L not drawn)");
        CHECK(L1.size() == 2, "both spiked: the winner's S and the loser's L stack in one column");
        int xs = -1, xl = -2, ys = 0, yl = 0; for (auto& d : D) if (d.type == "text" && d.color == WHITE && std::abs((d.x + d.r) / 2 - cx(h, 1)) <= 13) { if (d.text == "S") { xs = d.x; ys = d.y; } if (d.text == "L") { xl = d.x; yl = d.y; } }
        CHECK(xs == xl && ys > yl, "both spiked: one column, the winner's letter lowest (at the bar's bottom), the loser's above it");
        CHECK(L2.empty(), "the loser's letter is not drawn when the winner has none (it stays in the hover / record)");
        bool r3 = false; for (auto& d : D) if (d.type == "text" && d.text == "R?" && d.color == 0xE0242A && std::abs((d.x + d.r) / 2 - cx(h, 3)) <= 13) r3 = true;
        CHECK(r3, "the R? mark on the winning side's single bar in its colour");
        auto d4 = boxesNear(D, cx(h, 4), 13, isWhite);
        Pane pane; const off::PaneGeo g = off::paneGeo(&pane, off::MODE_READ);
        CHECK(d4.size() == 1 && d4[0]->y == g.yBase - off::barHeight(30, 120, g.px), "one refill dash: the winner's (30), not the loser's");
        // every letter inside its candle's single-bar column
        bool inside = true; for (auto& d : D) if (d.type == "text" && (d.color == WHITE || d.color == 0xE0242A)) { bool ok = false; for (int i = 0; i < 5; ++i) if (d.x >= cx(h, i) - 13 && d.r <= cx(h, i) + 13) ok = true; if (!ok) inside = false; }
        CHECK(inside, "letters stay inside their candle's slot");
        // marks off (StackStats): no letters, no R?, no dash - the tick stays
        std::vector<Cand> M = C; M[1].dash[0] = 40;
        const auto DM = drawC(h, M, 0, false, 120);
        int txt = 0, white = 0; for (auto& d : DM) { if (d.type == "text" && (d.color == WHITE || d.color == 0xE0242A || d.color == 0x168A42)) ++txt; if (d.type == "box" && d.color == WHITE) ++white; }
        CHECK(txt == 0, "marks off (StackStats): no S / L / I / R letters drawn");
        CHECK(white == 1 && boxesNear(DM, cx(h, 1), 13, isWhite).size() == 1, "marks off: no refill dash; the both-spiked tick is the only white mark");
        h.barW = 22; h.ppb = 22;
    }
    // 5) the spike label: one per candle, on the winner only when IT spiked, centred on the single bar; loser-only spike = no label
    {
        std::vector<Cand> C(40); for (int i = 0; i < 40; ++i) { C[i].v[0] = 20 + (i * 7) % 15; C[i].v[1] = 20 + (i * 5) % 15; }
        C[10].v[0] = 200; C[10].v[1] = 30; C[10].spk[0] = true;                   // seller spike: red label
        C[20].v[0] = 60; C[20].v[1] = 90; C[20].spk[0] = true;                    // loser (sellers) spiked, buyers bigger but normal: no label
        C[30].v[0] = 180; C[30].v[1] = 170; C[30].spk[0] = C[30].spk[1] = true;   // both: one label, the winner's
        const auto D = drawC(h, C, 1, true, 200);
        auto lab10 = textsNear(D, cx(h, 10), 20, SPK[0]); auto lab20r = textsNear(D, cx(h, 20), 20, SPK[0]), lab20g = textsNear(D, cx(h, 20), 20, SPK[1]);
        auto lab30r = textsNear(D, cx(h, 30), 20, SPK[0]), lab30g = textsNear(D, cx(h, 30), 20, SPK[1]);
        CHECK(lab10.size() == 3 && lab10[2] == "200", "seller spike: its label (ratio / pace / lots) in red above the bar");
        CHECK(lab20r.empty() && lab20g.empty(), "a spike on the LOSING side only: dim bar, no label (numbers in the hover)");
        CHECK(lab30r.size() == 3 && lab30g.empty() && lab30r[2] == "180", "both spiked: ONE label, the winner's");
        int lx = 0, lr = 0; for (auto& d : D) if (d.type == "text" && d.text == "200" && d.color == SPK[0]) { lx = d.x; lr = d.r; }
        CHECK(std::abs((lx + lr) / 2 - cx(h, 10)) <= 2, "the label is centred on the single bar");
    }
    // 6) no overlap + persistence (fuzz): letters never overlap each other or a tick; labels never overlap letters or each other; a
    //    later candle never changes an earlier label (time order) - all in one-bar mode
    {
        unsigned rs = 99; auto rnd = [&](int lo, int hi) { rs = rs * 1103515245u + 12345u; return lo + (int)((rs >> 16) % (unsigned)(hi - lo + 1)); };
        int overlapsFound = 0, changed = 0, runs = 0, ticks = 0;
        const char* lets[] = { "", "S", "L", "SL", "I", "IL" };
        for (int run = 0; run < 300; ++run) {
            h.barW = rnd(10, 30); h.ppb = h.barW; h.paneBottom = rnd(90, 260);
            const int n = 30; std::vector<Cand> C(n);
            for (int i = 0; i < n; ++i) { for (int s = 0; s < 2; ++s) { C[i].v[s] = rnd(0, 300); C[i].spk[s] = rnd(0, 5) == 0; C[i].let[s] = lets[rnd(0, 5)]; if (rnd(0, 12) == 0) C[i].mark[s] = "R?"; } C[i].dir = rnd(-1, 1); }
            const auto D = drawC(h, C, run % 2, true, 300);
            struct R4 { int l, t, r, b; bool letter; };
            std::vector<R4> rs4;
            for (auto& d : D) if (d.type == "text") rs4.push_back(R4{ d.x, d.y - 4, d.r - 1, d.b - 1, d.color == WHITE || d.color == 0xE0242A || d.color == 0x168A42 });
            std::vector<R4> tk; for (auto& d : D) if (d.type == "box" && d.color == WHITE && d.b - d.y == 2) { tk.push_back(R4{ d.x, d.y, d.r, d.b, false }); ++ticks; }
            // letters are drawn in boxes (top .. bottom); labels in rows of LABEL_LH: compare their full rectangles
            std::vector<R4> letterR, labelR;
            for (auto& d : D) if (d.type == "text") { const bool lt = d.color == WHITE || d.color == 0xE0242A || d.color == 0x168A42; R4 q{ d.x, (int)d.y - (lt ? 5 : off::LABEL_LH / 2), d.r - 1, lt ? d.b - 1 : (int)d.y + off::LABEL_LH / 2 - 1, lt }; (lt ? letterR : labelR).push_back(q); }
            for (size_t a = 0; a < letterR.size(); ++a) { for (size_t b = a + 1; b < letterR.size(); ++b) if (rectHit(letterR[a].l, letterR[a].t, letterR[a].r, letterR[a].b, letterR[b].l, letterR[b].t, letterR[b].r, letterR[b].b)) ++overlapsFound;
                for (auto& t : tk) if (rectHit(letterR[a].l, letterR[a].t, letterR[a].r, letterR[a].b, t.l, t.t, t.r, t.b - 1)) ++overlapsFound;
                for (auto& lb : labelR) if (rectHit(letterR[a].l, letterR[a].t, letterR[a].r, letterR[a].b, lb.l, lb.t, lb.r, lb.b)) ++overlapsFound; }
            // persistence: the labels of candles 0..k drawn with k+1..n appended stay the same
            std::map<int, std::vector<std::string> > base;
            { const auto Dk = drawC(h, std::vector<Cand>(C.begin(), C.begin() + 20), run % 2, true, 300);
              for (int i = 0; i < 20; ++i) { base[i] = textsNear(Dk, cx(h, i), 0, SPK[0]); auto g = textsNear(Dk, cx(h, i), 0, SPK[1]); base[i].insert(base[i].end(), g.begin(), g.end()); } }
            for (int i = 0; i < 20; ++i) { auto a = textsNear(D, cx(h, i), 0, SPK[0]); auto g = textsNear(D, cx(h, i), 0, SPK[1]); a.insert(a.end(), g.begin(), g.end()); if (a != base[i]) ++changed; }
            ++runs; (void)rs4;
        }
        char m[200]; std::snprintf(m, sizeof(m), "fuzz %d layouts (%d ticks): no letter over a letter / tick / label (overlaps %d)", runs, ticks, overlapsFound);
        CHECK(overlapsFound == 0 && ticks > 50, m);
        std::snprintf(m, sizeof(m), "fuzz: a later candle never changes an earlier candle's label rows (changed %d)", changed);
        CHECK(changed == 0, m);
        h.barW = 22; h.ppb = 22; h.paneBottom = 200;
    }
    // 7) the default (oneBull = -1) is the old two-bar drawing (backward compatible for other users of the header)
    {
        std::vector<Cand> C(4); for (int i = 0; i < 4; ++i) { C[i].v[0] = 30 + i; C[i].v[1] = 20 + 3 * i; }
        C[2].spk[0] = C[2].spk[1] = true;
        Pane pane; const off::PaneGeo g = off::paneGeo(&pane, off::MODE_READ);
        auto xOf = [&](int i) { cppExtension::PNT p; p.set(i, 0.0f); return (int)p.h; };
        auto look = [&](int i) { off::BarLook k; k.ok = true; for (int s = 0; s < 2; ++s) { k.v[s] = C[i].v[s]; k.spike[s] = C[i].spk[s]; } return k; };
        h.draws.clear(); off::drawBars(&pane, g, 0, 3, 22, 40, -1, NRM, SPK, xOf, look);
        int bars = 0, white = 0; for (auto& d : h.draws) { if (d.type == "box" && barCol(d.color)) ++bars; if (d.type == "box" && d.color == WHITE) ++white; }
        CHECK(bars == 8 && white == 0, "default drawBars (no one-bar flag): two bars per candle, no tick - unchanged");
    }
    // 8) titles and the pressing wording (logic)
    {
        char b[64]; CHECK(off::copyTitle(b, sizeof(b), bas::TITLE, bas::VERSION) && std::string(b) == "Bid/Ask Stats - Who is Pressing v1.7.0", "BidAskStats title + version");
        char s8[8]; CHECK(off::copyTitle(s8, sizeof(s8), bas::TITLE, bas::VERSION) && std::string(s8) == "Bid/Ask", "title cut to the buffer, terminated");
        CHECK(!off::copyTitle(nullptr, 10, "x", "1") && !off::copyTitle(b, 1, "x", "1"), "no buffer / size 1 -> refused");
        bas::Stat s; s.m.ok = true; s.m.bid = 100; s.m.ask = 100; s.bidRatioOk = s.askRatioOk = true; s.bidRatio = s.askRatio = 3.0; s.bidSpike = s.askSpike = true;
        const std::string none[2]; const int held[2] = { 0, 0 };
        const nl::Msg m = bas::message(s, nullptr, none, "", held);
        CHECK(m.line1.find("pressing") != std::string::npos && m.line1.find("attack") == std::string::npos, "message: 'Both sides pressing evenly', no 'attacking'");
    }
    std::printf("one bar (logic, OrderFlowFeed %s): %d passed, %d failed\n", off::VERSION, passes, fails);
    return fails ? 1 : 0;
}
#else
// ------------------------------------------------------------------------------------------------------------ the plugins on the mock host
static void dispose(Ind* p) { p->destroy(); p->~Ind(); ::operator delete(p); }
static Ind* make() { return static_cast<Ind*>(CreateExtension()); }
int main() {
    char tmpl[] = "/tmp/onebarXXXXXX"; const char* tmp = mkdtemp(tmpl); setenv("USERPROFILE", tmp, 1);
    mock::Host h; mock::current = &h;
    Ind* p = make();
    char t[128];
#if defined(BAS)
    CHECK(p->parmsTitle(t, sizeof(t)) == RTX_OK && std::string(t) == "Bid/Ask Stats - Who is Pressing v1.7.0" && std::string(BAS_VERSION) == "1.7.0", "BidAskStats pane title (parmsTitle) with its version");
    {   // ties take the close direction READ FROM THE CHART (open / close); the hover (Numbers box) still shows both sides
        dispose(p); h.data = nullptr;
        h.tick = 0.25f; h.seconds = 60; h.symbol = "ESZ6"; h.root = "ES"; h.paneBottom = 300; h.paneRight = 1200; h.scaleLeft = 1180; h.lists[7] = 1;   // Box shows: Numbers
        const unsigned long T0 = 1791900000UL + 3600UL;
        for (int i = 0; i < 26; ++i) { mock::Bar b; b.time = T0 + 60UL * i; b.open = 7000; b.close = 7000; b.high = 7001; b.low = 6999;
            const long bid = i == 21 ? 30 : 10, ask = i == 21 ? 30 : 10;              // candle 21: 30 / 30 tie
            b.rows.push_back(mock::Price(7000.0f, ask, bid, ask + bid)); b.volume = (unsigned long)(ask + bid); h.bars.push_back(b); }
        h.bars[21].open = 7000.0f; h.bars[21].close = 7000.75f;                       // up close -> buyers' green
        h.bars[22].rows[0] = mock::Price(7000.0f, 12, 12, 24); h.bars[22].open = 7001.0f; h.bars[22].close = 7000.0f;   // tie, down close -> red
        p = make(); NOW += 2000; p->calc(0); NOW += 2000; p->calc(0);
        h.draws.clear(); p->draw();
        auto colAt = [&](int i) { const int xc = 50 + i * h.barW; COLOR c = 1; int n = 0; for (auto& d : h.draws) if (d.type == "box" && d.x >= xc - 6 && d.r <= xc + 6 && d.color != 0x00FFFFFF && d.color != 0) { c = d.color; ++n; } return n == 1 ? c : (COLOR)2; };
        CHECK(colAt(21) == C_ASK_SPIKE || colAt(21) == C_ASK_BAR, "BidAskStats tie on an UP close: one green (buyers) bar");
        CHECK(colAt(22) == C_BID_BAR || colAt(22) == C_BID_SPIKE, "BidAskStats tie on a DOWN close: one red (sellers) bar");
        CHECK(colAt(5) == C_BID_BAR, "a flat 10 / 10 candle: one dim red bar");
        RTX_EVENT e; std::memset(&e, 0, sizeof(e)); e.type = E_MOUSE_MOVE; e.v.mouse.bar = 21; p->mouse(&e); h.draws.clear(); p->draw();
        bool sellers = false, buyers = false, both30 = false;
        for (size_t k = 0; k < h.draws.size(); ++k) { const auto& d = h.draws[k]; if (d.type != "text") continue; if (d.text == "Sellers") sellers = true; if (d.text == "Buyers") buyers = true;
            if (d.text == "Lots" && k + 2 < h.draws.size() && h.draws[k + 1].text.find("30") == 0 && h.draws[k + 2].text.find("30") == 0) both30 = true; }
        if (getenv("DBG")) for (auto& d : h.draws) if (d.type == "text") std::printf("  [%s] %d,%d\n", d.text.c_str(), d.x, d.y);
        CHECK(sellers && buyers && both30, "hover box: Sellers | Buyers columns, Lots 30 | 30 - BOTH sides' numbers (one bar drawn)");
    }
#elif defined(STACK)
    CHECK(p->parmsTitle(t, sizeof(t)) == RTX_OK && std::string(t) == "Stack Stats - Who is Arriving v1.4.0" && std::string(SS_VERSION) == st::VERSION, "StackStats pane title (parmsTitle) with its version");
    CHECK(p->oneBarBull() == 0 && !p->barMarks(), "StackStats: one bar per candle (bids = buyers) with NO letters / dashes (Rassul 23:00 CT)");
#else
    CHECK(p->parmsTitle(t, sizeof(t)) == RTX_OK && std::string(t) == "Pull Stats - Who is Leaving v1.6.0" && std::string(PS_VERSION) == ps::VERSION, "PullStats pane title (parmsTitle) with its version");
    CHECK(p->oneBarBull() == 0 && p->barMarks(), "PullStats: one bar per candle (bids = buyers), letters kept on the winning bar");
#endif
    CHECK(p->parmsTitle(nullptr, 10) == RTX_FAIL && p->parmsTitle(t, 1) == RTX_FAIL, "parmsTitle refuses no buffer");
    // the version literal in setVersion equals the macro (read from the .cpp)
    {
#if defined(BAS)
        const char* f = "BidAskStats.cpp"; const std::string want = std::string("p->setVersion(\"") + BAS_VERSION + "\")";
#elif defined(STACK)
        const char* f = "StackStats.cpp"; const std::string want = std::string("p->setVersion(\"") + SS_VERSION + "\")";
#else
        const char* f = "PullStats.cpp"; const std::string want = std::string("p->setVersion(\"") + PS_VERSION + "\")";
#endif
        std::string path = std::string(SRC_DIR) + "/" + f; FILE* fp = std::fopen(path.c_str(), "rb"); std::string s; if (fp) { char b[4096]; size_t n; while ((n = std::fread(b, 1, sizeof(b), fp)) > 0) s.append(b, n); std::fclose(fp); }
        CHECK(!s.empty() && s.find(want) != std::string::npos, "setVersion literal = the version macro");
    }
    dispose(p);
    std::printf("one bar host (%s): %d passed, %d failed\n",
#if defined(BAS)
        "BidAskStats " BAS_VERSION,
#elif defined(STACK)
        "StackStats " SS_VERSION,
#else
        "PullStats " PS_VERSION,
#endif
        passes, fails);
    return fails ? 1 : 0;
}
#endif
