#!/usr/bin/env python3
"""render_check.py -- draws render-check.png from the plugins' OWN draw calls on the mock host (render_dump.cpp output).
usage: render_check.py <bas.tsv> <stack.tsv> <pull.tsv> <out.png>   (of140 6:18 PM pane order: BidAskStats, StackStats, PullStats - attack and wall side by side)
Every rectangle and text below the price pane is exactly what BidAskStats / PullStats / StackStats asked the host to draw
(positions, colours, text); only the font face is approximated (the mock measures text at 6 px a character, so a 10 px mono font)."""
import sys
from PIL import Image, ImageDraw, ImageFont

BG = (11, 14, 18)
FD = "/usr/share/fonts/truetype/dejavu/"
def font(size, bold):
    return ImageFont.truetype(FD + ("DejaVuSansMono-Bold.ttf" if bold else "DejaVuSansMono.ttf"), size)
def rgb(h): v = int(h, 16); return ((v >> 16) & 255, (v >> 8) & 255, v & 255)

def load(p):
    pane, items, bars, axis = None, [], [], None
    for ln in open(p, encoding="cp1252"):
        f = ln.rstrip("\n").split("\t")
        if f[0] == "PANE": pane = (f[1], *map(int, f[2:6]))
        elif f[0] == "BOX": items.append(("box", *map(int, f[1:5]), rgb(f[5]), rgb(f[6]), int(f[7]), rgb(f[8])))
        elif f[0] == "TEXT": items.append(("text", *map(int, f[1:5]), rgb(f[5]), int(f[6]), int(f[7]), int(f[8]), int(f[9]), "\t".join(f[10:])))
        elif f[0] == "BAR": bars.append((int(f[1]), *map(float, f[2:6])))
        elif f[0] == "AXIS": axis = (float(f[1]), float(f[2]))
    return pane, items, bars, axis

def main():
    dumps = [load(p) for p in sys.argv[1:4]]
    out = sys.argv[4]
    W = 1230; PH = 300; GAP = 26; paneH = dumps[0][0][4] - dumps[0][0][2]
    H = 34 + PH + 3 * (GAP + paneH) + 40
    im = Image.new("RGB", (W, H), BG); d = ImageDraw.Draw(im)
    d.text((10, 8), "render-check (of140): BidAskStats 1.7.0 / StackStats 1.4.0 / PullStats 1.6.0 (one bar per candle) (pane order) as drawn by the plugins themselves (mock host, CL 3-min, reversal at LonLO 92.90)", fill=(225, 228, 232), font=font(13, True))
    # price pane (scenario candles; not a plugin drawing)
    bars = dumps[0][2]; top = 34; lo = min(b[3] for b in bars) - 0.05; hi = max(b[2] for b in bars) + 0.05
    y = lambda p: top + 6 + (hi - p) / (hi - lo) * (PH - 12)
    d.rectangle([0, top, 1130, top + PH], outline=(40, 44, 50))
    d.text((6, top + 4), "CL 3-min (scenario price, for orientation)", fill=(150, 156, 164), font=font(11, False))
    yl = y(92.90); d.line([0, yl, 1130, yl], fill=(245, 158, 11), width=1); d.text((60, yl - 15), "92.90 LonLO", fill=(245, 158, 11), font=font(11, False))
    for x, o, h_, l, c in bars:
        col = (34, 197, 94) if c >= o else (239, 68, 68)
        d.line([x, y(h_), x, y(l)], fill=col); d.rectangle([x - 6, min(y(o), y(c)), x + 6, max(y(o), y(c)) + 1], fill=col)
    for i in range(6):
        p = lo + (hi - lo) * i / 5; d.text((1136, y(p) - 6), "%.2f" % p, fill=(140, 146, 154), font=font(10, False))
    oy = top + PH + GAP
    for pane, items, _, axis in dumps:
        name, L, T, R, B = pane
        d.text((4, oy - 18), name + "  (hover on its story candle; spike labels = ratio over quantity)", fill=(225, 228, 232), font=font(12, False))
        sub = Image.new("RGB", (R - L + 1, B - T + 1), BG); sd = ImageDraw.Draw(sub)
        for it in items:
            if it[0] == "box":
                _, x0, y0, x1, y1, fill, border, w, pen = it
                # (1.0.1) worst case of IRT: the perimeter is drawn with the PEN in effect (not the border argument), so a pen
                # left white would show as the white outline Rassul saw; every bar / letter box must come out with no outline
                sd.rectangle([x0, y0, x1, y1], fill=fill, outline=pen, width=max(1, w))
        for it in items:
            if it[0] != "text": continue
            _, x0, yc, x1, yb, col, centred, fid, fsize, fstyle, text = it
            fz = 7 if fsize <= 7 else 10
            f = font(9 if fsize <= 7 else 10, fstyle == 1)   # (of140 6:18 PM) 10 px mono = the mock's 6 px a character, so a line the plugin fitted is drawn as wide as it measured it
            yt = 2 * yc - yb
            if centred:
                w = sd.textlength(text, font=f); sd.text(((x0 + x1) / 2 - w / 2, yt - 1), text, fill=col, font=f)
            else:
                sd.text((x0, yt - (1 if fz == 10 else 0)), text, fill=col, font=f)
        im.paste(sub, (L, oy + T))
        d.rectangle([L, oy + T, 1130, oy + B], outline=(40, 44, 50))
        if axis:                                                      # the pane's own value axis from scale()
            mn, mx = axis
            for i in range(5):
                v = mn + (mx - mn) * (0.08 + 0.21 * i)
                yy = oy + B - (v - mn) / (mx - mn) * (B - T)
                d.text((1136, yy - 6), "%d" % round(v), fill=(140, 146, 154), font=font(10, False))
        oy += paneH + GAP
    d.text((6, H - 30), "Bars / letters / spike labels / info box / message line: the plugins' own draw calls. Axis labels from each plugin's scale(). "
           "Fonts approximated (mono).", fill=(140, 146, 154), font=font(10, False))
    im.save(out); print("saved", im.size)

if __name__ == "__main__":
    main()
