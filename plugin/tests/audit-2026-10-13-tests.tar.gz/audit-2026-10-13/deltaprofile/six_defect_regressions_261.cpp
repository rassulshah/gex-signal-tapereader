// Regressions F2-F6 from the DeltaProfile 2.5.6 read-only audit.
// This is a Linux/mock-SDK logic test; it is not an MSVC or live IRT test.
#include "../../plugin/DeltaProfile.cpp"
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <sys/stat.h>
#include <unistd.h>

namespace mock { Host* current = NULL; }

static void check(bool ok, const char* why) {
    if (!ok) throw std::runtime_error(why);
}
static LatchBook& book(const mock::Host& h) {
    return latchBooks()[(safeField(h.symbol) + "|" + std::to_string(h.seconds))];
}
static void mkdirIgnore(const std::string& path) {
    if (mkdir(path.c_str(), 0700) != 0 && errno != EEXIST) throw std::runtime_error("mkdir failed");
}
static std::string profileHome(const char* name) {
    const char* base = std::getenv("DP_AUDIT_TMP");
    const std::string root = (base && base[0]) ? base : "/tmp/delta-profile-audit";
    const std::string home = root + "/" + name;
    mkdirIgnore(root); mkdirIgnore(home); mkdirIgnore(home + "/InvestorRT");
    mkdirIgnore(home + "/InvestorRT/rtx"); mkdirIgnore(home + "/InvestorRT/rtx/lsFlexLevels");
    setenv("USERPROFILE", home.c_str(), 1);
    return home + "/InvestorRT/rtx/lsFlexLevels/DeltaProfile/";
}
static mock::Host fixture(const std::string& symbol = "ESZ26", unsigned long start = 1791504000UL + 9UL * 3600UL + 30UL * 60UL) {
    mock::Host h;
    h.root = "ES"; h.symbol = symbol; h.seconds = 60; h.tick = 1.0f;
    for (int i = 0; i < 110; ++i) {
        mock::Bar b;
        b.time = start + static_cast<unsigned long>(i * 60);
        b.rows = { mock::Price(120, 1, 0, 1), mock::Price(121, 1, 0, 1), mock::Price(122, 1, 0, 1),
                   mock::Price(123, 1, 0, 1), mock::Price(124, 1, 0, 1) };
        b.volume = 5; b.low = 101; b.high = 125; b.open = 104; b.close = 104;
        h.bars.push_back(b);
    }
    mock::Bar& node = h.bars[40];
    node.rows.push_back(mock::Price(100, 0, 10000, 10000));
    node.volume += 10000; node.low = 99; node.high = 125; node.open = node.close = 100;
    return h;
}
static void addConfirmThenForming(mock::Host& h) {
    mock::Bar green = h.bars.back();
    green.time += 60; green.open = 103; green.close = 106; green.low = 100; green.high = 125;
    h.bars.push_back(green);
    mock::Bar forming = green;
    forming.time += 60; forming.open = forming.close = 104;
    h.bars.push_back(forming);
}
static void addChronologyChallenge(mock::Host& h) {
    mock::Bar green = h.bars.back();
    green.time += 60; green.open = 103; green.close = 106; green.low = 101; green.high = 125;
    h.bars.push_back(green); // earliest decisive close after frozen peak: A
    mock::Bar extra = green;
    extra.time += 60; extra.open = extra.close = 104; extra.low = 99; extra.high = 125;
    extra.rows.push_back(mock::Price(100, 0, 2000, 2000));
    extra.volume += 2000;
    h.bars.push_back(extra);
    mock::Bar red = green;
    red.time = extra.time + 60; red.open = 99; red.close = 96; red.low = 95; red.high = 99.5f;
    red.rows = { mock::Price(97, 1, 0, 1) }; red.volume = 1;
    h.bars.push_back(red);
    mock::Bar forming = red;
    forming.time += 60; forming.open = forming.close = 98;
    h.bars.push_back(forming);
}
static int rings(const mock::Host& h) {
    int out = 0;
    for (std::size_t i = 0; i < h.draws.size(); ++i) if (h.draws[i].type == "ring") ++out;
    return out;
}
static std::string slurp(const std::string& path) {
    std::ifstream in(path.c_str(), std::ios::binary); std::ostringstream out; out << in.rdbuf(); return out.str();
}
static void destroy(DeltaProfile& p, mock::Host& h) {
    mock::current = &h; p.destroy(); latchBooks().clear();
}

static void f2_provisional_cannot_confirm() {
    profileHome("f2"); latchBooks().clear();
    mock::Host h = fixture(); DeltaProfile p; mock::current = &h;
    check(p.draw() == RTX_OK && book(h).v.size() == 1 && book(h).v[0].code == "A?", "F2 fixture failed");
    addConfirmThenForming(h);
    h.bars[50].failStats = 1; // closed VAP read failure makes the rebuilt profile provisional
    mock::current = &h; check(p.draw() == RTX_OK, "F2 provisional draw failed");
    const ChartState& state = *static_cast<ChartState*>(h.data);
    check(state.shortHistory && state.missingVap == 1, "F2 fixture did not become provisional");
    check(book(h).v[0].code == "A?", "F2 provisional profile bypassed the confirmation gate");
    destroy(p, h); std::cout << "PASS F2 provisional confirmation gate\n";
}
static void f3_contracts_never_share_latches_or_records() {
    profileHome("f3"); latchBooks().clear();
    mock::Host front = fixture("ESZ26"); DeltaProfile p; mock::current = &front;
    check(p.draw() == RTX_OK && book(front).v.size() == 1, "F3 front-contract fixture failed");
    const std::string frontPath = book(front).path;
    mock::Host next = fixture("ESU27");
    next.bars[40].rows.pop_back(); next.bars[40].volume -= 10000; next.bars[40].open = next.bars[40].close = 104;
    next.draws.clear(); mock::current = &next; check(p.draw() == RTX_OK, "F3 next-contract draw failed");
    check(book(next).path == frontPath && &book(next) != &book(front), "F3 (2.6.x) one sync260 file per market, separate contract books");
    check(book(next).v.empty() && rings(next) == 0, "F3 same-root contract inherited a latch or circle");
    destroy(p, front); mock::current = &next; p.destroy(); latchBooks().clear();
    std::cout << "PASS F3 full contract isolation\n";
}
static void f4_frozen_first_close_wins() {
    profileHome("f4"); latchBooks().clear();
    mock::Host h = fixture(); DeltaProfile p; mock::current = &h;
    check(p.draw() == RTX_OK && book(h).v.size() == 1 && book(h).v[0].code == "A?", "F4 fixture failed");
    addChronologyChallenge(h);
    h.draws.clear(); mock::current = &h; check(p.draw() == RTX_OK, "F4 catch-up draw failed");
    check(book(h).v[0].code == "A" && book(h).v[0].support, "F4 refreshed classification overrode frozen first close");
    destroy(p, h); std::cout << "PASS F4 frozen first-close chronology\n";
}
static void f5_tick_change_rekeys_pending_latch() {
    profileHome("f5"); latchBooks().clear();
    mock::Host h = fixture(); DeltaProfile p; mock::current = &h;
    check(p.draw() == RTX_OK && book(h).v.size() == 1 && book(h).v[0].low == 100, "F5 fixture failed");
    h.tick = 0.5f;
    mock::Bar green = h.bars.back();
    green.time += 60; green.open = 60; green.close = 75; green.low = 60; green.high = 80;
    green.rows = { mock::Price(75, 1, 0, 1) }; green.volume = 1; h.bars.push_back(green);
    mock::Bar forming = green; forming.time += 60; forming.open = forming.close = 75; h.bars.push_back(forming);
    mock::current = &h; check(p.draw() == RTX_OK, "F5 tick-change draw failed");
    check(book(h).v[0].low == 200 && book(h).v[0].high == 200, "F5 pending latch was not re-keyed");
    check(book(h).v[0].code == "A?", "F5 sub-node green close confirmed against stale tick keys");
    destroy(p, h); std::cout << "PASS F5 in-memory tick re-key\n";
}
static void f6_failed_rollover_append_is_retained_and_retried() {
    const std::string dir = profileHome("f6"); mkdirIgnore(dir); latchBooks().clear();
    const std::string oldPath = dir + syncRecordName("ES", 60, 20735);
    unlink(oldPath.c_str());
    check(symlink("/nonexistent-delta-profile-regression/old.csv", oldPath.c_str()) == 0, "F6 dangling-link fixture failed");
    mock::Host h = fixture("ESZ26", 1791504000UL + 14UL * 3600UL);
    DeltaProfile p; mock::current = &h; check(p.draw() == RTX_OK, "F6 initial draw failed");
    addConfirmThenForming(h); mock::current = &h; check(p.draw() == RTX_OK, "F6 decision draw failed");
    check(!book(h).journal.empty(), "F6 failing write did not retain current-session journal");
    while (h.bars.back().time < 1791504000UL + 17UL * 3600UL + 60UL) {
        mock::Bar b = h.bars.back(); b.time += 60; b.open = b.close = 104; b.low = 101; b.high = 125; h.bars.push_back(b);
    }
    mock::current = &h; check(p.draw() == RTX_OK, "F6 rollover draw failed");
    check(!book(h).carry.empty() && !book(h).carry[0].second.empty(), "F6 rollover discarded failed old-session records");
    unlink(oldPath.c_str()); // storage recovers after rollover
    mock::Bar retry = h.bars.back(); retry.time += 60; h.bars.push_back(retry);
    mock::current = &h; check(p.draw() == RTX_OK, "F6 recovery retry draw failed");
    check(book(h).carry.empty() && access(oldPath.c_str(), F_OK) == 0, "F6 recovered old-session append was not retried");
    const std::string text = slurp(oldPath);
    check(text.find("|F|") != std::string::npos && text.find("|D|") != std::string::npos, "F6 recovered record lacks retained events");
    destroy(p, h); std::cout << "PASS F6 rollover write retry\n";
}

int main() {
    setenv("TZ", "UTC", 1); tzset();
    try {
        f2_provisional_cannot_confirm();
        f3_contracts_never_share_latches_or_records();
        f4_frozen_first_close_wins();
        f5_tick_change_rekeys_pending_latch();
        f6_failed_rollover_append_is_retained_and_retried();
    } catch (const std::exception& e) {
        std::cerr << "FAIL six_defect_regressions: " << e.what() << '\n';
        return 1;
    }
    std::cout << "RESULT 5 adapter/persistence regressions passed\n";
    return 0;
}
