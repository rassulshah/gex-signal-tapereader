// Regression for F1: native float OHLC and VAP values on the same tick must not
// compare as being beyond a reconstructed double node boundary.
#include "../../plugin/DeltaProfile.cpp"
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <stdexcept>

namespace mock { Host* current = NULL; }

static void check(bool ok, const char* why) {
    if (!ok) throw std::runtime_error(why);
}

static void run(const char* market, double price, double tick, bool selling) {
    latchBooks().clear();
    mock::Host h;
    h.root = market;
    h.symbol = std::string(market) + "Z26";
    h.seconds = 60;
    h.tick = static_cast<float>(tick);
    for (int i = 0; i < 110; ++i) {
        mock::Bar b;
        b.time = 1791504000UL + static_cast<unsigned long>(i * 60);
        b.open = b.close = static_cast<float>(price);
        b.low = static_cast<float>(selling ? price : price - 10 * tick);
        b.high = static_cast<float>(selling ? price + 10 * tick : price);
        for (int k = 1; k <= 5; ++k)
            b.rows.push_back(mock::Price(static_cast<float>(price + (selling ? 1 : -1) * k * tick), 1, 0, 1));
        b.volume = 5;
        if (i == 40) {
            b.rows.push_back(mock::Price(static_cast<float>(price), selling ? 0 : 10000, selling ? 10000 : 0, 10000));
            b.volume += 10000;
        }
        h.bars.push_back(b);
    }
    mock::current = &h;
    DeltaProfile p;
    check(p.draw() == RTX_OK, "initial draw failed");
    LatchBook& book = latchBooks()[(safeField(h.symbol) + "|" + std::to_string(h.seconds))];
    check(book.v.size() == 1 && book.v[0].code == "A?", "fixture did not create an undecided candidate");
    mock::Bar close = h.bars.back();
    close.time += 60;
    close.open = static_cast<float>(price + (selling ? -1 : 1) * tick);
    close.close = static_cast<float>(price); // exactly the node's integer tick
    close.low = std::min(close.open, close.close);
    close.high = std::max(close.open, close.close);
    close.rows = { mock::Price(static_cast<float>(price), 1, 1, 2) };
    close.volume = 2;
    h.bars.push_back(close);
    mock::Bar forming = close;
    forming.time += 60;
    h.bars.push_back(forming);
    check(p.draw() == RTX_OK, "boundary draw failed");
    check(book.v.size() == 1 && book.v[0].code == "A?", "on-node native float close was falsely confirmed");
    std::cout << "PASS " << market << " close_key=" << dp::priceKey(close.close, h.tick)
              << " node=" << book.v[0].low << '\n';
    mock::current = &h;
    p.destroy();
    latchBooks().clear();
}

int main() {
    unsetenv("USERPROFILE");
    setenv("TZ", "UTC", 1);
    tzset();
    try {
        run("GC", 4214.5, .1, false);
        run("HG", 5, .0005, false);
        run("NG", 3, .001, false);
        run("CL", 75, .01, true);
        run("EU", 1.1, .00005, true);
    } catch (const std::exception& e) {
        std::cerr << "FAIL native_float_boundary: " << e.what() << '\n';
        return 1;
    }
    std::cout << "RESULT 5 native float boundary regressions passed\n";
    return 0;
}
