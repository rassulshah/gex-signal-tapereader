// stubmock/irtsdk.h -- a deliberately TINY mock for the retired lsPulling stub (2026-10-14): only what a stub may call. It has NO
// drawing, NO order feed (DEPTH_BY_ORDER), NO parameters except setParameterVersion and NO file helpers - if the stub ever drew,
// subscribed to the feed or added a setting, this test would not compile.
#pragma once
#include <string>
enum { RTX_OK = 0, RTX_FAIL = -1 };
enum : unsigned long { POST_DRAWING = 0x1, NO_UI = 0x2, TRACK_MOUSE = 0x4, OVERLAY = 0x8, FRONT_DRAWING = 0x10 };
namespace stubmock { struct Rec { int arrays = -1, parmVersion = -1; unsigned long flags = 0, xflags = 0; std::string desc, version; }; inline Rec& rec() { static Rec r; return r; } }
class cppExtension {
public:
    virtual ~cppExtension() {}
    virtual int draw(void) { return RTX_FAIL; }
    int init(void); int setup(void); int calc(int); int done(void); int destroy(void);
    void setArrayCount(int n) { stubmock::rec().arrays = n; }
    void setFlags(unsigned long f) { stubmock::rec().flags = f; }
    void setExtendedFlags(unsigned long f) { stubmock::rec().xflags = f; }
    void setDescription(const char* d) { stubmock::rec().desc = d ? d : ""; }
    void setVersion(const char* v) { stubmock::rec().version = v ? v : ""; }
    void setParameterVersion(int v) { stubmock::rec().parmVersion = v; }
};
