#!/bin/sh
# lsPulling 1.0.0 RETIRED stub (2026-10-14 night; its read is lsPullStats 1.5.0's line - those tests are tests_of/test_pullstats_zone_host.cpp
# (ported from test_pulling_zone_host.cpp) and tests_zone): the stub on a deliberately tiny mock (it cannot draw / subscribe / add
# settings), PullingLogic.h's own logic test (the header stays in plugin\ unused), the MinGW syntax check of the stub against the REAL
# irtsdk.h and the Win32 import check. The 0.3.0 host / zone-host tests went with the 0.3.0 source to plugin\retired\.
D=$(cd "$(dirname "$0")" && pwd); B=${BUILD:-/tmp/pl-build}; SDK=${SDK:-/mnt/user-data/uploads/sdk/c++/include}; mkdir -p "$B"
SAN="-fsanitize=address,undefined -fno-sanitize-recover=undefined"; CXX="g++ -std=c++17 -g -Wall -Wextra -Werror $SAN"
step() { echo "== $1" >&2; shift; "$@" || { echo "FAILED: $*"; exit 1; }; }
export ASAN_OPTIONS=detect_leaks=0
step "logic (PullingLogic.h, unused)" $CXX -I"$D/.." "$D/test_pulling_logic.cpp" -o "$B/tl"; step "run" "$B/tl"
step "stub" $CXX -I"$D/stubmock" -I"$D/.." "$D/test_pulling_stub.cpp" -o "$B/ts"; step "run" "$B/ts" "$D/../Pulling.cpp"
rm -f "$B/tl" "$B/ts"
x86_64-w64-mingw32-g++ -std=c++17 -fsyntax-only -Wall -Wextra -Wno-unknown-pragmas -I"$SDK" -I"$D/.." "$D/wrap_Pulling.cpp" > "$B/syntax-Pulling.log" 2>&1
E=$(grep -c ' error' "$B/syntax-Pulling.log"); W=$(grep 'warning' "$B/syntax-Pulling.log" | grep -vc "$SDK")
echo "syntax Pulling: $E errors, $W warnings outside the SDK"; [ "$E" = 0 ] && [ "$W" = 0 ] || { head -20 "$B/syntax-Pulling.log"; exit 1; }
x86_64-w64-mingw32-g++ -std=c++17 -c -O0 -I"$SDK" -I"$D/.." "$D/wrap_Pulling.cpp" -o "$B/w32-Pulling.o" 2>/dev/null || { echo "win32 Pulling: compile failed"; exit 1; }
imps=$(x86_64-w64-mingw32-nm -u "$B/w32-Pulling.o" | grep "__imp_" | sed 's/.*__imp_//' | grep -E '^[A-Z]' | sort -u | tr '\n' ' ')
for f in GetCursorPos WindowFromPoint ScreenToClient GetAsyncKeyState MessageBoxA; do case " $imps " in *" $f "*) echo "win32 Pulling: user32 $f needs a pragma"; exit 1;; esac; done
echo "win32 Pulling: ok ($imps)"; rm -f "$B/w32-Pulling.o"
echo "ALL PULLING SUITES PASSED"
