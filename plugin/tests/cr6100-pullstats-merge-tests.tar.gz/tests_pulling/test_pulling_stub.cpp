// test_pulling_stub.cpp -- lsPulling 1.0.0 RETIRED stub (2026-10-14 night; its read merged into lsPullStats 1.5.0): the DLL name and the
// five SDK entry points stay; it draws nothing, has no settings, opens no feed, writes no files; description + version as agreed.
#include "Pulling.cpp"
#include <cstdio>
#include <fstream>
#include <sstream>
static int fails = 0, passes = 0;
#define CHECK(c, m) do { if (c) ++passes; else { ++fails; std::printf("FAIL %d %s\n", __LINE__, m); } } while (0)
int main(int argc, char** argv) {
    cppExtension* p = CreateExtension();
    const stubmock::Rec& r = stubmock::rec();
    CHECK(p && r.version == "1.0.0" && std::string(PL_VERSION) == r.version, "version 1.0.0 = PL_VERSION = setVersion");
    CHECK(r.desc.compare(0, 24, "RETIRED on 2026-10-14: l") == 0 && r.desc.find("lsPullStats 1.5.0") != std::string::npos && r.desc.find("draws nothing") != std::string::npos, "description: retired into lsPullStats 1.5.0 on 2026-10-14");
    CHECK((r.flags & NO_UI) && !(r.flags & TRACK_MOUSE) && !(r.flags & OVERLAY) && r.xflags == 0, "own pane, no mouse tracking, not continuous");
    CHECK(p->init() == RTX_OK && p->setup() == RTX_OK && r.parmVersion == 1, "setup: no settings (parameter version unchanged)");
    CHECK(p->calc(0) == RTX_OK && p->draw() == RTX_OK && p->done() == RTX_OK && p->destroy() == RTX_OK, "entry points return OK; draw claims the pane and draws nothing");
    delete p;
    // the source: no feed, no file, no drawing call, no parameter call besides setParameterVersion
    if (argc > 1) {
        std::ifstream f(argv[1]); std::stringstream s; s << f.rdbuf(); const std::string src = s.str();
        const size_t body = src.find("#define PL_VERSION"); const std::string code = body == std::string::npos ? src : src.substr(body);
        const char* banned[] = { "DEPTH_BY_ORDER", "ofstream", "fopen", "drawText", "setIntegerParameter", "setBoolParameter", "setListParameter", "setFloatParameter", "setColorParameter", "#include \"PullingLogic.h\"", "ZoneRead.h" };
        bool clean = true; for (const char* b : banned) if (code.find(b) != std::string::npos || src.find(std::string("#include \"") + b) != std::string::npos) { clean = false; std::printf("  found %s\n", b); }
        CHECK(clean, "source: no feed, no files, no drawing, no settings, no zone read");
    }
    std::printf("pulling stub (lsPulling %s RETIRED): %d passed, %d failed\n", PL_VERSION, passes, fails); return fails ? 1 : 0;
}
