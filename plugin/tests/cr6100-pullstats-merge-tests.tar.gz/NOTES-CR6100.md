# CR6100 - lsPulling's read merged into lsPullStats; lsPulling retired (2026-10-14 night)

Requests: Rassul approved the merge at 20:04 CT ("merge the Pulling read into PullStats and retire lsPulling"; built, tested, compile-clean
before 08:00 CT; no plugin changes 08:30-15:00 CT). Design change the same night (via the coordinator): "the PullStats line shows ONLY
state 3, the locked arrival read after the 3-min window ... It emphasises the pull. Draw NO pre-touch line and NO 'measuring' line;
nothing shows until the read locks. Still compute and record the pre-touch % in the zoneread CSV, and put it in the hover as a
secondary fact."

| Part | Version | What changed |
|---|---|---|
| ZoneRead.h | 1.0.0 -> 1.1.0 | PullStats pane line = the arrival read (lsPulling 0.3.0's words / colour rule), shown ONLY once locked (nothing while approaching / measuring); pre-touch measured at arrival -> record + hover row "Before the touch (secondary)"; "arrived" row at arrival (PullStats host only); restore of arrived / frozen / 1.0.0 rows; restart inside the window = nothing, then grey "bids: arrival read not known (restarted during the 3 min) ?"; 4 columns appended (pre_moved / pre_partial / pre_impl / pre_text) + one-time atomic header upgrade of an existing 1.0.0 file; helpers take an encounter (Pulling / BidAsk / Stack lines byte-identical) |
| lsPullStats | 1.4.0 -> 1.5.0 | the line above; description; bars / spike labels / letters / feed clock / recorder unchanged; no setting changes (parameter version unchanged) |
| lsPulling | 0.3.0 -> 1.0.0 RETIRED stub | keeps the DLL name; draws nothing; no settings; no feed; no files; 0.3.0 source -> plugin\retired\Pulling_0_3_0.cpp; PullingLogic.h left in plugin\ unused |
| gex-build.bat | | `call :one Pulling lsPulling` (stub, no headers) + REM lines |
| VERSIONS.json (LRA docs\design) | | PullStats approved 1.5.0, Pulling 1.0.0 retired |

Colours: red = the defending side pulled at support (bearish); offers pulled at resistance = green; traded + held at support = green
(at resistance = red); mixed = grey; always "?".

Tests (Linux, ASan/UBSan, -Werror): tests_zone (143, parity 400/400; new: testPullStatsMerged - 3 states, colours both sides, hover
parts and caveats, record rows, restart after the lock, restart INSIDE the window, 1.0.0 rows, garbled rows; testHeaderUpgrade),
tests_of (155, 124, 28, 61, 103, 51, 47, panel host 28/28/27, label persist 17/18/18/18, pull host 71, stack host 58, NEW pullstats zone
host 22 (ported from tests_pulling/test_pulling_zone_host.cpp), feed clock 21, mborecord 24 + mbo_live parse ok, MinGW 0/0 x3 against
the real irtsdk.h, win32 ok x3), tests_pulling (PullingLogic 14, stub 6 on a tiny mock that cannot draw / subscribe / add settings,
MinGW 0/0, win32 ok). Also MinGW syntax of LiquidityProfile.cpp with ZoneRead 1.1.0: 0/0.
Rebuilt by gex-build because they hash ZoneRead.h (behaviour unchanged, record rows 4 columns longer): lsBidAskStats, lsStackStats,
lsLiquidityProfile, lsLiquidityFlow.
Mockup: /home/claude/aud/panes/mockup-pullstats-merged.png (render_dump ZHOOK / ZTEXT / ZIMPL / ZNONE = the plugin's own draw calls).
Not verified - needs his IRT: the line on a live chart at a real level (needs 10+ sessions loaded for the ADR), the hover height in his
real PullStats pane (rows are ordered so the caveats come before the partial note).
