// test_panel_host.cpp -- lsPullStats 1.2.1 (default) / lsStackStats 1.1.2 (-DSTACK) / lsBidAskStats 1.5.2 (-DBAS) against the mock
// host: the 1.3.0 panel end to end (CR4800, Rassul 2026-10-14 07:02-07:22).
//   - Read mode by default (no file, and a 1.2.x / 1.5.1 file): the READ box at Top left, the read inside it, no numbers
//   - mouse over the read box: the numbers grid (every row), the candle it reads stays; mouse off the chart: back
//   - settings round trip: dialog -> Apply -> per-market file -> restart -> draw at Position + Offset; the dialog filled from the file;
//     a control he did not touch keeps the file's value; Apply from the chart copy never saves
//   - fuzz: 2,000 random dialog values (garbage, out of range) -> the file only ever holds valid values, no crash
//   - jitter: 1,000 draws with a live-updating forming bar, mouse moves (outside the box) and alternating reads -> the box never moves
//   - two charts of the same market share the per-market file (the place file rule) and each clamps inside its own pane
//   - letters: white text, no box; nothing drawn on candles with no order data
#if defined(BAS)
#include "BidAskStats.cpp"
typedef BidAskStats Ind;
long long bas_test_now_ms = 1000000;
void* bas_test_cursor_wnd = nullptr;
#define NOW bas_test_now_ms
static const char* const NAME = "BidAskStats";
static const int BASE = 5;
#elif defined(STACK)
#include "StackStats.cpp"
typedef StackStats Ind;
namespace off { long long off_test_now_ms = 1000000; void* off_test_cursor_wnd = nullptr; }
#define NOW off::off_test_now_ms
static const char* const NAME = "StackStats";
static const int BASE = 6;
#else
#include "PullStats.cpp"
typedef PullStats Ind;
namespace off { long long off_test_now_ms = 1000000; void* off_test_cursor_wnd = nullptr; }
#define NOW off::off_test_now_ms
static const char* const NAME = "PullStats";
static const int BASE = 7;
#endif
#include <cstdio>
#include <random>
// (1.5.0 / BidAskStats 1.6.0) the READ box became ONE read line (shown only inside a key / gamma zone): this suite now places that line
// (a fixed line through ZREAD_TEST_HOOK - the zone logic itself is tested in tests_zone), its hover detail box, settings, jitter
#include <sys/stat.h>
namespace mock { Host* current = nullptr; Feed feed; }
static int fails = 0, passes = 0;
#define CHECK(c, m) do { if (c) ++passes; else { ++fails; std::printf("FAIL %d %s\n", __LINE__, m); } } while (0)
static std::string readAll(const std::string& p) { std::ifstream f(p.c_str()); std::stringstream s; s << f.rdbuf(); return s.str(); }
static void dispose(Ind* p) { p->destroy(); p->~Ind(); ::operator delete(p); }
static Ind* make() { return static_cast<Ind*>(CreateExtension()); }
static const unsigned long T0 = 1791900000UL;
static mock::Bar bar(unsigned long t) { mock::Bar b; b.time = t; b.close = 7000.0f; b.low = 6999.5f; b.high = 7001.0f; b.volume = 100; b.rows.push_back(mock::Price(7000.0f, 50, 50, 100)); return b; }
static void apply(Ind* p) { const std::string sv = mock::current->period; mock::current->period = ""; p->parmsApply(); mock::current->period = sv; }
static void load(Ind* p) { const std::string sv = mock::current->period; mock::current->period = ""; p->parmsLoad(); mock::current->period = sv; }
static const mock::Draw* bigBlackBox(mock::Host& h) { const mock::Draw* b = nullptr; for (auto& d : h.draws) if (d.type == "box" && d.color == 0x00000000 && d.border == 0x009CA3AF && (!b || d.r - d.x > b->r - b->x)) b = &d; return b; }
static bool hasText(mock::Host& h, const std::string& t) { for (auto& d : h.draws) if (d.type == "text" && d.text == t) return true; return false; }
[[maybe_unused]] static std::string boxSig(const mock::Draw* b) { return b ? std::to_string(b->x) + "," + std::to_string(b->y) + "," + std::to_string(b->r) + "," + std::to_string(b->b) : std::string("none"); }
static void tick(Ind* p, int ms) { NOW += ms; p->calc(0); }
static const std::string LINE_TXT = "ES 7750 \x97 bids pulled, not filled (62% in 3 min) \x97 less support ?";
static void hookLine(Ind* p) {
#if defined(BAS)
    auto& z = p->testState()->zr.e;
#else
    auto& z = p->testState()->zr.e;
#endif
    z.hookOn = true; z.hook.show = true; z.hook.text = LINE_TXT; z.hook.impl = -1; z.hook.locked = true;
    z.hook.hover = { "Pulling read \xB7 ES 7750 PDL (key) \xB7 support", "Bids resting at the level at arrival: 212 lots (38 orders)", "Study 10-14: held about 19 pp less often ?" };
}
static const mock::Draw* lineText(mock::Host& h) { for (auto& d : h.draws) if (d.type == "text" && d.text == LINE_TXT) return &d; return nullptr; }
static std::string lastBox(Ind* p) { const bp::Box& b = p->testState()->lastBox; return std::to_string(b.l) + "," + std::to_string(b.t) + "," + std::to_string(b.r) + "," + std::to_string(b.b); }

int main() {
    char tmpl[] = "/tmp/pnlXXXXXX"; const char* tmp = mkdtemp(tmpl); setenv("USERPROFILE", tmp, 1);
    const std::string flex = std::string(tmp) + "\\InvestorRT\\rtx\\lsFlexLevels"; mkdir(flex.c_str(), 0700);
    const std::string pp = flex + "\\" + NAME + ".place-ES.txt";
    mock::Host h; mock::current = &h; h.tick = 0.25f; h.seconds = 60; h.symbol = "ESZ6"; h.root = "ES"; h.paneTop = 0; h.paneBottom = 87; h.paneRight = 2000; h.scaleLeft = 1980; h.ppb = 10; h.barW = 20;
    h.listIndex = 0; h.parms[0] = 20; h.parms[4] = 10; h.parms[5] = 0; h.parms[6] = 0; h.box6 = 1;
    for (int i = 0; i < 31; ++i) h.bars.push_back(bar(T0 + 60UL * i));
    Ind* p = make(); tick(p, 100);
    // ---------------- Read mode by default ----------------
    h.draws.clear(); p->draw();
    CHECK(bigBlackBox(h) == nullptr && lineText(h) == nullptr && !hasText(h, "Live"), "(1.5.0) Read, no zone read: no box, no line, no numbers");
    hookLine(p); h.draws.clear(); p->draw();
    const mock::Draw* rl = lineText(h); if (rl && getenv("DBG")) std::printf("rl x %d y %d col %lx box %p\n", rl->x, rl->y, (unsigned long)rl->color, (const void*)bigBlackBox(h));
    CHECK(rl && rl->x == 7 && p->testState()->lastBox.l == 3 && p->testState()->lastBox.t == 3 && rl->y >= 3 && rl->y <= 3 + off::READ_LH && bigBlackBox(h) == nullptr && rl->color == off::C_RED_SPIKE, "(1.5.0) the read line at Top left (no box), red (support less defended)");
    CHECK(!hasText(h, "Live") && !hasText(h, "Sellers") && !hasText(h, "Bids"), "the numbers are not drawn");
    const int rlY = rl ? rl->y : -1;
    { std::ofstream f(pp.c_str()); f << (std::string(NAME) == "BidAskStats" ? "20,0,20,15,10\n" : std::string(NAME) == "PullStats" ? "20,0,20,15,10,0,1\n" : "20,0,20,15,10,0\n"); }
    tick(p, 1100); h.draws.clear(); p->draw();
    CHECK(lineText(h) && lineText(h)->x == 7, "a 1.2.x / 1.5.1 settings file (no Box shows field) = Read");
    // ---------------- hover over the read box ----------------
    {
        const int barsBefore = (int)h.draws.size(); (void)barsBefore;
        RTX_EVENT e; std::memset(&e, 0, sizeof(e)); e.type = E_MOUSE_MOVE; e.v.mouse.bar = 25; e.v.mouse.h = 900; e.v.mouse.v = 40;   // over the bars, right of the box
        p->mouse(&e); h.draws.clear(); p->draw();
        const std::string sigOut = lastBox(p);
        e.v.mouse.bar = 3; e.v.mouse.h = 100; e.v.mouse.v = 8;                                            // over the read line (candle 3 is under it)
        const int inv = h.invalidates; p->mouse(&e); h.draws.clear(); p->draw();
        const std::string rowZ = "Study 10-14: held about 19 pp less often ?";
        const mock::Draw* hb = bigBlackBox(h);
        CHECK(h.invalidates > inv && hb && hasText(h, "Pulling read \xB7 ES 7750 PDL (key) \xB7 support") && hasText(h, rowZ) && hb->y > rlY, "mouse over the read line: its detail box (every hover line) under it");
#if defined(BAS)
        CHECK(p->testState()->hover.bar != 3, "the candle under the box is not picked (the box keeps reading its candle)");
#else
        CHECK(p->testState()->hov.hover.bar != 3, "the candle under the box is not picked (the box keeps reading its candle)");
#endif
        const int inv2 = h.invalidates; p->mouse(&e); CHECK(h.invalidates == inv2, "moving inside the box: no extra redraw");
        e.v.mouse.h = 900; e.v.mouse.bar = 25; p->mouse(&e); h.draws.clear(); p->draw();
        CHECK(!hasText(h, rowZ) && bigBlackBox(h) == nullptr && lastBox(p) == sigOut, "mouse off the line: no detail box, the line in the same place");
    }
#if !defined(BAS)
    {   // hover candle freeze in the panes (the MboPane keeps its hovered candle while over the box)
        RTX_EVENT e; std::memset(&e, 0, sizeof(e)); e.type = E_MOUSE_MOVE; e.v.mouse.bar = 25; e.v.mouse.h = 900; e.v.mouse.v = 40; p->mouse(&e);
        const int before = p->testState()->hov.hover.bar;
        e.v.mouse.bar = 3; e.v.mouse.h = 100; e.v.mouse.v = 8; p->mouse(&e);
        CHECK(p->testState()->hov.hover.bar == before && before == 25, "over the line: the candle stays 25 (not the bar under the line)");
        e.v.mouse.bar = -1; e.v.mouse.h = 900; p->mouse(&e);
    }
#endif
    // ---------------- settings round trip ----------------
    {
        h.parms[0] = 20; h.lists[1] = 2; h.parms[BASE] = -45; h.parms[BASE + 1] = 10; h.lists[BASE + 2] = 0;
        const std::string before = readAll(pp);
        p->parmsApply(); CHECK(readAll(pp) == before, "Apply from the chart copy (it has a bar size): never saves");
        apply(p);
        const std::string f1 = readAll(pp);
        CHECK(f1.find(",-45,10,0\n") != std::string::npos && f1.compare(0, 5, "20,2,") == 0, "Apply: Position Top right, Offset X -45, Offset Y 10, Box shows Read in the per-market file");
        tick(p, 1100); h.draws.clear(); p->draw();
        const bp::Box b1 = p->testState()->lastBox;
        cppExtension::PNT e; e.set((int)h.bars.size() - 1, 0.0f, cppExtension::kBarRight);
        if (getenv("DBG")) std::printf("b1 %s eh %d file [%s]\n", lastBox(p).c_str(), (int)e.h, f1.c_str());
        CHECK(b1.w() > 0 && b1.r == e.h - 3 - 45 && b1.t == 3 + 10, "the line at Top right, 45 px left of the last bar, 10 px down");
        dispose(p); p = make(); tick(p, 100); hookLine(p); h.draws.clear(); p->draw();
        const bp::Box b2 = p->testState()->lastBox;
        CHECK(b2.w() > 0 && b2.l == b1.l && b2.t == b1.t, "restart: the same place from the file");
        // the dialog opens: filled from the file; an untouched stale control keeps the file's value
        h.parms[0] = 0; h.lists[1] = 0; h.parms[BASE] = 0; h.parms[BASE + 1] = 0; h.lists[BASE + 2] = 1;   // IRT's stale dialog values
        load(p);
        CHECK(readAll(pp) == f1, "opening the dialog never saves");
        CHECK(h.parms[0] == 20 && h.lists[1] == 2 && h.parms[BASE] == -45 && h.parms[BASE + 1] == 10 && h.lists[BASE + 2] == 0, "the dialog is filled from the file (Position Top right, -45, 10, Read)");
        apply(p); CHECK(readAll(pp) == f1, "OK without touching anything: the file is unchanged");
        h.parms[BASE] = 30; apply(p);
        CHECK(readAll(pp).find(",30,10,0\n") != std::string::npos, "he changes Offset X to 30: only that changes");
        // the fill did not reach IRT's dialog (it shows its own stale values) and he presses OK: nothing he did not touch changes
        const std::string f2 = readAll(pp);
        h.ignoreSets = true; h.parms[0] = 20; h.lists[1] = 0; h.parms[BASE] = 0; h.parms[BASE + 1] = 0; h.lists[BASE + 2] = 1;   // stale values shown
        load(p); apply(p);
        CHECK(readAll(pp) == f2, "a dialog showing stale values (the fill ignored): OK keeps the file's Position / offsets / mode");
        h.parms[BASE + 1] = 5; apply(p);
        CHECK(readAll(pp).find(",30,5,0\n") != std::string::npos && readAll(pp).compare(0, 5, "20,2,") == 0, "in that stale dialog he changes Offset Y to 5: only Offset Y changes");
        h.ignoreSets = false;
        load(p); h.lists[BASE + 2] = 1; apply(p);
        CHECK(readAll(pp).find(",1\n") != std::string::npos, "Box shows: Numbers saved");
        tick(p, 1100); h.draws.clear(); p->draw();
        CHECK(hasText(h, std::string(NAME) == "BidAskStats" ? "Sellers" : "Bids"), "Numbers: the compact numbers box is back");
        load(p); h.lists[BASE + 2] = 0; h.parms[BASE] = 0; h.parms[BASE + 1] = 0; h.lists[1] = 0; apply(p); tick(p, 1100);
    }
    // ---------------- fuzz the dialog ----------------
    {
        std::mt19937 rng(7); int bad = 0;
        for (int i = 0; i < 2000; ++i) {
            load(p);
            const int pick = (int)(rng() % 6);
            const int vals[] = { (int)(rng() % 2000) - 1000, INT_MIN, INT_MAX, 601, -601, 599 };
            if (pick == 0) h.parms[BASE] = vals[rng() % 6];
            else if (pick == 1) h.parms[BASE + 1] = vals[rng() % 6];
            else if (pick == 2) h.lists[BASE + 2] = (int)(rng() % 7) - 3;
            else if (pick == 3) h.lists[1] = (int)(rng() % 14) - 3;
            else if (pick == 4) h.parms[0] = vals[rng() % 6];
            else h.parms[BASE] = (int)(rng() % 1201) - 600;
            apply(p);
            const std::string ln = readAll(pp);
            std::vector<std::string> f = bp::fields(ln.substr(0, ln.size() - 1));
            const size_t n = f.size(); int dx = 0, dy = 0;
            if (n < 8 || !bp::intTok(f[n - 3], dx) || !bp::intTok(f[n - 2], dy) || !bp::offOk(dx) || !bp::offOk(dy) || (f[n - 1] != "0" && f[n - 1] != "1") || f[1].size() != 1 || f[1][0] < '0' || f[1][0] > '8') ++bad;
        }
        CHECK(bad == 0, "2,000 random / garbage dialog values: the file only ever holds valid values (offsets -600..600, mode 0/1, position 0-8)");
        tick(p, 1100); h.draws.clear(); p->draw();
        CHECK(lineText(h) != nullptr || bigBlackBox(h) != nullptr, "still draws after the fuzz");
        load(p); h.lists[BASE + 2] = 0; h.parms[BASE] = 0; h.parms[BASE + 1] = 0; h.lists[1] = 0; h.parms[0] = 20; apply(p); tick(p, 1100);
    }
    // ---------------- jitter: 1,000 draws ----------------
    {
        std::string first; int moved = 0;
        RTX_EVENT e; std::memset(&e, 0, sizeof(e)); e.type = E_MOUSE_MOVE;
        for (int i = 0; i < 1000; ++i) {
            h.bars.back().close = 7000.0f + (float)(i % 7) * 0.25f; h.bars.back().high = 7002.0f + (float)(i % 3);   // the forming bar updates
            if (i % 50 == 49) { h.bars.push_back(bar(h.bars.back().time + 60)); }                                        // a new bar now and then
            e.v.mouse.h = (short)(500 + (i * 37) % 900); e.v.mouse.v = (short)(10 + i % 60); e.v.mouse.bar = 5 + i % 20; p->mouse(&e);   // the mouse moves over the bars
            if (i % 2) tick(p, 10);
            h.draws.clear(); p->draw();
            const std::string sig = lastBox(p);
            if (i == 0) first = sig; else if (sig != first) { if (getenv("DBG") && moved < 3) std::printf("jitter i %d %s vs %s\n", i, sig.c_str(), first.c_str()); ++moved; }
        }
        CHECK(moved == 0, "1,000 draws (live bar updating, new bars, mouse over the bars): the line never moved or resized");
    }
    // ---------------- two charts of the same market ----------------
    {
        load(p); h.lists[1] = 8; h.parms[BASE] = -100; h.parms[BASE + 1] = 0; apply(p); tick(p, 1100);
        mock::Host h2 = h; h2.data = nullptr; h2.paneRight = 700; h2.scaleLeft = 690; h2.draws.clear(); h2.bars.resize(20);
        mock::current = &h2; Ind* q = make(); tick(q, 100); hookLine(q); tick(q, 1100); h2.draws.clear(); q->draw();
        const bp::Box b2 = q->testState()->lastBox; cppExtension::PNT e2; e2.set((int)h2.bars.size() - 1, 0.0f, cppExtension::kBarRight);
        CHECK(b2.w() > 0 && b2.l >= 3 && b2.r <= e2.h - 3 && b2.b <= h2.paneBottom - 3, "a second ES chart (last bar at 430 px): the same Bottom right - 100 px, clamped inside its own pane (never off-screen, never past its last bar)");
        mock::current = &h; h.draws.clear(); p->draw(); const bp::Box b1 = p->testState()->lastBox; cppExtension::PNT e1; e1.set((int)h.bars.size() - 1, 0.0f, cppExtension::kBarRight);
        CHECK(b1.w() > 0 && b1.r == e1.h - 3 - 100, "the first chart: placed against its own last bar");
        mock::current = &h2; dispose(q); mock::current = &h;
        load(p); h.lists[1] = 0; h.parms[BASE] = 0; apply(p); tick(p, 1100);
    }
    // ---------------- letters: white text, no box; nothing on no-data candles ----------------
    {
        h.draws.clear(); p->draw();
        int white = 0, black = 0; for (auto& d : h.draws) { if (d.type == "box" && d.color == 0x00FFFFFF && d.b - d.y > 3) ++white; if (d.type == "text" && d.text.size() <= 2 && d.color == 0x00000000) ++black; }
        CHECK(white == 0 && black == 0, "no white letter boxes, no black letters");
        int marks = 0; for (auto& d : h.draws) if (d.type == "text" && (d.text == "L" || d.text == "S" || d.text == "I") ) ++marks;
        CHECK(marks == 0, "candles with no order data (before the feed): no letters at all");
    }
    dispose(p);
    std::printf("panel host %s: %d passed, %d failed\n", NAME, passes, fails);
    return fails ? 1 : 0;
}
