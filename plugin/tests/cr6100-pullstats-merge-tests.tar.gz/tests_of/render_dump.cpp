// render_dump.cpp -- runs ONE plugin (-DWHICH=1 BidAskStats, 2 PullStats, 3 StackStats) through render_scenario.h on the mock host and
// prints its own draw calls (render_check.py turns the three dumps into render-check.png).
#if WHICH == 1
#include "BidAskStats.cpp"
long long bas_test_now_ms = 1000000; void* bas_test_cursor_wnd = nullptr;
typedef BidAskStats Ind; static long long& CLK = bas_test_now_ms; static const char* NAME = "BidAskStats 1.5.1 - who is ATTACKING (bars = lots of the biggest bid / ask at one price)";
#elif WHICH == 2
#include "PullStats.cpp"
namespace off { long long off_test_now_ms = 1000000; void* off_test_cursor_wnd = nullptr; }
typedef PullStats Ind; static long long& CLK = off::off_test_now_ms; static const char* NAME = "PullStats 1.1.1 - who is LEAVING (bars = lots pulled near price)";
#else
#include "StackStats.cpp"
namespace off { long long off_test_now_ms = 1000000; void* off_test_cursor_wnd = nullptr; }
typedef StackStats Ind; static long long& CLK = off::off_test_now_ms; static const char* NAME = "StackStats 1.1.1 - who is ARRIVING (bars = lots added near price)";
#endif
#include <fstream>
#include <unistd.h>
#include <utime.h>
namespace mock { Host* current = nullptr; Feed feed; }
#include "render_scenario.h"
int main(int argc, char** argv) {
    char tmpl[] = "/tmp/rndXXXXXX"; const char* tmp = mkdtemp(tmpl); setenv("USERPROFILE", tmp, 1);
    scen::levels(std::string(tmp) + "\\InvestorRT\\rtx\\lsFlexLevels");
    mock::Host h; mock::current = &h; h.paneTop = 0; h.paneBottom = 170; h.paneLeft = 0; h.barW = 22; h.ppb = 22; h.paneRight = 1130; h.scaleLeft = 1130; h.listIndex = 0;
    Ind* p = static_cast<Ind*>(CreateExtension());
    scen::run(h, CLK, [&]() { p->calc(0); });
    {   // (of140) the bridge's options file: the grid of the 21st candle's end, written 30 s later (it arrived on candle 22), fresh at 22..26
        const std::string F = std::string(tmp) + "\\InvestorRT\\rtx\\lsFlexLevels";
        h.now = (unsigned long)h.bars.back().time;
        const long long u21 = (long long)std::time(NULL) - (long long)(h.bars.back().time - (scen::T0 + 180UL * 21));
        { std::ofstream f((F + "\\LRA-Options-CL.csv").c_str()); f << "VERSION,1\nMARKET,CL\nASOF," << u21 << "\nOHIT,92.5,P,2.4,2.0,dn,put sellers,1200\nOPULL,CR,93.5,-30,dn,-\nOSTACK,PS,92.9,40,+,3,2.4,building\nOWALL,PS,92.9,2.4,+,40,building,-\nODEX,1200,111000000,2.1,0\nOHVL,92.6,above\n"; }
        struct utimbuf ub; ub.actime = ub.modtime = (time_t)(u21 + 30); utime((F + "\\LRA-Options-CL.csv").c_str(), &ub);
        CLK += 61000; p->calc(0);
    }
#ifdef ZREAD_TEST_HOOK
    if (getenv("ZHOOK")) {                                               // (1.5.0 mockup) the pane's read line as it reads at LonLO 92.90
        auto& z = p->testState()->zr.e; z.hookOn = true; z.hook.show = true; z.hook.locked = true;
        const int w = WHICH; z.hook.text = w == 1 ? "CL 92.90 \x97 sellers hitting 3.1x normal, price held ?" : w == 2 ? "CL 92.90 \x97 bids pulled, not filled (62% in 3 min) \x97 less support ?" : "CL 92.90 \x97 bids stacking 2.3x normal ?";
        z.hook.impl = w == 2 ? -1 : 1;                                   // (PullStats 1.5.0) the locked arrival read
        if (getenv("ZTEXT")) z.hook.text = getenv("ZTEXT");              // (PullStats 1.5.0 mockup) one of the three locked states
        if (getenv("ZIMPL")) z.hook.impl = std::atoi(getenv("ZIMPL"));
        if (getenv("ZNONE")) z.hook.show = false;                        //   ... or no line (approaching / measuring)
        z.hook.hover = { std::string(w == 1 ? "BidAskStats" : w == 2 ? "PullStats" : "StackStats") + " read \xB7 CL 92.90 LonLO (key) \xB7 support (price came down)",
                         "What it is / why it matters / numbers vs the 9:00 - 9:30 normal / how to use / an example", "Study 10-14 (MBO, 22 days): ... NOT YET proven ?" };
    }
#endif
    h.draws.clear(); p->draw(); double mn, mx; p->scale(0, (int)h.bars.size() - 1, &mn, &mx); h.draws.clear(); p->draw();
    if (argc > 2 && std::string(argv[2]) == "board") {                    // (fix1) the mouse is in the PRICE pane (another window) over bar argv[1]
        h.visFrom = 0; h.visTo = (int)h.bars.size() - 1;
        hb::fakeCursor() = 501; hb::publish(h.symbol, h.seconds, h.bars[(size_t)std::atoi(argv[1])].time, h.bars.front().time, h.bars.back().time);
        CLK += 10; p->calc(0); h.draws.clear(); p->draw();
    } else if (argc > 1) { RTX_EVENT e; std::memset(&e, 0, sizeof(e)); e.type = E_MOUSE_MOVE; e.v.mouse.bar = std::atoi(argv[1]); p->mouse(&e); h.draws.clear(); p->draw(); }
    std::printf("AXIS\t%.4f\t%.4f\n", mn, mx);
    scen::dump(h, NAME);
    if (WHICH == 1) scen::candles(h);
    return 0;
}
