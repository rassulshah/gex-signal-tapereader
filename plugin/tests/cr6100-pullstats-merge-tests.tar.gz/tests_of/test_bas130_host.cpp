// test_bas130_host.cpp -- lsBidAskStats 1.3.0 additions against the mock host: the order feed (S / L letters), the message line,
// the info box, spike labels, the session record (write / reload), the params file, drain limits, decide timing.
#include "BidAskStats.cpp"
#include <cstdio>
#include <unistd.h>
#include <dirent.h>
namespace mock { Host* current = nullptr; Feed feed; }
long long bas_test_now_ms = 1000000;
void* bas_test_cursor_wnd = nullptr;
static int fails = 0, passes = 0;
#define CHECK(c, m) do { if (c) ++passes; else { ++fails; std::printf("FAIL %d %s\n", __LINE__, m); } } while (0)
static std::string readAll(const std::string& p) { std::ifstream f(p.c_str()); std::stringstream s; s << f.rdbuf(); return s.str(); }
static void dispose(BidAskStats* p) { p->destroy(); p->~BidAskStats(); ::operator delete(p); }
static BidAskStats* make() { return static_cast<BidAskStats*>(CreateExtension()); }
static mock::Bar bar(unsigned long t, std::vector<std::pair<long, long>> bidAsk, float p0 = 7000.0f) {
    mock::Bar b; b.time = t; b.volume = 0; b.close = p0; b.low = p0 - 0.5f; b.high = p0 + 1.0f;
    for (size_t k = 0; k < bidAsk.size(); ++k) { b.rows.push_back(mock::Price(p0 + 0.25f * (float)k, bidAsk[k].second, bidAsk[k].first, bidAsk[k].first + bidAsk[k].second)); b.volume += (unsigned long)(bidAsk[k].first + bidAsk[k].second); }
    return b;
}
static const unsigned long T0 = 1791900000UL;
static void fill(unsigned char a, unsigned char side, float px, unsigned long size, RTDATE t, int id, int aggr) { mock::feed.push(a, side, px, size, t, id); mock::feed.ev.back().aggressorOrderID = aggr; }
static const mock::Draw* textAt(mock::Host& h, const std::string& t, COLOR c = 0xFFFFFFFF) { for (auto& d : h.draws) if (d.type == "text" && d.text == t && (c == 0xFFFFFFFF || d.color == c)) return &d; return nullptr; }
// (1.5.2) the read may wrap to 2 lines beside the numbers box: the lines joined
static std::string msgLine(mock::Host& h) { std::string o; for (auto& d : h.draws) if (d.type == "text" && d.y < h.paneTop + 35 && (d.color == off::C_NEUTRAL || d.color == off::C_GREEN_SPIKE || d.color == off::C_RED_SPIKE)) o += (o.empty() ? "" : " ") + d.text; return o.empty() ? "?" : o; }
// (1.5.1) the wider info box leaves the message less room: it may be one of fitMessage's shortened forms (large-order clause / pace words
// dropped, lvls) or a "..." cut of the last one - never anything else
static bool fitsFrom(const std::string& got, const std::string& full) {
    const std::vector<std::string> v = off::compactVariants(full);
    if (got == full) return true;                                         // (1.5.2) wrapped, not cut
    for (const std::string& t : v) if (got == t) return true;
    const std::string& last = v.back();
    return got.size() > 3 && got.compare(got.size() - 3, 3, "...") == 0 && last.compare(0, got.size() - 3, got.substr(0, got.size() - 3)) == 0;
}
[[maybe_unused]] static COLOR msgColour(mock::Host& h) { for (auto& d : h.draws) if (d.type == "text" && d.y < h.paneTop + 20 && (d.color == off::C_NEUTRAL || d.color == off::C_GREEN_SPIKE || d.color == off::C_RED_SPIKE)) return d.color; return 1; }
static std::string boxValue(mock::Host& h, const std::string& label, COLOR* color = nullptr) {
    for (size_t i = 0; i + 1 < h.draws.size(); ++i) if (h.draws[i].type == "text" && h.draws[i].text == label) { if (color) *color = h.draws[i + 1].color; return h.draws[i + 1].text; }
    return "?";
}
// a drawn line equal to want, or cut with "..." at the last bar of this narrow mock chart (a prefix of it)
static bool cutOf(const std::string& got, const std::string& want) {
    if (got == want) return true;
    return got.size() > 8 && got.compare(got.size() - 3, 3, "...") == 0 && want.compare(0, got.size() - 3, got.substr(0, got.size() - 3)) == 0;
}
static std::string clk(unsigned long t) { time_t v = (time_t)t; struct tm x; gmtime_r(&v, &x); return off::clockShort(x.tm_hour, x.tm_min); }

// (1.0.1, Rassul 1:43 PM) NO WHITE OUTLINE: every rectangle except the info box (black fill, grey border) is drawn flat - width 0,
// border = fill, and the PEN in effect (IRT draws the perimeter with it) = fill. Returns the number of offending rectangles.
static int outlined(mock::Host& h, int* flat = nullptr) {
    int bad = 0, ok = 0;
    for (auto& d : h.draws) if (d.type == "box" && d.color != 0x00000000) { if (d.width != 0 || d.border != d.color || d.pen != d.color) ++bad; else ++ok; }
    if (flat) *flat = ok;
    return bad;
}
static int whitePenOnColour(mock::Host& h) { int n = 0; for (auto& d : h.draws) if (d.type == "box" && d.color != 0x00FFFFFF && d.color != 0x00000000 && (d.pen == 0x00FFFFFF || d.border == 0x00FFFFFF)) ++n; return n; }

// (1.5.2) the settings window's copy has no bar size: only there are the dialog values real (Apply / Load from the chart copy do nothing)
#define APPLY(p) do { const std::string sv_ = mock::current->period; mock::current->period = ""; (p)->parmsApply(); mock::current->period = sv_; } while (0)
#define LOAD(p) do { const std::string sv_ = mock::current->period; mock::current->period = ""; (p)->parmsLoad(); mock::current->period = sv_; for (int k_ = 0; k_ < 16; ++k_) { mock::current->floatSet[k_] = false; mock::current->lists[k_] = -99; } } while (0)
int main() {
    char tmpl[] = "/tmp/b13XXXXXX"; const char* tmp = mkdtemp(tmpl); setenv("USERPROFILE", tmp, 1);
    const std::string flex = std::string(tmp) + "\\InvestorRT\\rtx\\lsFlexLevels";
    mock::Host h; mock::current = &h; h.tick = 0.25f; h.seconds = 60; h.symbol = "ESZ6"; h.root = "ES"; h.paneBottom = 300; h.paneRight = 1200; h.ppb = 20; h.barW = 20; h.listIndex = 0;   // (1.5.1) 20 px bars: the wider info box (Crowd row) still leaves room for the message and labels
    // 30 quiet closed bars + bar 30 forming (it will be a bid spike: 50 vs 10)
    for (int i = 0; i < 30; ++i) h.bars.push_back(bar(T0 + 60UL * i, { {10, 10}, {5, 5} }));
    h.bars.push_back(bar(T0 + 60UL * 30, { {50, 10}, {5, 5} }));
    BidAskStats* p = make(); p->calc(0); BASState* S = p->testState();
    CHECK((h.flags & TRACK_MOUSE) && (h.xflags & CALL_CONTINUOUSLY) && (h.flags & VAP_REQUIRED), "flags: TRACK_MOUSE, VAP_REQUIRED + CALL_CONTINUOUSLY (the feed drains while idle)");
    CHECK(mock::feed.opens == 1 && mock::feed.lastTicker == "ESZ6" && S->feed.via == "chart symbol ESZ6", "the order feed opened once with the chart symbol");
    CHECK(S->fin.size() == 30 && !S->fin.begin()->second.dbo && S->fin.begin()->second.let[0].empty(), "bars before the feed: decided without letters (dbo 0, no fake history)");
    // bar 30 (end T0+1800 covers [T0+1740, T0+1800)): a resting bid book, then ONE seller (aggressor 900) sweeps 3 prices, 25 lots
    const RTDATE in30 = T0 + 1800 - 30;
    fill(0, 1, 7000.00f, 10, in30, 11, 0); fill(0, 1, 6999.75f, 10, in30, 12, 0); fill(0, 1, 6999.50f, 10, in30, 13, 0);
    fill(3, 1, 7000.00f, 10, in30, 11, 900); fill(3, 1, 6999.75f, 10, in30, 12, 900); fill(3, 1, 6999.50f, 5, in30, 13, 900);
    bas_test_now_ms += 100; p->calc(0);
    CHECK(S->e.events == 6 && S->firstBarKey == (long long)(T0 + 1800) && S->accs.count(T0 + 1800), "events go to the forming candle by their stamp");
    h.bars.push_back(bar(T0 + 60UL * 31, { {10, 10} }));                   // bar 30 closes
    bas_test_now_ms += 100; p->calc(0);
    CHECK(!S->fin.count(T0 + 1800), "not decided before 0.5 s");
    bas_test_now_ms += 500; p->calc(0);
    const BasFin F = S->fin[T0 + 1800];
    if (getenv("DBG")) std::printf("let [%s][%s] msg [%s]\n", F.let[0].c_str(), F.let[1].c_str(), F.msg.line1.c_str());
    CHECK(F.dbo && F.let[0] == "SL" && F.let[1].empty() && F.r.sweepLv[0] == 3 && F.r.aggrMax[0] == 25 && F.r.partial, "decided: S + L on the bid (sellers) side; the first feed candle is partial");
    const std::string MSG30 = "Sellers hit the bid with a 50-lot (5.0x) fast (p 3.7x ?), swept 3 levels with one 25-lot order - price held: buyers absorbing.";
    CHECK(F.msg.line1 == MSG30 && F.msg.impl == nl::BULL, "(1.5.0) message: SPEC grammar - lots (ratio), pace fast (? until PACE_SHOW,on), sweep + large, price held = buyers absorbing");
    CHECK(F.pc.p100[0] == 367 && F.pc.note[0] == 1 && F.pc.gate == 1 && F.r.pace100[0] == 367, "(1.5.0) pace: 55 lots at the bid in 60 s vs the rolling norm (10 lots / 60 s) = 3.7x, fast, recorded");
    h.draws.clear(); p->draw();
    { const std::string full = clk(T0 + 1800) + " " + F.msg.line1, got = msgLine(h);
      const bool pref = fitsFrom(got, full);
      if (getenv("DBG")) std::printf("got [%s]\nfull[%s]\n", got.c_str(), full.c_str());
      (void)pref; CHECK(!F.msg.line1.empty() && msgLine(h) == "?", "(1.6.0) the candle message is decided and recorded, no longer drawn (no zone: no read line)");
    }
    const mock::Draw* sL = textAt(h, "S", 0x00FFFFFF); const mock::Draw* lL = textAt(h, "L", 0x00FFFFFF);
    const int xc = 50 + 30 * h.barW;
    CHECK(sL && lL && sL->x < xc + 1 && lL->x < xc + 1 && sL->y < lL->y && lL->y > h.paneBottom - 12, "letters: S over L at the BOTTOM of the red (left) bar (1.5.2: white text)");
    int white = 0; for (auto& d : h.draws) if (d.type == "box" && d.color == 0x00FFFFFF && d.x >= xc - 12 && d.r <= xc + 12 && d.b >= h.paneBottom - 30) ++white;
    CHECK(white == 0, "(1.5.2) no white letter boxes (Rassul 07:16 'remove the white boxes')");
    { int flat = 0; CHECK(outlined(h, &flat) == 0 && flat > 60 && whitePenOnColour(h) == 0, "(1.3.1) no white outline: every bar and letter box drawn flat (pen = border = fill), no white pen on a coloured bar"); }
    COLOR c = 0; CHECK(boxValue(h, "Sweep", &c) == "3 lvls" && c == C_BID && boxValue(h, "Large") == "25" && boxValue(h, "Lots") == "50 (5.0x)" && boxValue(h, "Pace") == "3.7x (2.0x) ?", "(1.5.0) info box: Sellers column - Lots (ratio), Pace (thr) ?, Sweep, Large (red)");
    CHECK(textAt(h, "Live", C_LABEL) != nullptr, "box header Live");
    // spike labels: "5.0x" over "50", bright red, just above the bar top
    const mock::Draw* q = textAt(h, "50", C_BID_SPIKE); const mock::Draw* x = textAt(h, "5.0x", C_BID_SPIKE);
    int barTop = 0; for (auto& d : h.draws) if (d.type == "box" && d.color == C_BID_SPIKE) barTop = d.y;
    const mock::Draw* pl = textAt(h, "p 3.7x", C_BID_SPIKE);
    CHECK(q && x && pl && x->y < pl->y && pl->y < q->y && q->y < barTop && barTop - q->y <= 2 * off::LABEL_LH, "(1.5.0) spike label in 3 rows: ratio / pace / lots, above the spike bar, in its colour");
    int labels = 0; for (auto& d : h.draws) if (d.type == "text" && d.y > h.paneTop + 34 && (d.color == C_BID_SPIKE || d.color == C_ASK_SPIKE)) ++labels;
    CHECK(labels == 3, "labels only on spikes (one spike: 3 rows)");
    // hover: box header and message line move together
    RTX_EVENT e; std::memset(&e, 0, sizeof(e)); e.type = E_MOUSE_MOVE; e.v.mouse.bar = 10; p->mouse(&e);
    h.draws.clear(); p->draw();
    CHECK(msgLine(h) == "?" && boxValue(h, "Sweep") == "n/a", "hover bar 10: its box (feed not live then: n/a); (1.6.0) no message line");
    { time_t v = (time_t)(T0 + 600); struct tm t; gmtime_r(&v, &t); CHECK(textAt(h, bas::clock12(t.tm_hour, t.tm_min), C_LABEL) != nullptr, "box header = the hovered candle's time"); }
    e.v.mouse.bar = 30; p->mouse(&e); h.draws.clear(); p->draw();
    { const std::string full = clk(T0 + 1800) + " " + MSG30, got = msgLine(h);
      const bool pref = fitsFrom(got, full);
      (void)pref; (void)got; CHECK(boxValue(h, "Large") == "25", "hover bar 30: its box"); }
    { int flat = 0; CHECK(outlined(h, &flat) == 0 && whitePenOnColour(h) == 0 && flat > 60, "(1.3.1) hovering the S/L candle: still no outline on its bars or its letter boxes"); }
    e.v.mouse.bar = -1; p->mouse(&e);
    {   // (1.5.1, Rassul 9:25 PM) the CHART-WIDE hover: another pane's plugin (the Tape Reader in the price pane, window 501) publishes the
        // candle under the mouse; this pane follows it without the mouse inside it; Live when the mouse leaves; other charts never interfere
        h.visFrom = 0; h.visTo = (int)h.bars.size() - 1;
        const unsigned long long t0 = h.bars.front().time, t1 = h.bars.back().time;
        hb::fakeCursor() = 501; hb::publish("ESZ6", 60, h.bars[20].time, t0, t1);
        const int inv0 = h.invalidates; bas_test_now_ms += 10; p->calc(0);
        CHECK(S->hover.bar == 20 && h.invalidates > inv0, "mouse over the price pane: this pane follows candle 20 (redrawn once)");
        const int inv1 = h.invalidates; bas_test_now_ms += 10; p->calc(0);
        CHECK(h.invalidates == inv1, "no change: no redraw");
        h.draws.clear(); p->draw();
        { time_t v = (time_t)h.bars[20].time; struct tm t; gmtime_r(&v, &t); CHECK(textAt(h, bas::clock12(t.tm_hour, t.tm_min), C_LABEL) != nullptr && textAt(h, "Live", C_LABEL) == nullptr, "its info box shows candle 20"); }
        hb::fakeCursor() = 999; bas_test_now_ms += 10; p->calc(0);
        CHECK(S->hover.bar == -1, "mouse left the chart: back to Live");
        hb::fakeCursor() = 601; hb::publish("NQZ6", 60, h.bars[10].time, t0, t1); bas_test_now_ms += 10; p->calc(0);
        CHECK(S->hover.bar == -1, "a second chart (NQ) under the mouse: this chart stays Live");
        hb::publish("ESZ6", 60, h.bars[10].time, h.bars[5].time, t1); bas_test_now_ms += 10; p->calc(0);
        CHECK(S->hover.bar == -1, "a second ES chart (other visible range) under the mouse: this chart stays Live");
        hb::fakeCursor() = 0; unsetenv("LRA_HV_ESZ6_60"); unsetenv("LRA_HV_NQZ6_60"); h.visFrom = h.visTo = -1;
    }
    // the session record
    const std::string rec = flex + "\\BidAskStats\\ES-ESZ6-60-20261013.csv";
    const std::string R = readAll(rec);
    CHECK(R.find("bar_time|ct_time|dbo|bid|ask|bbid|bask|partial|") != std::string::npos && R.find(std::to_string(T0 + 1800) + "|" + clk(T0 + 1800) + "|1|50|10|") != std::string::npos
          && R.find("|SL||1|0|-|-|bull||" + MSG30 + "|BBid 50") != std::string::npos, "record: numbers, letters, spike flags, implication, message, numbers line");
    size_t rows = 0; for (char ch : R) rows += ch == '\n'; CHECK(rows == 2 + 31, "every closed candle of the session once (31) + 2 header lines");
    // restart within the session: the letters and message come back from the record (no events for bar 30 any more)
    dispose(p); h.data = nullptr; mock::feed.ev.clear(); mock::feed.at = 0;
    p = make(); bas_test_now_ms += 100; p->calc(0); S = p->testState();
    CHECK(S->fin.count(T0 + 1800) && S->fin[T0 + 1800].fromFile && S->fin[T0 + 1800].let[0] == "SL" && S->fin[T0 + 1800].msg.line1 == F.msg.line1, "restart: letters + message reloaded");
    CHECK(S->file.loaded == 31 && readAll(rec) == R, "the record is not rewritten by a reload");
    // params file: sweepLevels 4 -> a 3-price sweep is no longer S; bad line reported in the status file
    { std::ofstream f((flex + "\\LRA-OrderFlow-ES.csv").c_str()); f << "VERSION,1\nMARKET,ES\nPARAM,sweepLevels,4\nPARAM,largeLotPct,7\n"; }
    bas_test_now_ms += 6000;
    const RTDATE in32 = T0 + 60 * 32 - 20;
    fill(0, 0, 7001.0f, 10, in32, 21, 0); fill(0, 0, 7001.25f, 10, in32, 22, 0); fill(0, 0, 7001.5f, 10, in32, 23, 0);
    fill(3, 0, 7001.0f, 2, in32, 21, 901); fill(3, 0, 7001.25f, 2, in32, 22, 901); fill(3, 0, 7001.5f, 2, in32, 23, 901);
    h.bars.back() = bar(T0 + 60UL * 31, { {10, 10} }); h.bars.push_back(bar(T0 + 60UL * 32, { {10, 60} }));
    p->calc(0);
    h.bars.push_back(bar(T0 + 60UL * 33, { {10, 10} })); bas_test_now_ms += 100; p->calc(0); bas_test_now_ms += 600; p->calc(0);
    CHECK(S->params.load.p.sweepLevels == 4 && S->fin.count(T0 + 1920) && S->fin[T0 + 1920].r.sweepLv[1] == 3 && S->fin[T0 + 1920].let[1].empty(), "params sweepLevels 4: a 3-level sweep gets no S");
    bas_test_now_ms += 61000; p->calc(0);
    const std::string st = readAll(flex + "\\BidAskStats.status-ES-ESZ6-60.txt");
    CHECK(st.find("VERSION,1.6.0") != std::string::npos && st.find("PARAMS_SOURCE,file (1 params)") != std::string::npos && st.find("PARAMS_NOTE,largeLotPct: bad value '7' (50..100) - default 99") != std::string::npos
          && st.find("sweepLevels=4(file)") != std::string::npos && st.find("MBO,subscribed 1,opened_with chart symbol ESZ6") != std::string::npos && st.find("LETTERS_TODAY,") != std::string::npos, "status: params, reasons, feed state, letters");
    // drain limits: a 12,000-event backlog is read 5,000 per call, carried, and a closing candle waits (<= 5 s) for it
    mock::feed.ev.clear(); mock::feed.at = 0;
    for (int i = 0; i < 12000; ++i) fill(0, 1, 6990.0f, 1, T0 + 60 * 34 - 10, 100000 + i, 0);
    h.bars.push_back(bar(T0 + 60UL * 34, { {10, 10} })); bas_test_now_ms += 10; p->calc(0);
    CHECK(mock::feed.at == 5000 && S->feed.lastCapped && S->feed.capHits >= 1, "one call reads at most 5,000 events");
    h.bars.push_back(bar(T0 + 60UL * 35, { {10, 10} })); bas_test_now_ms += 600; p->calc(0);
    CHECK(mock::feed.at == 10000 && !S->fin.count(T0 + 60 * 34), "backlog carried; the closed candle waits while the drain is capped");
    bas_test_now_ms += 600; p->calc(0);
    CHECK(mock::feed.at == 12000 && !S->feed.lastCapped, "caught up on the third call");
    bas_test_now_ms += 600; p->calc(0);
    CHECK(S->fin.count(T0 + 60 * 34) && S->fin[T0 + 60 * 34].r.events == 12000, "decided once caught up, with every event");
    // ================= (of140) R? stop run through the host, the oHit line, the pace gate =================
    {
        { std::ofstream f((flex + "\\LRA-KeyLevels-ES.csv").c_str()); f << "KEYLV,1," << (long long)std::time(NULL) << "\nL|PDL|6999.75|x\n"; }
        { std::ofstream f((flex + "\\LRA-OrderFlow-ES.csv").c_str()); f << "VERSION,1\nMARKET,ES\nPACE_SHOW,on\n"; }
        bas_test_now_ms += 61000; p->calc(0);
        const unsigned long tb = T0 + 60UL * 36;
        h.bars.push_back(bar(tb, { {300, 10} }, 6999.5f));                    // the break bar: low 6999.0 under PDL 6999.75, closes 6999.5 (outside), a bid spike
        h.bars.push_back(bar(tb + 60, { {10, 10} }));                          // forming
        bas_test_now_ms += 100; p->calc(0); bas_test_now_ms += 600; p->calc(0); bas_test_now_ms += 600; p->calc(0);
        CHECK(S->fin.count(tb) && S->ser.bars[(long long)tb].bidSpike && S->srEv.empty() && S->det.pending.size() == 1, "R?: the break bar closed outside with a bid spike - watched, nothing drawn yet");
        h.draws.clear(); p->draw(); CHECK(textAt(h, "R?") == nullptr, "no mark before price is back inside");
        h.bars.push_back(bar(tb + 120, { {10, 10} }));                         // bar tb+60 (closes 7000.0: back above PDL) is now closed
        bas_test_now_ms += 100; p->calc(0); bas_test_now_ms += 600; p->calc(0); bas_test_now_ms += 600; p->calc(0);
        CHECK(S->srEv.count((long long)tb) && S->srEv[(long long)tb][0].dir == -1 && S->srEv[(long long)tb][0].reclaimT == (long long)(tb + 60), "R?: back inside the next bar - the event, on the break bar, decided at the reclaim bar's close");
        h.draws.clear(); p->draw();
        const mock::Draw* rm = textAt(h, "R?", C_SR_GREEN);
        CHECK(rm != nullptr && rm->y > h.paneBottom - 30, "a green R? (sellers trapped) at the bottom of the break bar's sellers' bar");
        RTX_EVENT e3; std::memset(&e3, 0, sizeof(e3)); e3.type = E_MOUSE_MOVE; e3.v.mouse.bar = 36; p->mouse(&e3); h.draws.clear(); p->draw();
        CHECK(sr::message(S->srEv[(long long)tb][0]).find("Stop run? below PDL - sellers trapped (25.0x spike") == 0
              && boxValue(h, "StopRun") == "below PDL 3t?", "hover the break bar: the stop-run message and the StopRun row (Sellers column)");
        CHECK(boxValue(h, "Pace").find(" ?") == std::string::npos && S->fin[(long long)tb].pc.gate == ofo::GATE_ON, "PACE_SHOW,on in force when the candle closed: the pace without ?");
        e3.v.mouse.bar = -1; p->mouse(&e3);
        CHECK(readAll(flex + "\\BidAskStats\\ES-ESZ6-60-20261013.csv").find("\nSR|" + std::to_string(tb) + "|") != std::string::npos, "the stop run is in the session record (SR| line)");
        // the oHit line
        const COLOR BLUE = 0x0058A6FF;
        { std::ofstream f((flex + "\\LRA-Options-ES.csv").c_str()); f << "VERSION,1\nMARKET,ES\nASOF," << (long long)std::time(NULL) - 120 << "\nOHIT,5800,P,2.4,2.0,dn,put sellers,1200\nODEX,1200,487000000,2.1,1\n"; }
        h.now = h.bars.back().time; bas_test_now_ms += 6000; p->calc(0); h.draws.clear(); p->draw();
        { std::string got; int y = -1, my = -1; for (auto& d : h.draws) if (d.type == "text") { if (d.color == BLUE) { got = d.text; y = d.y; } else if (d.y < h.paneTop + 20 && d.color == off::C_GREEN_SPIKE) my = d.y; }
          (void)my; CHECK(cutOf(got, "Unsigned put volume 2.4x pace ? - buyer / seller unknown") && y >= 0, "(1.6.0, approval MARK ?) Numbers: the blue line says the options volume is unsigned"); }
        e3.v.mouse.bar = 30; p->mouse(&e3); h.draws.clear(); p->draw(); int nb = 0; for (auto& d : h.draws) if (d.type == "text" && d.color == BLUE) ++nb;
        CHECK(nb == 0, "a candle before the grid arrived: no oHit line"); e3.v.mouse.bar = -1; p->mouse(&e3);
        const std::string st2 = readAll(flex + "\\BidAskStats.status-ES-ESZ6-60.txt"); bas_test_now_ms += 61000; p->calc(0);
        CHECK(readAll(flex + "\\BidAskStats.status-ES-ESZ6-60.txt").find("OPTIONS,ok") != std::string::npos && readAll(flex + "\\BidAskStats.status-ES-ESZ6-60.txt").find("STOPRUN,") != std::string::npos, "status: options + stop run lines");
        (void)st2;
        // restart: the R? comes back from the record, exactly
        dispose(p); h.data = nullptr; mock::feed.ev.clear(); mock::feed.at = 0;
        p = make(); bas_test_now_ms += 100; p->calc(0); S = p->testState(); h.draws.clear(); p->draw();
        CHECK(S->srLoaded == 1 && S->srEv.count((long long)tb) && textAt(h, "R?", C_SR_GREEN) != nullptr, "restart in the session: the R? reloads from the record");
        std::remove((flex + "\\LRA-KeyLevels-ES.csv").c_str()); std::remove((flex + "\\LRA-Options-ES.csv").c_str());
    }
    // two charts: own feeds
    mock::Host h2 = h; h2.data = nullptr; h2.symbol = "NQZ6"; h2.root = "NQ"; mock::current = &h2;
    const int opens0 = mock::feed.opens;
    BidAskStats* q2 = make(); q2->calc(0);
    CHECK(mock::feed.opens == opens0 + 1 && mock::feed.lastTicker == "NQZ6" && q2->testState() != S, "a second chart opens its own feed");
    dispose(q2); mock::current = &h;
    // the feed not subscribed: the indicator still works (VAP), state says so
    dispose(p); h.data = nullptr; mock::feed.subscribe = false; mock::feed.ev.clear(); mock::feed.at = 0;
    p = make(); p->calc(0); bas_test_now_ms += 1500; p->calc(0); S = p->testState();
    CHECK(S->feed.flag == 0 && S->feed.stateText(bas_test_now_ms) == "MBO: not subscribed" && S->ser.bars.size() > 30, "not subscribed: bars still drawn from VAP, state says so");
    const long long gn = mock::feed.getNext; for (int i = 0; i < 5; ++i) { bas_test_now_ms += 100; p->calc(0); }
    CHECK(mock::feed.getNext - gn <= 2, "re-subscribe asked at most once a second");
    mock::feed.subscribe = true; mock::feed.throwOnNext = true; bas_test_now_ms += 1100; p->calc(0);
    CHECK(S->feed.dead && S->feed.faults == 1, "a faulting read: the feed is closed for good (never re-entered)");
    mock::feed.throwOnNext = false;
    dispose(p);
    std::printf("host 1.3.x: %d passed, %d failed\n", passes, fails); return fails ? 1 : 0;
}
