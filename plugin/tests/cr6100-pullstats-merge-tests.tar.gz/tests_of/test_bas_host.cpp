// test_bas_host.cpp -- lsBidAskStats 1.2.0 against the mock host.
// g++ -std=c++17 -DBAS_TEST_CLOCK -Imock -I.. test_bas_host.cpp -o th && ./th
#include "BidAskStats.cpp"
#include <cstdio>
#include <unistd.h>
#include <dirent.h>
#include <climits>
namespace mock { Host* current = nullptr; Feed feed; }
long long bas_test_now_ms = 1000000;
void* bas_test_cursor_wnd = nullptr;
static int fails = 0, passes = 0;
#define CHECK(c, m) do { if (c) ++passes; else { ++fails; std::printf("FAIL %d %s\n", __LINE__, m); } } while (0)
static std::string readAll(const std::string& p) { std::ifstream f(p.c_str()); std::stringstream s; s << f.rdbuf(); return s.str(); }
static std::string g_tmp;
// (1.3.0) a disposed indicator's session record is wiped: the next test section reuses the same bar times with other data
static void wipe() { DIR* d = opendir("/tmp"); if (!d) return; const std::string pre = g_tmp.substr(5) + "\\"; while (dirent* e = readdir(d)) { const std::string n = e->d_name; if (n.compare(0, pre.size(), pre) == 0 && n.find("\\BidAskStats\\") != std::string::npos) std::remove(("/tmp/" + n).c_str()); } closedir(d); }
static void dispose(BidAskStats* p) { p->destroy(); p->~BidAskStats(); ::operator delete(p); wipe(); }
static BidAskStats* make() { return static_cast<BidAskStats*>(CreateExtension()); }
// a bar: rows (price, ask = buyVolume, bid = sellVolume)
static mock::Bar bar(unsigned long t, std::vector<std::pair<long, long>> bidAsk, float p0 = 7000.0f) {
    mock::Bar b; b.time = t; b.volume = 0;
    for (size_t k = 0; k < bidAsk.size(); ++k) {
        const long bid = bidAsk[k].first, ask = bidAsk[k].second;
        b.rows.push_back(mock::Price(p0 + 0.25f * (float)k, ask, bid, ask + bid)); b.volume += (unsigned long)(ask + bid);
    }
    return b;
}
static unsigned long T0 = 1791900000UL;   // 2026-10-13
static void fill(mock::Host& h, int n, unsigned seed) {
    h.bars.clear(); unsigned x = seed;
    for (int i = 0; i < n; ++i) {
        std::vector<std::pair<long, long>> r;
        for (int k = 0; k < 6; ++k) { x = x * 1103515245u + 12345u; const long b = (long)(x >> 20) % 90 + 1; x = x * 1103515245u + 12345u; const long a = (long)(x >> 20) % 90 + 1; r.push_back(std::make_pair(b, a)); }
        h.bars.push_back(bar(T0 + 60UL * (unsigned long)i, r));
    }
}
// reference: the stats recomputed from scratch with the logic (closed bars 0..n-2)
static bas::Series reference(mock::Host& h, int ratioBars) {
    bas::Series s;
    for (size_t i = 0; i + 1 < h.bars.size(); ++i) {
        mock::Bar& b = h.bars[i]; std::vector<bas::Row> r;
        for (auto& p : b.rows) r.push_back(bas::Row{ p.price, p.sell, p.buy });
        s.add((long long)b.time, b.failStats ? bas::BarMax() : bas::maxOf(r, h.tick), ratioBars);
    }
    return s;
}
static bool same(const bas::Stat& a, const bas::Stat& b) {
    return a.m.ok == b.m.ok && a.m.bid == b.m.bid && a.m.ask == b.m.ask && a.m.bidPx == b.m.bidPx && a.m.askPx == b.m.askPx && a.bBid == b.bBid && a.bAsk == b.bAsk
        && a.bidRatioOk == b.bidRatioOk && a.askRatioOk == b.askRatioOk && a.bidRatio == b.bidRatio && a.askRatio == b.askRatio;
}
// (1.5.0) the two-column box: label, then the Sellers value, then the Buyers value
static std::string boxValue2(mock::Host& h, const std::string& label, int col, COLOR* color = nullptr) {
    for (size_t i = 0; i + 2 < h.draws.size(); ++i) if (h.draws[i].type == "text" && h.draws[i].text == label) { if (color) *color = h.draws[i + 1 + col].color; return h.draws[i + 1 + col].text; }
    return "?";
}
static std::string lotsOf(const bas::Stat& k, int side) { return k.m.ok ? std::to_string(side == 0 ? k.m.bid : k.m.ask) + " (" + bas::fmtRatio(side == 0 ? k.bidRatioOk : k.askRatioOk, side == 0 ? k.bidRatio : k.askRatio) + ")" : std::string("n/a"); }
static std::string boxValue(mock::Host& h, const std::string& label, COLOR* color = nullptr) {
    for (size_t i = 0; i + 1 < h.draws.size(); ++i) if (h.draws[i].type == "text" && h.draws[i].text == label) { if (color) *color = h.draws[i + 1].color; return h.draws[i + 1].text; }
    return "?";
}
// (1.2.0) a bid bar is dark red or (spike) bright red, an ask bar dark green or (spike) bright green
static bool sameSide(COLOR drawn, COLOR c) { return drawn == c || (c == C_BID && (drawn == C_BID_BAR || drawn == C_BID_SPIKE)) || (c == C_ASK && (drawn == C_ASK_BAR || drawn == C_ASK_SPIKE)); }
static int rects(mock::Host& h, COLOR c) { int n = 0; for (auto& d : h.draws) if (d.type == "box" && sameSide(d.color, c)) ++n; return n; }

// (1.5.2) the settings window's copy has no bar size: only there are the dialog values real (Apply / Load from the chart copy do nothing)
#define APPLY(p) do { const std::string sv_ = mock::current->period; mock::current->period = ""; (p)->parmsApply(); mock::current->period = sv_; } while (0)
#define LOAD(p) do { const std::string sv_ = mock::current->period; mock::current->period = ""; (p)->parmsLoad(); mock::current->period = sv_; for (int k_ = 0; k_ < 16; ++k_) { mock::current->floatSet[k_] = false; if (k_ != 7) mock::current->lists[k_] = -99; } } while (0)
int main() {
    char tmpl[] = "/tmp/basXXXXXX"; const char* tmp = mkdtemp(tmpl); setenv("USERPROFILE", tmp, 1); g_tmp = tmp;
    const std::string flex = std::string(tmp) + "\\InvestorRT\\rtx\\lsFlexLevels";
    mock::Host h; mock::current = &h; h.tick = 0.25f; h.seconds = 60; h.symbol = "ESZ6"; h.root = "ES"; h.paneBottom = 300; h.paneRight = 1200; h.lists[7] = 1;   /* (1.5.2) Box shows: Numbers - this suite checks the numbers box (the mock's other lists read listIndex) */
    CHECK(std::string(BAS_VERSION) == "1.6.0" && std::string(bas::VERSION) == BAS_VERSION, "(1.6.0) version 1.6.0 everywhere");
    fill(h, 41, 7);                                                         // 40 closed + 1 forming
    BidAskStats* p = make(); p->calc(0);
    BASState* S = p->testState();
    CHECK(S && S->ser.bars.size() == 40 && S->lastClosedTime == (long long)h.bars[39].time, "40 closed bars computed; the forming bar is not");
    {
        bas::Series ref = reference(h, 20); bool all = true;
        for (auto& kv : ref.bars) if (!S->ser.bars.count(kv.first) || !same(S->ser.bars[kv.first], kv.second)) all = false;
        CHECK(all, "host stats equal the logic reference on every closed bar");
    }
    {   // a known last closed bar: the biggest bid of the session and a 3.5x ask
        h.bars.clear(); for (int i = 0; i < 30; ++i) h.bars.push_back(bar(T0 + 60UL * i, { {10, 20}, {5, 1} }));
        h.bars.push_back(bar(T0 + 60UL * 30, { {3, 70}, {50, 2}, {1, 1} }));  // last closed: bid 50 @7000.25, ask 70 @7000.00
        h.bars.push_back(bar(T0 + 60UL * 31, { {900, 900} }));               // forming: huge, must not reach the box
        dispose(p); h.data = nullptr; p = make(); p->calc(0); S = p->testState();
        const bas::Stat& st = S->ser.bars[(long long)h.bars[30].time];
        CHECK(st.m.bid == 50 && st.m.bidPx == 7000.25 && st.m.ask == 70 && st.m.askPx == 7000.0, "VAP: bid = sellVolume, ask = buyVolume, per price");
        CHECK(st.bBid == 31 && st.bAsk == 31, "BBid / BAsk 31 = the biggest of every bar available");
        h.draws.clear(); p->draw();
        COLOR c1 = 0, c2 = 0, c3 = 0, c4 = 0;
        CHECK(boxValue2(h, "Lots", 0, &c1) == "50 (5.0x)" && boxValue2(h, "Lots", 1, &c2) == "70 (3.5x)" && boxValue(h, "Sellers", &c3) != "?" && boxValue(h, "Buyers", &c4) != "?",
              "(1.5.0) box: Lots 50 (5.0x) | 70 (3.5x) (bid 50/10, ask 70/20) - the last CLOSED bar, not the forming one; Sellers | Buyers columns");
        CHECK(c1 == C_BID && c2 == C_ASK, "sellers' (bid) values red, buyers' (ask) values green");
        bool labelsWhite = true; for (auto& d : h.draws) if (d.type == "text" && (d.text == "BBid" || d.text == "BAsk" || d.text == "BidRatio" || d.text == "AskRatio") && d.color != C_LABEL) labelsWhite = false;
        CHECK(labelsWhite, "labels white");
        const mock::Draw* box = nullptr; for (auto& d : h.draws) if (d.type == "box" && d.color == C_BLACK) box = &d;
        CHECK(box && box->border == C_BORDER && box->width == 1 && box->x == 3 && box->y == 3, "solid black box with a solid border at the top left of the pane");
        CHECK(rects(h, C_BID) == 32 && rects(h, C_ASK) == 32, "a red and a green bar for every candle, the forming one included");
        // shared scale: the forming bar (900) is the tallest; the closed 50 bid is 50/900 of it
        int hForm = 0, h50 = 0;
        for (auto& d : h.draws) if (d.type == "box" && sameSide(d.color, C_BID)) { const int x = d.b - d.y; if (d.x > 50 + 31 * 10 - 10) hForm = x; else if (d.x > 50 + 30 * 10 - 10) h50 = x; }
        { const int PX = off::drawPx(300, off::textReserve(300));   // (1.3.0 adapted) headroom for the spike labels and the message line
        CHECK(hForm == PX && PX < 294 && std::abs(h50 - (int)(PX * 50.0 / 900 + .5)) <= 1, "both bars on one shared scale (tallest = the headroom height)"); }
        bool order = true; for (size_t i = 0; i + 1 < h.draws.size(); ++i) if (h.draws[i].type == "box" && sameSide(h.draws[i].color, C_BID) && h.draws[i + 1].type == "box" && sameSide(h.draws[i + 1].color, C_ASK) && !(h.draws[i].r <= h.draws[i + 1].x)) order = false;
        CHECK(order, "red left of green inside the slot");
    }
    {   // closed values never change as new bars arrive; the bar that was forming is read fresh when it closes
        std::map<long long, bas::Stat> before = S->ser.bars;
        h.bars.back() = bar(h.bars.back().time, { {40, 10} });                // the forming bar finishes differently
        h.bars.push_back(bar(T0 + 60UL * 32, { {1, 1} }));
        bas_test_now_ms += 10; p->calc(0);
        bool frozen = true; for (auto& kv : before) if (!same(S->ser.bars[kv.first], kv.second)) frozen = false;
        CHECK(frozen && S->ser.bars.size() == before.size() + 1, "closed bars never change as new bars arrive");
        CHECK(S->ser.bars[(long long)h.bars[31].time].m.bid == 40, "the newly closed bar is read as closed (not its forming snapshot)");
        // incremental: one more bar = one new computation and 2 VAP reads (the new closed bar + the forming bar)
        const long long comp = S->ser.computed; const int calls = h.statsCalls;
        h.bars.push_back(bar(T0 + 60UL * 33, { {2, 2} })); bas_test_now_ms += 10; p->calc(0);
        CHECK(S->ser.computed == comp + 1 && h.statsCalls == calls + 2, "a new bar = 1 stats computation, 2 VAP reads");
        if (!(S->ser.computed == comp + 1 && h.statsCalls == calls + 2)) std::printf("  computed +%lld, reads +%d\n", S->ser.computed - comp, h.statsCalls - calls);
        const int c2 = h.statsCalls; p->draw(); p->draw(); p->calc(0);
        CHECK(h.statsCalls == c2, "repaints in the same 250 ms touch no VAP");
        bas_test_now_ms += 300; p->draw();
        CHECK(h.statsCalls == c2 + 1 && S->ser.computed == comp + 1, "after 250 ms only the forming bar is re-read");
    }
    {   // a failed VAP read = n/a, not 0; excluded from counts; retried and recovered without revising later bars
        dispose(p); h.data = nullptr; fill(h, 41, 11);
        for (auto& b : h.bars) b.rows[0].sell = 10;                          // flat bids: every bar's biggest bid >= 10
        h.bars[20].rows[0].sell = 500; h.bars[20].failStats = 1;            // the big bar cannot be read
        h.bars[21].rows.clear();                                            // statistics say 0 prices but the bar traded: missing
        p = make(); p->calc(0); S = p->testState();
        const bas::Stat& na = S->ser.bars[(long long)h.bars[20].time];
        CHECK(!na.m.ok && na.m.bid == 0 && S->vapFailures >= 2, "failed read -> n/a (counted), never 0");
        CHECK(!S->ser.bars[(long long)h.bars[21].time].m.ok, "0 prices with bar volume -> n/a");
        bas::Series ref = reference(h, 20); ref.bars[(long long)h.bars[21].time] = bas::Stat();
        // the reference with 20 and 21 n/a: recompute 22.. from scratch
        bas::Series r2; for (size_t i = 0; i + 1 < h.bars.size(); ++i) { mock::Bar& b = h.bars[i]; std::vector<bas::Row> rr; for (auto& q : b.rows) rr.push_back(bas::Row{ q.price, q.sell, q.buy });
            r2.add((long long)b.time, (i == 20 || i == 21) ? bas::BarMax() : bas::maxOf(rr, h.tick), 20); }
        bool excl = true; for (auto& kv : r2.bars) if (!same(S->ser.bars[kv.first], kv.second)) excl = false;
        CHECK(excl, "n/a bars excluded from every later count and average");
        h.draws.clear(); p->draw();
        CHECK(rects(h, C_BID) == 39 && rects(h, C_ASK) == 39, "no histogram bars for the two n/a candles");
        const bas::Stat later = S->ser.bars[(long long)h.bars[30].time];
        h.bars[20].failStats = 0; bas_test_now_ms += 200; p->calc(0);
        CHECK(!S->ser.bars[(long long)h.bars[20].time].m.ok, "retry waits at least 1 s");
        bas_test_now_ms += 1000; p->calc(0);
        CHECK(S->ser.bars[(long long)h.bars[20].time].m.ok && S->ser.bars[(long long)h.bars[20].time].m.bid == 500, "back-filled VAP: the n/a bar recovers its own value");
        CHECK(same(S->ser.bars[(long long)h.bars[30].time], later), "later bars' stats are not revised (no repaint)");
        for (int k = 0; k < 12; ++k) { bas_test_now_ms += 1100; p->calc(0); }
        CHECK(S->naTries.empty() && !S->ser.bars[(long long)h.bars[21].time].m.ok, "a bar still missing after 10 tries stays n/a for good");
        const int calls = h.statsCalls; bas_test_now_ms += 5000; p->calc(0);
        CHECK(h.statsCalls == calls + 1, "no more retries after that (only the forming bar is read)");
    }
    {   // status file: content, atomic, at most once a minute
        const std::string sp = flex + "\\BidAskStats.status-ES-ESZ6-60.txt";
        const std::string t = readAll(sp);
        CHECK(t.find("VERSION,1.6.0\n") != std::string::npos && t.find("MARKET,ES\n") != std::string::npos && t.find("SYMBOL,ESZ6\n") != std::string::npos
              && t.find("LAST_CLOSED_BAR,") != std::string::npos && t.find("BIGGEST_BID,") != std::string::npos && t.find("BBID,") != std::string::npos
              && t.find("BID_RATIO,") != std::string::npos && t.find("VAP_FAILURES,") != std::string::npos, "status file has every field");
        CHECK(readAll(sp + ".tmp").empty(), "no temporary file left behind");
        h.bars.push_back(bar(h.bars.back().time + 60, { {1, 1} })); bas_test_now_ms += 1000; p->calc(0);
        const std::string t1 = readAll(sp);
        bas_test_now_ms += 61000; p->calc(0);
        const std::string t2 = readAll(sp);
        CHECK(t1 != t2 || t1.find("LAST_CLOSED_BAR," + std::to_string(S->lastClosedTime)) != std::string::npos, "a change is published within a minute");
        h.bars.push_back(bar(h.bars.back().time + 60, { {1, 1} })); bas_test_now_ms += 1000; p->calc(0);
        CHECK(readAll(sp) == t2, "not rewritten again inside the minute");
        bas_test_now_ms += 60000; p->calc(0);
        CHECK(readAll(sp).find("LAST_CLOSED_BAR," + std::to_string(S->lastClosedTime) + ",") != std::string::npos, "rewritten after the minute with the last closed bar");
        // 2026-10-13 stamp printed on the chart clock
        CHECK(readAll(sp).find(",2026-10-") != std::string::npos, "readable bar stamp");
    }
    {   // two charts on one DLL: independent state and status files
        mock::Host h2 = h; h2.data = nullptr; h2.symbol = "NQZ6"; h2.root = "NQ"; fill(h2, 25, 99);
        mock::current = &h2; BidAskStats* q = make(); q->calc(0); BASState* Q = q->testState();
        mock::current = &h; p->calc(0);
        CHECK(Q && Q != S && Q->market == "NQ" && S->market == "ES" && Q->ser.bars.size() == 24 && S->ser.bars.size() == 42, "two charts keep their own state");
        mock::current = &h2; bas_test_now_ms += 61000; q->calc(0);
        CHECK(!readAll(flex + "\\BidAskStats.status-NQ-NQZ6-60.txt").empty() && readAll(flex + "\\BidAskStats.status-ES-ESZ6-60.txt").find("MARKET,ES") != std::string::npos, "status files per market + contract");
        dispose(q); mock::current = &h;
        mock::Host h3; h3.noSlot = true; mock::current = &h3; fill(h3, 10, 1); BidAskStats* z = make(); z->calc(0); z->draw();
        CHECK(z->testState() == nullptr, "no host slot: fail closed (nothing shared)");
        dispose(z); mock::current = &h;
    }
    {   // settings: per-market file written only from Apply with valid values, read back by stamp
        const std::string pp = flex + "\\BidAskStats.place-ES.txt";
        h.parms[0] = 30; h.listIndex = -1; APPLY(p);
        CHECK(readAll(pp) == "30,0,20,15,10,0,0,1\n", "(1.5.2) an invalid list index keeps the file's Position (top left); garbage offsets / Box shows keep theirs");
        LOAD(p); CHECK(readAll(pp) == "30,0,20,15,10,0,0,1\n", "loading never saves");
        h.parms[0] = 30; h.listIndex = 8; APPLY(p);
        CHECK(readAll(pp) == "30,8,20,15,10,0,0,1\n", "Apply writes Ratio bars,Position,spike settings (+ 1.5.2 Offset X, Offset Y, Box shows)");
        const bas::Stat b0 = S->ser.bars[S->lastClosedTime];
        bas_test_now_ms += 1100; p->calc(0);
        CHECK(S->ratioBars == 30 && S->pos == 8, "settings picked up");
        const bas::Stat& b1 = S->ser.bars[S->lastClosedTime];
        CHECK(b1.bBid == b0.bBid && b1.m.bid == b0.m.bid, "Ratio bars change keeps the counts");
        h.draws.clear(); p->draw();
        const mock::Draw* box = nullptr; for (auto& d : h.draws) if (d.type == "box" && d.color == C_BLACK) box = &d;
        cppExtension::PNT e; e.set((int)h.bars.size() - 1, 0.0f, cppExtension::kBarRight);
        CHECK(box && box->b == h.paneBottom - 3 && box->r <= e.h - 3, "Position bottom right: inside the area up to where price ends");
        { std::ofstream f(pp.c_str()); f << "3,9\n"; }
        bas_test_now_ms += 1100; p->calc(0);
        CHECK(S->ratioBars == 20 && S->pos == 0, "a malformed settings file -> defaults (20, top left)");
        { std::ofstream f(pp.c_str()); f << "20,0\n"; }
        h.parms[0] = 500; h.listIndex = 3; APPLY(p);
        CHECK(readAll(pp) == "20,0\n", "an out-of-range Ratio bars is not saved");
    }
    {   // a long chart loads in bounded slices; replay equals live; the box waits until done
        dispose(p); h.data = nullptr; fill(h, 1500, 3); h.statsCalls = 0;
        p = make(); p->calc(0); S = p->testState();
        CHECK(h.statsCalls <= READS_PER_PASS + 1 && S->backlog, "first pass bounded to 600 VAP reads");
        h.draws.clear(); p->draw();
        CHECK(boxValue2(h, "Lots", 0) == "n/a", "box n/a while loading");
        for (int k = 0; k < 4; ++k) { bas_test_now_ms += 10; p->calc(0); }
        CHECK(!S->backlog && S->ser.bars.size() == 1499, "all closed bars in after a few passes");
        bas::Series ref = reference(h, 20); bool all = true;
        for (auto& kv : ref.bars) if (!same(S->ser.bars[kv.first], kv.second)) all = false;
        CHECK(all, "sliced load equals one straight pass");
        // replay: the same chart added bar by bar equals the one-shot load
        mock::Host r = h; r.data = nullptr; r.bars.resize(2); mock::current = &r;
        BidAskStats* rp = make(); rp->calc(0);
        for (size_t i = 2; i < h.bars.size(); ++i) { r.bars.push_back(h.bars[i]); bas_test_now_ms += 10; rp->calc(0); }
        BASState* RS = rp->testState(); bool eq = RS->ser.bars.size() == S->ser.bars.size();
        for (auto& kv : S->ser.bars) if (!RS->ser.bars.count(kv.first) || !same(RS->ser.bars[kv.first], kv.second)) eq = false;
        CHECK(eq, "bar-by-bar replay equals the one-shot load");
        dispose(rp); mock::current = &h;
    }
    {   // geometry: tiny pane draws nothing; no tick -> nothing computed, state says so
        h.paneBottom = 10; h.draws.clear(); p->draw(); CHECK(h.draws.empty(), "pane too short: nothing drawn");
        h.paneBottom = 300;
        mock::Host t = h; t.data = nullptr; t.tick = 0; mock::current = &t; BidAskStats* tp = make(); tp->calc(0);
        CHECK(tp->testState()->ser.bars.empty() && tp->testState()->state == "native tick size unavailable", "no tick size: nothing computed");
        dispose(tp); mock::current = &h;
    }
    {   // the visible range from IRT: only those candles get bars
        h.bars.resize(60); bas_test_now_ms += 300; p->calc(0);
        h.visFrom = (int)h.bars.size() - 20; h.visTo = (int)h.bars.size() - 1; h.draws.clear(); bas_test_now_ms += 300; p->draw();
        CHECK(rects(h, C_BID) == 20 && rects(h, C_ASK) == 20, "only visible candles drawn");
        h.visFrom = h.visTo = -1;
    }
    dispose(p); h.data = nullptr;
    // ======================= 1.1.0: hover, position (1.2.0: Ratio line removed) =======================
    auto mouseAt = [&](BidAskStats* x, long bar) { RTX_EVENT e; std::memset(&e, 0, sizeof(e)); e.type = E_MOUSE_MOVE; e.v.mouse.bar = bar; return x->mouse(&e); };
    auto header = [&](mock::Host& hh) { for (auto& d : hh.draws) if (d.type == "text" && d.color == C_LABEL && (d.text == "Live" || d.text.find(" AM") != std::string::npos || d.text.find(" PM") != std::string::npos || d.text == "n/a")) return d.text; return std::string("?"); };
    {   // hover bar k shows bar k's values AS OF k (from bars 0..k-1 only), header = its 12-hour time
        { std::ofstream f((flex + "\\BidAskStats.place-ES.txt").c_str()); f << "20,0,15\n"; }
        fill(h, 61, 5); h.bars[25].rows[0].sell = 400;                      // bar 25: a big bid
        h.bars[40].rows[0].sell = 2000; h.bars[40].rows[1].buy = 2000;     // a LATER, much bigger bar: must not reach bar 25's box
        bas_test_cursor_wnd = (void*)0x11;
        p = make(); bas_test_now_ms += 2000; p->calc(0); S = p->testState();
        mock::Host part = h; part.bars.resize(27); bas::Series asOf = reference(part, 20);   // bars 0..25 closed only
        const bas::Stat& k = asOf.bars[(long long)h.bars[25].time];
        const std::vector<bas::Line> want = bas::boxLines(&k);
        h.invalidates = 0; mouseAt(p, 25); h.draws.clear(); p->draw();
        CHECK(boxValue2(h, "Lots", 0) == lotsOf(k, 0) && boxValue2(h, "Lots", 1) == lotsOf(k, 1) && want[2].value == bas::fmtRatio(k.bidRatioOk, k.bidRatio),
              "hover bar 25: the box shows bar 25's values computed from the bars before it only");
        CHECK(S->ser.bars[(long long)h.bars[25].time].bBid == k.bBid && k.bBid == 26, "BBid as of bar 25 = 26 (bar 40's bigger bid is not seen; BBid stays in the status / record)");
        CHECK(header(h) == "2:25 PM", "header = the hovered bar's time on the 12-hour clock (2:25 PM)");
        mock::Host part2 = h; part2.bars.resize(61); bas::Series full = reference(part2, 20);
        CHECK(same(S->ser.bars[(long long)h.bars[25].time], k) && same(full.bars[(long long)h.bars[25].time], k), "bar 25's stats identical with or without the later bars (no look-ahead)");
        CHECK(h.invalidates == 1 && S->redraws == 1, "hover change -> exactly one redraw");
        mouseAt(p, 25); mouseAt(p, 25); RTX_EVENT hv; std::memset(&hv, 0, sizeof(hv)); hv.type = E_MOUSE_HOVER; hv.v.mouse.bar = 25; p->mouse(&hv);
        CHECK(h.invalidates == 1, "the same bar again (move / hover) -> no redraw");
        CHECK(mouseAt(p, 26) == RTX_FAIL && h.invalidates == 2, "a new bar -> one more redraw; the event is never swallowed");
        // (1.3.1, Rassul 1:43 PM) no white outline: the hovered bar is drawn exactly like every other bar - border = pen = fill
        h.draws.clear(); p->draw();
        int outl = 0; for (auto& d : h.draws) if (d.type == "box" && (sameSide(d.color, C_BID) || sameSide(d.color, C_ASK)) && (d.width != 0 || d.border != d.color || d.pen != d.color)) ++outl;
        CHECK(outl == 0, "(1.3.1) no bar has an outline: not the hovered bar, not any other (border = pen = fill, width 0)");
        int plain = 0; for (auto& d : h.draws) if (d.type == "box" && (sameSide(d.color, C_BID) || sameSide(d.color, C_ASK)) && d.width == 0 && d.border == d.color && d.pen == d.color) ++plain;
        CHECK(plain == 2 * 61, "(1.3.1) every bar, the hovered one included, drawn flat (no white outline)");
        // the box keeps its size as the numbers change
        const mock::Draw* b1 = nullptr; for (auto& d : h.draws) if (d.type == "box" && d.color == C_BLACK) b1 = &d; const mock::Draw B1 = *b1;
        mouseAt(p, 40); h.draws.clear(); p->draw();
        const mock::Draw* b2 = nullptr; for (auto& d : h.draws) if (d.type == "box" && d.color == C_BLACK) b2 = &d;
        CHECK(b2 && b2->r - b2->x == B1.r - B1.x && b2->b - b2->y == B1.b - B1.y, "fixed box size while hovering different bars");
        // out of range: past the last bar, the forming bar, negative -> Live (and one redraw for that change only)
        const int before = h.invalidates;
        mouseAt(p, 60); CHECK(S->hover.bar == -1 && h.invalidates == before + 1, "the forming bar -> Live");
        mouseAt(p, 500); mouseAt(p, -1); mouseAt(p, LONG_MAX);
        CHECK(S->hover.bar == -1 && h.invalidates == before + 1, "out-of-range bars ignored (stay Live, no redraw)");
        h.draws.clear(); p->draw();
        const bas::Stat& live = S->ser.bars[(long long)h.bars[59].time];
        CHECK(header(h) == "Live" && boxValue2(h, "Lots", 0) == lotsOf(live, 0) && boxValue2(h, "Lots", 1) == lotsOf(live, 1), "Live: header Live, the last closed bar's values");
        int outl2 = 0; for (auto& d : h.draws) if (d.type == "box" && d.width == 1 && d.border == C_LABEL) ++outl2;
        CHECK(outl2 == 0, "no highlight when Live");
        // the mouse leaves the chart window -> Live on the next calc (one redraw); unknown cursor window keeps the hover
        mouseAt(p, 30); const int i0 = h.invalidates;
        bas_test_cursor_wnd = nullptr; p->calc(0); CHECK(S->hover.bar == 30, "cursor window unknown: hover kept");
        bas_test_cursor_wnd = (void*)0x22; mouseAt(p, 31); CHECK(S->hover.bar == 31 && S->hoverWnds.size() == 2, "a second chart window (the price pane) counts as the chart");
        bas_test_cursor_wnd = (void*)0x11; p->calc(0); CHECK(S->hover.bar == 31, "moving between the chart's own windows keeps the hover");
        bas_test_cursor_wnd = (void*)0x99; p->calc(0);
        CHECK(S->hover.bar == -1 && h.invalidates == i0 + 2, "cursor off the chart -> Live, one redraw");
        p->calc(0); CHECK(h.invalidates == i0 + 2, "no further redraws while away");
        h.draws.clear(); p->draw(); CHECK(header(h) == "Live", "box back to Live");
        bas_test_cursor_wnd = (void*)0x11;
    }
    {   // (1.2.0) the gray Ratio lines are gone; a 1.1.0 settings file (3 fields) is still read, its line field ignored
        h.draws.clear(); p->draw();
        bool noLines = true; for (auto& d : h.draws) if (d.type == "box" && d.b - d.y == 1 && d.color != C_BID_BAR && d.color != C_ASK_BAR && d.color != C_BID_SPIKE && d.color != C_ASK_SPIKE) noLines = false;
        CHECK(noLines && rects(h, 0x005A5F66) == 0, "no gray lines drawn");
        { std::ofstream f((flex + "\\BidAskStats.place-ES.txt").c_str()); f << "25,4,0\n"; }
        h.parms[0] = 20; bas_test_now_ms += 1100; S->settingsStamp = -2; p->calc(0);
        CHECK(S->pos == 4 && S->ratioBars == 25 && S->ser.spike == bas::SpikeCfg(), "1.1.0 file: Ratio bars + Position kept, default spikes");
        { std::ofstream f((flex + "\\BidAskStats.place-ES.txt").c_str()); f << "20,4\n"; }
        bas_test_now_ms += 1100; S->settingsStamp = -2; p->calc(0);
        CHECK(S->pos == 4 && S->ratioBars == 20, "1.0.0 file read");
    }
    {   // settings parse + every one of the 9 spots inside the pane and left of where price ends
        int r = 0, q = 0, t = 0;
        bas::SpikeCfg c0;
        CHECK(parseSettings("20,4,15", r, q, &c0) && r == 20 && q == 4 && c0 == bas::SpikeCfg(), "parse a 1.1.0 file (its Ratio line field ignored)");
        CHECK(parseSettings("200,8,0", r, q, &c0) && parseSettings("5,0", r, q, &c0), "parse 1.1.0 / 1.0.0 forms");
        CHECK(!parseSettings("20,4,101", r, q, &c0) && !parseSettings("20,9,15", r, q, &c0) && !parseSettings("20,4,1.5", r, q, &c0) && !parseSettings("20,4,15,1", r, q, &c0)
              && !parseSettings("20,,15", r, q, &c0) && !parseSettings("4,4,15", r, q, &c0) && !parseSettings("", r, q, &c0) && !parseSettings("20,4,", r, q, &c0), "malformed settings rejected");
        (void)t;
        bool all = true; const int lastI = (int)h.bars.size() - 1; cppExtension::PNT e; e.set(lastI, 0.0f, cppExtension::kBarRight);
        int prevL = -1; bool distinct = false;
        for (int pos = 0; pos < 9; ++pos) {
            h.parms[0] = 20; h.listIndex = pos; APPLY(p);        // Apply: re-read on the next pass
            bas_test_now_ms += 10; p->calc(0); h.draws.clear(); p->draw();
            const mock::Draw* bx = nullptr; for (auto& d : h.draws) if (d.type == "box" && d.color == C_BLACK) bx = &d;
            if (!bx || S->pos != pos || bx->x < h.paneLeft + 3 || bx->y < h.paneTop + 3 || bx->b > h.paneBottom - 3 || bx->r > e.h - 3) { all = false; if (getenv("DBG") && bx) std::printf("pos %d box %d,%d-%d,%d edge %d S.pos %d\n", pos, bx->x, bx->y, bx->r, bx->b, (int)e.h, S->pos); }
            if (getenv("DBG") && bx) for (auto& d : h.draws) if (d.type == "text" && (d.color == C_LABEL || d.color == C_BID || d.color == C_ASK) && (d.x < bx->x || d.x > bx->r || d.y < bx->y || d.y > bx->b)) std::printf("pos %d out [%s] %d,%d box %d,%d-%d,%d\n", pos, d.text.c_str(), d.x, d.y, bx->x, bx->y, bx->r, bx->b);
            if (bx && prevL >= 0 && bx->x != prevL) distinct = true;
            if (bx) prevL = bx->x;
            for (auto& d : h.draws) if (d.type == "text" && bx && (d.color == C_LABEL || d.color == C_BID || d.color == C_ASK) && (d.x < bx->x || d.x > bx->r || d.y < bx->y || d.y > bx->b)) all = false;
            // (1.3.0) the message line (implication colours) is never over the box
            for (auto& d : h.draws) if (d.type == "text" && bx && (d.color == off::C_NEUTRAL || d.color == off::C_GREEN_SPIKE || d.color == off::C_RED_SPIKE) && d.y < h.paneTop + 20 && d.x >= bx->x && d.x <= bx->r && d.y >= bx->y && d.y <= bx->b) { all = false; if (getenv("DBG")) std::printf("pos %d msg over box [%s] %d,%d box %d,%d-%d,%d\n", pos, d.text.c_str(), d.x, d.y, bx->x, bx->y, bx->r, bx->b); }
        }
        if (getenv("DBG")) std::printf("all %d distinct %d\n", (int)all, (int)distinct);
        CHECK(all && distinct, "all 9 positions: box and its text inside the pane, never past the last bar");
    }
    {   // (1.1.0) the pane's own value axis: contracts, 0 at the bottom - never the instrument's prices
        dispose(p); h.data = nullptr; fill(h, 41, 7); for (auto& b : h.bars) for (auto& r : b.rows) r.price += 0;   // prices ~7000
        p = make(); bas_test_now_ms += 2000; p->calc(0); S = p->testState();
        CHECK((h.flags & TRACK_MOUSE) && !(h.flags & INSTRUMENT_SCALE) && !(h.flags & OVERLAY), "flags: TRACK_MOUSE, own pane, no instrument scale");
        h.draws.clear(); p->draw();                                          // learns the pane height
        double mn = -1, mx = -1; const int rc = p->scale(0, (int)h.bars.size() - 1, &mn, &mx);
        long long top = 0; for (auto& kv : S->ser.bars) if (kv.second.m.ok) top = std::max(top, std::max(kv.second.m.bid, kv.second.m.ask));
        if (S->live.ok) top = std::max(top, std::max(S->live.bid, S->live.ask));
        CHECK(rc == RTX_OK && S->axisTop == top && top > 0 && top < 200, "scale(): the tallest bid / ask in contracts");
        CHECK(mn <= 0 && mn > -2 && mx >= (double)top * 1.45 && mx < (double)top * 2.0 && mx < 1000, "(1.3.0 adapted) axis = 0 .. sizes (not prices ~7000), headroom >= 1.45x the tallest bar");
        // the axis puts each value at its bar's pixel: y(v) = top + (mx - v) / (mx - mn) * paneH
        h.draws.clear(); p->draw();
        const int paneH = h.paneBottom - h.paneTop; bool aligned = true; int checked = 0;
        for (auto& d : h.draws) if (d.type == "box" && (sameSide(d.color, C_BID) || sameSide(d.color, C_ASK)) && d.width == 0) {
            const double v = mn + (mx - mn) * (double)(h.paneBottom - d.y) / (double)paneH;   // the axis value at the bar's top pixel
            const int xc = d.x; (void)xc; ++checked;
            // find this bar's value: height in px -> value on the drawing scale
            const double drawn = (double)(h.paneBottom - 1 - d.y) * (double)top / (double)off::drawPx(paneH, off::textReserve(paneH));   // (1.3.0) the headroom height
            if (std::fabs(v - drawn) > (mx - mn) / paneH * 1.01) aligned = false;
        }
        CHECK(checked > 0 && aligned, "every bar's top sits at its value on the axis (within 1 px)");
        double a0 = 0, a1 = 0; p->scale(5, 2, &a0, &a1); CHECK(a1 > 0 && a0 <= 0, "an empty / reversed range still gives a sane axis");
        mock::Host z; z.noSlot = true; mock::current = &z; BidAskStats* q = make(); double b0 = -5, b1 = -5;
        CHECK(q->scale(0, 10, &b0, &b1) == RTX_OK && b0 == 0 && b1 == 10, "no state: a neutral 0..10 axis, never prices");
        dispose(q); mock::current = &h;
    }
    {   // (1.2.0) spikes on the chart: colours, prior bars only, either side, closed colour final, forming may change, 0 = off
        dispose(p); h.data = nullptr; h.spikeAvg = 2.0f; h.spikeJump = 1.5f; h.parms[4] = 10; h.parms[0] = 20; h.listIndex = 0; h.lists[7] = 1;   // (1.5.2) Box shows: Numbers (the mock's other lists read listIndex)
        { std::ofstream f((flex + "\\BidAskStats.place-ES.txt").c_str()); f << "20,0,20,15,10\n"; }
        h.bars.clear(); for (int i = 0; i < 30; ++i) h.bars.push_back(bar(T0 + 60UL * i, { {10, 10} }));
        h.bars.push_back(bar(T0 + 60UL * 30, { {25, 10} }));               // bid spike (2.5x avg, 2.5x prior biggest)
        h.bars.push_back(bar(T0 + 60UL * 31, { {10, 25} }));               // ask 25 = 1.0x the prior biggest (bar 30's bid): normal
        h.bars.push_back(bar(T0 + 60UL * 32, { {10, 40} }));               // ask 40: 3.7x avg, 1.6x prior biggest: ask spike
        h.bars.push_back(bar(T0 + 60UL * 33, { {70, 10} }));               // forming: a bid spike for now (70 = 1.75x the prior biggest 40)
        p = make(); bas_test_now_ms += 2000; p->calc(0); S = p->testState();
        auto colourAt = [&](int barI, bool bidSide) { const int xc = 50 + barI * 10;
            for (auto& d : h.draws) if (d.type == "box" && (bidSide ? sameSide(d.color, C_BID) : sameSide(d.color, C_ASK)) && d.x >= xc - 6 && d.r <= xc + 6) return d.color;
            return (COLOR)1; };
        h.draws.clear(); p->draw();
        CHECK(colourAt(30, true) == C_BID_SPIKE && colourAt(30, false) == C_ASK_BAR, "bar 30: bid spike bright red, its ask normal (darker) green");
        CHECK(colourAt(31, false) == C_ASK_BAR, "bar 31: 2.5x its average but not 1.5x the prior biggest of EITHER side -> normal");
        CHECK(colourAt(32, false) == C_ASK_SPIKE, "bar 32: ask spike bright green");
        auto lum = [](COLOR c) { return 0.2126 * ((c >> 16) & 255) + 0.7152 * ((c >> 8) & 255) + 0.0722 * (c & 255); };
        auto hue = [](COLOR c, int ch) { const int r = (c >> 16) & 255, g = (c >> 8) & 255, b = c & 255; return ch == 0 ? (r > g && r > b) : (g > r && g > b); };
        CHECK(lum(C_ASK_SPIKE) > lum(C_ASK_BAR) * 1.4 && lum(C_BID_SPIKE) > lum(C_BID_BAR) * 1.4 && hue(C_BID_SPIKE, 0) && hue(C_BID_BAR, 0) && hue(C_ASK_SPIKE, 1) && hue(C_ASK_BAR, 1),
              "spikes are clearly brighter than normal bars, and stay in the red / green families");
        CHECK(colourAt(29, true) == C_BID_BAR && colourAt(29, false) == C_ASK_BAR, "normal bars: darker red / green");
        CHECK(colourAt(33, true) == C_BID_SPIKE, "forming bar: spike colour as of now");
        h.bars[33] = bar(h.bars[33].time, { {10, 10} }); bas_test_now_ms += 300; p->calc(0); h.draws.clear(); p->draw();
        CHECK(colourAt(33, true) == C_BID_BAR, "forming bar's colour may change until it closes");
        h.bars[33] = bar(h.bars[33].time, { {60, 10} });                    // closes as a spike (60 = exactly 1.5x the prior biggest 40)
        h.bars.push_back(bar(T0 + 60UL * 34, { {10, 10} })); bas_test_now_ms += 300; p->calc(0);
        CHECK(S->ser.bars[(long long)h.bars[33].time].bidSpike, "closed: decided once from its closed read");
        for (int i = 35; i < 60; ++i) h.bars.push_back(bar(T0 + 60UL * i, { {900, 900} }));
        bas_test_now_ms += 300; p->calc(0); h.draws.clear(); p->draw();
        CHECK(S->ser.bars[(long long)h.bars[30].time].bidSpike && S->ser.bars[(long long)h.bars[33].time].bidSpike && S->ser.bars[(long long)h.bars[32].time].askSpike,
              "closed colours never change as bigger bars arrive");
        // box Jump line on a hovered spike
        mouseAt(p, 30); h.draws.clear(); p->draw(); COLOR jc = 0;
        CHECK(boxValue2(h, "Lots", 0, &jc).find("(2.5x)") != std::string::npos && jc == C_BID, "hover bar 30: the sellers' Lots ratio 2.5x (red, the bid side)");
        mouseAt(p, -1);
        // status
        bas_test_now_ms += 61000; p->calc(0);
        const std::string st = readAll(flex + "\\BidAskStats.status-ES-ESZ6-60.txt");
        CHECK(st.find("SPIKE_VS_AVERAGE,2.0x\n") != std::string::npos && st.find("SPIKE_VS_PRIOR_BIGGEST,1.5x\n") != std::string::npos && st.find("SPIKE_LOOKBACK,10\n") != std::string::npos,
              "status: spike settings");
        int wantB = 0, wantA = 0; for (auto& kv : S->ser.bars) { wantB += kv.second.bidSpike; wantA += kv.second.askSpike; }
        CHECK(st.find("SPIKES_TODAY_BID," + std::to_string(wantB) + "\n") != std::string::npos && st.find("SPIKES_TODAY_ASK," + std::to_string(wantA) + "\n") != std::string::npos && wantB >= 2 && wantA >= 1,
              "status: today's spike counts");
        // 0 = off (Apply), then back on
        h.spikeAvg = 0.0f; APPLY(p);
        if (getenv("DBG")) std::printf("file [%s]\n", readAll(flex + "\\BidAskStats.place-ES.txt").c_str());
        CHECK(readAll(flex + "\\BidAskStats.place-ES.txt") == "20,0,0,15,10,0,0,1\n", "Apply saves the spike settings");
        bas_test_now_ms += 1100; p->calc(0); h.draws.clear(); p->draw();
        CHECK(rects(h, C_BID_SPIKE) == 0 && rects(h, C_ASK_SPIKE) == 0 && !S->ser.bars[(long long)h.bars[30].time].bidSpike, "Spike vs average 0 = no spike colours");
        h.spikeAvg = 2.0f; h.parms[4] = 0; APPLY(p); bas_test_now_ms += 1100; p->calc(0); h.draws.clear(); p->draw();
        int sp0 = 0; for (auto& d : h.draws) if (d.type == "box" && (d.color == C_BID_SPIKE || d.color == C_ASK_SPIKE)) ++sp0;
        CHECK(sp0 == 0, "Spike lookback 0 = off");
        h.parms[4] = 10; APPLY(p); bas_test_now_ms += 1100; p->calc(0); h.draws.clear(); p->draw();
        CHECK(colourAt(30, true) == C_BID_SPIKE, "back on: re-decided from the stored values");
        h.parms[4] = 51; APPLY(p); CHECK(readAll(flex + "\\BidAskStats.place-ES.txt") == "20,0,20,15,10,0,0,1\n", "an out-of-range lookback is not saved");
        int r = 0, q = 0, t = 0; bas::SpikeCfg c;
        CHECK(parseSettings("20,0,25,18,12", r, q, &c) && c.avgT == 25 && c.jumpT == 18 && c.lookback == 12, "parse the 1.2.0 5-field file");
        CHECK(parseSettings("20,0,15", r, q, &c) && c == bas::SpikeCfg() && !parseSettings("20,0,20,15", r, q, &c) && !parseSettings("20,0,15,20,15,10", r, q, &c)
              && !parseSettings("20,0,20,15,51", r, q, &c) && !parseSettings("20,0,101,15,10", r, q, &c), "1.1.0 file = default spikes; 4/6 fields or out of range rejected");
        (void)t;
    }
    dispose(p);
    std::printf("host: %d passed, %d failed\n", passes, fails); return fails ? 1 : 0;
}
