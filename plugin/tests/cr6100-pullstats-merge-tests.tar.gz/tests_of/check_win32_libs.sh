#!/bin/sh
# check_win32_libs.sh (2026-10-13) -- every Win32 API a plugin imports must be in a library the build links: kernel32 comes with
# the CRT (cl /MD); anything else (user32: GetCursorPos / WindowFromPoint) needs a #pragma comment(lib, ...) in that translation
# unit. 1.3.0 never linked on Rassul's PC (LNK2019 GetCursorPos / WindowFromPoint) because user32 was missing.
# Method: compile each plugin with MinGW, list its __imp_ imports, map each to its DLL, and require the pragma in the preprocessed TU.
D=$(cd "$(dirname "$0")" && pwd); B=${BUILD:-/tmp/of140-build}; mkdir -p "$B"; SDK=${SDK:-/mnt/user-data/uploads/sdk/c++/include}
KERNEL32="GetDiskFreeSpaceExA GetFileAttributesExA CreateDirectoryA MoveFileExA GetLastError CreateFileA CloseHandle GetFileAttributesA DeleteFileA GetTickCount GetTickCount64 Sleep GetEnvironmentVariableA SetEnvironmentVariableA GetModuleFileNameA"   # (fix1) HoverBoard.h: Set / GetEnvironmentVariableA are kernel32
USER32="GetCursorPos WindowFromPoint GetForegroundWindow ScreenToClient GetAsyncKeyState MessageBoxA"
bad=0
for N in ${W32_PANES:-BidAskStats PullStats StackStats TapeReader}; do   # (of140) + TapeReader 1.1.0
  x86_64-w64-mingw32-g++ -std=c++17 -c -O0 -I"$SDK" -I"$D/.." "$D/wrap_$N.cpp" -o "$B/w32-$N.o" 2>/dev/null || { echo "win32 $N: compile failed"; bad=1; continue; }
  # TapeReader guards its pragmas with _MSC_VER (cl = his gex-build): preprocess it as cl would see it
  MSC=""; [ "$N" = TapeReader ] && MSC="-D_MSC_VER=1930"
  x86_64-w64-mingw32-g++ -std=c++17 -E $MSC -I"$SDK" -I"$D/.." "$D/wrap_$N.cpp" 2>/dev/null > "$B/w32-$N.i"
  imps=$(x86_64-w64-mingw32-nm -u "$B/w32-$N.o" | grep "__imp_" | sed 's/.*__imp_//' | grep -E '^[A-Z]' | sort -u)
  need=""; unknown=""
  for f in $imps; do
    case " $KERNEL32 " in *" $f "*) continue;; esac
    case " $USER32 " in *" $f "*) need="$need user32"; continue;; esac
    unknown="$unknown $f"
  done
  miss=""
  for l in $(echo $need | tr ' ' '\n' | sort -u); do grep -q "pragma comment(lib, \"$l.lib\")" "$B/w32-$N.i" || miss="$miss $l"; done
  if [ -n "$miss$unknown" ]; then bad=1; echo "win32 $N: FAIL missing pragma:$miss unmapped:$unknown"; else echo "win32 $N: ok ($(echo $imps | tr '\n' ' '))"; fi
done
exit $bad
