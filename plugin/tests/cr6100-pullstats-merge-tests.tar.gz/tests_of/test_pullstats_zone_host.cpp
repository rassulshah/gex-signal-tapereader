// test_pullstats_zone_host.cpp -- lsPullStats 1.5.0 on the mock host (ported from tests_pulling/test_pulling_zone_host.cpp, lsPulling
// 0.3.0, retired into lsPullStats on 2026-10-14): the ONE zone read line end to end through the plugin - levels from LRA-KeyLevels,
// the lagged ADR from the chart's bars, normals from LRA-ZoneReadNorms, the order feed's own ids, the 3-minute window on the plugin's
// clock. 1.5.0 (Rassul 2026-10-14 night): the line shows ONLY the locked arrival read - nothing while approaching or measuring; the
// pre-touch share is recorded and in the hover. Recorded, read back after a restart (no repaint), and a restart INSIDE the window.
#include "PullStats.cpp"
#include <cstdio>
#include <unistd.h>
#include <sys/stat.h>
namespace mock { Host* current = nullptr; Feed feed; }
namespace off { long long off_test_now_ms = 1000000; void* off_test_cursor_wnd = nullptr; }
static int fails = 0, passes = 0;
#define CHECK(c, m) do { if (c) ++passes; else { ++fails; std::printf("FAIL %d %s\n", __LINE__, m); } } while (0)
static std::string readAll(const std::string& p) { std::ifstream f(p.c_str()); std::stringstream s; s << f.rdbuf(); return s.str(); }
static void dispose(PullStats* p) { p->destroy(); p->~PullStats(); ::operator delete(p); }
static void ev(unsigned char a, unsigned char side, float px, unsigned long sz, RTDATE t, int id) { mock::feed.push(a, side, px, sz, t, id); }
static const mock::Draw* lineText(mock::Host& h) { for (auto& d : h.draws) if (d.type == "text" && d.text.compare(0, 8, "ES 7000 ") == 0) return &d; return nullptr; }
static void dump(mock::Host& h) { if (getenv("DBG")) for (auto& d : h.draws) if (d.type == "text") std::printf("  T %d,%d %06lx [%s]\n", d.x, d.y, (unsigned long)d.color, d.text.c_str()); }
static void run(PullStats* p, int ms) { off::off_test_now_ms += ms; p->calc(0); }
static bool hoverHas(mock::Host& h, const std::string& part) { for (auto& d : h.draws) if (d.type == "text" && d.text.find(part) != std::string::npos) return true; return false; }
int main() {
    char tmpl[] = "/tmp/pszXXXXXX"; const char* tmp = mkdtemp(tmpl); setenv("USERPROFILE", tmp, 1);
    const std::string flex = std::string(tmp) + "\\InvestorRT\\rtx\\lsFlexLevels"; mkdir(flex.c_str(), 0700);
    { std::ofstream f((flex + "\\LRA-KeyLevels-ES.csv").c_str()); f << "KEYLV,1," << (long long)std::time(NULL) << "\nL|PDL|7000.00|0\n"; }
    { std::ofstream f((flex + "\\LRA-ZoneReadNorms-ES.csv").c_str()); f << "VERSION|1\nMARKET|ES\nNORM|pull_def|ALL|0.30|0.10|100\nNORM|fill_def|ALL|100|40|100\nNORM|added|ALL|1000|400|100\nNORM|aggr|ALL|500|200|100\nNORM|pull_app|ALL|0.20|0.06|100\n"; }
    mock::Host h; mock::current = &h; h.tick = 0.25f; h.seconds = 180; h.symbol = "ESZ6"; h.root = "ES"; h.paneBottom = 300; h.paneRight = 2000; h.ppb = 10; h.barW = 20;
    const unsigned long day = (unsigned long)(off::civilDays(2026, 10, 12) * 86400LL);
    // 12 prior sessions, one bar each of range 60 (ADR 60 -> zone +/- 3.6 = 14 ticks), then today's bars above the level
    for (int d = 12; d >= 1; --d) { mock::Bar b; b.time = day - d * 86400 + 10 * 3600; b.high = 7040; b.low = 6980; b.open = b.close = 7010; b.volume = 10; h.bars.push_back(b); }
    const unsigned long t0 = day + 9 * 3600;
    for (int i = 0; i < 3; ++i) { mock::Bar b; b.time = t0 + 180 * i; b.high = 7012; b.low = 7008; b.open = b.close = 7010; b.volume = 10; h.bars.push_back(b); }
    h.now = t0 + 2 * 180 - 170;
    PullStats* p = static_cast<PullStats*>(CreateExtension());
    run(p, 100); run(p, 100);
    auto* S = p->testState();
    CHECK(S && S->zr.e.lv.size() == 1 && S->zr.e.adr > 59.9 && S->zr.e.adr < 60.1 && S->zr.e.zoneHalf == 14, "PDL loaded; ADR 60 from the chart's prior sessions; zone +/- 14 ticks");
    CHECK(S && S->zr.e.arrRec, "the PullStats host records the 'arrived' row");
    h.draws.clear(); p->draw();
    CHECK(!lineText(h), "price 7010 (outside the zone): no line");
    // 20 bids x 10 at the level, 5+ minutes of feed (far from the level), 4 of them cancelled before the touch (20%)
    for (int i = 0; i < 20; ++i) ev(0, 1, 7000.00f, 10, h.now, 100 + i);
    for (int k = 0; k < 22; ++k) { ev(0, 1, 6990.00f, 1, h.now, 5000 + k); run(p, 15000); }
    for (int i = 0; i < 4; ++i) ev(2, 1, 7000.00f, 10, h.now, 100 + i);
    // price trades down into the zone (7002 = 8 ticks from the level, outside the 4-tick band): approach
    ev(0, 1, 7002.00f, 1, h.now, 900); ev(3, 1, 7002.00f, 1, h.now, 900);
    h.bars.back().close = 7002.0f; h.bars.back().low = 7002.0f;
    run(p, 1000); h.draws.clear(); p->draw(); dump(h);
    CHECK(S->zr.e.cur.state == zread::APPROACH, "in the zone (armed by the close above it): approaching");
    CHECK(!lineText(h), "state 1 approaching: PullStats draws NO line (1.5.0)");
    ev(3, 1, 7000.00f, 1, h.now, 104);                                // the first trade at the level: arrival
    h.bars.back().close = 7000.25f; h.bars.back().low = 6999.75f;
    run(p, 1000);
    CHECK(S->zr.e.cur.state == zread::MEASURE && S->zr.e.cur.shown == 160, "arrival: 160 lots of bids at the level");
    CHECK(S->zr.e.cur.pre.text.find("bids stayed before touch (20% pulled) ?") != std::string::npos, "the pre-touch share measured at arrival (20%)");
    for (int i = 5; i < 15; ++i) ev(2, 1, 7000.00f, 10, h.now, 100 + i);   // 100 lots cancelled, not traded
    run(p, 60000); h.draws.clear(); p->draw(); dump(h);
    CHECK(!lineText(h), "state 2 measuring (1:00 of 3:00): NO line - no 'measuring' text");
    const std::string rec = S->zr.recPath;
    CHECK(readAll(rec).find("|arrived|PullStats|") != std::string::npos, "the arrived row is in the session record (restart-safe pre-touch part)");
    run(p, 119000); h.draws.clear(); p->draw();
    CHECK(!lineText(h) && S->zr.e.cur.state == zread::MEASURE, "2:59 after arrival: still nothing");
    run(p, 1000); h.draws.clear(); p->draw(); dump(h);
    const mock::Draw* l = lineText(h);
    const std::string locked = S->zr.e.line(zread::P_PULLSTATS, off::off_test_now_ms).text, drawn = l ? l->text : std::string();
    // (the mock chart is narrow: the drawn line is the read fitted to the space up to the last bar - a prefix + "...")
    CHECK(l && locked == "ES 7000 \x97 bids pulled, not filled (62% in 3 min) \x97 less support ?" && drawn.size() > 20 && locked.compare(0, drawn.size() - 3, drawn.substr(0, drawn.size() - 3)) == 0 && l->color == off::C_RED_SPIKE, "state 3 locked at 3:00: red 'ES 7000 - bids pulled, not filled (62% in 3 min) - less support ?'");
    // the mouse on the line: its detail box with both parts and both caveats
    { RTX_EVENT e; std::memset(&e, 0, sizeof(e)); e.type = E_MOUSE_MOVE; e.v.mouse.h = (short)(l ? l->x + 5 : 0); e.v.mouse.v = (short)(l ? l->y + 3 : 0); e.v.mouse.bar = -1;
      p->mouse(&e); h.draws.clear(); p->draw(); dump(h);
      CHECK(hoverHas(h, "PullStats read") && hoverHas(h, "cancelled 100 (62%)") && hoverHas(h, "Before the touch (secondary): 20% of the 200 lots"), "hover: the arrival numbers + the pre-touch part");
      e.v.mouse.h = 900; e.v.mouse.v = 200; p->mouse(&e); h.draws.clear(); p->draw();
      CHECK(!hoverHas(h, "Before the touch (secondary)"), "mouse off the line: no detail box"); }
    // no repaint: more events after the window change nothing
    for (int i = 15; i < 20; ++i) ev(3, 1, 7000.00f, 10, h.now, 100 + i);
    run(p, 5000); h.draws.clear(); p->draw();
    CHECK(lineText(h) && lineText(h)->text == drawn, "later fills: the locked line is unchanged");
    const std::string r1 = readAll(rec);
    CHECK(r1.compare(0, 13, "wall_arrival|") == 0 && r1.find("|frozen|PullStats|-1|" + locked + "|") != std::string::npos && r1.find("|frozen|Pulling|") != std::string::npos, "the locked read is recorded (one row per pane)");
    CHECK(r1.find("\x97 bids stayed before touch (20% pulled) ?\n") != std::string::npos, "the frozen row ends with the pre-touch text");
    // restart AFTER the lock: read back, same text, while price is still in the zone
    dispose(p);
    PullStats* q = static_cast<PullStats*>(CreateExtension());
    ev(3, 1, 7001.00f, 1, h.now, 950); ev(0, 1, 7001.00f, 1, h.now, 951);
    run(q, 100); run(q, 100); h.draws.clear(); q->draw();
    CHECK(lineText(h) && lineText(h)->text == drawn && lineText(h)->color == off::C_RED_SPIKE, "after a restart (price still in the zone): the same locked read from the record");
    // price leaves the zone: nothing
    h.bars.back().close = 7010.0f;
    ev(3, 0, 7010.00f, 1, h.now, 960); ev(0, 0, 7010.00f, 1, h.now, 961);
    run(q, 100); h.draws.clear(); q->draw();
    CHECK(!lineText(h), "out of the zone: no line");
    dispose(q);
    // ---- RESTART INSIDE THE WINDOW: a second level (6980 PDL2) ----
    {   std::ofstream f((flex + "\\LRA-KeyLevels-ES.csv").c_str()); f << "KEYLV,1," << (long long)std::time(NULL) << "\nL|PDL|7000.00|0\nL|ONL|6980.00|0\n"; }
    mock::Bar nb; nb.time = t0 + 180 * 3; nb.high = 7011; nb.low = 7009; nb.open = nb.close = 7010; nb.volume = 10; h.bars.push_back(nb);   // a close above both zones re-arms
    mock::Bar nb2 = nb; nb2.time = t0 + 180 * 4; h.bars.push_back(nb2); h.now = t0 + 180 * 4 - 100;
    PullStats* a = static_cast<PullStats*>(CreateExtension());
    run(a, 100); run(a, 11000); auto* A = a->testState();
    for (int i = 0; i < 10; ++i) ev(0, 1, 6980.00f, 10, h.now, 3000 + i);
    for (int k = 0; k < 22; ++k) { ev(0, 1, 6970.00f, 1, h.now, 6000 + k); run(a, 15000); }
    h.bars.back().close = 6982.0f; h.bars.back().low = 6982.0f;
    ev(3, 1, 6982.00f, 1, h.now, 7000); ev(0, 1, 6982.00f, 1, h.now, 7000); run(a, 1000);
    ev(3, 1, 6980.00f, 1, h.now, 3000); h.bars.back().close = 6980.0f; h.bars.back().low = 6980.0f; run(a, 1000);
    CHECK(A->zr.e.cur.state == zread::MEASURE && A->zr.e.cur.c == 27920, "second encounter (6980) measuring");
    run(a, 30000);
    if (getenv("DBG")) std::printf("%s\n", readAll(A->zr.recPath).c_str());
    CHECK(readAll(A->zr.recPath).find("|6980|ONL|0|support|14|6|60|arrived|PullStats|") != std::string::npos, "its arrived row is recorded");
    h.now += 60; dispose(a);                                         // IRT closes 1 minute after the arrival
    PullStats* b = static_cast<PullStats*>(CreateExtension());
    run(b, 100); run(b, 100); auto* B = b->testState();
    ev(3, 1, 6980.25f, 1, h.now, 7100); ev(0, 1, 6980.25f, 1, h.now, 7101); run(b, 100);
    h.draws.clear(); b->draw(); dump(h);
    const mock::Draw* ln = nullptr; for (auto& d : h.draws) if (d.type == "text" && d.text.compare(0, 8, "ES 6980 ") == 0) ln = &d;
    CHECK(!ln && B->zr.e.cur.state == zread::NONE, "restarted 1:00 into the window: nothing drawn, no second encounter");
    run(b, 125000); h.draws.clear(); b->draw(); dump(h);
    ln = nullptr; for (auto& d : h.draws) if (d.type == "text" && d.text.compare(0, 8, "ES 6980 ") == 0) ln = &d;
    if (getenv("DBG")) std::printf("B state %d kept %zu restored %lld [%s]\n", B->zr.e.cur.state, B->zr.e.kept.size(), B->zr.restored, B->zr.e.line(zread::P_PULLSTATS, off::off_test_now_ms).text.c_str());
    CHECK(ln && B->zr.e.line(zread::P_PULLSTATS, off::off_test_now_ms).text == "ES 6980 \x97 bids: arrival read not known (restarted during the 3 min) ?" && ln->color == off::C_NEUTRAL, "after the window: grey 'arrival read not known (restarted during the 3 min) ?'");
    dispose(b);
    std::printf("pullstats zone host (PullStats %s, ZoneRead %s): %d passed, %d failed\n", ps::VERSION, zread::VERSION, passes, fails); return fails ? 1 : 0;
}
