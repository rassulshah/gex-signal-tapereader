"""Seed LRA-ZoneReadNorms-<MKT>.csv from the MBO study event cache (lra.mbo_study 1.13.0, touch rows, MEDIUM width, the study's
population A). Metrics per arrival: pull_def = coh_def_pulled / coh_def_shown, fill_def = coh_def_filled (lots), added (lots),
aggr = aggr_vol (lots), pull_app = coh_app_pulled / coh_app_shown. Per 30-min CT slot of t_arr (slot = minute the slot starts) and ALL:
median, MAD (unscaled), n."""
import csv, gzip, glob, os, sys, statistics as st
src, out = sys.argv[1], sys.argv[2]
rows = {}
for p in sorted(glob.glob(os.path.join(src, "*_portal.csv.gz"))):
    m = os.path.basename(p)[:2]
    with gzip.open(p, "rt") as f:
        for r in csv.DictReader(f):
            if r.get("kind") != "touch" or r.get("variant") != "medium": continue
            rows.setdefault(m, []).append(r)
def fl(x):
    try: v = float(x); return v if v == v else None
    except: return None
for m, R in sorted(rows.items()):
    vals = {k: {} for k in ("pull_def", "fill_def", "added", "aggr", "pull_app")}
    for r in R:
        t = r["t_arr"]; hh, mm = int(t[11:13]), int(t[14:16]); slot = (hh * 60 + mm) // 30 * 30
        sh, pu, fi = fl(r["coh_def_shown"]), fl(r["coh_def_pulled"]), fl(r["coh_def_filled"])
        if sh and sh > 0 and pu is not None: vals["pull_def"].setdefault(slot, []).append(pu / sh)
        if sh and sh > 0 and fi is not None: vals["fill_def"].setdefault(slot, []).append(fi)
        for k, c in (("added", "added"), ("aggr", "aggr_vol")):
            v = fl(r[c])
            if v is not None and v >= 0: vals[k].setdefault(slot, []).append(v)
        a, b = fl(r["coh_app_shown"]), fl(r["coh_app_pulled"])
        if a and a > 0 and b is not None: vals["pull_app"].setdefault(slot, []).append(b / a)
    L = ["# LRA zone-read normals (seed) - from lra.mbo_study 1.13.0 event cache (touch rows, MEDIUM width, %d arrivals, %s..%s); "
         "written 2026-10-14 night for lsBidAskStats / lsStackStats / lsPullStats / lsPulling ZoneRead.h 1.0.0; median / MAD (unscaled) / n per 30-min CT slot"
         % (len(R), min(r["session"] for r in R), max(r["session"] for r in R)), "VERSION|1", "MARKET|" + m]
    def row(k, s, v):
        med = st.median(v); mad = st.median([abs(x - med) for x in v])
        L.append("NORM|%s|%s|%.6g|%.6g|%d" % (k, s, med, mad, len(v)))
    for k in vals:
        allv = [x for s in vals[k] for x in vals[k][s]]
        if allv: row(k, "ALL", allv)
        for s in sorted(vals[k]): row(k, str(s), vals[k][s])
    open(os.path.join(out, "LRA-ZoneReadNorms-%s.csv" % m), "w", newline="\r\n").write("\n".join(L) + "\n")
    print(m, len(R), {k: sum(len(v) for v in vals[k].values()) for k in vals})
