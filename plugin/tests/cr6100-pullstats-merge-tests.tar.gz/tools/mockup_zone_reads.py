import sys, random
from PIL import Image, ImageDraw, ImageFont
FD="/usr/share/fonts/truetype/dejavu/"
def f(s,b=False): return ImageFont.truetype(FD+("DejaVuSans-Bold.ttf" if b else "DejaVuSans.ttf"),s)
BG=(11,14,18); G=(34,197,94); R=(239,68,68); GREY=(156,163,175); W=(225,228,232)
src=Image.open(sys.argv[1]); w,h=src.size
PH=170; out=Image.new("RGB",(w,h+PH+26+175),BG); out.paste(src,(0,0)); d=ImageDraw.Draw(out)
d.rectangle([0,0,w,30],fill=BG)
d.text((10,8),"MOCKUP v2 10-14 night: ONE read line per order-flow pane in place of the read box (only while price is in a key / gamma zone) - top 3 panes = the plugins' own draw calls",fill=W,font=f(13,True))
# zone band on the price pane: LonLO 92.90 +/- 0.06 ADR (CL ADR ~2.40 -> +/-0.14)
def y(p): top=34; lo=92.86-0.05+0.0; return None
# erase boxes (x 3..364) in the three panes and draw the line
panes=[(363,"CL 92.90 — sellers hitting 3.1x normal, price held ?",G),
       (559,"CL 92.90 — bids stacking 2.3x normal ?",G),
       (755,"CL 92.90 — offers pulled before touch (45%) ?",G)]
if len(sys.argv) < 4:
  for top,txt,c in panes:
    d.rectangle([2,top,366,top+82],fill=BG)
    d.text((8,top+3),txt,fill=c,font=f(12,True))
# price-pane zone band
pt=34; hi=93.74; lo=92.86
yy=lambda p: pt+6+(93.79-p)/(93.79-92.81)*(300-12)
d.rectangle([0,yy(92.90+0.14),1130,yy(92.90-0.14)],outline=(245,158,11))
d.text((140,yy(92.90+0.14)-14),"LonLO zone 92.76 - 93.04 (±0.06 ADR, ADR 2.40)",fill=(245,158,11),font=f(10))
# Pulling pane
T=h+26; d.text((4,T-18),"Pulling 0.3.0 - who pulled resting orders near price (lines = x the normal pulling; read line replaces the header readout)",fill=W,font=f(12))
d.rectangle([0,T,1130,T+PH],outline=(40,44,50))
d.text((6,T+2),"PULLING   ",fill=GREY,font=f(11,True))
d.text((80,T+2),"CL 92.90 — bids traded, held (2.1x normal) — support holding ?",fill=G,font=f(11,True))
d.text((1060,T+2),"MBO 98%",fill=GREY,font=f(11,True))
random.seed(3); base=T+PH-6
yl=lambda v: base-(PH-26)*min(1,v/4.0)
d.line([0,yl(1.5),1130,yl(1.5)],fill=(51,65,85)); d.text((1096,yl(1.5)-14),"1.5x",fill=GREY,font=f(10))
for col,seed in ((R,1),(G,2)):
    random.seed(seed); pts=[]
    for i in range(48):
        x=44+i*22.2; v=max(0.2,random.gauss(1.0,0.35)+(1.6 if (col==R and i==27) else 0)+(1.2 if (col==G and i==33) else 0)); pts.append((x,yl(v)))
    d.line(pts,fill=col,width=2)
    for x,yv in pts: d.rectangle([x-2,yv-2,x+2,yv+2],fill=col)
# variants + hover
H0=T+PH+12
d.text((6,H0),"Other states (same spot, same rules):",fill=W,font=f(12,True))
rows=[("Pulling","CL 92.90 — bids pulled, not filled (62% in 3 min) — less support ?",R),
      ("Pulling","CL 92.90 — bids: measuring 1:20 of 3:00 ?",GREY),
      ("StackStats","CL 92.90 — no new bids ?",GREY),
      ("BidAskStats","CL 92.90 — sellers hitting 3.1x, price through ?",R),
      ("PullStats","CL 92.90 — bids pulled before touch (45%) ?",R),
      ("all","(price outside every key / gamma zone: no line)",GREY)]
for k,(p,t,c) in enumerate(rows):
    d.text((14,H0+18+k*17),p,fill=GREY,font=f(11)); d.text((110,H0+18+k*17),t,fill=c,font=f(11,True))
# hover example box (right)
hx=640; hy=H0; lines=["Pulling read  ·  CL 92.90 LonLO (key)  ·  support",
 "Arrived 9:12 AM, window closed 9:15 AM (locked)",
 "Bids resting in the zone at arrival: 212 lots (38 orders)",
 "Traded 141 lots (67%) · cancelled 22 lots (10%)",
 "Traded 2.1x this slot's normal (9:00-9:30, median 67 lots)",
 "Q: is the size at the level being cancelled or traded?",
 "Use: cancelled = give the level less weight; wait for RB / CoB",
 "Study 10-14: cancelled share top-of-normal -> held ~19 pp",
 " less often; association only, NOT YET proven ?"]
d.rectangle([hx,hy,hx+480,hy+16*len(lines)+10],fill=(0,0,0),outline=GREY)
for k,l in enumerate(lines): d.text((hx+6,hy+5+16*k),l,fill=W if k else G,font=f(10,k==0))
out.save(sys.argv[2]); print(out.size)
