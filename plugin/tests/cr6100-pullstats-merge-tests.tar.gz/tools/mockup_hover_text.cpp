#include <sstream>
#include <map>
#include <deque>
#include <unordered_map>
#include <fstream>
#include <locale>
#include <vector>
#include <string>
#include <algorithm>
#include <cmath>
#include <cstdlib>
#define private public
#include "ZoneRead.h"
#include <cstdio>
using namespace zread;
int main(int, char** v) {
    Engine e; e.market = "CL"; e.tick = 0.01;
    Norms n; parseNorms("VERSION|1\nMARKET|CL\nNORM|pull_def|540|0.28|0.09|31\nNORM|fill_def|540|67|30|31\nNORM|pull_app|540|0.18|0.07|31\n", "CL", n); e.norms = n;
    Enc c; c.c = 9290; c.name = "LonLO"; c.kind = 0; c.support = true; c.minArr = 552; c.nOrders = 38; c.shown = 212;
    c.preShown = 240; c.prePulled = 29; c.preFilled = 6; c.preMoved = 4;
    int s = atoi(v[1]);
    if (s == 0) { c.pulled = 131; c.filled = 9; c.moved = 6; }
    if (s == 1) { c.pulled = 22; c.filled = 141; c.moved = 3; }
    if (s == 2) { c.pulled = 64; c.filled = 50; c.moved = 5; c.through = false; }
    Line L = e.pullStatsLineOf(c);
    std::printf("%d\t%s\n", L.impl, L.text.c_str());
    for (auto& h : L.hover) std::printf("%s\n", h.c_str());
}
