import sys
from PIL import Image, ImageDraw, ImageFont
B="/home/claude/aud/cr6100/build/"; FD="/usr/share/fonts/truetype/dejavu/"
def f(s,b=False,mono=False): return ImageFont.truetype(FD+("DejaVuSansMono" if mono else "DejaVuSans")+("-Bold" if b else "")+".ttf",s)
BG=(11,14,18); G=(34,197,94); R=(239,68,68); GREY=(156,163,175); W=(225,228,232); AMB=(245,158,11)
old=Image.open("/home/claude/aud/panes/mockup-pull-read.png").convert("RGB")
TOPH=735                                   # price pane + BidAskStats + StackStats exactly as before
crop=lambda p:Image.open(B+p).convert("RGB").crop((0,735,1230,923))
states=[("pn.png","STATES 1 + 2 - approaching the level / measuring the first 3 minutes:  NO line (nothing until the read locks)",GREY),
        ("pa.png","STATE 3 locked at 3:00 - the defending bids were PULLED, not filled:  red (at resistance, offers pulled = green)",R),
        ("pb.png","STATE 3 locked at 3:00 - the bids TRADED and price HELD:  green (at resistance, offers traded + held = red)",G),
        ("pc.png","STATE 3 locked at 3:00 - MIXED (cancelled share under the line, traded under 1.0x normal):  grey",GREY)]
PH=188; HOV=13*16+16
H=TOPH+len(states)*(PH+22)+HOV+70
out=Image.new("RGB",(1230,H),BG); out.paste(old.crop((0,0,1230,TOPH)),(0,0)); d=ImageDraw.Draw(out)
d.rectangle([0,0,1230,30],fill=BG)
d.text((10,8),"MOCKUP 10-14 night: lsPullStats 1.5.0 - lsPulling's read merged in (lsPulling retired) - the line shows ONLY the locked arrival read",fill=W,font=f(13,True))
y=TOPH
for k,(p,cap,col) in enumerate(states):
    d.text((6,y+3),cap,fill=col,font=f(12,True)); y+=22
    im=crop(p); out.paste(im,(0,y))
    d.rectangle([0,y,1230,y+15],fill=BG)
    d.text((4,y+1),"PullStats 1.5.0 - who is LEAVING (bars = lots pulled near price; bars, spike labels and letters unchanged)",fill=W,font=f(12,False,True))
    if k==1: hy=y+38
    y+=PH
# the hover of the red state, as the plugin wraps it (<= 700 px, under the line)
lines=open("hov0.txt",encoding="utf-8").read().splitlines()[1:]
hx=4; hw=700
d.text((6,y+8),"Mouse on the red line (state 3) - its detail box (drawn over the bars, under the line; rows in order of importance, the pane shows as many as fit):",fill=W,font=f(12,True))
by=y+30; d.rectangle([hx,by,hx+hw,by+16*len(lines)+10],fill=(0,0,0),outline=GREY)
for i,l in enumerate(lines):
    c=R if i==0 else W
    d.text((hx+6,by+5+16*i),l,fill=c,font=f(10,i==0))
nx=hx+hw+20
notes=["Rules (unchanged): only inside a key / gamma zone (level +/- 0.06 ADR);",
       "arrival = first trade within the level band; window 3:00; always '?';",
       "never repainted; read back from the session record after a restart.",
       "",
       "Restart INSIDE the 3 minutes: nothing until the window ends, then",
       "grey 'bids: arrival read not known (restarted during the 3 min) ?'",
       "(the orders resting before the restart cannot be followed).",
       "",
       "Pre-touch share (the Before the touch row): measured at arrival,",
       "recorded in the session CSV, shown only here - no line of its own.",
       "",
       "lsPulling 1.0.0: retired stub - draws nothing, no settings."]
for i,l in enumerate(notes): d.text((nx,by+2+16*i),l,fill=GREY if l else W,font=f(11))
out.save(sys.argv[1]); print(out.size)
