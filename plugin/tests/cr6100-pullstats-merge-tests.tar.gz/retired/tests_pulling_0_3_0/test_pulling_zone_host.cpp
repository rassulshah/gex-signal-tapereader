// test_pulling_zone_host.cpp -- lsPulling 0.3.0 on the mock host: the ONE zone read line wired end to end (ZoneRead.h through the plugin):
// levels from LRA-KeyLevels, the lagged ADR from the chart's bars, normals from LRA-ZoneReadNorms, the order feed's ids, the 3-minute
// window on the plugin's clock, the line drawn only inside the zone, locked, recorded and read back after a restart (no repaint).
#define PL_TEST_CLOCK
#include "Pulling.cpp"
#include <cstdio>
#include <unistd.h>
#include <sys/stat.h>
long long pl_test_now_ms = 1000000;
namespace mock { Host* current = nullptr; }
static int fails = 0, passes = 0;
#define CHECK(c, m) do { if (c) ++passes; else { ++fails; std::printf("FAIL %d %s\n", __LINE__, m); } } while (0)
static std::string readAll(const std::string& p) { std::ifstream f(p.c_str()); std::stringstream s; s << f.rdbuf(); return s.str(); }
static DEPTH_ORDER ev(int a, int side, float px, unsigned long sz, int id, RTDATE ts) { DEPTH_ORDER o; std::memset(&o, 0, sizeof(o)); o.action = (unsigned char)a; o.buySell = (unsigned char)side; o.price = px; o.size = sz; o.orderID = id; o.bid = 0; o.ask = 0; o.timestamp = ts; return o; }
static const mock::Draw* lineText(mock::Host& h) { for (auto& d : h.draws) if (d.type == "text" && d.text.compare(0, 8, "ES 7000 ") == 0) return &d; return nullptr; }
int main() {
    char tmpl[] = "/tmp/plzXXXXXX"; const char* tmp = mkdtemp(tmpl); setenv("USERPROFILE", tmp, 1);
    const std::string flex = std::string(tmp) + "\\InvestorRT\\rtx\\lsFlexLevels";
    { std::ofstream f((flex + "\\LRA-KeyLevels-ES.csv").c_str()); f << "KEYLV,1," << (long long)std::time(NULL) << "\nL|PDL|7000.00|0\n"; }
    { std::ofstream f((flex + "\\LRA-ZoneReadNorms-ES.csv").c_str()); f << "VERSION|1\nMARKET|ES\nNORM|pull_def|ALL|0.30|0.10|100\nNORM|fill_def|ALL|100|40|100\nNORM|added|ALL|1000|400|100\nNORM|aggr|ALL|500|200|100\nNORM|pull_app|ALL|0.20|0.06|100\n"; }
    mock::Host h; mock::current = &h; h.tick = 0.25f; h.seconds = 180; h.symbol = "ESZ6"; h.root = "ES";
    const unsigned long day = (unsigned long)(civilDays(2026, 10, 12) * 86400LL);
    // 12 prior sessions, each one bar of range 60 (ADR 60 -> zone +/- 3.6 = 14 ticks), then today's bars above the level
    for (int d = 12; d >= 1; --d) { mock::Bar b; b.time = day - d * 86400 + 10 * 3600; b.high = 7040; b.low = 6980; b.open = b.close = 7010; b.volume = 10; h.bars.push_back(b); }
    unsigned long t0 = day + 9 * 3600;
    for (int i = 0; i < 3; ++i) { mock::Bar b; b.time = t0 + 180 * i; b.high = 7012; b.low = 7008; b.open = b.close = 7010; b.volume = 10; h.bars.push_back(b); }
    DEPTH_LEVEL L; L.bid = 7009.75f; L.ask = 7010.00f; L.bidsize = 10; L.asksize = 10; h.depth.push_back(L);
    h.now = t0 + 2 * 180 - 60;
    Pulling* p = static_cast<Pulling*>(CreateExtension());
    pl_test_now_ms += 100; p->calc(0);
    PLState* S = p->testState();
    CHECK(S && S->zr.e.lv.size() == 1 && S->zr.e.adr > 59.9 && S->zr.e.adr < 60.1 && S->zr.e.zoneHalf == 14, "PDL loaded; ADR 60 from the chart's prior sessions; zone +/- 14 ticks");
    h.draws.clear(); p->draw();
    CHECK(!lineText(h), "price 7010 (outside the zone): no line");
    // bids resting at the level (the cohort), then price trades down into the zone
    for (int i = 0; i < 10; ++i) h.dboQueue.push_back(ev(0, 1, 7000.00f, 10, 100 + i, h.now));
    h.dboQueue.push_back(ev(3, 1, 7002.00f, 1, 900, h.now)); h.dboQueue.push_back(ev(0, 1, 7002.00f, 1, 900, h.now));
    pl_test_now_ms += 1000; p->calc(0); h.draws.clear(); p->draw();
    const mock::Draw* l = lineText(h);
    CHECK(l && l->text.find("level not reached yet ?") != std::string::npos, "in the zone (armed by the close above it): 'level not reached yet ?'");
    h.dboQueue.push_back(ev(3, 1, 7000.00f, 2, 100, h.now));          // the first trade at the level: arrival
    h.bars.back().close = 7000.25f; h.bars.back().low = 6999.75f;      // the forming bar follows price
    pl_test_now_ms += 1000; p->calc(0);
    CHECK(S->zr.e.cur.state == zread::MEASURE && S->zr.e.cur.shown == 100, "arrival: 100 lots of bids at the level");
    for (int i = 1; i < 8; ++i) h.dboQueue.push_back(ev(2, 1, 7000.00f, 10, 100 + i, h.now));   // 70 lots cancelled, not traded
    pl_test_now_ms += 60000; p->calc(0); h.draws.clear(); p->draw();
    l = lineText(h);
    if (getenv("DBG")) std::printf("[%s] state %d\n", l ? l->text.c_str() : "none", S->zr.e.cur.state);
    CHECK(l && l->text.find("bids: measuring 1:00 of 3:00 ?") != std::string::npos, "measuring 1:00 of 3:00");
    pl_test_now_ms += 120000; p->calc(0); h.draws.clear(); p->draw();
    l = lineText(h);
    const std::string locked = l ? l->text : std::string();
    CHECK(l && l->text.find("bids pulled, not filled (70% in 3 min)") != std::string::npos && l->color == C_SELL, "locked at 3 min: red 'bids pulled, not filled (70% in 3 min) - less support ?'");
    // the mouse on the line: its detail box
    { RTX_EVENT e; std::memset(&e, 0, sizeof(e)); e.type = E_MOUSE_MOVE; e.v.mouse.h = (short)(l ? l->x + 5 : 0); e.v.mouse.v = 5; const int inv = h.invalidates; p->mouse(&e);
      h.draws.clear(); p->draw(); bool study = false; for (auto& d : h.draws) if (d.type == "text" && d.text.find("Study 10-14") == 0) study = true;
      CHECK(S->hoverOn && h.invalidates == inv + 1 && study, "mouse on the line: the detail box with the study caveat");
      e.v.mouse.h = 900; e.v.mouse.v = 200; p->mouse(&e); CHECK(!S->hoverOn, "mouse off the line: no detail box"); }
    // no repaint: more events after the window change nothing
    for (int i = 8; i < 10; ++i) h.dboQueue.push_back(ev(3, 1, 7000.00f, 10, 100 + i, h.now));
    pl_test_now_ms += 5000; p->calc(0); h.draws.clear(); p->draw();
    CHECK(lineText(h) && lineText(h)->text == locked, "later fills: the locked line is unchanged");
    const std::string rec = readAll(flex + "\\Pulling\\ES-ESZ6-180-zoneread-" + std::to_string(S->zrSession) + ".csv");
    CHECK(rec.find("wall_arrival|") == 0 && rec.find("|Pulling|-1|" + locked + "|") != std::string::npos, "the locked read is recorded (one line per pane)");
    // restart: read back, same text, while price is still in the zone
    p->destroy();
    Pulling* q = static_cast<Pulling*>(CreateExtension());
    h.dboQueue.push_back(ev(3, 1, 7001.00f, 1, 950, h.now)); h.dboQueue.push_back(ev(0, 1, 7001.00f, 1, 950, h.now));
    q->calc(0); pl_test_now_ms += 100; q->calc(0); h.draws.clear(); q->draw();
    CHECK(lineText(h) && lineText(h)->text == locked, "after a restart (price still in the zone): the same locked read from the record");
    // price leaves the zone: nothing
    h.bars.back().close = 7010.0f;
    h.dboQueue.push_back(ev(3, 0, 7010.00f, 1, 960, h.now)); h.dboQueue.push_back(ev(0, 0, 7010.00f, 1, 960, h.now));
    pl_test_now_ms += 100; q->calc(0); h.draws.clear(); q->draw();
    CHECK(!lineText(h), "out of the zone: no line");
    q->destroy();
    ::operator delete(q); ::operator delete(p);
    std::printf("pulling zone host: %d passed, %d failed\n", passes, fails); return fails ? 1 : 0;
}
