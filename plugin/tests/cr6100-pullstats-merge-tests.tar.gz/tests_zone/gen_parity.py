import sys, random, numpy as np
sys.path.insert(0, sys.argv[1]); from zone_outcome_study import zone_outcome
random.seed(7); out=[]
for case in range(400):
    n=random.randint(8,60); c=100.0; C=[];H=[];L=[]
    for i in range(n):
        o=c; c=c+random.gauss(0,0.6); C.append(round(c,2)); H.append(round(max(o,c)+abs(random.gauss(0,0.3)),2)); L.append(round(min(o,c)-abs(random.gauss(0,0.3)),2))
    adr=random.choice([2.0,3.0,5.0]); side=random.choice(['above','below']); cen=C[0]+random.uniform(-1,1)
    w=0.06*adr; x=0.10*adr; lo,hi=cen-w,cen+w; i_end=n-1
    o=zone_outcome(np.array(H),np.array(L),np.array(C),0,side,lo,hi,x,i_end)
    out.append("%s %.6f %.6f %.6f %d %s %d %d %d" % (side,lo,hi,x,n," ".join("%.2f"%v for v in C),{"REV":1,"CONT":2,"PIN":3}[o['res']],o['k_res'],o["failed_breaks"]))
open(sys.argv[2],'w').write("\n".join(out)+"\n")
print(len(out))
