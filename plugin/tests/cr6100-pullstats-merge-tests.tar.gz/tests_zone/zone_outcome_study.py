import numpy as np
ACCEPT_BARS, HORIZON_BARS = 5, 40
def zone_outcome(H, L, C, j: int, side: str, lo: float, hi: float, x: float, i_end: int,
                 accept: int = ACCEPT_BARS, horizon: int = HORIZON_BARS, gaps=None) -> dict:
    """PURE: how an event that ENTERED the zone [lo, hi] at bar j from `side` ('above' = came down = support test, 'below' = came up)
    resolved, with CLOSE-based acceptance:
      REV  first close >= x beyond the near edge (from bar j on);
      CONT first close >= x beyond the far edge with no close back inside [lo, hi] (or beyond it toward the entry side) within
           `accept` bars; otherwise a FAILED break - counted, and the event continues after the bar that closed back;
      PIN  neither by min(j + horizon, i_end).
    Depth (pen) = how far past the near edge, over = past the level midpoint, beyond_far = past the far edge - all measured up to
    the resolving bar (exclusive of the accepted breaking bar for CONT). tick_res = the old tick rule (a TRADE x beyond an edge first)
    for comparison."""
    up = side == "below"                          # came up into the zone (resistance test)
    near, far = (lo, hi) if up else (hi, lo)
    mid = 0.5 * (lo + hi)
    end = min(i_end, j + horizon)
    res, k_res, failed = "PIN", end, 0
    k = j
    while k <= end:
        c = C[k]
        if (c <= near - x) if up else (c >= near + x):
            res, k_res = "REV", k
            break
        if (c >= far + x) if up else (c <= far - x):
            back = None
            for q in range(k + 1, min(k + accept, i_end) + 1):
                if (C[q] <= hi) if up else (C[q] >= lo):
                    back = q
                    break
            if back is None:
                res, k_res = "CONT", k
                break
            failed += 1
            k = back + 1
            continue
        k += 1
    k_end = k_res if res != "CONT" else max(j, k_res - 1)
    if up:
        ext = float(np.max(H[j:k_end + 1]))
        pen, over, beyond = ext - near, ext - mid, ext - far
    else:
        ext = float(np.min(L[j:k_end + 1]))
        pen, over, beyond = near - ext, mid - ext, far - ext
    tick_res = "PIN"
    for q in range(j, end + 1):
        tc = (H[q] >= far + x) if up else (L[q] <= far - x)
        tr = q > j and ((L[q] <= near - x) if up else (H[q] >= near + x))
        if tc or tr:
            tick_res = "AMBIG" if (tc and tr) else ("CONT" if tc else "REV")
            break
    through = bool((H[j:k_end + 1].max() > mid) if up else (L[j:k_end + 1].min() < mid))
    if gaps is not None and bool(np.any(gaps[j + 1:k_res + 1])):
        res = "CENSORED"                            # a feed gap inside the window: censored, never scored as REV / CONT
    return dict(res=res, k_res=int(k_res), failed_breaks=int(failed), ext=ext, pen=float(pen), over=float(over),
                beyond_far=float(beyond), tick_res=tick_res, traded_through_level=through)


