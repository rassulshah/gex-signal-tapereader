// test_bas_logic.cpp -- BidAskStatsLogic.h unit tests. g++ -std=c++17 -I.. test_bas_logic.cpp -o tl && ./tl
#include "BidAskStatsLogic.h"
#include <cstdio>
static int fails = 0, passes = 0;
#define CHECK(c, m) do { if (c) ++passes; else { ++fails; std::printf("FAIL %d %s\n", __LINE__, m); } } while (0)
using namespace bas;
static Row R(double p, long long b, long long a) { Row r; r.price = p; r.bid = b; r.ask = a; return r; }
static BarMax M(long long b, long long a) { BarMax m; m.ok = true; m.bid = b; m.ask = a; return m; }
static BarMax NA() { return BarMax(); }
int main() {
    // ---- per-bar max
    {
        std::vector<Row> rows = { R(7000.00, 12, 3), R(7000.25, 40, 9), R(7000.50, 7, 55), R(7000.75, 0, 20) };
        BarMax m = maxOf(rows, .25);
        CHECK(m.ok && m.bid == 40 && m.bidPx == 7000.25 && m.ask == 55 && m.askPx == 7000.50, "max bid / ask and their prices");
    }
    {   // ties: bid -> lowest price, ask -> highest; independent of row order
        std::vector<Row> a = { R(10.5, 30, 8), R(10.0, 30, 8), R(10.25, 1, 8) };
        std::vector<Row> b = { R(10.25, 1, 8), R(10.0, 30, 8), R(10.5, 30, 8) };
        BarMax x = maxOf(a, .25), y = maxOf(b, .25);
        CHECK(x.bid == 30 && x.bidPx == 10.0 && x.ask == 8 && x.askPx == 10.5, "ties: bid at the lowest, ask at the highest price");
        CHECK(y.bidPx == x.bidPx && y.askPx == x.askPx, "ties do not depend on row order");
    }
    {   // rows of the same tick (float noise) are summed on the tick grid
        std::vector<Row> rows = { R(7000.2499, 10, 1), R(7000.2501, 15, 2), R(7000.5, 20, 1) };
        BarMax m = maxOf(rows, .25);
        CHECK(m.ok && m.bid == 25 && m.bidPx == 7000.25, "same-tick rows summed on the chart tick grid");
    }
    {   // malformed rows -> the whole bar n/a, never a partial answer
        std::vector<Row> neg = { R(1, 5, 5), R(2, -1, 3) };
        std::vector<Row> nan = { R(1, 5, 5), R(0.0 / 0.0, 1, 1) };
        CHECK(!maxOf(neg, .25).ok && !maxOf(nan, .25).ok, "negative volume / NaN price -> n/a");
        CHECK(!maxOf(neg, 0).ok && !maxOf(std::vector<Row>{R(1, 1, 1)}, -1).ok, "bad tick -> n/a");
        BarMax e = maxOf(std::vector<Row>(), .25);
        CHECK(e.ok && e.bid == 0 && e.ask == 0, "no rows (a bar that traded nothing) is a valid 0 / 0");
    }
    {   // volumes above 2^31 (lesson 2)
        std::vector<Row> rows = { R(1, 3000000000LL, 1), R(1, 3000000000LL, 1) };
        CHECK(maxOf(rows, .25).bid == 6000000000LL, "long long volumes, no overflow");
    }
    // ---- BBid / BAsk counts
    {
        bool cap = false;
        CHECK(countBiggest({}, 5, cap) == 1 && !cap, "first bar: biggest of 1");
        CHECK(countBiggest({ 1, 2, 3 }, 5, cap) == 4, "bigger than all 3 prior: 4");
        CHECK(countBiggest({ 9, 1, 2 }, 5, cap) == 3, "stops at the first bar that is not smaller");
        CHECK(countBiggest({ 1, 5 }, 5, cap) == 1, "equal is not smaller: 1");
        CHECK(countBiggest({ 7 }, 5, cap) == 1, "smaller than the previous: 1");
        std::vector<long long> many(2000, 1);
        int n = countBiggest(many, 5, cap);
        CHECK(n == COUNT_CAP && cap && fmtCount(n, cap, true) == "999+", "capped at 999 -> 999+");
        std::vector<long long> some(23 - 1, 1);
        const int n23 = countBiggest(some, 5, cap); CHECK(n23 == 23 && fmtCount(n23, cap, true) == "23", "biggest in 23 candles = 23");
    }
    // ---- ratios
    {
        bool ok = true;
        ratioOf({ 1, 2, 3, 4 }, 10, 20, ok); CHECK(!ok, "< 5 prior bars -> n/a");
        double r = ratioOf({ 10, 10, 10, 10, 10 }, 35, 20, ok); CHECK(ok && fmtRatio(ok, r) == "3.5x", "5 prior bars: 35 / 10 = 3.5x");
        std::vector<long long> p(30, 100); for (int i = 0; i < 10; ++i) p[i] = 1000;   // old big bars outside the last 20
        r = ratioOf(p, 250, 20, ok); CHECK(ok && fmtRatio(ok, r) == "2.5x", "only the last 20 prior bars are averaged");
        r = ratioOf(p, 250, 30, ok); CHECK(ok && std::fabs(r - 250.0 / 400.0) < 1e-12, "Ratio bars 30 averages 30");
        ratioOf({ 0, 0, 0, 0, 0 }, 5, 20, ok); CHECK(!ok, "zero mean -> n/a, not infinity");
        CHECK(fmtRatio(false, 1) == "n/a" && fmtRatio(true, 3.46) == "3.5x" && fmtRatio(true, 12.04) == "12.0x", "one decimal + x");
        CHECK(clampRatioBars(4) < 0 && clampRatioBars(201) < 0 && clampRatioBars(20) == 20, "Ratio bars 5-200");
    }
    // ---- the series: n/a bars excluded from counts and averages, stats frozen
    {
        Series s;
        for (int i = 0; i < 6; ++i) s.add(100 + i, M(10, 20), 20);
        s.add(200, NA(), 20);                      // n/a in the middle
        const Stat& x = s.add(300, M(30, 5), 20);
        CHECK(x.m.ok && x.bBid == 7 && x.bAsk == 1, "n/a bar skipped by the count (7 = itself + 6 valid prior)");
        CHECK(x.bidRatioOk && std::fabs(x.bidRatio - 3.0) < 1e-12 && x.askRatioOk && std::fabs(x.askRatio - .25) < 1e-12, "n/a bar excluded from the averages");
        CHECK(!s.bars[200].m.ok && boxLines(&s.bars[200])[0].value == "n/a", "the n/a bar itself shows n/a");
        Series f; f.add(1, M(5, 5), 20); const Stat& y = f.add(2, M(9, 1), 20);
        CHECK(y.bBid == 2 && !y.bidRatioOk && boxLines(&y)[2].value == "n/a", "second bar: BBid 2, ratio n/a (< 5 prior)");
        Series big; for (int i = 0; i < 1200; ++i) big.add(i, M(1, 1), 20);
        const Stat& z = big.add(5000, M(9, 1), 20);
        CHECK(boxLines(&z)[0].value == "999+" && z.bAsk == 1, "series cap at 999");
        const long long before = big.computed; big.add(5001, M(1, 1), 20);
        CHECK(big.computed == before + 1, "one new bar = one computation");
        // reratio: only ratios change
        s.reratio(5);
        CHECK(s.bars[300].bBid == 7 && std::fabs(s.bars[300].bidRatio - 3.0) < 1e-12, "reratio keeps counts");
    }
    // ---- box and layout helpers
    {
        CHECK(boxLines(nullptr).size() == 5 && boxLines(nullptr)[0].label == "BBid" && boxLines(nullptr)[3].label == "AskRatio" && boxLines(nullptr)[4].label == "Jump", "box lines in order");
        CHECK(boxLines(nullptr)[0].side < 0 && boxLines(nullptr)[1].side > 0 && boxLines(nullptr)[2].side < 0 && boxLines(nullptr)[3].side > 0, "bid lines red, ask lines green");
        Box a = { 0, 0, 400, 200 };
        Box tl = placeIn(a, 100, 50, 0), br = placeIn(a, 100, 50, 8), mc = placeIn(a, 100, 50, 4), bad = placeIn(a, 100, 50, 42);
        CHECK(tl.l == 0 && tl.t == 0 && br.r == 400 && br.b == 200 && mc.l == 150 && mc.t == 75 && bad.l == 0 && bad.t == 0, "9-spot position, bad -> top left");
        Box tiny = placeIn(Box{ 0, 0, 50, 20 }, 100, 50, 8); CHECK(tiny.l == 0 && tiny.t == 0, "clamped inside a small area");
        for (int slot = 1; slot <= 40; ++slot) {
            Pair p = pairIn(100, slot);
            const bool inside = p.redL >= 100 - (slot < 2 ? 2 : slot) / 2 - 1 && p.greenR <= 100 + (slot < 2 ? 2 : slot) / 2 + 1;
            if (!(p.redL < p.redR && p.greenL < p.greenR && p.redR <= p.greenL && inside)) { CHECK(false, "pair inside its slot"); break; }
            if (slot == 40) CHECK(true, "pair inside its slot, red left of green, all slot widths 1-40");
        }
        CHECK(barHeight(0, 10, 100) == 0 && barHeight(10, 10, 100) == 100 && barHeight(1, 1000, 100) == 1 && barHeight(5, 10, 100) == 50, "shared scale heights");
    }
    // ---- 1.1.0: hover, clock
    {
        CHECK(hoverIndex(0, 10) == 0 && hoverIndex(8, 10) == 8 && hoverIndex(9, 10) == -1 && hoverIndex(-1, 10) == -1 && hoverIndex(50, 10) == -1 && hoverIndex(0, 1) == -1,
              "hoverIndex: closed bars only; forming / out of range = Live");
        Hover hv; CHECK(!hv.set(-1) && hv.set(5) && !hv.set(5) && hv.set(6) && hv.set(-1) && !hv.set(-7) && hv.bar == -1, "Hover.set true only on a change");
        CHECK(clock12(0, 5) == "12:05 AM" && clock12(10, 24) == "10:24 AM" && clock12(12, 0) == "12:00 PM" && clock12(23, 59) == "11:59 PM" && clock12(24, 0) == "n/a",
              "12-hour clock");
        CHECK(tenthsOf(1.5f) == 15 && tenthsOf(0.0f) == 0 && tenthsOf(10.0f) == 100 && tenthsOf(10.5f) == -1 && tenthsOf(-1.0f) == -1 && clampLineTenths(101) == -1,
              "spike settings in tenths, 0..10.0");
        CHECK(fmtTenths(15) == "1.5x" && fmtTenths(20) == "2.0x", "tenths shown as a ratio");
        // the stored average is the one the ratio divides by, as of the bar (prior bars only): ratio > X  <=>  value > X * mean
        Series s2; for (int i = 0; i < 25; ++i) { BarMax b; b.ok = true; b.bid = 10 + (i % 3); b.ask = 20; s2.add(100 + i, b, 20); }
        BarMax hi; hi.ok = true; hi.bid = 17; hi.ask = 20; const Stat& h1 = s2.add(200, hi, 20);
        CHECK(h1.bidMean > 0 && std::fabs(h1.bidRatio - 17.0 / h1.bidMean) < 1e-12 && (h1.bidRatio > 1.5) == (17 > 1.5 * h1.bidMean), "stored average = the ratio's average (above)");
        BarMax lo; lo.ok = true; lo.bid = 15; lo.ask = 20; const Stat& h2 = s2.add(300, lo, 20);
        CHECK((h2.bidRatio > 1.5) == (15 > 1.5 * h2.bidMean) && h2.bidRatio < 1.5, "stored average = the ratio's average (below)");
        const double m200 = s2.bars[200].bidMean; s2.add(400, hi, 20);
        CHECK(s2.bars[200].bidMean == m200, "a later bar never changes an earlier bar's average");
        Series s3; BarMax one; one.ok = true; one.bid = 5; one.ask = 5; for (int i = 0; i < 3; ++i) s3.add(i, one, 20);
        CHECK(s3.bars[2].bidMean == 0, "no average (fewer than 5 prior bars) -> no line");
    }
    {   // (1.1.0) the value axis
        double mn = 0, mx = 0; axisFor(100, 306, mn, mx);
        CHECK(std::fabs(mn + 100.0 / 300) < 1e-12 && std::fabs(mx - 305 * 100.0 / 300) < 1e-12, "axis: 0 at yBase, top at the drawing's top");
        axisFor(0, 306, mn, mx); CHECK(mn == 0 && mx == 10, "no data: 0..10");
        axisFor(50, 10, mn, mx); CHECK(mn == 0 && mx > 50, "tiny pane: 0..top");
    }
    {   // (1.2.0) spikes
        SpikeCfg c;
        CHECK(isSpike(20, 10.0, 12, c) && !isSpike(19, 10.0, 12, c), "vs average boundary: exactly 2.0x is a spike, 1.9x is not");
        CHECK(isSpike(30, 10.0, 20, c) && !isSpike(30, 10.0, 21, c), "vs prior biggest boundary: exactly 1.5x is a spike, 1.43x is not");
        CHECK(!isSpike(30, 0.0, 10, c) && !isSpike(30, 10.0, 0, c) && !isSpike(0, 10.0, 1, c), "no average / no prior bars / nothing traded = no spike");
        SpikeCfg a0 = c; a0.avgT = 0; SpikeCfg j0 = c; j0.jumpT = 0; SpikeCfg l0 = c; l0.lookback = 0;
        CHECK(!isSpike(100, 10.0, 10, a0) && !isSpike(100, 10.0, 10, j0) && !isSpike(100, 10.0, 10, l0) && isSpike(100, 10.0, 10, c), "any spike setting 0 = off");
        std::vector<long long> pb = { 99, 1, 2, 3 }, pa = { 1, 1, 7, 1 };
        CHECK(priorMaxEither(pb, pa, 3) == 7 && priorMaxEither(pb, pa, 4) == 99 && priorMaxEither(pb, pa, 0) == 0 && priorMaxEither({}, {}, 10) == 0,
              "prior biggest = either side, only the last N bars");
        // series: as of the bar, prior bars only; either side's prior max blocks
        auto M = [](long long b, long long a) { BarMax m; m.ok = true; m.bid = b; m.ask = a; return m; };
        Series s; for (int i = 0; i < 20; ++i) s.add(i, M(10, 10), 20);
        const Stat b20 = s.add(20, M(25, 10), 20);
        CHECK(b20.bidSpike && !b20.askSpike && b20.priorMax == 10, "bid 25 vs average 10 (2.5x) and prior biggest 10 (2.5x) = bid spike");
        const Stat b21 = s.add(21, M(10, 25), 20);
        CHECK(!b21.askSpike && b21.priorMax == 25, "ask 25 is 2.5x its average but only 1.0x the prior biggest (the BID of the bar before): no spike");
        for (int i = 22; i < 40; ++i) s.add(i, M(500, 500), 20);
        CHECK(s.bars[20].bidSpike && s.bars[20].priorMax == 10, "later bars never change an earlier bar's spike");
        std::vector<long long> nb, na; for (int i = 0; i < 3; ++i) { nb.push_back(1); na.push_back(1); }
        Series few; for (int i = 0; i < 3; ++i) few.add(i, M(1, 1), 20);
        CHECK(!few.add(3, M(100, 100), 20).bidSpike, "fewer than 5 prior bars (no average) = no spike");
        SpikeCfg off = c; off.avgT = 0; s.respike(off);
        CHECK(!s.bars[20].bidSpike && s.bars[20].priorMax == 10, "respike with 0: off for every recorded bar");
        s.respike(c); CHECK(s.bars[20].bidSpike, "respike back: decided again from the stored values");
        const Stat pk = s.peek(1000, M(5000, 1), 20);
        CHECK(pk.bidSpike && !s.bars.count(1000), "peek (forming bar) decides without recording");
        CHECK(boxLines(&b20)[4].label == "Jump" && boxLines(&b20)[4].value == "2.5x" && boxLines(&b20)[4].side < 0, "Jump 2.5x on the bid side (red)");
        CHECK(boxLines(&b21)[4].value == "1.0x" && boxLines(&b21)[4].side > 0, "Jump on the ask side (green)");
    }
    std::printf("logic: %d passed, %d failed\n", passes, fails); return fails ? 1 : 0;
}
