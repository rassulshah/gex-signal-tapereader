// test_label_persist.cpp -- CR5300 (2026-10-14, Rassul 11:59 CT, CLZ6 3-min BidAskStats: "the label for pace and lots on the red spike
// goes away but it is there on the green spike. fix it .. also check other indicators").
// ROOT CAUSE (OrderFlowFeed.h <= 1.3.0 spikeLabels pass 2): a spike with no free label spot (under the read box / hover grid, the forming
// bar, a crowded spot) SHRANK the nearest already-placed full labels to their ratio alone - one after another until none were left - so
// a label lost its pace + lots because of a different candle. These tests fail on OrderFlowFeed.h 1.3.0 and pass on 1.3.1.
//   -DLOGIC (default)  spikeLabels / drawBars (the shared code of all three panes): the cascade case, seller / buyer mirror symmetry,
//                      "a later spike never changes an earlier label" (fuzz: every prefix), hover-grid independence, scroll stability
//   -DBAS              lsBidAskStats on the mock host: a buyer spike under the read box + a seller spike in the clear (and the mirror);
//                      the seller label keeps ratio / pace / lots after N more bars, every hover, the mouse in the box (grid), scrolling,
//                      a restart (record reload) and the 17:00 CT session boundary
//   -DPULL / -DSTACK   lsPullStats / lsStackStats on the mock host: the same, spikes from the order-by-order feed
#if defined(BAS)
#include "BidAskStats.cpp"
typedef BidAskStats Ind;
long long bas_test_now_ms = 1000000; void* bas_test_cursor_wnd = nullptr;
#define NOW bas_test_now_ms
static const char* const NAME = "BidAskStats";
#elif defined(PULL) || defined(STACK)
#if defined(STACK)
#include "StackStats.cpp"
typedef StackStats Ind;
static const char* const NAME = "StackStats";
#else
#include "PullStats.cpp"
typedef PullStats Ind;
static const char* const NAME = "PullStats";
#endif
namespace off { long long off_test_now_ms = 1000000; void* off_test_cursor_wnd = nullptr; }
#define NOW off::off_test_now_ms
#else
#define LOGIC 1
#include "irtsdk.h"
#define OFF_SDK 1
#include "OrderFlowFeed.h"
int cppExtension::init() { return 0; } int cppExtension::setup() { return 0; } int cppExtension::calc(int) { return 0; } int cppExtension::done() { return 0; } int cppExtension::destroy() { return 0; }
#endif
#include <cstdio>
#include <map>
#include <random>
#include <sys/stat.h>
namespace mock { Host* current = nullptr; Feed feed; }
static int fails = 0, passes = 0;
#define CHECK(c, m) do { if (c) ++passes; else { ++fails; std::printf("FAIL %d %s\n", __LINE__, m); } } while (0)

#ifdef LOGIC
// ------------------------------------------------------------------------------------------------------------ the shared label code
static int W(const std::string& s) { return (int)s.size() * 6; }
static off::SpikeIn S(int cx, int top, int side, const char* x, const char* p, const char* q) { off::SpikeIn a; a.cx = cx; a.barTop = top; a.side = side; a.x = x; a.p = p; a.q = q; return a; }
static const off::SLabel* of(const std::vector<off::SLabel>& L, int side, const std::string& x) { for (auto& l : L) if (l.side == side && l.x == x) return &l; return nullptr; }
static bool full(const off::SLabel* l) { return l && !l->p.empty() && !l->q.empty(); }
static std::string sig(const off::SLabel& l) { char b[160]; std::snprintf(b, sizeof(b), "%d,%d,%d,%d,%d|%s|%s|%s", l.l, l.t, l.r, l.b, l.side, l.x.c_str(), l.p.c_str(), l.q.c_str()); return b; }
// a cppExtension the shared drawBars can draw through (mock SDK), with the draws read back as spike labels: colour -> strings
struct Pane : cppExtension {};
static std::map<long, std::vector<std::string> > labelsDrawn(mock::Host& h, COLOR red, COLOR green) {
    std::map<long, std::vector<std::string> > m;
    for (auto& d : h.draws) if (d.type == "text" && (d.color == red || d.color == green)) m[(long)d.color].push_back(d.text);
    return m;
}
int main() {
    // 1) the cascade (Rassul's case): a seller label in the clear keeps ratio / pace / lots when a buyer spike sits under the read box
    {
        std::vector<off::SpikeIn> in; in.push_back(S(100, 60, 1, "3.0x", "p 2.0x", "90")); in.push_back(S(500, 120, 0, "5.0x", "p 1.3x", "111"));
        std::vector<off::LBox> box(1, off::LBox{ 3, 3, 380, 84, 0, 0 });
        const auto L = off::spikeLabels(in, 4, box, W, 1, 900);
        CHECK(full(of(L, 0, "5.0x")), "seller spike in the clear keeps its pace + lots when a buyer spike under the box has no room (1.3.0 shrank it)");
        CHECK(!of(L, 1, "3.0x") && !of(L, 1, "90"), "the boxed-in buyer spike draws nothing over the box");
        // the mirror: sides swapped -> the same rows (seller and buyer labels behave the same)
        std::vector<off::SpikeIn> mi = in; for (auto& s : mi) s.side = 1 - s.side;
        const auto M = off::spikeLabels(mi, 4, box, W, 1, 900);
        CHECK(full(of(M, 1, "5.0x")) && M.size() == L.size(), "mirror: a buyer label in the clear keeps its pace + lots (symmetric)");
        // the order does not matter: the boxed-in spike LATER in time
        std::vector<off::SpikeIn> in2; in2.push_back(S(100, 120, 0, "5.0x", "p 1.3x", "111")); in2.push_back(S(300, 60, 1, "3.0x", "p 2.0x", "90"));
        const auto L2 = off::spikeLabels(in2, 4, box, W, 1, 900);
        // (the first is under the box too here: x 100) -> check a clear one instead
        std::vector<off::SpikeIn> in3; in3.push_back(S(600, 120, 0, "5.0x", "p 1.3x", "111")); in3.push_back(S(300, 60, 1, "3.0x", "p 2.0x", "90"));
        const auto L3 = off::spikeLabels(in3, 4, box, W, 1, 900);
        CHECK(full(of(L3, 0, "5.0x")), "a later boxed-in spike never shrinks an earlier label");
        (void)L2;
    }
    // 2) the forming bar / a crowded neighbour: two tall spikes side by side -> the OLDER keeps its full label; the newer adapts
    {
        std::vector<off::SpikeIn> in; in.push_back(S(500, 50, 0, "6.1x", "p 2.2x", "240")); in.push_back(S(511, 50, 1, "4.0x", "p 1.9x", "160"));
        const auto L = off::spikeLabels(in, 4, std::vector<off::LBox>(), W, 1, 900);
        CHECK(full(of(L, 0, "6.1x")), "older seller label keeps all rows next to a newer tall buyer spike");
        std::vector<off::SpikeIn> mi = in; for (auto& s : mi) s.side = 1 - s.side;
        const auto M = off::spikeLabels(mi, 4, std::vector<off::LBox>(), W, 1, 900);
        CHECK(full(of(M, 1, "6.1x")), "mirror: older buyer label keeps all rows next to a newer tall seller spike");
        bool noOverlap = true;
        for (size_t a = 0; a < L.size(); ++a) for (size_t b = a + 1; b < L.size(); ++b) if (off::overlaps(off::LBox{ L[a].l, L[a].t, L[a].r, L[a].b, 0, 0 }, off::LBox{ L[b].l, L[b].t, L[b].r, L[b].b, 0, 0 })) noOverlap = false;
        CHECK(noOverlap, "labels never overlap");
    }
    // 3) FUZZ: 3,000 random spike sequences with a random box; every prefix laid out again: an earlier label is NEVER changed by a later
    //    spike (same rect, same rows), labels never overlap each other or the box, every label stays inside [xMin, xMax] and below yTop;
    //    and the mirror (sides swapped) gives the same rows
    {
        std::mt19937 rng(5300); int changed = 0, overl = 0, outside = 0, asym = 0, runs = 0;
        for (int it = 0; it < 3000; ++it) {
            const int n = 2 + (int)(rng() % 12), yTop = (int)(rng() % 40);
            std::vector<off::LBox> obs; if (rng() % 2) obs.push_back(off::LBox{ 3, 3, 120 + (int)(rng() % 300), 40 + (int)(rng() % 80), 0, 0 });
            std::vector<off::SpikeIn> in; int cx = 20;
            for (int k = 0; k < n; ++k) {
                cx += 6 + (int)(rng() % 40);
                off::SpikeIn s; s.cx = cx; s.barTop = yTop + 20 + (int)(rng() % 150); s.side = (int)(rng() % 2);
                s.x = std::to_string(10 + k) + "." + std::to_string(rng() % 10) + "x";   // unique per spike: labels are matched by it s.p = rng() % 4 ? "p " + std::to_string(1 + rng() % 5) + ".0x" : std::string(); s.q = std::to_string(10 + rng() % 400);
                in.push_back(s);
            }
            std::vector<std::string> prev;
            for (int m = 1; m <= n; ++m) {
                const std::vector<off::SpikeIn> pre(in.begin(), in.begin() + m);
                // the label of each input (unplaced = "-"), matched by its unique ratio text
                const auto L = off::spikeLabels(pre, yTop, obs, W, 1, 1200);
                std::vector<std::string> cur;
                for (int k = 0; k < m; ++k) { std::string g = "-"; for (auto& l : L) if (l.x == pre[(size_t)k].x) g = sig(l); cur.push_back(g); }
                for (size_t k = 0; k < prev.size(); ++k) if (prev[k] != cur[k]) ++changed;
                prev = cur; ++runs;
                for (size_t a = 0; a < L.size(); ++a) {
                    if (L[a].l < 1 || L[a].r > 1200 || L[a].t < yTop) ++outside;
                    for (auto& o : obs) if (off::overlaps(off::LBox{ L[a].l, L[a].t, L[a].r, L[a].b, 0, 0 }, o)) ++overl;
                    for (size_t b = a + 1; b < L.size(); ++b) if (off::overlaps(off::LBox{ L[a].l, L[a].t, L[a].r, L[a].b, 0, 0 }, off::LBox{ L[b].l, L[b].t, L[b].r, L[b].b, 0, 0 })) ++overl;
                }
            }
            std::vector<off::SpikeIn> mi = in; for (auto& s : mi) s.side = 1 - s.side;
            const auto A = off::spikeLabels(in, yTop, obs, W, 1, 1200), B = off::spikeLabels(mi, yTop, obs, W, 1, 1200);
            if (A.size() != B.size()) ++asym; else for (size_t k = 0; k < A.size(); ++k) if (A[k].l != B[k].l || A[k].t != B[k].t || A[k].p != B[k].p || A[k].q != B[k].q || A[k].side != 1 - B[k].side) ++asym;
        }
        char m[200]; std::snprintf(m, sizeof(m), "fuzz %d layouts: no earlier label changed by a later spike (%d changed)", runs, changed); CHECK(changed == 0, m);
        std::snprintf(m, sizeof(m), "fuzz: no label overlaps another label or the box (%d)", overl); CHECK(overl == 0, m);
        std::snprintf(m, sizeof(m), "fuzz: every label inside the pane and below yTop (%d)", outside); CHECK(outside == 0, m);
        std::snprintf(m, sizeof(m), "fuzz: seller / buyer mirror gives identical labels (%d differ)", asym); CHECK(asym == 0, m);
    }
    // 4) drawBars (the code all three panes draw with): the hover grid is drawn over the labels and never re-lays them out; a scroll
    //    that keeps a candle in view keeps its label rows
    {
        mock::Host h; mock::current = &h; h.paneTop = 0; h.paneBottom = 170; h.paneLeft = 0; h.paneRight = 1130; h.scaleLeft = 1130; h.barW = 22; h.ppb = 22;
        for (int i = 0; i < 48; ++i) { mock::Bar b; b.time = 1791900000UL + 180UL * i; h.bars.push_back(b); }
        Pane pane; const off::PaneGeo g = off::paneGeo(&pane, off::MODE_READ);
        const COLOR normal[2] = { 0x962D2D, 0x1F9D55 }, spike[2] = { 0xFF3B3B, 0x00FF00 };
        auto xOf = [&](int i) { cppExtension::PNT p; p.set(i, 0.0f); return (int)p.h; };
        auto look = [&](int i) { off::BarLook k; k.ok = true; k.v[0] = 20 + (i * 7) % 30; k.v[1] = 20 + (i * 11) % 30;
            if (i == 6) { k.v[1] = 300; k.spike[1] = true; k.ratioOk[1] = true; k.ratio[1] = 3.0; k.p100[1] = 200; }   // buyer spike under the box
            if (i == 40) { k.v[0] = 200; k.spike[0] = true; k.ratioOk[0] = true; k.ratio[0] = 5.0; k.p100[0] = 130; }  // seller spike in the clear
            if (i == 42) { k.v[1] = 290; k.spike[1] = true; k.ratioOk[1] = true; k.ratio[1] = 4.2; k.p100[1] = 210; }  // tall buyer spike after it
            return k; };
        const std::vector<off::LBox> boxOnly(1, off::LBox{ 3, 3, 363, 84, 0, 0 });
        h.draws.clear(); off::drawBars(&pane, g, 0, 47, 22, 300, -1, normal, spike, xOf, look, boxOnly);
        auto D = labelsDrawn(h, 0xFF3B3B, 0x00FF00);
        auto has = [&](long c, const std::string& t) { for (auto& s : D[c]) if (s == t) return true; return false; };
        CHECK(has(0xFF3B3B, "5.0x") && has(0xFF3B3B, "p 1.3x") && has(0xFF3B3B, "200"), "drawBars: the seller label has ratio / pace / lots with a buyer spike under the box");
        CHECK(has(0x00FF00, "4.2x") && has(0x00FF00, "p 2.1x") && has(0x00FF00, "290"), "drawBars: the later buyer label has ratio / pace / lots too");
        const auto before = D;
        // the old code added the hover grid as an obstacle: the grid over the seller spike's label area must not change the labels drawn
        h.draws.clear(); off::drawBars(&pane, g, 0, 47, 22, 300, -1, normal, spike, xOf, look, boxOnly);   // the hosts no longer pass the grid
        CHECK(labelsDrawn(h, 0xFF3B3B, 0x00FF00) == before, "drawBars: a redraw draws the same labels");
        // scroll: the view starts at 30 (the boxed spike scrolled away), then 39 (the seller candle near the left edge): rows kept
        h.draws.clear(); off::drawBars(&pane, g, 30, 47, 22, 300, -1, normal, spike, xOf, look, boxOnly); D = labelsDrawn(h, 0xFF3B3B, 0x00FF00);
        CHECK(has(0xFF3B3B, "5.0x") && has(0xFF3B3B, "p 1.3x") && has(0xFF3B3B, "200"), "drawBars: scrolled (view from 30) the seller label keeps its rows");
        h.draws.clear(); off::drawBars(&pane, g, 39, 47, 22, 300, -1, normal, spike, xOf, look, boxOnly); D = labelsDrawn(h, 0xFF3B3B, 0x00FF00);
        CHECK(has(0x00FF00, "4.2x") && has(0x00FF00, "p 2.1x") && has(0x00FF00, "290"), "drawBars: scrolled (view from 39) the buyer label keeps its rows");
        // N more candles: the seller label's rows never change as later bars (spikes or not) arrive
        bool kept = true;
        for (int n = 42; n < 48; ++n) { h.draws.clear(); off::drawBars(&pane, g, 0, n, 22, 300, -1, normal, spike, xOf, look, boxOnly); D = labelsDrawn(h, 0xFF3B3B, 0x00FF00); if (!(has(0xFF3B3B, "p 1.3x") && has(0xFF3B3B, "200"))) kept = false; }
        CHECK(kept, "drawBars: the seller label keeps pace + lots through 6 more candles");
    }
    std::printf("label persist (logic, OrderFlowFeed %s): %d passed, %d failed\n", off::VERSION, passes, fails);
    return fails ? 1 : 0;
}
#else
// ------------------------------------------------------------------------------------------------------------ the plugins on the mock host
static void dispose(Ind* p) { p->destroy(); p->~Ind(); ::operator delete(p); }
static Ind* make() { return static_cast<Ind*>(CreateExtension()); }
static const unsigned long T0 = 1791900000UL + 3600UL;     // 2026-10-13 15:00 (mock clock = gmtime): 40 3-min bars reach 17:00 at k = 40
static const COLOR RED = 0x00FF3B3B, GREEN = 0x0000FF00;
static unsigned rs = 777; static int rnd(int lo, int hi) { rs = rs * 1103515245u + 12345u; return lo + (int)((rs >> 16) % (unsigned)(hi - lo + 1)); }
static int SPK_BOX = 12, SPK_CLEAR = 30;                      // the spike under the read box / the one in the clear
static int SIDE_BOX = 1, SIDE_CLEAR = 0;                     // BidAskStats: 0 = sellers (bids hit, red), 1 = buyers (green)
static const int NB = 52;
#if defined(BAS)
static mock::Bar barOf(int k) {
    mock::Bar b; b.time = T0 + 180UL * k; b.open = 92.80f; b.close = 92.82f; b.high = 92.86f; b.low = 92.78f; b.volume = 0;
    for (int j = 0; j < 9; ++j) {
        long bid = rnd(5, 30), ask = rnd(5, 30);
        if (j == 4 && k == SPK_BOX) (SIDE_BOX == 0 ? bid : ask) = 320;
        if (j == 4 && k == SPK_CLEAR) (SIDE_CLEAR == 0 ? bid : ask) = 160;
        b.rows.push_back(mock::Price(92.78f + 0.01f * j, ask, bid, ask + bid)); b.volume += (unsigned long)(ask + bid);
    }
    return b;
}
static void flow(int) {}
#else
static int oid = 1;
static mock::Bar barOf(int k) { mock::Bar b; b.time = T0 + 180UL * k; b.close = 7000.0f; b.low = 6999.5f; b.high = 7001.0f; b.volume = 100; b.rows.push_back(mock::Price(7000.0f, 50, 50, 100)); return b; }
// candle k's order flow: a few adds (+ pulls) each side; the spike candles one-sided bursts. Side 0 = bids (left), 1 = offers (right)
static void flow(int k) {
    const RTDATE t = T0 + 180UL * k - 90;
    auto put = [&](int side, int n, unsigned long sz) {
        for (int i = 0; i < n; ++i) { const int o = oid++; const float px = side == 0 ? 6999.75f : 7000.25f; mock::feed.push(0, side == 0 ? 1 : 0, px, sz, t, o);
#ifndef STACK
            mock::feed.push(2, side == 0 ? 1 : 0, px, sz, t, o);
#endif
        } };
    put(0, rnd(3, 6), 2); put(1, rnd(3, 6), 2);
    if (k == SPK_BOX) put(SIDE_BOX, 40, 8);
    if (k == SPK_CLEAR) put(SIDE_CLEAR, 25, 6);
}
#endif
static void step(mock::Host& h, Ind* p, int k) { h.bars.push_back(barOf(k)); NOW += 50; p->calc(0); flow(k); NOW += 50; p->calc(0); NOW += 700; p->calc(0); NOW += 3000; p->calc(0); }
// the spike-label strings drawn in a colour near an x (the candle's centre)
static std::vector<std::string> near(mock::Host& h, COLOR c, int cx) { std::vector<std::string> v; for (auto& d : h.draws) if (d.type == "text" && d.color == c && d.y > h.paneTop + 4 && std::abs(d.x + (d.r - d.x) / 2 - cx) <= 30) v.push_back(d.text); return v; }
static int candleX(mock::Host& h, int i) { return 50 + i * h.barW; }
static void dump(mock::Host& h) { if (getenv("DBG")) for (auto& d : h.draws) if (d.type == "text") std::printf("  T %d,%d-%d %06lx [%s]\n", d.x, d.y, d.r, (unsigned long)d.color, d.text.c_str()); }
static void draw(Ind* p, mock::Host& h) { h.draws.clear(); p->draw(); dump(h); }
static bool sameRows(const std::vector<std::string>& a, const std::vector<std::string>& b) { return a == b; }
static void scenario(const char* tag) {
    char tmpl[] = "/tmp/lblXXXXXX"; const char* tmp = mkdtemp(tmpl); setenv("USERPROFILE", tmp, 1);
    mock::feed = mock::Feed(); rs = 777;
    mock::Host h; mock::current = &h; h.tick = 0.01f; h.seconds = 180; h.symbol = "CLZ6"; h.root = "CL"; h.priceBase = 92.6f;
    h.paneTop = 0; h.paneBottom = 170; h.paneLeft = 0; h.paneRight = 1300; h.scaleLeft = 1300; h.barW = 22; h.ppb = 22; h.listIndex = 0;
#if !defined(BAS)
    h.tick = 0.25f; h.symbol = "ESZ6"; h.root = "ES"; h.priceBase = 6990;
#endif
    const COLOR clearCol = SIDE_CLEAR == 0 ? (NAME[0] == 'B' ? RED : GREEN) : (NAME[0] == 'B' ? GREEN : RED);   // BAS left = red; Pull / Stack left = green
    const int cxClear = candleX(h, SPK_CLEAR);
    Ind* p = make();
    for (int k = 0; k < 2; ++k) h.bars.push_back(barOf(k));
    NOW += 100; p->calc(0); NOW += 1000; p->calc(0);
    for (int k = 2; k < SPK_CLEAR + 3; ++k) step(h, p, k);
    draw(p, h);
    const std::vector<std::string> ref = near(h, clearCol, cxClear);
    char m[300];
    std::snprintf(m, sizeof(m), "%s %s: the spike in the clear shows ratio / pace / lots (3 rows) with a spike under the read box (got %zu rows)", NAME, tag, ref.size());
    CHECK(ref.size() == 3 && ref[1].compare(0, 2, "p ") == 0, m);
    // N more bars, a redraw after each (the forming bar flickering included)
    bool kept = true;
    for (int k = SPK_CLEAR + 3; k < 38; ++k) { step(h, p, k); draw(p, h); if (!sameRows(near(h, clearCol, cxClear), ref)) kept = false; }
    std::snprintf(m, sizeof(m), "%s %s: rows unchanged through %d more bars", NAME, tag, 38 - SPK_CLEAR - 3); CHECK(kept, m);
    // the mouse over every candle (the read changes) and inside the read box (the hover grid)
    kept = true;
    for (int b = 0; b < (int)h.bars.size(); ++b) { RTX_EVENT e; std::memset(&e, 0, sizeof(e)); e.type = E_MOUSE_MOVE; e.v.mouse.bar = b; e.v.mouse.h = 900; e.v.mouse.v = 150; p->mouse(&e); draw(p, h); if (!sameRows(near(h, clearCol, cxClear), ref)) kept = false; }
    std::snprintf(m, sizeof(m), "%s %s: rows unchanged while hovering every candle", NAME, tag); CHECK(kept, m);
    { RTX_EVENT e; std::memset(&e, 0, sizeof(e)); e.type = E_MOUSE_MOVE; e.v.mouse.bar = 5; e.v.mouse.h = 20; e.v.mouse.v = 20; p->mouse(&e); draw(p, h);
      std::snprintf(m, sizeof(m), "%s %s: rows unchanged with the mouse in the read box (hover grid shown)", NAME, tag);
      const std::vector<std::string> g = near(h, clearCol, cxClear); CHECK(sameRows(g, ref) || g.empty(), m);   // drawn, or covered by the grid - never shrunk
      e.v.mouse.h = 900; e.v.mouse.v = 150; p->mouse(&e); draw(p, h);
      std::snprintf(m, sizeof(m), "%s %s: rows back as they were after leaving the box", NAME, tag); CHECK(sameRows(near(h, clearCol, cxClear), ref), m); }
    // scroll: the view from 12 (the boxed spike off view), from SPK_CLEAR - 1 (the candle at the left edge), back to all
    h.visFrom = 12; h.visTo = (int)h.bars.size() - 1; draw(p, h);
    std::snprintf(m, sizeof(m), "%s %s: rows unchanged scrolled (view from 12)", NAME, tag); CHECK(sameRows(near(h, clearCol, cxClear), ref), m);
    h.visFrom = SPK_CLEAR - 1; draw(p, h);
    std::snprintf(m, sizeof(m), "%s %s: rows unchanged with the candle near the left edge of the view", NAME, tag); CHECK(sameRows(near(h, clearCol, cxClear), ref), m);
    h.visFrom = -1; h.visTo = -1; draw(p, h);
    // restart: a new indicator object re-reads the session record and the bars
    dispose(p); h.data = NULL; p = make(); NOW += 100; p->calc(0); for (int i = 0; i < 6; ++i) { NOW += 1500; p->calc(0); } draw(p, h);
    std::snprintf(m, sizeof(m), "%s %s: rows unchanged after a restart (record reload)", NAME, tag);
    const std::vector<std::string> rr = near(h, clearCol, cxClear);
    // BidAskStats records the pace and redraws it; the MBO panes keep their decided candles from the session record
    CHECK(sameRows(rr, ref), m);
    if (!sameRows(rr, ref)) { std::printf("   ref:"); for (auto& s : ref) std::printf(" [%s]", s.c_str()); std::printf("  got:"); for (auto& s : rr) std::printf(" [%s]", s.c_str()); std::printf("\n"); }
    // across the 17:00 CT session boundary (k = 40 ends at 17:00)
    kept = true;
    for (int k = 38; k < NB; ++k) { step(h, p, k); draw(p, h); if (!sameRows(near(h, clearCol, cxClear), ref)) kept = false; }
    std::snprintf(m, sizeof(m), "%s %s: rows unchanged across the 17:00 CT session boundary", NAME, tag); CHECK(kept, m);
    dispose(p);
}
int main() {
    SIDE_BOX = 1; SIDE_CLEAR = 0; scenario("left-side spike in the clear, right-side spike under the box");
    SIDE_BOX = 0; SIDE_CLEAR = 1; scenario("mirror: right-side spike in the clear, left-side spike under the box");
    std::printf("label persist (%s): %d passed, %d failed\n", NAME, passes, fails);
    return fails ? 1 : 0;
}
#endif
