// test_fix1_logic.cpp -- fix1 (2026-10-13 9:12-9:45 PM CT; BidAskStats 1.5.1 / StackStats 1.1.1 / PullStats 1.1.1 / OrderFlowFeed.h 1.2.1 /
// HoverBoard.h 1.0.0). No SDK. Live issue: "Rebuilt 200% ?" on both sides; spike labels / info boxes too small; the panes did not follow
// the mouse over the price pane.
#define HB_FAKE 1
#include "PullStatsLogic.h"
#include "StackStatsLogic.h"
#include "BidAskStatsLogic.h"
#include <cstdio>
#include <vector>
static int fails = 0, passes = 0;
#define CHECK(c, m) do { if (c) ++passes; else { ++fails; std::printf("FAIL %d %s\n", __LINE__, m); } } while (0)
using namespace off;
static Ev ev(int a, int side, Tick px, long long size, long long id) { Ev e; e.action = a; e.side = side; e.px = px; e.size = size; e.id = id; return e; }
static Engine eng() { Engine e; e.ref = 1000; e.haveRef = true; e.near = 10; return e; }
static int W7(const std::string& s) { return (int)s.size() * 7; }

int main() {
    // ================= REBUILT % (the 9:12 PM "Rebuilt 200% ?") =================
    {   // the live case: a 1-lot hit at the best bid, then ordinary queue joins of 40 lots at that price -> was 4000% shown as 200%
        Engine e = eng(); Acc a;
        e.apply(a, ev(NEW, BID, 1000, 5, 1)); e.apply(a, ev(FILL, BID, 1000, 1, 1)); e.apply(a, ev(MOD, BID, 1000, 4, 1));
        for (int k = 0; k < 8; ++k) e.apply(a, ev(NEW, BID, 1000, 5, 10 + k));
        const Rec r = e.numbers(a, false, Params());
        CHECK(r.hitC[BID] == 1 && r.rebuildC[BID] == 1 && rebuiltPctOf(r.rebuildC[BID], r.hitC[BID]) == 100, "a 1-lot hit then 40 lots of queue joins = 100% rebuilt (the hit size restored), never 200% / 4000%");
    }
    {   // two hit prices: 20 hit at 1000 (12 back), 10 hit at 999 (10 + 30 back) -> (12 + 10) / 30 = 73%
        Engine e = eng(); Acc a;
        e.apply(a, ev(NEW, BID, 1000, 20, 1)); e.apply(a, ev(FILL, BID, 1000, 20, 1)); e.apply(a, ev(DEL, BID, 1000, 0, 1));
        e.apply(a, ev(NEW, BID, 999, 10, 2)); e.apply(a, ev(FILL, BID, 999, 10, 2)); e.apply(a, ev(DEL, BID, 999, 0, 2));
        e.apply(a, ev(NEW, BID, 1000, 12, 3)); e.apply(a, ev(NEW, BID, 999, 40, 4)); e.apply(a, ev(NEW, BID, 998, 50, 5));
        const Rec r = e.numbers(a, false, Params());
        CHECK(r.hitC[BID] == 30 && r.rebuildC[BID] == 22 && rebuiltPctOf(r.rebuildC[BID], r.hitC[BID]) == 73, "per price: at most that price's hit lots count as rebuilt; another price never counts");
    }
    {   // adds BEFORE the hit never count; a second hit at the same price makes room again
        Engine e = eng(); Acc a;
        e.apply(a, ev(NEW, BID, 1000, 30, 1)); e.apply(a, ev(FILL, BID, 1000, 5, 1)); e.apply(a, ev(MOD, BID, 1000, 25, 1));
        e.apply(a, ev(NEW, BID, 1000, 3, 2)); e.apply(a, ev(FILL, BID, 1000, 5, 1)); e.apply(a, ev(MOD, BID, 1000, 20, 1)); e.apply(a, ev(NEW, BID, 1000, 9, 3));
        const Rec r = e.numbers(a, false, Params());
        CHECK(r.hitC[BID] == 10 && r.rebuildC[BID] == 10 && rebuiltPctOf(10, 10) == 100, "3 after the first 5-lot hit, 7 of 9 after the second: 10 of 10 hit");
        Engine f = eng(); Acc b; f.apply(b, ev(NEW, BID, 1000, 30, 1));
        CHECK(rebuiltPctOf(f.numbers(b, false, Params()).rebuildC[BID], f.numbers(b, false, Params()).hitC[BID]) == -1, "no hits: no Rebuilt (the hover shows -)");
    }
    {   // the hover row and the message: never above 100%; "-" without hits; the message names it only at >= rebuiltPct
        Params P; P.gate[ofo::G_REBUILT] = ofo::GATE_Q; PaneBar b; b.ok = true; b.r.events = 5; b.r.addN[BID] = 8; b.r.addC[BID] = 40; b.r.hitC[BID] = 1; b.r.rebuildC[BID] = 1;
        const Info I = st::info(&b, P);
        CHECK(I.rows[1].label == "Rebuilt" && I.rows[1].v[0] == "100% ?" && I.rows[1].v[1] == "-", "hover: 100% ? (gate ?), the side without hits -");
        b.r.rebuildC[BID] = 40; CHECK(st::info(&b, P).rows[1].v[0] == "100% ?", "an old 1.1.0 record (rebuilt > hit) still reads at most 100%");
    }
    // ================= INFO BOX ROWS (Rassul "just do it") =================
    {
        Params P; PaneBar b; b.ok = true; b.r.events = 9; b.r.pullN[ASK] = 96; b.r.pullC[ASK] = 365; b.r.pullMax[ASK] = 44; b.r.addN[BID] = 96; b.r.addC[BID] = 365; b.r.addTop[BID] = 44;
        const Info p = ps::info(&b, P), s = st::info(&b, P);
        std::string pl, sl; for (size_t k = 0; k < p.rows.size(); ++k) pl += p.rows[k].label + "|"; for (size_t k = 0; k < s.rows.size(); ++k) sl += s.rows[k].label + "|";
        CHECK(pl == "Pulled|Before price|Traded first|Pace|Crowd|" && p.rows[4].v[1] == "96 \xB7 avg 3.8 \xB7 top 12%" && p.colHead[0] == "Bids" && p.colHead[1] == "Offers", "PullStats rows + Crowd, columns unchanged");
        CHECK(sl == "Added|Rebuilt|Pace|Crowd|Refills (I)|" && s.rows[3].v[0] == "96 \xB7 avg 3.8 \xB7 top 12%", "StackStats rows + Crowd");
        CHECK(ps::info(nullptr, P).rows[4].v[0] == "n/a" && st::info(nullptr, P).rows[3].v[1] == "n/a", "Crowd n/a without the order feed");
        CHECK(W7(CROWD_TMPL) >= W7("96 \xB7 avg 3.8 \xB7 top 12%") && W7(CROWD_TMPL) >= W7("9999 (99.9x) ?") && W7(CROWD_TMPL) >= W7("2.3x (2.0x) ?"), "the box width template fits the longest value");
    }
    // ================= SPIKE LABELS at 10 pt: never over each other / letters / the message line; the ratio always kept =================
    {
        auto w = [](const std::string& t) { return (int)t.size() * 7; };       // ~10 pt
        std::vector<SpikeIn> in;
        for (int k = 0; k < 6; ++k) { SpikeIn s; s.cx = 100 + k * 11; s.barTop = 150; s.side = k % 2; s.q = "240"; s.x = "6.4x"; s.p = "p 5.0x"; in.push_back(s); }   // 6 spikes 11 px apart
        const std::vector<LBox> none;
        const std::vector<SLabel> L = spikeLabels(in, 40, none, w, 0, 1000);
        bool ov = false; for (size_t i = 0; i < L.size(); ++i) for (size_t j = i + 1; j < L.size(); ++j) ov = ov || overlaps(LBox{ L[i].l, L[i].t, L[i].r, L[i].b, 0, 0 }, LBox{ L[j].l, L[j].t, L[j].r, L[j].b, 0, 0 });
        bool top = true; for (size_t i = 0; i < L.size(); ++i) top = top && L[i].t >= 40;
        int ratios = 0; for (size_t i = 0; i < L.size(); ++i) ratios += L[i].x == "6.4x";
        CHECK(L.size() == 6 && ratios == 6 && !ov && top, "6 close spikes: every one keeps its ratio, none overlap, none above the message line");
        int full = 0; for (size_t i = 0; i < L.size(); ++i) full += !L[i].p.empty();
        CHECK(full >= 1 && full < 6, "the crowded ones fall back to the ratio alone (the hover box has the rest)");
        std::vector<LBox> lets(1, LBox{ 90, 120, 130, 149, 'S', 0 });
        std::vector<SpikeIn> one(1, in[0]);
        const std::vector<SLabel> M = spikeLabels(one, 40, lets, w, 0, 1000);
        CHECK(M.size() == 1 && !overlaps(LBox{ M[0].l, M[0].t, M[0].r, M[0].b, 0, 0 }, lets[0]), "never over a letter box");
        const std::vector<SLabel> N = spikeLabels(one, 140, none, w, 0, 1000);
        CHECK(N.empty(), "no room under the message line: not drawn (never over it)");
        std::vector<SpikeIn> edge(1, in[0]); edge[0].cx = 2;
        const std::vector<SLabel> E = spikeLabels(edge, 40, none, w, 0, 1000);
        CHECK(E.size() == 1 && E[0].l >= 0, "kept inside the pane at its left edge");
        CHECK(LABEL_PT >= 10 && INFO_PT >= 10 && LABEL_LH >= 13 && INFO_LH >= 14, "10 pt labels and info box");
    }
    // ================= HOVER BOARD (Rassul 9:25 PM: every pane follows the candle under the mouse anywhere on the chart) =================
    {
        hb::Pub p; p.wnd = 77; p.t = 3874771080ULL; p.t0 = 3874700000ULL; p.t1 = 3874771260ULL; hb::Pub q;
        CHECK(hb::decode(hb::encode(p), q) && q.wnd == 77 && q.t == p.t && q.t0 == p.t0 && q.t1 == p.t1, "encode / decode");
        CHECK(!hb::decode("1,2,3", q) && !hb::decode("1,2,3,4,5", q) && !hb::decode("a,2,3,4", q) && !hb::decode("", q), "bad values rejected");
        CHECK(hb::varName("ESZ6", 180) == "LRA_HV_ESZ6_180" && hb::varName("@ES Z6=", 60) == "LRA_HV_ESZ6_60", "variable name per symbol and bar size");
        unsigned long long t = 9;
        CHECK(hb::follow(p, true, 77, p.t0, p.t1, t) && t == p.t, "cursor over the publishing pane of this chart: that candle");
        CHECK(!hb::follow(p, true, 78, p.t0, p.t1, t) && t == 0, "cursor anywhere else (left the chart): Live");
        CHECK(!hb::follow(p, true, 77, p.t0 + 180, p.t1, t), "another chart of the same symbol scrolled differently: never followed");
        std::vector<unsigned long long> times; for (int k = 0; k < 10; ++k) times.push_back(1000 + 180 * k);
        CHECK(hb::indexOf(times, 10, 1000 + 180 * 4) == 4 && hb::indexOf(times, 10, 1000 + 180 * 9) == -1 && hb::indexOf(times, 10, 1001) == -1 && hb::indexOf(times, 10, 0) == -1, "time -> closed bar index; the forming bar / unknown = Live");
        // the process-wide board: the Tape Reader (price pane, window 501) publishes; the panes of chart A follow; chart B (other symbol) does not
        hb::fakeCursor() = 501; hb::publish("ESZ6", 180, 1000 + 180 * 3, 1000, 2620);
        unsigned long long ta = 0, tb = 0;
        CHECK(hb::hovered("ESZ6", 180, 1000, 2620, ta) && ta == 1540, "mouse over the price pane: chart A's panes follow candle 3");
        CHECK(!hb::hovered("NQZ6", 180, 1000, 2620, tb), "chart B (NQ) has no board entry: keeps its own hover");
        hb::fakeCursor() = 999;
        CHECK(hb::hovered("ESZ6", 180, 1000, 2620, ta) && ta == 0, "mouse left the chart: Live");
        hb::fakeCursor() = 601; hb::publish("ESZ6", 180, 1000 + 180 * 5, 1180, 2620);   // a second ES chart (window 601, other range) publishes
        hb::fakeCursor() = 601;
        CHECK(hb::hovered("ESZ6", 180, 1000, 2620, ta) && ta == 0, "chart A (range 1000..2620) ignores the second ES chart's hover");
        CHECK(hb::hovered("ESZ6", 180, 1180, 2620, ta) && ta == 1900, "while the second ES chart follows its own");
        hb::fakeCursor() = 0;
    }
    std::printf("fix1 logic: %d passed, %d failed\n", passes, fails); return fails ? 1 : 0;
}
