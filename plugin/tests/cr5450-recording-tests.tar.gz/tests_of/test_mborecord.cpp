// test_mborecord.cpp -- MboRecord.h 1.0.0 (lsPullStats 1.2.0 "Record order feed"), SDK-free.
//   g++ -std=c++17 -Wall -Wextra -Werror -fsanitize=address,undefined -I.. test_mborecord.cpp && ./a.out <out dir>
// Writes <out dir>/data/irt/2026-10-13/ES/mbo_HH.csv (1,000 events over two hours) for the lra.mbo_live parser check.
#include "MboRecord.h"
#include <cstdio>
#include <cstdlib>
#include <filesystem>
#include <iostream>
#include <sstream>
#include <vector>

static int passed = 0, failed = 0;
#define CHECK(c, t) do { if (c) ++passed; else { ++failed; std::cerr << "FAIL: " << t << " (line " << __LINE__ << ")\n"; } } while (0)
static std::vector<std::string> lines(const std::string& f) { std::ifstream in(f.c_str()); std::string l; std::vector<std::string> v; while (std::getline(in, l)) v.push_back(l); return v; }
static mrec::Ev ev(int y, int mo, int d, int h, int mi, int s, int act, double px, unsigned long sz, long long id, int side) {
    mrec::Ev e; e.y = y; e.mo = mo; e.d = d; e.h = h; e.mi = mi; e.s = s; e.action = act; e.price = px; e.prev = act == 1 ? px - 0.25 : 0; e.size = sz;
    e.oid = id; e.aid = act == 3 ? id + 7 : 0; e.side = side; e.bid = px - 0.25; e.ask = px; return e;
}

int main(int argc, char** argv)
{
    namespace fs = std::filesystem;
    const std::string out = argc > 1 ? argv[1] : "/tmp/mborec-test";
    std::error_code ec; fs::remove_all(out, ec); fs::create_directories(out + "/data/irt", ec);
    const std::string root = out + "/data/irt"; mrec::rootOverride() = root; mrec::testFreeBytes() = 100LL << 30;

    // ---- sessions (mbo_live._today_session): 17:00 CT = the next day; Saturday / Sunday = Monday
    CHECK(mrec::sessionOf(2026, 10, 13, 9) == "2026-10-13", "Tuesday 09:00 = Tuesday");
    CHECK(mrec::sessionOf(2026, 10, 13, 17) == "2026-10-14", "Tuesday 17:00 = Wednesday");
    CHECK(mrec::sessionOf(2026, 10, 16, 17) == "2026-10-19", "Friday 17:00 = Monday");
    CHECK(mrec::sessionOf(2026, 10, 18, 17) == "2026-10-19", "Sunday 17:00 (Globex open) = Monday");
    CHECK(mrec::sessionOf(2026, 12, 31, 18) == "2027-01-01", "New Year's Eve 18:00 = 1 Jan (the year rolls)");
    CHECK(mrec::sessionOf(2026, 13, 1, 9).empty() && mrec::sessionOf(2026, 10, 13, 24).empty(), "garbage clock fields = no file");
    CHECK(mrec::pathOf(root, "ES", ev(2026, 10, 13, 9, 1, 2, 0, 1, 1, 1, 1)) == root + "/2026-10-13/ES/mbo_09.csv", "path <root>/<session>/<MKT>/mbo_HH.csv");
    CHECK(mrec::lineOf(ev(2026, 10, 13, 9, 1, 2, 3, 6712.25, 3, 123456, 1)) == "2026-10-13 09:01:02|FILL|6712.25|0|3|123456|123463|B|6712|6712.25\n", "line format = lsPulling 0.2.0 / IRT Reader dbo");

    // ---- buffering: nothing written until a calc pass a second later; a draw never writes (below 4 MB)
    {
        mrec::Recorder r; r.setMarket("ES"); r.setOn(true);
        long long now = 1000; r.tick(now, false);                       // first pass: claims, nothing buffered
        for (int k = 0; k < 600; ++k) r.add(ev(2026, 10, 13, 9, k / 60, k % 60, k % 4, 6700 + 0.25 * (k % 9), (unsigned long)(1 + k % 5), 1000 + k, k % 2));
        for (int k = 0; k < 400; ++k) r.add(ev(2026, 10, 13, 10, k / 60, k % 60, k % 4, 6710 + 0.25 * (k % 9), (unsigned long)(1 + k % 5), 5000 + k, k % 2));
        r.tick(now + 300, false);
        CHECK(!fs::exists(root + "/2026-10-13/ES/mbo_09.csv"), "within the second: buffered, not written");
        r.tick(now + 1200, true);
        CHECK(!fs::exists(root + "/2026-10-13/ES/mbo_09.csv"), "a draw pass never writes (small buffer)");
        r.tick(now + 1200, false);
        std::vector<std::string> a = lines(root + "/2026-10-13/ES/mbo_09.csv"), b = lines(root + "/2026-10-13/ES/mbo_10.csv");
        CHECK(a.size() == 601 && b.size() == 401 && a[0] == mrec::HEADER && b[0] == mrec::HEADER, "two hour files, header + rows (600 + 400)");
        CHECK(r.rows == 1000 && r.fails == 0 && r.dropped == 0 && r.flushes == 1, "1,000 rows in one flush");
    }
    // ---- a restart appends (no second header), across a new Recorder
    {
        mrec::Recorder r; r.setMarket("ES"); r.setOn(true);
        r.add(ev(2026, 10, 13, 10, 59, 59, 2, 6711, 2, 99999, 0)); r.tick(50000, false);
        std::vector<std::string> b = lines(root + "/2026-10-13/ES/mbo_10.csv");
        CHECK(b.size() == 402 && b[0] == mrec::HEADER && b[1] != mrec::HEADER && b.back().find("|DEL|6711|") != std::string::npos, "after a restart: appended, one header");
    }
    // ---- one writer per market: a second chart of the same market does not write; it takes over when the first is gone
    {
        mrec::Recorder a, b; a.setMarket("NQ"); b.setMarket("NQ"); a.setOn(true); b.setOn(true);
        a.add(ev(2026, 10, 13, 11, 0, 0, 0, 24000, 1, 1, 1)); a.tick(100000, false);
        b.add(ev(2026, 10, 13, 11, 0, 0, 0, 24000, 1, 1, 1)); b.tick(100000, false);
        CHECK(a.owner && !b.owner && lines(root + "/2026-10-13/NQ/mbo_11.csv").size() == 2, "the second NQ chart does not write (no duplicates)");
        CHECK(b.note.find("another PullStats chart of NQ") != std::string::npos, "and says why");
        a.setOn(false);                                                  // unticked on the first chart: it lets go
        b.add(ev(2026, 10, 13, 11, 0, 1, 0, 24001, 1, 2, 1)); b.tick(101100, false);
        CHECK(b.owner && lines(root + "/2026-10-13/NQ/mbo_11.csv").size() == 3, "the other chart takes over");
    }
    // ---- another program writing the same file (lsPulling 0.2.x): stop, drop, resume after it stands still 10 s
    {
        mrec::Recorder r; r.setMarket("CL"); r.setOn(true);
        const std::string f = root + "/2026-10-13/CL/mbo_12.csv";
        r.add(ev(2026, 10, 13, 12, 0, 0, 0, 61.23, 1, 1, 1)); r.tick(200000, false);
        { std::ofstream o(f.c_str(), std::ios::app); o << "2026-10-13 12:00:00|NEW|61.24|0|1|77|0|S|61.23|61.24\n"; }   // the other writer
        r.add(ev(2026, 10, 13, 12, 0, 1, 0, 61.25, 1, 2, 1)); r.tick(201100, false);
        CHECK(r.foreign && lines(f).size() == 3 && r.dropped == 1, "the file grew by more than we wrote: stop, our line dropped (never twice)");
        r.add(ev(2026, 10, 13, 12, 0, 2, 0, 61.26, 1, 3, 1)); r.tick(205000, false);
        CHECK(r.foreign && lines(f).size() == 3, "still another writer: still not writing");
        r.add(ev(2026, 10, 13, 12, 0, 3, 0, 61.27, 1, 4, 1)); r.tick(212000, false);
        CHECK(!r.foreign && lines(f).size() == 4, "the file stood still 10 s: recording again");
    }
    // ---- under 2 GB free: paused with a note, nothing written
    {
        mrec::testFreeBytes() = 1LL << 30;
        mrec::Recorder r; r.setMarket("GC"); r.setOn(true);
        r.add(ev(2026, 10, 13, 9, 0, 0, 0, 4000, 1, 1, 1)); r.tick(300000, false);
        CHECK(!fs::exists(root + "/2026-10-13/GC") && r.dropped == 1 && r.note.find("paused: 1.0 GB free") != std::string::npos, "low disk: paused, nothing written");
        std::ostringstream o; r.status(o); CHECK(o.str().find("\nMBO_RECORD,paused: 1.0 GB free on the drive (< 2 GB),rows 0,") != std::string::npos, "status line says so");
        mrec::testFreeBytes() = 100LL << 30;
    }
    // ---- OFF: nothing buffered, nothing written
    {
        mrec::Recorder r; r.setMarket("HG"); r.setOn(false);
        r.add(ev(2026, 10, 13, 9, 0, 0, 0, 4.8735, 1, 1, 1)); r.tick(400000, false); r.tick(402000, false);
        CHECK(!fs::exists(root + "/2026-10-13/HG") && r.bufBytes == 0, "off: nothing written");
        std::ostringstream o; r.status(o); CHECK(o.str().find("MBO_RECORD,off (setting)") != std::string::npos, "status: off (setting)");
    }
    // ---- the destructor writes what is left (chart closed / indicator removed)
    {
        { mrec::Recorder r; r.setMarket("NG"); r.setOn(true); r.tick(500000, false); r.add(ev(2026, 10, 13, 9, 0, 0, 0, 3.123, 1, 1, 1)); }
        CHECK(lines(root + "/2026-10-13/NG/mbo_09.csv").size() == 2, "the buffer is written when the pane goes away");
    }
    std::cout << "mborecord: " << passed << " passed, " << failed << " failed\n";
    return failed ? 1 : 0;
}
