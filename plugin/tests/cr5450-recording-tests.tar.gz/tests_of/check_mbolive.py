import sys, gzip, datetime as dt, json
sys.path.insert(0, sys.argv[1])
from lra import mbo_live
repo = sys.argv[2]
res = mbo_live.run(repo, now=dt.datetime(2026, 10, 14, 10, 0), log=print)
print(json.dumps(res))
inv = json.load(open(repo + "/data/mbo/live/inventory.json"))
es = inv["sessions"]["2026-10-13"]["ES"]["mbo"]

with gzip.open(repo + "/data/mbo/live/ES/2026-10-13.mbo.csv.gz", "rt") as g:
    hdr = g.readline().strip(); rows = [l.rstrip("\n").split("|") for l in g]
assert hdr == mbo_live.DBO_HEADER, hdr
assert all(len(r) == 10 for r in rows), "10 columns"
for r in rows:
    dt.datetime.strptime(r[0], "%Y-%m-%d %H:%M:%S"); float(r[2]); float(r[3]); int(r[4]); int(r[5]); int(r[6]); float(r[8]); float(r[9])
    assert r[1] in ("NEW", "MOD", "DEL", "FILL") and r[7] in ("B", "S")
print("mbo_live parse: ES rows", es["rows"], "header ok, 10 columns, every field parses; archive files", es["files"])
assert es["rows"] == 1001
