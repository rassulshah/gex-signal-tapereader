// test_feedclock_host.cpp -- OrderFlowFeed.h 1.4.0 / lsPullStats 1.3.0 / MboRecord.h 1.1.0 on the mock host (2026-10-14 evening).
// The LIQ-DAY-2026-10-14 loss, reproduced and fixed. The mock feed behaves like IRT's per-subscriber buffer: it keeps only the last
// RING events; older unread events are overwritten (lost). IRT drew the busy 3-min chart every ~6-10 s, so:
//   A) calc / draw only, every 8 s, at ES-open rates  -> most events lost (coverage well under 50%), as on 10-14
//   B) the 250 ms feed clock, same rates and bursts   -> nothing lost: every event in mbo_HH.csv once, in order; MBO_COVERAGE ~100%
//   C) a burst of 40,000 events inside one 250 ms tick (ring big enough) -> all read in one tick (<= 50,000 per tick)
//   D) session boundary: events at 16:59:59 and 17:00:00 go to different session folders, hour files mbo_16 / mbo_17
//   E) the chart hidden (no calc / draw for 2 min): the clock alone records and flushes; the queue is routed in order later
//   F) a faulting clock read stops the clock (FEED_CLOCK off), calc / draw keep reading; remove the indicator = timer destroyed
//   G) IRT refuses the timer: status says so, calc / draw still read (old behaviour)
#include "PullStats.cpp"
typedef PullStats Ind;
#include <cstdio>
#include <unistd.h>
#include <filesystem>
#include <sstream>
#include <vector>
namespace mock { Host* current = nullptr; Feed feed; }
namespace off { long long off_test_now_ms = 1000000; void* off_test_cursor_wnd = nullptr; }
static int fails = 0, passes = 0;
#define CHECK(c, m) do { if (c) ++passes; else { ++fails; std::printf("FAIL %d %s\n", __LINE__, m); } } while (0)
static std::string readAll(const std::string& p) { std::ifstream f(p.c_str()); std::stringstream s; s << f.rdbuf(); return s.str(); }
static void dispose(Ind* p) { p->destroy(); p->~Ind(); ::operator delete(p); }
static size_t RING = 600; static long long lost = 0;
// IRT appends to the subscriber's buffer; past RING unread events the oldest are overwritten
static void publish(unsigned char a, unsigned char side, float px, unsigned long size, RTDATE t, int id) {
    mock::feed.push(a, side, px, size, t, id);
    if (mock::feed.ev.size() - mock::feed.at > RING) { ++lost; ++mock::feed.at; }
}
static void tickTimers(Ind* p) { for (auto& kv : std::map<int, int>(mock::timers())) { RTX_EVENT e; std::memset(&e, 0, sizeof(e)); e.v.timer.id = kv.first; p->timer(&e); } }
static mock::Bar bar(unsigned long t, unsigned long vol) { mock::Bar b; b.time = t; b.close = 7000.0f; b.low = 6999.5f; b.high = 7001.0f; b.volume = vol; b.rows.push_back(mock::Price(7000.0f, 50, 50, 100)); return b; }
static long long countLines(const std::string& dir, const std::string& prefix, std::vector<std::string>* rows = nullptr) {
    long long n = 0;
    if (!std::filesystem::exists(dir)) return 0;
    std::vector<std::string> files; for (auto& f : std::filesystem::recursive_directory_iterator(dir)) if (f.is_regular_file() && f.path().filename().string().rfind(prefix, 0) == 0) files.push_back(f.path().string());
    std::sort(files.begin(), files.end());
    for (auto& f : files) { std::ifstream in(f); std::string l; bool first = true; while (std::getline(in, l)) { if (first) { first = false; if (l.rfind("time|", 0) == 0) continue; } ++n; if (rows) rows->push_back(l); } }
    return n;
}
static std::string statusLine(const std::string& st, const std::string& key) { size_t a = st.find("\n" + key + ","); if (a == std::string::npos) return ""; a += key.size() + 2; return st.substr(a, st.find('\n', a) - a); }

// one run: `mins` 1-minute bars, `rate` events per second (1/4 FILL, the rest NEW/DEL pairs), calc every calcEveryMs, timer every 250 ms
struct Run { long long events = 0, fillLots = 0, recorded = 0; std::string status; bool ordered = true; };
static Run simulate(const char* tag, int mins, int rate, long long calcEveryMs, bool useTimer, unsigned long t0) {
    Run r; lost = 0; mock::feed = mock::Feed(); mock::timers().clear(); mock::refuseTimers() = !useTimer;
    char tmpl[] = "/tmp/fclkXXXXXX"; const char* tmp = mkdtemp(tmpl); setenv("USERPROFILE", tmp, 1);
    const std::string root = std::string(tmp) + "/irt"; mrec::rootOverride() = root; mrec::testFreeBytes() = 50LL << 30;
    mock::Host h; mock::current = &h; h.tick = 0.25f; h.seconds = 60; h.symbol = "ESZ6"; h.root = "ES"; h.paneBottom = 300; h.paneRight = 2000;
    for (int i = 0; i < 31; ++i) h.bars.push_back(bar(t0 + 60UL * i, 100));
    Ind* p = static_cast<Ind*>(CreateExtension()); p->calc(0);
    // a first quiet event so the stream is subscribed and the clock starts in the chart's own call
    publish(0, 1, 6999.75f, 1, t0 + 60 * 30 - 1, 1); off::off_test_now_ms += 10; p->calc(0); ++r.events;
    int id = 2; long long msNow = 0, nextCalc = calcEveryMs;
    std::map<unsigned long, unsigned long> volOf;                   // bar end -> lots filled in it (the "real" bar volume)
    for (int m = 0; m < mins; ++m) {
        const unsigned long end = t0 + 60UL * (31 + m);              // the new forming bar (IRT bar time = its END), covers [end - 60, end)
        h.bars.push_back(bar(end, 0));
        for (int q = 0; q < 240; ++q) {                              // 240 quarter-seconds per minute
            const RTDATE t = (RTDATE)(end - 60 + q / 4);
            const int n = rate / 4;
            for (int k = 0; k < n; ++k) {
                const int kind = k % 4;
                if (kind == 0) { publish(3, 1, 6999.75f, 2, t, id); r.fillLots += 2; volOf[end] += 2; }
                else if (kind == 1) publish(0, 1, 6999.5f, 1, t, id);
                else if (kind == 2) publish(2, 1, 6999.5f, 1, t, id - 1);
                else publish(0, 0, 7000.25f, 1, t, id);
                ++id; ++r.events;
            }
            msNow += 250; off::off_test_now_ms += 250;
            if (useTimer) tickTimers(p);
            if (msNow >= nextCalc) { nextCalc += calcEveryMs; p->calc(0); p->draw(); }
        }
        h.bars.back().volume = volOf[end];                           // its real volume (= the lots filled in it)
    }
    h.bars.push_back(bar(t0 + 60UL * (31 + mins), 0));               // closes the last minute
    // drain whatever is left, let the last bars age 6 s and evaluate
    for (int k = 0; k < 30; ++k) { off::off_test_now_ms += 250; if (useTimer) tickTimers(p); if (k % 8 == 0) p->calc(0); }
    off::off_test_now_ms += 16000; p->calc(0); off::off_test_now_ms += 6000; p->calc(0);
    tickTimers(p); off::off_test_now_ms += 16000; p->calc(0);
    dispose(p);                                                      // the recorder's destructor writes what is left
    CHECK(mock::timers().empty(), "removing the indicator destroys its timer");
    std::vector<std::string> rows; r.recorded = countLines(root, "mbo_", &rows);
    long long lastId = 0; for (auto& l : rows) { std::vector<std::string> f; std::stringstream ss(l); std::string x; while (std::getline(ss, x, '|')) f.push_back(x); if (f.size() < 6) continue; const long long oid = std::atoll(f[5].c_str()); if (oid < lastId) r.ordered = false; lastId = oid; }
    const std::string flex = std::string(tmp) + "\\InvestorRT\\rtx\\lsFlexLevels";
    r.status = readAll(flex + "\\PullStats\\status-ES-ESZ6-60.txt");
    std::printf("  %s: published %lld, IRT overwrote %lld, recorded %lld, %s\n", tag, r.events, lost, r.recorded, statusLine(r.status, "MBO_COVERAGE").c_str());
    std::printf("     FEED_CLOCK,%s\n", statusLine(r.status, "FEED_CLOCK").c_str());
    std::filesystem::remove_all(tmp);
    return r;
}

int main() {
    const unsigned long T0 = 1792000000UL - (1792000000UL % 86400) + 14 * 3600;   // 14:00 (mock clock = UTC) on a weekday
    // A) the old behaviour: calc / draw every 8 s, 2,000 events/s, IRT keeps 600 (0.3 s; the real ratio on 10-14 was similar)
    Run a = simulate("A calc every 8 s, no clock", 2, 2000, 8000, false, T0);
    const int covA = std::atoi(statusLine(a.status, "MBO_COVERAGE").substr(statusLine(a.status, "MBO_COVERAGE").find("since load ") + 11).c_str());
    CHECK(lost > 0 && a.recorded < a.events / 2, "A: the old cadence loses most events (as on 10-14)");
    CHECK(covA > 0 && covA < 50, "A: MBO_COVERAGE shows the loss (< 50%)");
    CHECK(statusLine(a.status, "FEED_CLOCK").rfind("refused by IRT", 0) == 0, "G: a refused timer is reported; calc / draw still read");
    // B) the 1.4.0 clock: same cadence of calc, same rate and buffer
    Run b = simulate("B 250 ms clock", 2, 2000, 8000, true, T0);
    CHECK(lost == 0, "B: IRT never overwrites an unread event");
    CHECK(b.recorded == b.events, "B: every event published is in mbo_HH.csv exactly once");
    CHECK(b.ordered, "B: events in the file in feed order");
    const std::string cb = statusLine(b.status, "MBO_COVERAGE");
    CHECK(cb.find("last 10 bars 100%") != std::string::npos && cb.find("since load 100%") != std::string::npos, "B: MBO_COVERAGE 100%");
    CHECK(statusLine(b.status, "FEED_CLOCK").rfind("on,250 ms", 0) == 0 && statusLine(b.status, "FEED_CLOCK").find("clock_faults 0") != std::string::npos, "B: FEED_CLOCK on, no faults");
    CHECK(statusLine(b.status, "MBO_RECORD").find("dropped 0") != std::string::npos, "B: recorder dropped nothing");
    // C) a 40,000-event burst between two ticks (IRT's buffer large enough): one tick reads it all (<= 50,000 per tick)
    {
        mock::feed = mock::Feed(); mock::timers().clear(); mock::refuseTimers() = false; lost = 0; RING = 100000;
        char tmpl[] = "/tmp/fclkXXXXXX"; const char* tmp = mkdtemp(tmpl); setenv("USERPROFILE", tmp, 1);
        const std::string root = std::string(tmp) + "/irt"; mrec::rootOverride() = root;
        mock::Host h; mock::current = &h; h.tick = 0.25f; h.seconds = 60; h.symbol = "ESZ6"; h.root = "ES";
        for (int i = 0; i < 31; ++i) h.bars.push_back(bar(T0 + 60UL * i, 10));
        Ind* p = static_cast<Ind*>(CreateExtension()); p->calc(0); auto* S = p->testState();
        publish(0, 1, 6999.75f, 1, T0 + 60 * 30 - 9, 1); p->calc(0);
        for (int k = 0; k < 40000; ++k) publish(0, 1, 6999.5f, 1, T0 + 60 * 30 - 5, 10 + k);
        off::off_test_now_ms += 250; tickTimers(p);
        CHECK(S->feed.timerEvents == 40000 && S->feed.q.size() == 40000 && S->feed.qPeak == 40000, "C: 40,000 events read in one tick, queued in order");
        off::off_test_now_ms += 1100; tickTimers(p);
        CHECK(countLines(root, "mbo_") == 40001, "C: all 40,001 recorded by the clock's flush");
        p->calc(0);
        CHECK(S->feed.q.empty() && S->e.events >= 40001, "C: the chart's calc routed the queue to the engine");
        dispose(p); std::filesystem::remove_all(tmp); RING = 600;
    }
    // E) chart hidden: calc only every 2 minutes; the clock records everything and the queue routes later
    Run e = simulate("E chart hidden (calc every 120 s)", 2, 2000, 120000, true, T0);
    CHECK(lost == 0 && e.recorded == e.events && e.ordered, "E: recorded in full and in order while the chart was not drawn");
    CHECK(statusLine(e.status, "FEED_CLOCK").find("queue_dropped 0") != std::string::npos, "E: the routing queue held the backlog");
    // D) session boundary 16:59:59 -> 17:00:00 (mock clock = UTC = 'CT' here)
    {
        mock::feed = mock::Feed(); mock::timers().clear(); mock::refuseTimers() = false; lost = 0;
        char tmpl[] = "/tmp/fclkXXXXXX"; const char* tmp = mkdtemp(tmpl); setenv("USERPROFILE", tmp, 1);
        const std::string root = std::string(tmp) + "/irt"; mrec::rootOverride() = root;
        mock::Host h; mock::current = &h; h.tick = 0.25f; h.seconds = 60; h.symbol = "ESZ6"; h.root = "ES";
        const unsigned long t17 = T0 + 3 * 3600;                     // 17:00:00
        for (int i = 0; i < 31; ++i) h.bars.push_back(bar(t17 - 60UL * 29 + 60UL * i, 10));
        Ind* p = static_cast<Ind*>(CreateExtension()); p->calc(0);
        publish(0, 1, 6999.75f, 1, t17 - 2, 1); p->calc(0);
        publish(3, 1, 6999.75f, 1, t17 - 1, 1); publish(0, 1, 6999.75f, 1, t17, 2); publish(0, 1, 6999.75f, 1, t17 + 1, 3);
        off::off_test_now_ms += 250; tickTimers(p); off::off_test_now_ms += 1100; tickTimers(p);
        dispose(p);
        time_t a = (time_t)(t17 - 1), bb = (time_t)t17; struct tm ta, tb; gmtime_r(&a, &ta); gmtime_r(&bb, &tb);
        const std::string s1 = mrec::sessionOf(ta.tm_year + 1900, ta.tm_mon + 1, ta.tm_mday, ta.tm_hour), s2 = mrec::sessionOf(tb.tm_year + 1900, tb.tm_mon + 1, tb.tm_mday, tb.tm_hour);
        const long long n1 = countLines(root + "/" + s1 + "/ES", "mbo_16"), n2 = countLines(root + "/" + s2 + "/ES", "mbo_17");
        std::printf("  D: %s/mbo_16 %lld rows, %s/mbo_17 %lld rows\n", s1.c_str(), n1, s2.c_str(), n2);
        CHECK(s1 != s2 && n1 == 2 && n2 == 2, "D: 16:59:59 in today's session file mbo_16, 17:00:00 in the next session's mbo_17");
        std::filesystem::remove_all(tmp);
    }
    // F) a faulting clock read: the clock stops, calc / draw keep reading
    {
        mock::feed = mock::Feed(); mock::timers().clear(); mock::refuseTimers() = false;
        char tmpl[] = "/tmp/fclkXXXXXX"; const char* tmp = mkdtemp(tmpl); setenv("USERPROFILE", tmp, 1);
        mrec::rootOverride() = std::string(tmp) + "/irt";
        mock::Host h; mock::current = &h; h.tick = 0.25f; h.seconds = 60; h.symbol = "ESZ6"; h.root = "ES";
        for (int i = 0; i < 31; ++i) h.bars.push_back(bar(T0 + 60UL * i, 10));
        Ind* p = static_cast<Ind*>(CreateExtension()); p->calc(0); auto* S = p->testState();
        publish(0, 1, 6999.75f, 1, T0 + 60 * 30 - 5, 1); p->calc(0);
        CHECK(S->timerOn && mock::timers().size() == 1, "F: the clock started once the stream subscribed (chart context)");
        mock::feed.throwOnNext = true; publish(0, 1, 6999.75f, 1, T0 + 60 * 30 - 4, 2);
        off::off_test_now_ms += 250; tickTimers(p);
        CHECK(!S->timerOn && mock::timers().empty() && S->feed.timerOff && S->feed.timerFaults == 1, "F: a faulting clock read stops and destroys the clock");
        CHECK(!S->feed.dead, "F: the stream itself is not marked dead by a clock fault");
        dispose(p); std::filesystem::remove_all(tmp);
    }
    mrec::rootOverride().clear();
    std::printf("feed clock host (OrderFlowFeed %s, PullStats %s, MboRecord %s): %d passed, %d failed\n", off::VERSION, ps::VERSION, mrec::VERSION, passes, fails);
    return fails ? 1 : 0;
}
