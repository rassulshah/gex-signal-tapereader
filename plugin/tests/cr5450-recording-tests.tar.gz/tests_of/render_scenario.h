// render_scenario.h -- one CL 3-min reversal at LonLO 92.90, fed to each plugin on the mock host (bars, VAP and the order-by-order
// feed), for render-check.png. Each dump program includes ONE plugin .cpp, runs this, draws once and prints every draw call.
#include <cmath>
#include <cstdio>
#include <functional>
#include <string>
#include <vector>
namespace scen {
static const unsigned long T0 = 1791900000UL;            // 2026-10-13 14:00 (mock clock = gmtime): 9:00 bar ends
static const int N = 48;                                  // candles; the last one forming
static unsigned rng = 12345;
static int rnd(int lo, int hi) { rng = rng * 1103515245u + 12345u; return lo + (int)((rng >> 16) % (unsigned)(hi - lo + 1)); }
static double closeOf(int k) {                            // down into 92.92 at k = 24, then up to ~93.70
    if (k == 24) return 92.97;                                // the sweep candle closes back up: price held
    if (k <= 24) return 93.62 - 0.70 * k / 24.0 + 0.02 * std::sin(k * 1.7);
    return 92.94 + 0.76 * (1 - std::exp(-(k - 24) / 9.0)) + 0.02 * std::sin(k * 1.3);
}
static float r2(double v) { return (float)(std::floor(v * 100 + 0.5) / 100); }
static int id = 1;
static void ev(unsigned char a, unsigned char side, float px, unsigned long size, RTDATE t, int oid, int aggr = 0) { mock::feed.push(a, side, px, size, t, oid); mock::feed.ev.back().aggressorOrderID = aggr; }
// the order flow of candle k (stamped inside it): normal adds / pulls / small fills, plus the story candles
static void flow(int k) {
    const RTDATE t = T0 + 180UL * k - 90; const float c = r2(closeOf(k));
    int adds = rnd(4, 9), pulls = rnd(3, 7);
    if (k == 22) adds = 0;
    for (int i = 0; i < adds; ++i) { ev(0, 1, r2(c - 0.02 * rnd(1, 6)), rnd(1, 6), t, id++); ev(0, 0, r2(c + 0.02 * rnd(1, 6)), rnd(1, 6), t, id++); }
    for (int i = 0; i < pulls; ++i) {
        const int b = id++, a = id++; const float pb = r2(c - 0.01 * rnd(4, 9)), pa = r2(c + 0.01 * rnd(4, 9)); const unsigned long sz = rnd(1, 5);
        ev(0, 1, pb, sz, t, b); ev(0, 0, pa, sz, t, a); ev(2, 1, pb, sz, t, b); ev(2, 0, pa, sz, t, a);
    }
    for (int i = 0; i < 6; ++i) { const int o = id++; const bool buy = rnd(0, 1); const float px = buy ? r2(c + 0.01) : r2(c - 0.01); ev(0, buy ? 0 : 1, px, 4, t, o); ev(3, buy ? 0 : 1, px, rnd(1, 4), t, o, 50000 + id); }
    if (k == 22) {                                            // 1: buyers stack bids at LonLO: many adds, one 90-lot, reloads after fills (iceberg)
        for (int i = 0; i < 40; ++i) ev(0, 1, r2(92.90 + 0.01 * rnd(0, 2)), rnd(2, 5), t, id++);
        ev(0, 1, 92.92f, 90, t, id++);
        int o = id++; ev(0, 1, 92.89f, 4, t, o);                     // the iceberg: 4 shown, refilled after every fill
        for (int r = 0; r < 12; ++r) { ev(3, 1, 92.89f, 4, t, o, 70000 + r); ev(2, 1, 92.89f, 0, t, o); o = id++; ev(0, 1, 92.89f, 4, t, o); }
    }
    if (k == 24) {                                            // 2: one seller sweeps 4 bid levels with a 120-lot into LonLO
        const float lv[4] = { 92.95f, 92.94f, 92.93f, 92.92f };
        for (int i = 0; i < 4; ++i) { const int o = id++; ev(0, 1, lv[i], 30, t, o); ev(3, 1, lv[i], 30, t, o, 900001); }
    }
    if (k == 26) {                                            // 3: sellers pull their offers above price, incl. one 85-lot
        for (int i = 0; i < 30; ++i) { const int o = id++; const float px = r2(c + 0.01 * rnd(4, 10)); ev(0, 0, px, 3, t, o); ev(2, 0, px, 3, t, o); }
        const int o = id++; ev(0, 0, r2(c + 0.08), 85, t, o); ev(2, 0, r2(c + 0.08), 85, t, o);
    }
    if (k == 27) {                                            // 4: one buyer sweeps 3 offer levels with a 95-lot
        for (int i = 0; i < 3; ++i) { const int o = id++; const float px = r2(c + 0.01 * (i + 1)); ev(0, 0, px, 32, t, o); ev(3, 0, px, 32, t, o, 900002); }
    }
    if (k == 40) {                                            // 5: sellers build a wall above, incl. one 110-lot
        for (int i = 0; i < 38; ++i) ev(0, 0, r2(c + 0.01 * rnd(3, 9)), rnd(2, 5), t, id++);
        ev(0, 0, r2(c + 0.06), 110, t, id++);
    }
    if (k == 44) {                                            // 6: buyers pull their bids under price
        for (int i = 0; i < 28; ++i) { const int o = id++; const float px = r2(c - 0.01 * rnd(4, 10)); ev(0, 1, px, 3, t, o); ev(2, 1, px, 3, t, o); }
    }
}
static mock::Bar barOf(int k) {
    mock::Bar b; b.time = (unsigned long)(T0 + 180UL * k);
    const double o = closeOf(k - 1), c = closeOf(k);
    b.open = r2(o); b.close = r2(c); b.high = r2(std::max(o, c) + 0.02 + 0.01 * rnd(0, 3)); b.low = r2(std::min(o, c) - 0.02 - 0.01 * rnd(0, 3));
    if (k == 24) b.low = 92.91f;
    b.volume = 0;
    for (float px = b.low; px <= b.high + 0.001f; px = r2(px + 0.01)) {
        long bid = rnd(5, 40), ask = rnd(5, 40);
        if (k == 24 && px <= 92.95f) bid = 240 - (long)((px - 92.91f) * 1000);
        if (k == 27 && px >= b.high - 0.03f) ask = 380;
        b.rows.push_back(mock::Price(px, ask, bid, ask + bid)); b.volume += (unsigned long)(ask + bid);
    }
    return b;
}
// run the session candle by candle: the candle's events arrive while it forms, then it closes
static void run(mock::Host& h, long long& clock, const std::function<void()>& calc) {
    h.tick = 0.01f; h.seconds = 180; h.symbol = "CLX6"; h.root = "CL"; h.priceBase = 92.8f;
    h.bars.clear(); for (int k = 0; k < 16; ++k) h.bars.push_back(barOf(k));
    calc(); clock += 1000; calc();
    for (int k = 16; k < N; ++k) {
        h.bars.push_back(barOf(k)); clock += 50; calc();
        flow(k); clock += 50; calc(); clock += 50; calc();
        clock += 700; calc(); clock += 700; calc();
    }
}
static void levels(const std::string& flex) {
    std::ofstream f((flex + "\\LRA-KeyLevels-CL.csv").c_str()); f << "KEYLV,1," << (long long)std::time(NULL) << "\nL|LonLO|92.90|0\nL|PDH|94.40|0\n";
}
static void dump(mock::Host& h, const char* name) {
    std::printf("PANE\t%s\t%d\t%d\t%d\t%d\n", name, h.paneLeft, h.paneTop, h.paneRight, h.paneBottom);
    for (auto& d : h.draws) {
        if (d.type == "box") std::printf("BOX\t%d\t%d\t%d\t%d\t%06lx\t%06lx\t%d\t%06lx\n", d.x, d.y, d.r, d.b, (unsigned long)d.color, (unsigned long)d.border, d.width, (unsigned long)d.pen);
        else if (d.type == "text") std::printf("TEXT\t%d\t%d\t%d\t%d\t%06lx\t%d\t%d\t%d\t%d\t%s\n", d.x, d.y, d.r, d.b, (unsigned long)d.color, d.width, d.fid, d.fsize, d.fstyle, d.text.c_str());
    }
}
static void candles(mock::Host& h) { for (size_t i = 0; i < h.bars.size(); ++i) std::printf("BAR\t%d\t%.2f\t%.2f\t%.2f\t%.2f\n", 50 + (int)i * h.barW, h.bars[i].open, h.bars[i].high, h.bars[i].low, h.bars[i].close); }
}
