#!/usr/bin/env python3
"""render_fix1.py (fix1, 2026-10-13 ~10 PM CT) -- BEFORE / AFTER of the font sizes, the info-box rows and the chart-wide hover.
usage: render_fix1.py <before_dir> <after_dir> <tr_before.png> <tr_after.png> <out.png>
<dir> holds d1.tsv / d3.tsv / d2.tsv (BidAskStats / StackStats / PullStats - Rassul's pane order) from render_dump.cpp. Unlike render_check.py
the text is drawn in Liberation Sans (metric twin of the chart's Helvetica / Arial) at the plugin's own point size (px = pt x 4/3), so
the sizes compare like on his screen. The AFTER panes were laid out with the same real widths (OFF_REAL_WIDTHS) and show the
candle under the mouse while the mouse is in the PRICE pane (HoverBoard.h, published by another window)."""
import sys
from PIL import Image, ImageDraw, ImageFont

BG = (11, 14, 18)
LS = "/usr/share/fonts/truetype/liberation/"
def font(pt, bold):
    return ImageFont.truetype(LS + ("LiberationSans-Bold.ttf" if bold else "LiberationSans-Regular.ttf"), max(6, round(pt * 4 / 3)))
def rgb(h): v = int(h, 16); return ((v >> 16) & 255, (v >> 8) & 255, v & 255)

def load(p):
    pane, items = None, []
    for ln in open(p, encoding="cp1252"):
        f = ln.rstrip("\n").split("\t")
        if f[0] == "PANE": pane = (f[1], *map(int, f[2:6]))
        elif f[0] == "BOX": items.append(("box", *map(int, f[1:5]), rgb(f[5]), rgb(f[6]), int(f[7]), rgb(f[8])))
        elif f[0] == "TEXT": items.append(("text", *map(int, f[1:5]), rgb(f[5]), int(f[6]), int(f[7]), int(f[8]), int(f[9]), "\t".join(f[10:])))
    return pane, items

def pane_img(dump, width):
    (name, L, T, R, B), items = dump
    sub = Image.new("RGB", (width, B - T + 1), BG); sd = ImageDraw.Draw(sub)
    for it in items:
        if it[0] == "box":
            _, x0, y0, x1, y1, fill, border, w, pen = it
            sd.rectangle([x0, y0, x1, y1], fill=fill, outline=pen, width=max(1, w))
    for it in items:
        if it[0] != "text": continue
        _, x0, yc, x1, yb, col, centred, fid, fsize, fstyle, text = it
        f = font(fsize, fstyle == 1); yt = 2 * yc - yb
        if centred:
            w = sd.textlength(text, font=f); sd.text(((x0 + x1) / 2 - w / 2, yt - 1), text, fill=col, font=f)
        else:
            sd.text((x0, yt - 1), text, fill=col, font=f)
    return name, sub

def column(d, title, sub_title, dumps, trpng, x0, y0, W):
    hf = font(13, True); sf = font(10, False)
    d.text((x0 + 8, y0), title, fill=(245, 245, 245), font=hf)
    d.text((x0 + 8, y0 + 20), sub_title, fill=(160, 166, 174), font=sf)
    y = y0 + 44
    for dump in dumps:
        name, img = pane_img(dump, W)
        d.text((x0 + 8, y), name, fill=(225, 228, 232), font=font(10, True)); y += 18
        canvas.paste(img, (x0, y)); d.rectangle([x0, y, x0 + W - 1, y + img.size[1] - 1], outline=(40, 44, 50)); y += img.size[1] + 10
    tr = Image.open(trpng).convert("RGB")
    s = W / tr.size[0]; tr = tr.resize((W, int(tr.size[1] * s)))
    d.text((x0 + 8, y), "Tape Reader (price pane) - scaled to fit, text sizes as drawn", fill=(225, 228, 232), font=font(10, True)); y += 18
    canvas.paste(tr, (x0, y)); return y + tr.size[1]

if __name__ == "__main__":
    bdir, adir, trb, tra, out = sys.argv[1:6]
    before = [load(f"{bdir}/d{k}.tsv") for k in (1, 3, 2)]
    after = [load(f"{adir}/d{k}.tsv") for k in (1, 3, 2)]
    W = max(p[0][3] for p in before + after) + 1
    H = 120 + sum(p[0][4] - p[0][2] + 30 for p in after) + int(1360 * W / 2620) + 80
    canvas = Image.new("RGB", (W * 2 + 30, H), BG); d = ImageDraw.Draw(canvas)
    d.text((10, 8), "fix1 render check (2026-10-13): BEFORE (live of140) vs AFTER (BidAskStats 1.5.1 / StackStats 1.1.1 / PullStats 1.1.1 / Tape Reader 1.1.1) - panes in Rassul's order BidAsk, Stack, Pull",
           fill=(245, 245, 245), font=font(12, True))
    d.text((10, 30), "Fonts: spike labels 7 -> 10 pt, info boxes 9 -> 10 pt, Tape Reader 9 / 8 -> 12 / 11 pt.  Rows: BidAsk Lots, Pace, Sweep, Large, StopRun, Crowd, Burst; "
           "Stack Added, Rebuilt %, Pace, Crowd, Refills (I); Pull Pulled, Before price, Traded first, Pace, Crowd.", fill=(190, 196, 204), font=font(9, False))
    d.text((10, 48), "AFTER hover: the mouse is in the PRICE pane over the 10:12 candle (bar 24, the LonLO turn) - all three panes follow it (HoverBoard.h); BEFORE they stayed on Live.",
           fill=(190, 196, 204), font=font(9, False))
    column(d, "BEFORE (live 1.5.0 / 1.1.0 / 1.1.0 / TR 1.1.0)", "mouse in the price pane: the panes stay on Live", before, trb, 0, 70, W)
    column(d, "AFTER (fix1)", "mouse in the price pane over bar 24: every pane shows that candle", after, tra, W + 30, 70, W)
    canvas.save(out); print("saved", canvas.size)
