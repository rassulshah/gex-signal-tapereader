# CR5300 - spike labels lose pace / lots (2026-10-14)

Request (Rassul 11:59 CT, CLZ6 3-min BidAskStats screenshot): "the label for pace and lots on the red spike goes away but it is there
on the green spike. fix it .. also check other indicators".

Root cause: OrderFlowFeed.h <= 1.3.0 spikeLabels() pass 2. When ANY spike had no free label spot (a spike under the read box or the
hover grid, the forming bar, a crowded spot), it shrank the NEAREST already-placed full label to its ratio alone, then the next
nearest, and so on until no full label was left - so a label lost "p 1.3x" and "111" because of a different (often far-away) candle.
It came and went with new bars, the forming bar flickering, scrolling, and the mouse entering the read box (the grid was an obstacle).
Which colour lost depended only on which label was nearest - on his chart that was the seller (red) spike. Same shared code in
BidAskStats, PullStats and StackStats: all three had the bug (proved on the mock host, both sides).

Fix (OrderFlowFeed.h 1.3.1, BidAskStats 1.5.3, PullStats 1.2.2, StackStats 1.1.3):
- labels decided in TIME ORDER from older labels + fixed obstacles only: full label above its bar (staggered up), else the ratio alone
  for itself (staggered, shifted). Never shrinks another label; a later spike can never change an earlier label.
- the hover grid is no longer a label obstacle (it is drawn over the bars while the mouse is in the box).
- candles up to ~240 px left of the view take part in the layout (not drawn) so scrolling does not re-decide a label still in view.
- no change in the normal case: render dumps d1 / d2 / d3 byte-identical to 1.3.0.

Tests: tests_of/test_label_persist.cpp (logic + fuzz 22k layouts + drawBars; BidAskStats / PullStats / StackStats hosts, both sides:
3-row label with a spike under the box, N more bars, hover every candle, mouse in the box, scroll, restart, 17:00 CT session).
Old code: logic 9 failed, each host 4 failed. New code: all pass; full tests_of suite passes (ASan/UBSan -Werror, MinGW real-SDK
syntax 0/0, win32 libs ok). LiquidityProfile / LiquidityFlow (include OrderFlowFeed.h, do not use the label code): MinGW syntax 0/0.
Not verified - needs his IRT restart + screenshots.
