#!/usr/bin/env python3
"""render_final.py (of140, 2026-10-13 6:18 PM) -- render-check-final.png: the Tape Reader's own draw (trtests render, price chart +
the box, bottom centre) on top, then the three order-flow panes in Rassul's pane order BidAskStats, StackStats, PullStats (attack and
wall side by side), each the plugin's own draw calls (tests/render_check.py).
usage: render_final.py <tr.png> <panes.png> <out.png>"""
import sys
from PIL import Image, ImageDraw, ImageFont
tr, panes = Image.open(sys.argv[1]).convert("RGB"), Image.open(sys.argv[2]).convert("RGB")
W = panes.size[0]
tr = tr.resize((W, round(tr.size[1] * W / tr.size[0])), Image.LANCZOS)
f = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf", 13)
H = 30 + tr.size[1] + 8 + panes.size[1]
im = Image.new("RGB", (W, H), (11, 14, 18)); d = ImageDraw.Draw(im)
d.text((10, 8), "render-check-final (of140): price chart + Tape Reader 1.1.0 (bottom centre), then BidAskStats 1.5.0 / StackStats 1.1.0 / PullStats 1.1.0", fill=(225, 228, 232), font=f)
im.paste(tr, (0, 30)); im.paste(panes, (0, 30 + tr.size[1] + 8))
im.save(sys.argv[3]); print("saved", im.size)
