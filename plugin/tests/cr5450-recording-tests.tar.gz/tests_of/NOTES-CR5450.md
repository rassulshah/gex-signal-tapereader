# CR5450 - IRT data recording fix (2026-10-14 evening)

Rassul's standing order: "always record IRT data and keep the MBO files updated". Source: research-artifacts/review/LIQ-DAY-2026-10-14.md.

| Plugin | Version | What changed |
|---|---|---|
| lsIRTReader + lsFootprintReader<MKT> | 0.7.1 -> 0.8.0 | Depth recorder rewritten: opened / first read in calc-draw (named by the chart symbol), 250 ms guarded clock, valid books only, hourly dom_HH.csv + dbo_HH.csv, one writer per market, coverage, IRTReader.depth-<MKT>.txt; depth back ON for every market; pass watchdog; stuck VAP bar skip (HG); stale-feed ERROR (NG) |
| OrderFlowFeed.h | 1.3.1 -> 1.4.0 | 250 ms order-feed clock + queue for MboPane panes; Coverage meter; FEED_CLOCK / MBO_COVERAGE status lines |
| lsPullStats | 1.2.2 -> 1.3.0 | clock flushes the recorder; one getLocaltime per second |
| lsStackStats | 1.1.3 -> 1.2.0 | the clock (complete feed) |
| MboRecord.h | 1.0.0 -> 1.1.0 | path cached per hour, time cached per second |
| lsLiquidityProfile / Flow | 0.16.0 -> 0.16.1 | rebuilt % per hit price, <= 100% (hover + makeup log only) |
| lra.mbo_live | 1.1.0 -> 1.2.0 | archives dom_HH.csv |
| lra.irt_tape | - | reads dom_HH.csv in place, archive for finished sessions |
| analytics/test_mbo.py | - | end-to-end study test writes to a temp USERPROFILE, asserts the live LRA-LiqNorms-ES.csv untouched |

Tests (Linux, ASan/UBSan): tests_of/run_tests.sh (+ test_feedclock_host 21/21), tests_ir/run_tests.sh (host 32/32, contract 10/10, logic 14/14, MinGW syntax 0/0),
tests_lq/run_tests.sh (all LP suites, + rebuilt churn), pytest test_mbo_live (5/5), test_mbo end-to-end (1/1), test_orderflow_reasons (3/3).
Not verified - needs his IRT: that IRT honours a 250 ms timer for these plugins, that named DEPTH_BY_ORDER / MARKET_DEPTH reads from a
timer are clean on Rithmic (guarded: a fault turns that clock read off and is reported), the real ring size, CPU cost at the open.
After his restart: IRTReader.depth-<MKT>.txt (DOM snapshots climbing ~1/s, DBO events, MBO_COVERAGE), PullStats status FEED_CLOCK / MBO_COVERAGE.
