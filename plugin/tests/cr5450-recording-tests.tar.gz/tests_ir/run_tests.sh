#!/bin/sh
# lsIRTReader / lsFootprintReader<MKT> 0.8.0 (CR5450): logic + host (mock SDK, ASan/UBSan, -Werror), the state contract, the real-SDK
# syntax check of both builds (MinGW: windows.h before irtsdk.h). Binaries are removed after each run (disk is tight).
D=$(cd "$(dirname "$0")/.." && pwd); B=${BUILD:-/tmp/ir-build}; mkdir -p "$B"; SDK=${SDK:-/mnt/user-data/uploads/sdk/c++/include}
SAN="-fsanitize=address,undefined -fno-sanitize-recover=undefined"; CXX="g++ -std=c++17 -Wall -Wextra -Werror -g $SAN"
step() { echo "== $1" >&2; shift; "$@" || { echo "FAILED: $*"; exit 1; }; }
for T in test_irtreader_logic test_irtreader_logic_regression; do step "$T" $CXX -I"$D" "$D/$T.cpp" -o "$B/$T"; step "run" "$B/$T"; rm -f "$B/$T"; done
step "host 0.8.0" $CXX -I"$D/tests_ir" -I"$D" "$D/tests_ir/test_ir_host.cpp" -o "$B/tir"; step "run" "$B/tir"; rm -f "$B/tir"
step "state contract" python3 -I "$D/test_irtreader_state_contract.py"
for N in IRTReader FootprintReaderES; do
  x86_64-w64-mingw32-g++ -std=c++17 -fsyntax-only -Wall -Wextra -Wno-unknown-pragmas -I"$SDK" -I"$D" "$D/tests_settings/wrap_$N.cpp" > "$B/syntax-$N.log" 2>&1
  E=$(grep -c ' error' "$B/syntax-$N.log"); W=$(grep 'warning' "$B/syntax-$N.log" | grep -vc "$SDK")
  echo "syntax $N: $E errors, $W warnings outside the SDK"; [ "$E" = 0 ] && [ "$W" = 0 ] || { head -20 "$B/syntax-$N.log"; exit 1; }
done
echo "ALL IRT READER SUITES PASSED"
