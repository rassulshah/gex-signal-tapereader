#ifndef IR_TEST_SDK_H
#define IR_TEST_SDK_H
// TEST DOUBLE ONLY (lsIRTReader 0.8.0 host tests). Not the Linnsoft SDK. Models what the reader uses, and IRT's per-subscriber
// order-feed buffer: it keeps only the last `ring` unread events (older ones are overwritten = lost), as observed on 10-14.
#include <cstring>
#include <ctime>
#include <map>
#include <string>
#include <vector>
#include <stdexcept>
typedef unsigned long RTDATE; typedef unsigned short RTBOOL; typedef unsigned long COLOR; typedef int RTX_RESULT;
enum { RTX_OK = 0, RTX_FAIL = -1, POST_DRAWING = 1, OVERLAY = 2, NO_UI = 4, INSTRUMENT_SCALE = 8, VAP_REQUIRED = 16, CALL_CONTINUOUSLY = 1, kParmAppendSameLine = 1 };
typedef enum PERIODICITY { PD_TICK, PD_INTRA } PERIODICITY;
typedef enum DATA_SOURCE { DS_RITHMIC = 41, DS_CQG = 26 } DATA_SOURCE;
enum iARRAY { barDateTime, barVolume };
typedef struct DEPTH_LEVEL { float bid, ask; unsigned short bidsize, asksize; } DEPTH_LEVEL;
typedef struct DEPTH_ORDER { RTDATE timestamp; float price; float previousPrice; float bid, ask; unsigned long bidsize, asksize; unsigned long size; int orderID; int aggressorOrderID; unsigned char action; unsigned char buySell; } DEPTH_ORDER;
typedef struct RTX_EVENT { int type; union { struct { int id; void* userdata; void* futureUse; } timer; } v; } RTX_EVENT;
namespace mock {
struct FpRow { float price; long buy, sell, total; };
struct FpBar { RTDATE t; float o, h, l, c; unsigned long vol; std::vector<FpRow> rows; bool vapFails = false; };
struct Feed { std::vector<DEPTH_ORDER> ev; size_t at = 0; size_t ring = 0; long long lost = 0; bool throwOnNext = false; long long getNext = 0, opens = 0, live = 0;
    void publish(const DEPTH_ORDER& o) { ev.push_back(o); if (ring && ev.size() - at > ring) { ++lost; ++at; } } };
struct Host {
    std::string symbol = "ESZ6", root = "ES"; double tick = 0.25; int spb = 180; RTDATE now = 0; DATA_SOURCE ds = DS_RITHMIC;
    std::vector<RTDATE> barT; std::vector<unsigned long> barV;           // the chart's own bars (END times)
    std::vector<DEPTH_LEVEL> depth; bool depthOn = true; int depthThrowAt = -1; int depthObjects = 0; long long levelReads = 0;
    void* data = nullptr; bool noTimers = false;
};
extern Host* current; extern Feed feed; extern std::vector<FpBar> fp;
inline std::map<int, int>& timers() { static std::map<int, int> t; return t; }
}
class cppExtension {
public:
    struct VOLPROFILE { float price; long buyVolume, sellVolume, totalVolume, tickCount, maxDelta, minDelta; };
    struct BARSTATISTICS { long buyVolume, sellVolume, totalVolume, maxPriceVol, maxPriceDelta, maxSideVolume; int ticks, tpos, maxTPOs; long maxDelta, minDelta, openDelta; short prices, flags; };
    class RTARRAYI { public: iARRAY a; long count; std::vector<unsigned long>* own = nullptr; unsigned long tmp = 0;
        RTARRAYI(iARRAY x) : a(x), count((long)mock::current->barT.size()) {}
        RTARRAYI(std::vector<unsigned long>* v) : a(barDateTime), count((long)v->size()), own(v) {}
        unsigned long& operator[](int i) { if (own) return own->at(i); return a == barDateTime ? mock::current->barT.at(i) : mock::current->barV.at(i); } };
    class RTARRAY { public: std::vector<float>* v; RTARRAY(std::vector<float>* p) : v(p) {} float& operator[](int i) { return v->at(i); } };
    class RTBARS { public:
        RTARRAYI* dt; RTARRAY *op, *hi, *lo, *cl; RTARRAYI* vo; long count;
        std::vector<unsigned long> t_, v_; std::vector<float> o_, h_, l_, c_; std::vector<size_t> idx_;
        RTBARS(PERIODICITY = PD_INTRA, int = 1, RTBOOL = 0, const char* = NULL, RTBOOL = 0, RTDATE start = 0, RTBOOL = 1) {
            for (size_t i = 0; i < mock::fp.size(); ++i) if (mock::fp[i].t >= start) { idx_.push_back(i); t_.push_back(mock::fp[i].t); v_.push_back(mock::fp[i].vol); o_.push_back(mock::fp[i].o); h_.push_back(mock::fp[i].h); l_.push_back(mock::fp[i].l); c_.push_back(mock::fp[i].c); }
            dt = new RTARRAYI(&t_); vo = new RTARRAYI(&v_); op = new RTARRAY(&o_); hi = new RTARRAY(&h_); lo = new RTARRAY(&l_); cl = new RTARRAY(&c_); count = (long)t_.size(); }
        ~RTBARS() { delete dt; delete vo; delete op; delete hi; delete lo; delete cl; }
        RTX_RESULT getBarStatistics(int i, BARSTATISTICS& s) { const mock::FpBar& b = mock::fp.at(idx_.at(i)); if (b.vapFails) return RTX_FAIL; std::memset(&s, 0, sizeof(s));
            for (auto& r : b.rows) { s.buyVolume += r.buy; s.sellVolume += r.sell; s.totalVolume += r.total; } s.prices = (short)b.rows.size(); return RTX_OK; }
        RTX_RESULT getVolumeProfile(int i, int k, VOLPROFILE& v) { const mock::FpBar& b = mock::fp.at(idx_.at(i)); if (b.vapFails) return RTX_FAIL; const mock::FpRow& r = b.rows.at(k); std::memset(&v, 0, sizeof(v)); v.price = r.price; v.buyVolume = r.buy; v.sellVolume = r.sell; v.totalVolume = r.total; return RTX_OK; }
    };
    class RTTICKS { public: RTARRAYI* dt = nullptr; RTARRAY *ask = nullptr, *bid = nullptr, *price = nullptr; RTARRAYI* size = nullptr; long count = 0; RTTICKS(RTDATE = 0) {} };
    class MARKET_DEPTH { public: int maxLevels; std::string sym;
        MARKET_DEPTH(const char* t = NULL) : maxLevels((int)mock::current->depth.size()), sym(t ? t : "") { ++mock::current->depthObjects; }
        ~MARKET_DEPTH() { --mock::current->depthObjects; }
        RTBOOL available() { maxLevels = (int)mock::current->depth.size(); return mock::current->depthOn ? 1 : 0; }
        DEPTH_LEVEL& operator[](unsigned n) { ++mock::current->levelReads; if ((int)n == mock::current->depthThrowAt) throw std::runtime_error("C0000005"); return mock::current->depth.at(n); } };
    class DEPTH_BY_ORDER { public:
        DEPTH_BY_ORDER(const char* t = NULL) { index = 0; bDboSubscribed = 1; std::memset(symbol, 0, sizeof(symbol)); if (t) std::strncpy(symbol, t, 23); std::memset(&dbo, 0, sizeof(dbo)); ++mock::feed.opens; ++mock::feed.live; }
        ~DEPTH_BY_ORDER() { --mock::feed.live; }
    private: unsigned int index; RTBOOL bDboSubscribed;
    public: char symbol[24]; DEPTH_ORDER dbo;
        RTX_RESULT getNext() { ++mock::feed.getNext; (void)index; (void)bDboSubscribed; if (mock::feed.throwOnNext) { throw std::runtime_error("C0000005"); }
            if (mock::feed.at >= mock::feed.ev.size()) { return RTX_FAIL; }
            dbo = mock::feed.ev[mock::feed.at++];
            return RTX_OK; } };
    virtual ~cppExtension() {}
    virtual int init(); virtual int setup(); virtual int calc(int); virtual int done(); virtual int destroy();
    virtual int draw() { return RTX_FAIL; } virtual int timer(RTX_EVENT*) { return RTX_FAIL; }
    virtual int parmsLoad() { return RTX_FAIL; } virtual int parmsApply() { return RTX_FAIL; } virtual int parmsUpdt(unsigned int) { return RTX_OK; }
    void* getUserData() { return mock::current->data; } void setUserData(void* p) { mock::current->data = p; }
    long getBarCount() { return (long)mock::current->barT.size(); }
    char* getRootSymbol(char* b = NULL, const char* = NULL) { static char r[32]; std::strncpy(b ? b : r, mock::current->root.c_str(), 31); return b ? b : r; }
    const char* getSymbol() { return mock::current->symbol.c_str(); }
    double getTickIncrement(const char* = NULL) { return mock::current->tick; }
    int getSecondsPerBar() { return mock::current->spb; }
    RTDATE currentDate() { return mock::current->now; }
    struct tm* getLocaltime(RTDATE d, struct tm* t) { time_t v = (time_t)d; return localtime_r(&v, t); }
    DATA_SOURCE getDataSource() { return mock::current->ds; }
    RTX_RESULT createTimer(int id, int ms = 1000, void* = NULL) { if (mock::current->noTimers) return RTX_FAIL; mock::timers()[id] = ms; return RTX_OK; }
    RTX_RESULT destroyTimer(int id) { return mock::timers().erase(id) ? RTX_OK : RTX_FAIL; }
    int getListIndex(int) { return 0; } int getParameterCount() { return 0; }
    void setBoolParameter(const char*, int, short = 0) {} void setIntegerParameter(const char*, int, int = 0, short = 0) {} void setListParameter(const char*, short, const char*, int = 0, short = 0) {}
    void setParameterVersion(int) {} void setParameterDialogHeight(int) {} void setFlags(unsigned long) {} void setExtendedFlags(unsigned long) {}
    void setDescription(const char*) {} void setVersion(const char*) {} void setArrayCount(int) {}
};
#endif
