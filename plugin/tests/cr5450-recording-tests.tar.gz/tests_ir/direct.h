// TEST SHIM ONLY: <direct.h> on Linux for the IRT Reader host tests
#pragma once
#include <sys/stat.h>
#include <sys/types.h>
inline int _mkdir(const char* p) { return mkdir(p, 0755); }
