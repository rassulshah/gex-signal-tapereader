// test_ir_host.cpp -- lsIRTReader / lsFootprintReader<MKT> 0.8.0 on the mock SDK (tests_ir/irtsdk.h), TZ = America/Chicago.
//   1  the book and the order feed are opened from the chart's own call, named by the chart symbol; the clock starts there
//   2  DOM once a second from the clock alone (chart not drawn), every level, only when it changed; hourly dom_HH.csv
//   3  a book read while IRT rebuilds it (10-14 08:26:06: level 1 bid under level 5) is never written - counted BAD with the reason
//   4  order-feed bursts (2,000 / s, IRT keeps 600 unread): nothing lost, file order = feed order, MBO_COVERAGE 100%
//   5  hour and session boundaries: 16:59:59 -> <today>\dbo_16.csv, 17:00:00 -> <next session>\dbo_17.csv
//   6  lsPullStats recording mbo_HH.csv: events read, not written twice; status says so
//   7  two readers on one market (lsIRTReader + lsFootprintReaderES): one writer only
//   8  a faulting clock read (book / feed) turns that clock read off, is reported, and the chart keeps reading
//   9  a pass that never finished is detected after 30 s (was: the reader silent for the day)
//  10  a footprint bar whose volume at price never loads (HG 10-09 16:00) is skipped after 5 tries; later bars are written
#include "IRTReader.cpp"
#include <cstdio>
#include <unistd.h>
#include <dirent.h>
#include <sstream>
#include <algorithm>
namespace mock { Host* current = nullptr; Feed feed; std::vector<FpBar> fp; }
static int fails = 0, passes = 0;
#define CHECK(c, m) do { if (c) ++passes; else { ++fails; std::printf("FAIL %d %s\n", __LINE__, m); } } while (0)
static std::vector<std::string> filesWith(const std::string& part) { std::vector<std::string> v; DIR* d = opendir("."); if (!d) return v; while (dirent* e = readdir(d)) { std::string n = e->d_name; if (n.find(part) != std::string::npos) v.push_back(n); } closedir(d); std::sort(v.begin(), v.end()); return v; }
static std::vector<std::string> lines(const std::string& f) { std::vector<std::string> v; std::ifstream in(f.c_str()); std::string l; while (std::getline(in, l)) v.push_back(l); return v; }
static long long rowsIn(const std::string& part) { long long n = 0; for (auto& f : filesWith(part)) { auto L = lines(f); n += (long long)L.size() - (L.size() && (L[0].rfind("time|", 0) == 0 || L[0].rfind("bar|", 0) == 0) ? 1 : 0); } return n; }
static std::string readAll(const std::string& f) { std::ifstream in(f.c_str()); std::stringstream s; s << in.rdbuf(); return s.str(); }
static std::string line(const std::string& st, const std::string& k) { size_t a = st.find("\n" + k + ","); if (a == std::string::npos) return ""; a += k.size() + 2; return st.substr(a, st.find('\n', a) - a); }
static void tick(IRTReader* p) { for (auto& kv : std::map<int, int>(mock::timers())) { RTX_EVENT e; std::memset(&e, 0, sizeof(e)); e.v.timer.id = kv.first; p->timer(&e); } }
static void book(mock::Host& h, double bid, int n, unsigned short sz) { h.depth.clear(); for (int k = 0; k < n; ++k) { DEPTH_LEVEL L; L.bid = (float)(bid - k * h.tick); L.ask = (float)(bid + (k + 1) * h.tick); L.bidsize = sz + k; L.asksize = sz + 2 * k; h.depth.push_back(L); } }
static DEPTH_ORDER ord(unsigned char a, unsigned char side, float px, unsigned long size, RTDATE t, int id) { DEPTH_ORDER o; std::memset(&o, 0, sizeof(o)); o.timestamp = t; o.price = px; o.size = size; o.orderID = id; o.action = a; o.buySell = side; o.bid = 7000.0f; o.ask = 7000.25f; return o; }
static RTDATE ct(int y, int mo, int d, int hh, int mi, int ss) { struct tm t; std::memset(&t, 0, sizeof(t)); t.tm_year = y - 1900; t.tm_mon = mo - 1; t.tm_mday = d; t.tm_hour = hh; t.tm_min = mi; t.tm_sec = ss; t.tm_isdst = -1; return (RTDATE)mktime(&t); }
static DepthState* gD = nullptr;
static void chart(IRTReader* p) { if (gD) gD->lastChartMs = -1; p->calc(0); }
static RTDATE endOf(RTDATE t, RTDATE t0) { long long d = (long long)t - (long long)t0; long long k = d >= 0 ? d / 180 : -((-d + 179) / 180); return (RTDATE)((long long)t0 + 180 * (k + 1)); }
static IRTReader* make() { return static_cast<IRTReader*>(CreateExtension()); }
static void dispose(IRTReader* p) { p->destroy(); delete p; }
static const std::string ST = ".\\InvestorRT\\rtx\\lsFlexLevels\\IRTReader.depth-ES.txt";

int main() {
    setenv("TZ", "America/Chicago", 1); tzset();
    char tmpl[] = "/tmp/irhXXXXXX"; const char* tmp = mkdtemp(tmpl); if (!tmp || chdir(tmp) != 0) return 2;
    setenv("USERPROFILE", ".", 1);
    mock::Host h; mock::current = &h; h.spb = 180;
    const RTDATE t0 = ct(2026, 10, 14, 9, 0, 0);
    for (int i = 0; i < 20; ++i) { h.barT.push_back(t0 - 180 * (19 - i)); h.barV.push_back(0); }   // forming bar ends at 9:00:00
    h.now = t0 - 170; book(h, 7000.0, 40, 10); mock::feed.ring = 600;
    IRTReader* p = make(); p->setup(); p->calc(0);
    DepthState* D = static_cast<DepthState*>(h.data); gD = D;
    // 1
    CHECK(D && D->md && D->dbo && D->md->sym == "ESZ6" && std::string(D->dbo->symbol) == "ESZ6", "1: book + order feed opened in the chart call, named ESZ6");
    CHECK(D && D->owner && D->timerOn && mock::timers().size() >= 1, "1: this reader owns ES depth; the 250 ms clock started");
    CHECK(D && D->snaps == 1 && D->levelsLast == 40, "1: first snapshot from the chart call, all 40 levels");
    // 2: 60 s with the chart NOT drawn: the clock alone, a new book each second
    for (int s = 1; s <= 60; ++s) { h.now = t0 - 170 + s; book(h, 7000.0 + (s % 3) * 0.25, 40, (unsigned short)(10 + s)); for (int q = 0; q < 4; ++q) tick(p); }
    CHECK(D->snaps == 61, "2: one snapshot a second from the clock (61 in 61 s)");
    for (int q = 0; q < 8; ++q) tick(p);                              // same second, same book: nothing new
    CHECK(D->snaps == 61, "2: no snapshot without a change / within the second");
    usleep(1100 * 1000); tick(p);                                       // the once-a-second write
    { const std::vector<std::string> f = filesWith("\\ES\\dom_08.csv"); CHECK(f.size() == 1 && f[0].find("2026-10-14") != std::string::npos, "2: hourly file 2026-10-14\\ES\\dom_08.csv");
      const auto L = lines(f.empty() ? std::string() : f[0]); CHECK(L.size() == 1 + 61 * 40 && L[0] == "time|level|bid|bid_size|ask|ask_size", "2: header + 61 x 40 rows");
      bool ordered = true; for (size_t i = 1; i + 1 < L.size(); ++i) if (L[i].substr(0, 19) > L[i + 1].substr(0, 19)) ordered = false; CHECK(ordered, "2: snapshots in time order"); }
    // 3: a book being rebuilt
    h.now += 1; book(h, 7001.0, 40, 30); std::swap(h.depth[1], h.depth[5]); tick(p);
    CHECK(D->snaps == 61 && D->bad == 1 && D->badWhy.find("bids out of order at level") == 0, "3: an out-of-order book is not written, BAD + reason");
    h.now += 1; book(h, 7001.0, 40, 30); h.depth[0].ask = 7000.75f; tick(p);
    CHECK(D->bad == 2 && D->badWhy == "crossed book", "3: a crossed book is not written");
    h.now += 1; book(h, 7001.0, 40, 30); h.depth[3].bid = 7000.1f; tick(p);
    CHECK(D->bad == 3 && D->badWhy.find("off the tick grid") != std::string::npos, "3: a price off the tick grid is not written");
    h.now += 1; book(h, 7001.0, 40, 31); tick(p); CHECK(D->snaps == 62, "3: the next real book is written");
    // 4: order-feed bursts 2,000 / s for 6 minutes, the chart drawn every 20 s only; IRT keeps 600 unread events
    chart(p);                                                         // the chart's first order-feed read (nothing yet) - clock waits for events
    int id = 1; long long published = 0, fills = 0; RTDATE start = t0 - 120;
    mock::feed.publish(ord(0, 1, 6999.75f, 1, start - 1, id++)); ++published; h.now = start; chart(p);   // first chart read gets an event
    CHECK(D->dboLive && D->dboChart == 1, "4: the clock reads the feed only after the chart's own read got events");
    std::map<RTDATE, unsigned long> vol;
    for (int sec = 0; sec < 360; ++sec) {
        const RTDATE t = start + sec;
        for (int q = 0; q < 4; ++q) {
            for (int k = 0; k < 500; ++k) { const int kind = k % 4;
                if (kind == 0) { mock::feed.publish(ord(3, 1, 6999.75f, 2, t, id)); fills += 2; vol[endOf(t, t0)] += 2; }
                else if (kind == 1) mock::feed.publish(ord(0, 1, 6999.5f, 1, t, id));
                else if (kind == 2) mock::feed.publish(ord(2, 1, 6999.5f, 1, t, id - 1));
                else mock::feed.publish(ord(0, 0, 7000.25f, 1, t, id));
                ++id; ++published; }
            h.now = t; tick(p);
        }
        if (sec % 20 == 19) {                                         // IRT draws the chart: bars that closed get their volumes
            while (h.barT.back() <= t) { h.barT.push_back(h.barT.back() + 180); h.barV.push_back(0); }
            for (size_t i = 0; i < h.barT.size(); ++i) { auto it = vol.find(h.barT[i]); if (it != vol.end()) h.barV[i] = it->second; }
            chart(p);
        }
    }
    for (int k = 0; k < 40; ++k) { tick(p); }
    h.now += 30; chart(p); usleep(5200 * 1000); chart(p); D->statusMs = -1; chart(p);
    const std::string st = readAll(ST);
    std::printf("  DOM %s\n  DBO %s\n  MBO_COVERAGE %s\n", line(st, "DOM").c_str(), line(st, "DBO").c_str(), line(st, "MBO_COVERAGE").c_str());
    CHECK(mock::feed.lost == 0, "4: IRT never overwrote an unread event");
    CHECK(rowsIn("\\ES\\dbo_") == published && D->dboEvents == published, "4: every event published is in dbo_HH.csv once");
    { long long last = 0; bool ok = true; for (auto& f : filesWith("\\ES\\dbo_")) { auto L = lines(f); for (size_t i = 1; i < L.size(); ++i) { std::stringstream ss(L[i]); std::string x; int c = 0; long long oid = 0; while (std::getline(ss, x, '|')) { if (c == 5) oid = std::atoll(x.c_str()); ++c; } if (oid < last && !(L[i].find("|DEL|") != std::string::npos)) ok = false; if (L[i].find("|DEL|") == std::string::npos) last = oid; } } CHECK(ok, "4: file order = feed order"); }
    CHECK(line(st, "MBO_COVERAGE").find("last 10 bars 100%") != std::string::npos, "4: MBO_COVERAGE 100%");
    CHECK(line(st, "DBO").rfind("recording,", 0) == 0 && line(st, "DOM").rfind("available,", 0) == 0 && line(st, "CLOCK").rfind("on,250 ms", 0) == 0, "4: status lines DOM / DBO / CLOCK");
    // 5: hour + session boundary
    { const RTDATE a = ct(2026, 10, 14, 16, 59, 59), b = ct(2026, 10, 14, 17, 0, 0);
      mock::feed.publish(ord(0, 1, 6999.0f, 1, a, id++)); mock::feed.publish(ord(0, 1, 6999.0f, 1, b, id++)); tick(p); h.now = b + 2; usleep(1100 * 1000); tick(p);
      const auto f16 = filesWith("2026-10-14\\ES\\dbo_16.csv"), f17 = filesWith("2026-10-15\\ES\\dbo_17.csv");
      CHECK(f16.size() == 1 && f17.size() == 1 && lines(f16[0]).size() == 2 && lines(f17[0]).size() == 2, "5: 16:59:59 -> 2026-10-14\\dbo_16, 17:00:00 -> 2026-10-15\\dbo_17 (each with its header)"); }
    // 6: PullStats records mbo_HH.csv -> read, not written twice
    { const RTDATE now = ct(2026, 10, 14, 10, 5, 0); h.now = now;
      std::string mbo = RSet().folder + "\\2026-10-14\\ES\\mbo_10.csv"; { std::ofstream m(mbo.c_str()); m << "time|x\n"; }
      D->skipCheckMs = -1; D->lastChartMs = -1; usleep(210 * 1000); p->calc(0);
      const long long before = rowsIn("\\ES\\dbo_");
      for (int k = 0; k < 100; ++k) mock::feed.publish(ord(0, 1, 6999.0f, 1, now, id++));
      tick(p); usleep(1100 * 1000); tick(p);
      CHECK(D->dboSkip && rowsIn("\\ES\\dbo_") == before && D->dboNotWritten == 100, "6: lsPullStats recording: 100 events read, none written twice");
      D->statusMs = -1; tick(p); CHECK(line(readAll(ST), "DBO").find("read, not written - lsPullStats records mbo_10.csv") == 0, "6: status says why");
      std::remove(mbo.c_str()); D->skipCheckMs = -1; D->lastChartMs = -1; usleep(210 * 1000); p->calc(0); CHECK(!D->dboSkip, "6: PullStats gone: writing again"); }
    // 7: a second reader on the same market (another chart / DLL): not the writer
    { D->ownerMs = -1; chart(p);
      mock::Host h2 = h; h2.data = nullptr; mock::current = &h2;
      IRTReader* q = make(); q->setup(); gD = nullptr; q->calc(0); gD = D; DepthState* D2 = static_cast<DepthState*>(h2.data);
      CHECK(D2 && !D2->owner && !D2->md && !D2->dbo && D2->ownerNote.find("another reader") == 0, "7: the second reader does not open or write ES depth");
      dispose(q); mock::current = &h; }
    // 8: faults
    { h.depthThrowAt = 2; h.now += 1; book(h, 7002.0, 40, 50); h.depthThrowAt = 2; tick(p);
      CHECK(D->clockDomOff && D->domFaults == 1 && !D->mdDead, "8: a faulting clock read of the book: clock DOM off, the chart still reads");
      h.depthThrowAt = -1; h.now += 1; const long long s0 = D->snaps; chart(p); CHECK(D->snaps == s0 + 1, "8: the chart's read still snapshots");
      mock::feed.publish(ord(0, 1, 6999.0f, 1, h.now, id++)); mock::feed.throwOnNext = true; tick(p); mock::feed.throwOnNext = false;
      CHECK(D->clockDboOff && D->dboFaults == 1 && !D->dboDead, "8: a faulting clock read of the feed: clock feed reads off, chart reads go on");
      D->lastChartMs = -1; usleep(210 * 1000); p->calc(0); CHECK(D->dboChart >= 2, "8: the chart still drains the feed"); }
    // 9: a pass that faulted half-way leaves busy set: detected after 30 s
    { ReaderState* R = p->userState(); R->busy = true; p->busyAt = time(0) - 31; p->tickAll(); CHECK(!R->busy || p->busyAt >= time(0) - 1, "9: a never-finished pass is detected and the reader carries on"); }
    // 10: a footprint bar whose volume at price never loads (HG 2026-10-09 16:00)
    { mock::fp.clear(); const RTDATE b0 = ct(2026, 10, 9, 15, 58, 0);
      for (int i = 0; i < 6; ++i) { mock::FpBar b; b.t = b0 + 60 * i; b.o = b.h = b.l = b.c = 6.5f; b.vol = 10; b.rows.push_back({6.5f, 5, 5, 10}); b.vapFails = (b.t == ct(2026, 10, 9, 16, 0, 0)); mock::fp.push_back(b); }
      FpState M; M.mkt = "HG"; M.sym = "HGZ6"; M.tick = 0.0005; M.own = true; long long last = (long long)b0 - 1;
      cppExtension::RTBARS bars(PD_INTRA, 1, true, "HGZ6", false, 0, true);
      int wrote = 0; for (int pass = 0; pass < 4; ++pass) wrote += p->writeSlice(M, bars, last, false, 400);
      (void)wrote;
      CHECK(last == (long long)(b0 + 60) && M.err.find("not loaded yet from 2026-10-09 16:00:00") != std::string::npos, "10: tries 1-4: stops at the 16:00 bar (it may still load)");
      wrote += p->writeSlice(M, bars, last, false, 400);
      CHECK(M.skipped == 1 && last == (long long)(b0 + 60 * 4) && M.err.empty(), "10: 5th try: the 16:00 bar is skipped (traced), the cursor moves past it");
      CHECK(rowsIn("HG\\fp_bars.csv") == 4, "10: the 15:58, 15:59, 16:01, 16:02 bars written (the forming 16:03 bar is not)"); }
    dispose(p);
    CHECK(mock::timers().empty() && h.depthObjects == 0 && mock::feed.live == 0, "removing the reader stops its clock and releases book + feed");
    std::printf("IRT Reader host (0.8.0, depth %s): %d passed, %d failed\n", irl::DEPTH_VERSION, passes, fails);
    if (chdir("/") == 0) { std::string cmd = std::string("rm -rf ") + tmp; if (system(cmd.c_str()) != 0) {} }
    return fails ? 1 : 0;
}
