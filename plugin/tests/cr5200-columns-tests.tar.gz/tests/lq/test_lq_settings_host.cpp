// test_lq_settings_host.cpp -- lsLiquidityProfile / lsLiquidityFlow 0.15.1: the Width / Font settings reach every chart of the
// market and survive a restart (saved by OK / Apply to <name>.size-<MKT>.txt, read back by every draw). Build twice:
//   g++ -std=c++17 -Itests_lqp -I. tests_settings/test_lq_settings_host.cpp            (Liquidity Profile)
//   g++ -std=c++17 -DLQ_FLOW -Itests_lqp -I. tests_settings/test_lq_settings_host.cpp  (Liquidity Flow: Font only)
#include "LiquidityProfile.cpp"
#include <cstdio>
#include <cstdlib>
#include <unistd.h>
namespace mock { Host* current = nullptr; Feed feed; }
static int fails = 0, passes = 0;
#define CHECK(c, m) do { if (c) ++passes; else { ++fails; std::printf("FAIL %d %s\n", __LINE__, m); } } while (0)
static std::string readAll(const std::string& p) { std::ifstream f(p.c_str()); std::stringstream s; s << f.rdbuf(); return s.str(); }
static void chart(mock::Host& h, const char* root) {
    h.tick = 0.01f; h.seconds = 180; h.symbol = std::string(root) + "Z26"; h.root = root;
    const unsigned long t0 = (unsigned long)(civilDays(2026, 10, 12) * 86400LL) + 9 * 3600;
    for (int i = 0; i < 6; ++i) { mock::Bar b; b.time = t0 - (5 - i) * 180; b.open = 80.05f; b.high = 80.12f; b.low = 79.98f; b.close = 80.03f; b.rows.push_back(mock::Price(80.03f, 50, 40, 90)); h.bars.push_back(b); }
    h.now = t0;
}
int main() {
    char tmpl[] = "/tmp/lqsXXXXXX"; const char* tmp = mkdtemp(tmpl); setenv("USERPROFILE", tmp, 1);
    const std::string flex = std::string(tmp) + "\\InvestorRT\\rtx\\lsFlexLevels";
#ifdef LQ_FLOW
    const std::string name = "LiquidityFlow";
#else
    const std::string name = "LiquidityProfile";
#endif
    LiquidityProfile* p = static_cast<LiquidityProfile*>(CreateExtension());
    mock::Host a; mock::current = &a; chart(a, "CL"); p->calc(0); p->draw();
    LQState* S = static_cast<LQState*>(a.data);
    CHECK(S && S->width == 60 && S->font == 11, "no file: the defaults 60 px (0.16.0) / 11 pt");
    // the settings window (on chart a): Apply saves for the market
#ifdef LQ_FLOW
    CHECK(WIDTH_INDEX < 0 && FONT_INDEX == 0, "Flow: the window has Font only (row 0)");
    a.parms[0] = 14;
#else
    CHECK(WIDTH_INDEX == 0 && FONT_INDEX == 1, "Profile: Width row 0, Font row 1");
    a.parms[0] = 120; a.parms[1] = 13;
#endif
    p->parmsApply();
    const std::string file = flex + "\\" + name + ".size-CL.txt";
#ifdef LQ_FLOW
    CHECK(readAll(file) == "70,14\n", "Apply writes the market's size file (Flow: width stays 70)");
    CHECK(S && S->font == 14, "the chart follows at once");
#else
    CHECK(readAll(file) == "120,13,0,0,1\n", "Apply writes the market's size file (CR5000: + the label offset 0,0; 0.16.0: + Solid background 1)");
    CHECK(S && S->width == 120 && S->font == 13, "the chart follows at once");
#endif
    // a second CL chart (and a restart: a fresh host) reads the file; it is not lost
    mock::Host b; mock::current = &b; chart(b, "CL"); b.parms[0] = 50; b.parms[1] = 0; p->calc(0); p->draw();
    LQState* T = static_cast<LQState*>(b.data);
#ifdef LQ_FLOW
    CHECK(T && T->font == 14, "another CL chart / a restart gets the saved font");
#else
    CHECK(T && T->width == 120 && T->font == 13, "another CL chart / a restart gets the saved width and font");
#endif
    // another market keeps its own (none: the defaults)
    mock::Host c; mock::current = &c; chart(c, "ES"); p->calc(0); p->draw();
    LQState* U = static_cast<LQState*>(c.data);
    CHECK(U && U->width == 60 && U->font == 11, "ES keeps the defaults (per market)");
    // garbage and out-of-range values in the file are refused: the last good size stays
    mock::current = &b;
    usleep(1100000); { std::ofstream f(file.c_str(), std::ios::trunc); f << "9999,1\n"; } p->draw();
#ifdef LQ_FLOW
    CHECK(T && T->font == 14, "out-of-range file refused");
#else
    CHECK(T && T->width == 120 && T->font == 13, "out-of-range file refused");
#endif
    usleep(1100000); { std::ofstream f(file.c_str(), std::ios::trunc); f << "200,12\n"; } p->draw();
    CHECK(T && T->font == 12, "a new good file is followed without a restart");
#ifndef LQ_FLOW
    CHECK(T && T->width == 200, "width followed too");
#endif
    // the window's garbage is clamped, never saved raw
    mock::current = &a;
#ifdef LQ_FLOW
    a.parms[0] = 0;
#else
    a.parms[0] = 5; a.parms[1] = 99;
#endif
    p->parmsApply();
    { const std::string t = readAll(file); std::printf("  clamped file: %s", t.c_str());
#ifdef LQ_FLOW
      CHECK(t == "70,11\n", "font 0 -> the 11 pt default");
#else
      CHECK(t == "60,16,0,0,1\n", "width 5 -> the 60 px default (0.16.0), font 99 -> the 16 pt cap");
#endif
    }
#ifndef LQ_FLOW
    {   // (CR5000) the LIQ label Offset X / Y: dialog -> Apply -> file -> restart -> draw; old "w,f" files; garbage never saved / applied
        auto hdr = [&](mock::Host& hh) -> const mock::Draw* { for (auto& d : hh.draws) if (d.type == "text" && d.text.find("LIQ") == 0) return &d; return nullptr; };
        b.barW = 40;                                                       // a wider chart: room right of the label up to the last bar
        mock::current = &b; usleep(1100000); { std::ofstream f(file.c_str(), std::ios::trunc); f << "120,13\n"; } b.draws.clear(); p->draw();
        const mock::Draw* h0 = hdr(b); const int x0 = h0 ? h0->l : -1, y0 = h0 ? h0->t : -1;
        CHECK(h0 && T->labDx == 0 && T->labDy == 0 && T->width == 120, "an old 0.15.1 file \"120,13\": loads, no offset");
        // the settings window (no bar size): filled from the file, then he sets Offset X 40 / Y 25
        b.period = ""; b.parms[0] = 50; b.parms[1] = 0; b.parms[2] = 7; b.parms[3] = 7; p->parmsLoad();
        CHECK(b.parms[0] == 120 && b.parms[1] == 13 && b.parms[2] == 0 && b.parms[3] == 0, "the dialog opens filled from the file (120, 13, 0, 0)");
        b.parms[2] = 40; b.parms[3] = 25; p->parmsApply(); b.period = "3 min";
        CHECK(readAll(file) == "120,13,40,25,1\n", ("Apply: the file holds the offsets: " + readAll(file)).c_str());
        // restart: a fresh host (IRT reopened) reads the file and draws the label at the offset
        mock::Host r; r.barW = 40; mock::current = &r; chart(r, "CL"); p->calc(0); p->draw(); LQState* R = static_cast<LQState*>(r.data);
        const mock::Draw* h1 = hdr(r);
        CHECK(R && R->labDx == 40 && R->labDy == 25 && h1 && h1->l == x0 + 40 && h1->t == y0 + 25, ("after a restart the LIQ label is drawn 40 right / 25 down: " + std::to_string(h1 ? h1->l : -1) + "," + std::to_string(h1 ? h1->t : -1)).c_str());
        { std::ofstream f(file.c_str(), std::ios::trunc); f << "120,13,40,25\n"; }
        r.parms[0] = 120; r.parms[1] = 13; r.parms[2] = 40; r.parms[3] = 25; p->parmsLoad();
        const int before2 = r.parms[2]; p->parmsApply(); r.period = "3 min";
        CHECK(before2 == 40 && readAll(file) == "120,13,40,25,1\n", "OK without touching anything: unchanged");
        // garbage from the dialog never reaches the file; garbage in the file is refused (0,0 + the reason on the status)
        int bad = 0; const int IV[] = { -2147483647, -601, -600, 0, 600, 601, 2147483647 };
        for (int i = 0; i < 200; ++i) { r.period = ""; p->parmsLoad(); r.parms[2] = IV[i % 7]; r.parms[3] = IV[(i * 3) % 7]; p->parmsApply(); r.period = "3 min";
            const std::string t = readAll(file); int x = 0, y = 0; char tail[8] = {0};
            if (std::sscanf(t.c_str(), "%*d,%*d,%d,%d%7s", &x, &y, tail) < 2 || x < -600 || x > 600 || y < -600 || y > 600) ++bad; }
        CHECK(bad == 0, "200 dialog Applies with out-of-range offsets: the file always holds -600..600");
        const char* G[] = { "120,13,nan,5", "120,13,601,0", "120,13,1e3,0", "120,13,-0x5,1", "120,13,5", "120,13,5,5,5", "abc", "", "120,13,,", "120,13,-600,600" };
        int applied = 0;
        for (int i = 0; i < 10; ++i) { usleep(1100000); { std::ofstream f(file.c_str(), std::ios::trunc); f << G[i] << "\n"; } r.draws.clear(); p->draw();
            if (i < 9 && (R->labDx != 0 || R->labDy != 0) && !(i >= 4 && i <= 8 && R->labDx == -600)) ++applied; }
        CHECK(applied == 0 && R->labDx == -600 && R->labDy == 600, "garbage label offsets in the file never applied (NaN, 601, 1e3, hex, short / long lines); -600 / 600 accepted");
        r.draws.clear(); p->draw(); const mock::Draw* h2 = hdr(r);
        CHECK(h2 && h2->l >= r.paneLeft && h2->t >= r.paneTop + LQ_TITLE_ROW_PX && h2->b <= r.paneBottom, "extreme offsets: the label stays inside the pane, below the title row");
        { std::ofstream f(file.c_str(), std::ios::trunc); f << "120,13,40,25\n"; }
        // two charts of the same market: both follow the per-market offset, each inside its own pane
        mock::Host s2; s2.barW = 40; s2.paneRight = 900; s2.scaleLeft = 880; s2.paneBottom = 500; mock::current = &s2; chart(s2, "CL"); usleep(1100000); p->calc(0); p->draw(); LQState* S2 = static_cast<LQState*>(s2.data);
        mock::current = &r; r.draws.clear(); p->draw();
        CHECK(S2 && S2->labDx == 40 && S2->labDy == 25 && R->labDx == 40 && hdr(s2) && hdr(r) && hdr(s2)->l == hdr(r)->l, "two CL charts: both use the market's label offset");
        mock::current = &s2; p->destroy(); mock::current = &r; p->destroy();
    }
#endif
    mock::current = &a; p->destroy(); mock::current = &b; p->destroy(); mock::current = &c; p->destroy();
    (void)p;                                   // the one DLL object lives for the process, as in IRT
    std::string cmd = std::string("rm -rf ") + tmp; if (std::system(cmd.c_str())) {}
    std::printf("%s size settings: %d passed, %d failed\n", name.c_str(), passes, fails);
    return fails ? 1 : 0;
}
