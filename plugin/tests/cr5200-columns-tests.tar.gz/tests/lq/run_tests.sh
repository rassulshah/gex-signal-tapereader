#!/bin/sh
# Liquidity Profile 0.15.3 test run (ASan/UBSan): logic, hover logic, hover-params, profile / flow / hover host, size (profile + flow),
# MinGW syntax check against the real SDK, Win32 library check. Binaries removed after each run (disk is tight).
D=${D:-$(cd "$(dirname "$0")" && pwd)}
B=${BUILD:-$D/../bld/$(basename $D)}; SDK=${SDK:-/mnt/user-data/uploads/sdk/c++/include}
mkdir -p "$B"; touch "$B/.stamp"
cleanup() { find /tmp -maxdepth 1 \( -name "lqh*" -o -name "lqp*" -o -name "lqf*" -o -name "lqs*" \) -newer "$B/.stamp" -exec rm -rf {} + 2>/dev/null; rm -f "$B"/t_* "$B"/w32-*; }
trap cleanup EXIT
SAN="-fsanitize=address,undefined -fno-sanitize-recover=undefined"
CXX="g++ -std=c++17 -g -Wall -Wextra $SAN"
TW="-Wno-misleading-indentation -Wno-parentheses"
step() { echo "== $1" >&2; shift; "$@" || { echo "FAILED: $*"; exit 1; }; }
run() { N=$1; shift; export LQ_HP_FIX="$D/hp_fixtures"; step "$N build" $CXX "$@" -o "$B/t_$N"; ( cd "$B" && env LSAN_OPTIONS=suppressions="$D/lsan.supp" ./t_$N > "$B/$N.out" 2>&1 ); r=$?; tail -2 "$B/$N.out"; rm -f "$B/t_$N"; [ $r = 0 ] || { tail -30 "$B/$N.out"; echo "FAILED: $N"; exit 1; }; }
run logic -Werror -I"$D" "$D/test_liquidityprofile_logic.cpp"
run hoverlogic -Werror -I"$D" "$D/test_liquidityhover_logic.cpp"
[ -f "$D/test_liquidityhoverparams_logic.cpp" ] && run hoverparams -Werror -I"$D" "$D/test_liquidityhoverparams_logic.cpp"
run profilehost -O1 $TW -I"$D/mock" -I"$D" "$D/test_liquidityprofile_host.cpp"
run flowhost -O1 $TW -I"$D/mock" -I"$D" "$D/test_liquidityflow_host.cpp"
run hoverhost -O1 $TW -I"$D/mock" -I"$D" "$D/test_liquidityhover_host.cpp"
run columns -O1 $TW -I"$D/mock" -I"$D" "$D/test_lq_columns_host.cpp"
run sizeprofile -O1 $TW -I"$D/mock" -I"$D" "$D/test_lq_settings_host.cpp"
run sizeflow -O1 $TW -DLQ_FLOW -I"$D/mock" -I"$D" "$D/test_lq_settings_host.cpp"
for N in LiquidityProfile LiquidityFlow; do
  x86_64-w64-mingw32-g++ -std=c++17 -fsyntax-only -Wall -Wextra -Wno-unknown-pragmas -I"$SDK" -I"$D" "$D/wrap_$N.cpp" > "$B/syntax-$N.log" 2>&1
  E=$(grep -c ' error' "$B/syntax-$N.log"); W=$(grep 'warning' "$B/syntax-$N.log" | grep -vc "$SDK")
  echo "syntax $N: $E errors, $W warnings outside the SDK"; [ "$E" = 0 ] && [ "$W" = 0 ] || { head -20 "$B/syntax-$N.log"; exit 1; }
  x86_64-w64-mingw32-g++ -std=c++17 -c -O0 -I"$SDK" -I"$D" "$D/wrap_$N.cpp" -o "$B/w32-$N.o" 2>/dev/null || { echo "win32 $N: compile failed"; exit 1; }
  x86_64-w64-mingw32-g++ -std=c++17 -E -D_MSC_VER=1930 -I"$SDK" -I"$D" "$D/wrap_$N.cpp" 2>/dev/null > "$B/w32-$N.i"
  imps=$(x86_64-w64-mingw32-nm -u "$B/w32-$N.o" | grep "__imp_" | sed 's/.*__imp_//' | grep -E '^[A-Z]' | sort -u | tr '\n' ' ')
  for f in GetCursorPos WindowFromPoint ScreenToClient GetAsyncKeyState MessageBoxA GetClientRect; do
    case " $imps " in *" $f "*) grep -q 'pragma comment(lib, "user32.lib")' "$B/w32-$N.i" || { echo "win32 $N: user32 pragma missing for $f"; exit 1; };; esac
  done
  echo "win32 $N: ok ($imps)"; rm -f "$B/w32-$N.o" "$B/w32-$N.i"
done
echo "ALL LIQUIDITY SUITES PASSED"
