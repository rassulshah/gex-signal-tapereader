"""render_cols.py -- draws lsDealerProfile 2.11.0's OWN draw calls (test_dealerprofile_2110 liquidity scene, real ES files 13 Oct
2:57 PM CT, a Delta Profile on the board) into a PNG: Levels | Delta (outline: drawn by lsDeltaProfile) | Dealer columns."""
import sys
from PIL import Image, ImageDraw, ImageFont
S = 1; FD = '/usr/share/fonts/truetype/liberation/'
def font(pt, bold=False): return ImageFont.truetype(FD + ('LiberationSans-Bold.ttf' if bold else 'LiberationSans-Regular.ttf'), round(pt * 4 / 3))
def rgb(h): v = int(h, 16); return ((v >> 16) & 255, (v >> 8) & 255, v & 255)
rows = [l.rstrip('\n').split('|') for l in open(sys.argv[1], encoding='cp1252')]
pane = [r for r in rows if r[0] == 'pane'][0]; PW, PH, SR = int(pane[3]), int(pane[4]), int(pane[5])
TOP = 30
img = Image.new('RGB', (SR + 10, PH + TOP + 10), (0, 0, 0)); d = ImageDraw.Draw(img)
P = lambda x, y: (x, y + TOP)
d.text((6, 6), 'lsDealerProfile 2.11.0 render check: its own draw calls (mock host, ES 13 Oct 2:57 PM CT, liquidity file on CR0 / HVL / PS0)', font=font(10, True), fill=(255, 255, 255))
for r in rows:
    if r[0] == 'tick': y = int(r[1]); d.line([P(0, y), P(PW, y)], fill=(25, 28, 36)); d.text(P(PW + 4, y - 7), r[2], font=font(8), fill=(156, 163, 175))
for r in rows:
    if r[0] == 'bar':
        x, o, h, l, c = map(int, r[1:6]); col = (34, 197, 94) if c <= o else (239, 68, 68)
        d.line([P(x, h), P(x, l)], fill=col); d.rectangle([P(x - 1, min(o, c)), P(x + 1, max(o, c))], fill=col)
cols = [r for r in rows if r[0] == 'cols'][0]; pr, ll, lr, dl, dr, gl, gr = map(int, cols[1:])
d.rectangle([P(dl, 0), P(dr - 1, PH - 1)], outline=(80, 80, 80)); d.text(P(dl + 6, PH - 20), 'Delta 80', font=font(8), fill=(120, 120, 120))
d.line([P(pr, 0), P(pr, PH)], fill=(60, 60, 60)); d.text(P(pr - 70, PH - 20), 'price ends', font=font(8), fill=(120, 120, 120))
for r in rows:
    k = r[0]
    if k == 'line':
        l, t, rr, b = map(int, r[1:5]); d.line([P(l, t), P(rr, b)], fill=rgb(r[5]), width=max(1, int(r[6])))
    elif k in ('box', 'rbox'):
        l, t, rr, b = map(int, r[1:5]); d.rectangle([P(l, t), P(rr - 1, b - 1)], fill=rgb(r[5]))
    elif k == 'text':
        l, t, rr, b = map(int, r[1:5]); txt = '|'.join(r[8:]); pt = int(r[6]); bold = r[7] == '1'
        d.text(P(l, (t + b) / 2 + pt * 0.45), txt, font=font(pt, bold), fill=rgb(r[5]), anchor='lm')   # the plugin lifts the rect 0.45 x pt (IRT draws text low): undo it, as render_check.py
img.save(sys.argv[2])
