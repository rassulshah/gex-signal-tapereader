#!/bin/bash
# usage: run.sh <tree> [names...]
T=$1; shift; cd $T/plugin/tests_delta; mkdir -p ../../bin ../../scratch
for n in "$@"; do
 g++ -std=c++14 -O1 -g -I. -fsanitize=address,undefined -fno-omit-frame-pointer $n.cpp -o ../../bin/$n > ../../bin/$n.build.log 2>&1 || { echo "$n BUILD FAIL"; tail -20 ../../bin/$n.build.log; continue; }
 rm -rf ../../scratch/$n; mkdir -p ../../scratch/$n
 DP254_RUN=$PWD/../../scratch/$n USERPROFILE=$PWD/../../scratch/$n ASAN_OPTIONS=detect_leaks=0 UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1 timeout 300 ../../bin/$n > ../../bin/$n.run.log 2>&1; echo "$n exit=$? :: $(tail -2 ../../bin/$n.run.log | tr '\n' ' ')"
done
