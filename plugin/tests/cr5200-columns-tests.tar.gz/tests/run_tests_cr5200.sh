#!/bin/bash
# run_tests_cr5200.sh -- CR5200 (right-side columns): every suite of the three changed plugins, Linux g++ ASan/UBSan, MinGW syntax against
# the real Investor/RT SDK, Win32 import / pragma check. W = the plugin tree (DealerProfile.cpp ...), LQ = the Liquidity test dir.
W=${W:-/home/claude/aud/cr5200/work}; LQ=${LQ:-/home/claude/aud/cr5200/lq}; SDK=${SDK:-/mnt/user-data/uploads/sdk/c++/include}
B=${B:-/home/claude/aud/cr5200/bin}; mkdir -p $B/dp $B/lq; fail=0
echo "== Dealer Profile 2.11.0 (+ ColumnBoard 1.0.0 / DealerColumnsLogic 1.0.0)"
g++ -std=c++17 -g -Wall -Wextra -Werror -Wno-misleading-indentation -fsanitize=address,undefined -fno-sanitize-recover=undefined -I$W $W/test_columnboard_logic.cpp -o $B/t_cb && (cd $W && $B/t_cb | tail -1) || fail=1; rm -f $B/t_cb
g++ -std=c++17 -g -fsanitize=address,undefined -fno-sanitize-recover=undefined -I$SDK -I$W $W/test_dealerprofile_2110.cpp -Wl,--unresolved-symbols=ignore-all -o $B/t_2110 && (cd $W && $B/t_2110 | tail -1) || fail=1; rm -f $B/t_2110
P=$W B=$B/dp SDK=$SDK bash /home/claude/aud/cr5200/run_dp_tests.sh || fail=1
echo "== Delta Profile 2.8.0"
for n in core_tests adapter_tests test_exh270 test_rule262 test_record_254 test_sync260 test_session_noon test_audit_257 test_offscreen271 test_contract263 test_columns280; do
  bash /home/claude/aud/dp270/out/run_tests.sh /home/claude/aud/cr5200/tree $n 2>&1 | grep -v "^/home\|Aborted" | tail -1
  done
for n in core_tests adapter_tests test_exh270 test_rule262 test_record_254 test_sync260 test_session_noon test_audit_257 test_offscreen271 test_contract263 test_columns280; do
  tail -1 /home/claude/aud/cr5200/bin/$n.run.log | grep -Eq "0 failed|58 checks passed|10 passed, 0 failed" || { echo "FAIL $n"; fail=1; }; done
echo "== Liquidity Profile 0.16.0 / Liquidity Flow"
for f in LiquidityProfile.cpp LiquidityProfileLogic.h ColumnBoard.h BoxPlace.h BannerBoard.h DealerColumnsLogic.h DealerProfileAuditLogic.h DealerLogic.h; do cp $W/$f $LQ/; done
D=$LQ BUILD=$B/lq SDK=$SDK sh $LQ/run_tests.sh 2>&1 | grep -v "^==" | tail -4 || fail=1
for f in $B/lq/*.out; do echo "  $(basename $f .out): $(tail -1 $f)"; done
echo "== MinGW syntax against the real SDK + Win32 libraries"
printf '#define NOMINMAX\n#include <windows.h>\n#include "DeltaProfile.cpp"\n' > $W/wrap_DeltaProfile.cpp
for N in DealerProfile DeltaProfile; do
  EXTRA=""; [ $N = DeltaProfile ] && EXTRA="-DDELTA_WINDOWS_SDK_CHECK"
  x86_64-w64-mingw32-g++ -std=c++17 -fsyntax-only -Wall -Wextra -Wno-unknown-pragmas $EXTRA -I$SDK -I$W $W/wrap_$N.cpp > $B/syntax-$N.log 2>&1
  E=$(grep -c ' error' $B/syntax-$N.log); Wn=$(grep 'warning' $B/syntax-$N.log | grep -vc "irtsdk.h")
  echo "syntax $N: $E errors, $Wn warnings outside the SDK"; [ "$E" = 0 ] && [ "$Wn" = 0 ] || fail=1
  x86_64-w64-mingw32-g++ -std=c++17 -c -O0 $EXTRA -I$SDK -I$W $W/wrap_$N.cpp -o $B/w32-$N.o 2>/dev/null || { echo "win32 $N: compile failed"; fail=1; continue; }
  x86_64-w64-mingw32-g++ -std=c++17 -E -D_MSC_VER=1930 $EXTRA -I$SDK -I$W $W/wrap_$N.cpp 2>/dev/null > $B/w32-$N.i
  imps=$(x86_64-w64-mingw32-nm -u $B/w32-$N.o | grep "__imp_" | sed 's/.*__imp_//' | grep -E '^[A-Z]' | sort -u | tr '\n' ' ')
  for f in GetCursorPos WindowFromPoint ScreenToClient GetAsyncKeyState MessageBoxA GetClientRect; do
    case " $imps " in *" $f "*) grep -q 'pragma comment(lib, "user32.lib")' $B/w32-$N.i || { echo "win32 $N: user32 pragma missing for $f"; fail=1; };; esac
  done
  echo "win32 $N: ok ($imps)"; rm -f $B/w32-$N.o $B/w32-$N.i
done
[ $fail = 0 ] && echo "ALL CR5200 SUITES PASSED" || echo "SOME SUITES FAILED"
exit $fail
