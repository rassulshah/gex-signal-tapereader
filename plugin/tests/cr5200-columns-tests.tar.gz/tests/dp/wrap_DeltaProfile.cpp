#define NOMINMAX
#include <windows.h>
#include "DeltaProfile.cpp"
