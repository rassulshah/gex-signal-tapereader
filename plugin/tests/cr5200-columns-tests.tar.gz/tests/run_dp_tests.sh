#!/bin/bash
# run_tests.sh -- Dealer Profile suites (Linux g++ + ASan/UBSan), MinGW syntax with the real SDK, Win32 import-lib check
P=${P:-/home/claude/aud/cr5200/work}; B=${B:-/home/claude/aud/cr5200/bin/dp}; SDK=${SDK:-/mnt/user-data/uploads/sdk/c++/include}
SAN="-g -fsanitize=address,undefined -fno-sanitize-recover=undefined"
mkdir -p $B; fail=0; cd $P
run() { n=$1; shift; if g++ "$@" -o $B/$n 2>$B/$n.build.log; then if ASAN_OPTIONS=detect_leaks=1 $B/$n >$B/$n.run.log 2>&1; then echo "PASS $n: $(grep -Eio '[0-9]+ (passed|pass|ok)[^,]*|[0-9]+/[0-9]+[^ ]*|failures?[: =]+[0-9]+' $B/$n.run.log | tail -1)"; else echo "FAIL $n (run)"; tail -5 $B/$n.run.log; fail=1; fi; else echo "FAIL $n (build)"; head -20 $B/$n.build.log; fail=1; fi; rm -f $B/$n; }   # (disk) binaries removed after the run
run test_dealer_logic          -std=c++14 $SAN -I. test_dealer_logic.cpp
run test_dealerprofile_274     -std=c++17 -Wall -Wextra -Werror $SAN -I. test_dealerprofile_274.cpp
run test_dealerprofile_labels  -std=c++17 -Wall -Wextra $SAN -I. test_dealerprofile_labels.cpp
run test_dealerprofile_regression -std=c++14 -Wall -Wextra -Werror -pedantic $SAN -I. test_dealerprofile_regression.cpp
run test_keylevels_logic       -std=c++17 $SAN -I. test_keylevels_logic.cpp
run test_dealerprofile_host274 -std=c++17 $SAN -I$SDK -I. test_dealerprofile_host274.cpp -Wl,--unresolved-symbols=ignore-all
run test_dealerprofile_klc_twochart -std=c++17 $SAN -DRA1009_PATCHED -I$SDK -I. test_dealerprofile_klc_twochart.cpp -Wl,--unresolved-symbols=ignore-all
for t in $P/test_dealerprofile_290*.cpp; do [ -f "$t" ] || continue; n=$(basename $t .cpp)
  if grep -q irtsdk_host $t; then run $n -std=c++17 $SAN -I$SDK -I. $(basename $t) -Wl,--unresolved-symbols=ignore-all; else run $n -std=c++17 -Wall -Wextra $SAN -I. $(basename $t); fi; done
exit $fail
